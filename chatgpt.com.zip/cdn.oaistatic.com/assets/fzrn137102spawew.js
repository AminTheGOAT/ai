function e() {
    return e = Object.assign ? Object.assign.bind() : function(t) {
        for (var n = 1; n < arguments.length; n++) {
            var r = arguments[n];
            for (var a in r)({}).hasOwnProperty.call(r, a) && (t[a] = r[a])
        }
        return t
    }, e.apply(null, arguments)
}
export {
    e as _
};
//# sourceMappingURL=fzrn137102spawew.js.map