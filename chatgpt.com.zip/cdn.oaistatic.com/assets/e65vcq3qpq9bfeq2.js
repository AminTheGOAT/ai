const __vite__mapDeps = (i, m = __vite__mapDeps, d = (m.f || (m.f = ["assets/k4qvr2xancusigzk.js", "assets/hbhpmx2ipkndwudc.js", "assets/mgr0w69u3c317psp.js", "assets/root-ncdra6h0.css", "assets/ab2oz9enzsoo3wow.js", "assets/conversation-small-h7jqffb1.css", "assets/m0s651bq7jimn9ko.js", "assets/i77hfpek3e927jy9.js", "assets/ea44kbra0vpz5pj1.js"]))) => i.map(i => d[i]);
import {
    G as y,
    H as Q,
    r as d,
    c3 as Vt,
    m as e,
    df as R,
    c9 as L,
    aR as o,
    s as Ge,
    L as P,
    c5 as He,
    t as Ve,
    dt as so,
    dr as pt,
    bV as Ue,
    bW as We,
    aL as le,
    ba as qs,
    aX as K,
    F,
    a$ as ws,
    D as Se,
    dF as to,
    Z as ge,
    aE as ss,
    aD as we,
    P as w,
    d as A,
    aj as de,
    dP as se,
    n as Qs,
    S as ne,
    bZ as Xe,
    b_ as bs,
    c as ao,
    aJ as ue,
    hG as oo,
    bf as Ts,
    a3 as as,
    aQ as ys,
    bH as no,
    dj as Gs,
    gD as Xs,
    a2 as Kt,
    f3 as io,
    eN as Re,
    ei as $,
    a4 as lo,
    aM as ro,
    a_ as As,
    cd as co,
    u as Js,
    hH as uo,
    g4 as Ze,
    g5 as xt,
    hI as zt,
    bX as rs,
    bY as cs,
    dp as Hs,
    dq as Vs,
    hJ as go,
    bS as je,
    al as mo,
    w as Es,
    cD as fo,
    b0 as po,
    b1 as Ms,
    q as ve,
    de as Zs,
    dd as ts,
    eS as xo,
    br as ho,
    dc as Yt,
    dg as js,
    eL as bo,
    hK as ht,
    hL as Mo,
    du as yo,
    aH as jo,
    aI as vo
} from "./hbhpmx2ipkndwudc.js";
import {
    b2 as et,
    U as J,
    bD as Co,
    az as vs,
    bH as Be,
    ai as $t,
    bS as Ks,
    l as ie,
    k as Cs,
    hm as ko,
    kp as So,
    kq as wo,
    eF as ks,
    kr as To,
    cl as st,
    ks as zs,
    kt as tt,
    ku as qt,
    kv as Ie,
    kw as Ao,
    kx as Eo,
    ky as No,
    bC as Ys,
    kz as Qt,
    ay as Xt,
    kA as _o,
    kB as Po,
    bT as Lo,
    kC as Do,
    i9 as ee,
    c8 as Io,
    ia as Fo,
    ib as bt,
    ic as Bo,
    id as Oo,
    ig as Uo,
    bE as Wo,
    ih as Ro,
    ii as Mt,
    dz as Go,
    cp as E,
    kD as Ho,
    kE as Jt,
    kF as Zt,
    kG as Vo,
    kH as Ko,
    kI as ea,
    c7 as Ns,
    kJ as zo,
    iS as sa,
    kK as b,
    cg as ta,
    kL as ae,
    kM as Yo,
    h as ds,
    es as at,
    c2 as $o,
    c4 as qo,
    dA as os,
    cn as H,
    kN as Qo,
    kO as Xo,
    kP as Os,
    n as aa,
    c6 as O,
    kQ as Jo,
    kR as Zo,
    bL as en,
    bK as oa,
    hT as sn,
    kS as tn,
    jN as an,
    kT as on,
    kU as nn,
    jP as ln,
    iO as rn,
    iQ as cn,
    kV as na,
    aD as _s,
    cz as dn,
    bI as es,
    kW as un,
    dG as gn,
    kX as ia,
    hJ as mn,
    cS as fn,
    cT as pn,
    cm as Ae,
    co as Ce,
    kY as xn,
    il as yt,
    aF as hn,
    kZ as bn,
    hL as Mn
} from "./ab2oz9enzsoo3wow.js";
import {
    N as yn,
    r as jn,
    bO as la,
    bd as vn,
    aC as ra,
    b as ca,
    bP as Cn,
    bQ as kn,
    i as Sn,
    a6 as wn,
    _ as da,
    bR as Tn,
    e as ua,
    c as ga,
    ap as $s,
    am as An,
    an as En,
    al as Nn,
    bS as _n,
    F as ma,
    bC as Pn,
    E as fa,
    j as Ln,
    aS as Dn,
    bj as In,
    n as Fn,
    L as Bn,
    aW as On,
    aV as Un,
    aj as Wn,
    bT as Rn,
    C as Gn,
    aF as Hn,
    b7 as Vn,
    b9 as Kn,
    y as zn
} from "./mgr0w69u3c317psp.js";
import {
    R as Yn,
    I as $n
} from "./cmx2y9rq24lt8yit.js";
import {
    m as ot
} from "./m0s651bq7jimn9ko.js";
import {
    P as q,
    p as C,
    u as nt
} from "./nkwwlocwcrrxhxrr.js";
import {
    a as qn,
    c as Qn
} from "./fq4mdsrkbytz6b3u.js";
import {
    c as Xn
} from "./iej0cupg2dqkmejt.js";
import {
    A as it
} from "./igfqndo0r4tiklfi.js";
import {
    S as jt
} from "./k4r03ntvwl7kqhar.js";
import {
    B as Jn,
    S as pe
} from "./mco6ffvkuw2vrlq8.js";
import {
    H as pa,
    M as Zn
} from "./g4tl5lt9yqf20m4s.js";
import {
    j as ei
} from "./jk8w36bsokizpx57.js";
import {
    M as si,
    a as ti,
    R as ai
} from "./i0y9mtk4ga1n6rdp.js";
import "./c4bxzbp1808foto4.js";

function oi(s) {
    return Ge({
        queryKey: ["workspace", s, "owner_count"],
        queryFn: async () => await P.getWorkspaceOwnerCount(s)
    })
}

function ni({
    workspace: s
}) {
    const t = y(),
        a = Q(),
        n = et(),
        [i, l] = d.useState(""),
        r = s.isOwnerOfAccount(),
        u = oi(s.id),
        {
            data: c
        } = Vt(),
        [g, m] = d.useState(!1),
        [p, f] = d.useState(!1);
    if (!c) return null;
    const j = c.accountItems.find(T => T.id != s.id),
        M = () => {
            J.setLeaveWorkspaceData(null)
        },
        k = async () => {
            if (n != null) {
                f(!0);
                try {
                    await P.removeWorkspaceUser(s.id, n.id), m(!0)
                } catch {
                    a.danger(t.formatMessage({
                        id: "leaveWorkspaceModal.leaveFailed",
                        defaultMessage: "Failed to leave workspace"
                    }))
                }
                f(!1)
            }
        };
    if (g) return e.jsx(ri, {
        workspace: s,
        fallbackWorkspace: j,
        onClose: M
    });
    if (!u.data) return e.jsx(ii, {
        onClose: M
    });
    const B = u.data.total_count,
        D = u.data.owner_count;
    if (r && D < 2) return e.jsx(li, {
        workspace: s,
        onClose: M
    });
    const U = e.jsx(R.Button, {
            onClick: () => {
                J.setLeaveWorkspaceData(null)
            },
            title: t.formatMessage({
                id: "leaveWorkspaceModal.cancel",
                defaultMessage: "Cancel"
            })
        }),
        I = e.jsx(R.Button, {
            color: "danger",
            disabled: n == null || p || i == "" || i.toLowerCase() != n ? .email.toLowerCase(),
            title: t.formatMessage({
                id: "leaveWorkspaceModal.leaveButton",
                defaultMessage: "Leave workspace"
            }),
            onClick: () => {
                k()
            }
        });
    return e.jsx(L, {
        isOpen: !0,
        onClose: M,
        showCloseButton: !0,
        type: "danger",
        title: t.formatMessage({
            id: "leaveWorkspaceModal.leaveWorkspace",
            defaultMessage: "Leave the {workspaceName} workspace"
        }, {
            workspaceName: s.data.name
        }),
        primaryButton: I,
        secondaryButton: U,
        children: e.jsxs("div", {
            className: "flex flex-col gap-5",
            children: [e.jsxs("div", {
                className: "flex flex-row gap-3",
                children: [e.jsx(Co, {
                    size: "large",
                    src: s.data.profilePictureUrl
                }), e.jsxs("div", {
                    className: "flex flex-col justify-around",
                    children: [e.jsx("div", {
                        className: "text-base font-semibold",
                        children: s.data.name
                    }), e.jsx("div", {
                        className: "text-sm text-token-text-tertiary",
                        children: e.jsx(o, {
                            id: "leaveWorkspaceModal.memberCount",
                            defaultMessage: `{memberCount, plural,
                  one {1 member}
                  other {{memberCount} members}
                }`,
                            values: {
                                memberCount: B
                            }
                        })
                    })]
                })]
            }), e.jsxs("div", {
                children: [e.jsx("h3", {
                    className: "mb-2 text-base font-semibold",
                    children: e.jsx(o, {
                        id: "leaveWorkspaceModal.leaveAreYouSure",
                        defaultMessage: "Are you sure?"
                    })
                }), e.jsxs("ul", {
                    className: "ml-3 list-disc text-sm text-token-text-secondary",
                    children: [e.jsx("li", {
                        className: "mb-2",
                        children: e.jsx(o, {
                            id: "leaveWorkspaceModal.leaveWorkspaceWarning1",
                            defaultMessage: "This will remove you from your workspace and you won't be able to access all data, including profile, settings, and chat history."
                        })
                    }), e.jsx("li", {
                        children: e.jsx(o, {
                            id: "leaveWorkspaceModal.leaveWorkspaceWarning2",
                            defaultMessage: "You will lose access to all channels and messages in this workspace."
                        })
                    })]
                })]
            }), e.jsxs("div", {
                children: [e.jsx("h3", {
                    className: "mb-2 text-base",
                    children: e.jsx(o, {
                        id: "leaveWorkspaceModal.enterYourEmail",
                        defaultMessage: "Enter your email address to confirm"
                    })
                }), e.jsx(vs, {
                    name: "typeEmailConfirm",
                    value: i,
                    onChange: T => {
                        l(T.target.value)
                    }
                })]
            })]
        })
    })
}

function ii({
    onClose: s
}) {
    return e.jsx(L, {
        isOpen: !0,
        onClose: s,
        showCloseButton: !0,
        type: "warning",
        children: e.jsx("div", {
            className: "flex flex-row justify-center",
            children: e.jsx(He, {})
        })
    })
}

function li({
    workspace: s,
    onClose: t
}) {
    const a = y(),
        n = e.jsx(R.Button, {
            onClick: () => {
                J.setLeaveWorkspaceData(null)
            },
            title: a.formatMessage({
                id: "leaveWorkspaceModal.ok",
                defaultMessage: "OK"
            })
        });
    return e.jsx(L, {
        isOpen: !0,
        onClose: t,
        showCloseButton: !0,
        type: "danger",
        title: a.formatMessage({
            id: "leaveWorkspaceModal.cantLeaveWorkspace",
            defaultMessage: "Couldn't leave the {workspaceName} workspace"
        }, {
            workspaceName: s.data.name
        }),
        secondaryButton: n,
        children: e.jsx(o, {
            id: "leaveWorkspaceModal.lastOwnerWarning",
            defaultMessage: "Because you're the only owner in the {workspaceName} workspace, assign the owner role to another member before leaving.",
            values: {
                workspaceName: s.data.name
            }
        })
    })
}

function ri({
    workspace: s,
    fallbackWorkspace: t,
    onClose: a
}) {
    const n = Ve(),
        i = y(),
        l = Q(),
        r = Be(m => m.currentWorkspace),
        u = $t(),
        c = () => {
            if (t != null && r)
                if (J.setLeaveWorkspaceData(null), r.id == s.id) {
                    const {
                        willRedirect: m
                    } = so(n, t.id, u, i, l);
                    m || pt()
                } else n.invalidateQueries({
                    queryKey: ["account-status"]
                });
            else J.setLeaveWorkspaceData(null), Ue.deleteCookie(We.Workspace), Ue.deleteCookie(We.WorkspaceResidencyRegion), pt();
            a()
        },
        g = t != null ? e.jsx(R.Button, {
            color: "primary",
            onClick: c,
            title: i.formatMessage({
                id: "leaveWorkspaceModal.done",
                defaultMessage: "Done"
            })
        }) : e.jsx(R.Button, {
            color: "primary",
            onClick: c,
            title: i.formatMessage({
                id: "leaveWorkspaceModal.startPersonalAccount",
                defaultMessage: "Start using ChatGPT for free"
            })
        });
    return e.jsx(L, {
        isOpen: !0,
        onClose: c,
        primaryButton: g,
        type: "success",
        title: i.formatMessage({
            id: "leaveWorkspaceModal.leftWorkspaceTitle",
            defaultMessage: "Successfully left the {workspaceName} workspace"
        }, {
            workspaceName: s.data.name
        }),
        children: e.jsx("div", {
            className: "flex flex-col gap-5",
            children: e.jsx("p", {
                children: t != null ? e.jsx(o, {
                    id: "leaveWorkspaceModal.leftWorkspaceDescription",
                    defaultMessage: "You have successfully left the {workspaceName} workspace.",
                    values: {
                        workspaceName: s.data.name
                    }
                }) : e.jsx(o, {
                    id: "leaveWorkspaceModal.leftWorkspaceDescriptionNoOtherWorkspaces",
                    defaultMessage: "You have successfully left the {workspaceName} workspace. This will create your personal workspace automatically.",
                    values: {
                        workspaceName: s.data.name
                    }
                })
            })
        })
    })
}

function ci() {
    const s = y(),
        t = Ks(n => n.activeModals.has(ie.AgeVerificationInterstitial));
    return e.jsxs(L, {
        type: "success",
        isOpen: t,
        onClose: qs,
        title: s.formatMessage(xe.title),
        children: [e.jsxs("div", {
            className: "text-token-text-secondary",
            children: [e.jsx("p", {
                className: "mb-4",
                children: e.jsx(o, { ...xe.description0
                })
            }), e.jsx(vt, {
                children: e.jsx(o, { ...xe.subtitle1
                })
            }), e.jsxs("ol", {
                className: "mb-4 ml-4 list-decimal",
                children: [e.jsx("li", {
                    className: "",
                    children: e.jsx(o, { ...xe.description1Bullet1
                    })
                }), e.jsx("li", {
                    children: e.jsx(o, { ...xe.description1Bullet2
                    })
                })]
            }), e.jsx("p", {
                className: "mb-4 font-semibold",
                children: e.jsx(o, { ...xe.description1a
                })
            }), e.jsx("p", {
                className: "mb-4",
                children: e.jsx(o, { ...xe.description1b
                })
            }), e.jsx(vt, {
                children: e.jsx(o, { ...xe.subtitle2
                })
            }), e.jsx("p", {
                className: "mb-4",
                children: e.jsx(o, { ...xe.description2,
                    values: {
                        learnMoreLink: n => e.jsx("a", {
                            href: "https://help.openai.com/en/articles/8411987-why-am-i-being-asked-to-verify-my-age",
                            target: "_blank",
                            rel: "noreferrer",
                            className: "cursor-pointer font-normal underline",
                            children: n
                        })
                    }
                })
            })]
        }), e.jsx("div", {
            className: "mt-4 flex justify-center",
            children: e.jsx(K, {
                color: "primary",
                as: "link",
                to: "https://platform.openai.com/verify-age",
                openNewTab: !0,
                onClick: () => J.closeModal(ie.AgeVerificationInterstitial),
                icon: yn,
                children: e.jsx(o, { ...xe.redirect
                })
            })
        })]
    })
}
const vt = le.h3 `text-token-text-primary text-base mb-1`,
    xe = F({
        title: {
            id: "AgeVerificationInterstitial.title",
            defaultMessage: "Please verify your age"
        },
        redirect: {
            id: "AgeVerificationInterstitial.redirect",
            defaultMessage: "Sign in on platform.openai.com"
        },
        description0: {
            id: "AgeVerificationInterstitial.description0",
            defaultMessage: "To continue using ChatGPT, you need to complete a brief age verification check"
        },
        subtitle1: {
            id: "AgeVerificationInterstitial.title1",
            defaultMessage: "What will happen next?"
        },
        description1Bullet1: {
            id: "AgeVerificationInterstitial.description1",
            defaultMessage: "You will be redirected to platform.openai.com where you will need to sign in."
        },
        description1Bullet2: {
            id: "AgeVerificationInterstitial.description2",
            defaultMessage: "You will then be redirected to Yoti, our age verification provider, to verify your age."
        },
        description1a: {
            id: "AgeVerificationInterstitial.description1a",
            defaultMessage: "If you are between the ages of 13 and 17, your parent or guardian must complete the age verification check on your behalf."
        },
        description1b: {
            id: "AgeVerificationInterstitial.description1b",
            defaultMessage: "The process is quick and secure."
        },
        subtitle2: {
            id: "AgeVerificationInterstitial.title2",
            defaultMessage: "Why do I need to do this?"
        },
        description2: {
            id: "AgeVerificationInterstitial.description2-v3",
            defaultMessage: "We are required to verify that our users in Italy are old enough to use ChatGPT. <learnMoreLink>Learn more</learnMoreLink>."
        }
    });

function di() {
    return Cs(ie.CookieManagement) ? e.jsx(ui, {
        onClose: () => {
            J.closeModal(ie.CookieManagement)
        }
    }) : null
}

function ui({
    onClose: s
}) {
    const t = y(),
        a = Q(),
        {
            isUnauthenticated: n
        } = ws(),
        {
            data: i
        } = ko(),
        l = i ? .serverPrimedAllowBrowserStorageValue ? ? !1,
        r = i ? .isStorageComplianceEnabled ? ? !1,
        u = So({
            serverPrimedAllowBrowserStorageValue: l,
            enabled: r && !n
        }),
        [c, g] = d.useState(l),
        m = n ? c : u,
        p = h => {
            Ue.setCookie(We.AllowNonessential, h, {
                maxAge: To,
                domain: to
            }), n ? g(h) : f.mutateAsync({
                analytics_cookies_accepted: h
            }, {
                onSuccess() {
                    a.success(t.formatMessage(te.updateSuccess))
                },
                onError() {
                    a.danger(t.formatMessage(te.updateFailure))
                }
            })
        };
    d.useEffect(() => {
        if (n) {
            const h = Ue.getCookie(We.AllowNonessential) ? ? l;
            g(h)
        }
    }, [n, l]), d.useEffect(() => {
        Se.addAction("privacy_policy.show_manage_cookies_modal")
    }, []);
    const f = wo();
    return e.jsx(L, {
        type: "success",
        isOpen: !0,
        onClose: s,
        title: t.formatMessage(te.title),
        showCloseButton: !0,
        children: e.jsxs("div", {
            className: "text-sm text-token-text-secondary",
            children: [e.jsx(o, { ...te.description,
                values: {
                    cookiePolicy: h => e.jsx("a", {
                        className: "underline",
                        href: "https://openai.com/policies/privacy-policy",
                        children: h
                    })
                }
            }), e.jsxs(Ct, {
                children: [e.jsxs(kt, {
                    children: [e.jsx(St, {
                        children: t.formatMessage(te.preference1title)
                    }), e.jsx(wt, {
                        children: t.formatMessage(te.preference1desc)
                    })]
                }), e.jsx(ks, {
                    onChange: qs,
                    enabled: !0,
                    disabled: !0,
                    label: t.formatMessage(te.preference1toggle)
                })]
            }), e.jsxs(Ct, {
                children: [e.jsxs(kt, {
                    children: [e.jsx(St, {
                        children: t.formatMessage(te.preference2title)
                    }), e.jsx(wt, {
                        children: t.formatMessage(te.preference2desc)
                    })]
                }), e.jsx(ks, {
                    onChange: p,
                    enabled: !!m,
                    label: t.formatMessage(te.preference2toggle)
                })]
            }), e.jsxs("div", {
                className: "flex justify-end gap-3 border-t border-black/10 pt-4 dark:border-white/10",
                children: [e.jsx(K, {
                    color: "secondary",
                    onClick: () => p(!1),
                    children: e.jsx(o, { ...te.reject
                    })
                }), e.jsx(K, {
                    color: "secondary",
                    onClick: () => p(!0),
                    children: e.jsx(o, { ...te.accept
                    })
                })]
            })]
        })
    })
}
const Ct = le.div `flex gap-4 border-t last:border-b border-black/10 dark:border-white/10 py-4 mt-4 text-token-text-secondary`,
    kt = le.div `flex gap-2 flex-col `,
    St = le.p `font-semibold text-sm text-token-text-primary`,
    wt = le.p `text-xs`,
    te = F({
        title: {
            id: "ManageCookiesModal.title",
            defaultMessage: "Manage cookies"
        },
        description: {
            id: "ManageCookiesModal.description",
            defaultMessage: "OpenAI uses cookies to improve your experience and analyze site traffic. For more information, read our <cookiePolicy>cookie policy</cookiePolicy>."
        },
        preference1title: {
            id: "ManageCookiesModal.preference1title",
            defaultMessage: "Essential"
        },
        preference1desc: {
            id: "ManageCookiesModal.preference1desc.0",
            defaultMessage: "These cookies are required to operate our Services. For example, they allow us to authenticate users or enable specific features within the Services, including for security purposes."
        },
        preference1toggle: {
            id: "ManageCookiesModal.preference1toggle",
            defaultMessage: "Allow essential cookies"
        },
        preference2title: {
            id: "ManageCookiesModal.preference2title",
            defaultMessage: "Analytics"
        },
        preference2desc: {
            id: "ManageCookiesModal.preference2desc.0",
            defaultMessage: "These cookies help us analyze and understand how our Services perform and are used, such as the number of users, how they interact with our Services, and time spent using the Services."
        },
        preference2toggle: {
            id: "ManageCookiesModal.preference2toggle",
            defaultMessage: "Allow analytics cookies"
        },
        reject: {
            id: "ManageCookiesModal.reject",
            defaultMessage: "Reject all"
        },
        accept: {
            id: "ManageCookiesModal.accept",
            defaultMessage: "Accept all"
        },
        updateSuccess: {
            id: "ManageCookiesModal.updateSuccess",
            defaultMessage: "Your cookie preferences were updated successfully"
        },
        updateFailure: {
            id: "ManageCookiesModal.updateFailure",
            defaultMessage: "Unable to update cookie preferences. Try again later."
        }
    });

function lt() {
    const s = ge(),
        {
            layer: t
        } = ss("468168202");
    return {
        isSplitBetweenPersonalAndBusinessEnabled: t.get("is_split_between_personal_and_business_enabled", !1),
        isModalFullscreen: t.get("is_modal_fullscreen", !1),
        isTeamEnabled: t.get("is_team_enabled", !0) || s ? .isTeam(),
        isV2ToggleLabelsEnabled: t.get("is_v2_toggle_labels_enabled", !1)
    }
}

function gi({
    ariaLabel: s,
    className: t,
    leftItem: a,
    onChange: n,
    rightItem: i,
    value: l
}) {
    const r = y(),
        u = l === a.value;
    return e.jsx(Yn, {
        type: "single",
        "aria-label": r.formatMessage(s),
        onClick: () => {
            n(u ? i.value : a.value)
        },
        value: l,
        className: we("cursor-pointer select-none rounded-full border border-solid border-token-border-light bg-token-main-surface-tertiary p-0.5", t),
        children: e.jsxs("div", {
            className: "relative grid grid-cols-2",
            children: [e.jsx(Tt, { ...a,
                isSelected: l === a.value
            }), e.jsx(Tt, { ...i,
                isSelected: l === i.value
            })]
        })
    })
}

function Tt({
    ariaLabel: s,
    isSelected: t,
    label: a,
    value: n
}) {
    const i = y();
    return e.jsxs("div", {
        className: "relative z-10 px-3 py-1.5 text-center text-sm font-semibold",
        children: [e.jsx($n, {
            "aria-label": i.formatMessage(s),
            className: we({
                "text-token-text-primary": t,
                "text-token-text-tertiary": !t
            }),
            value: n,
            children: e.jsx(o, { ...a
            })
        }), t ? e.jsx(ot.div, {
            transition: {
                duration: .05
            },
            layoutId: "SegmentedControlToggleItem-selectedBackground",
            className: "absolute inset-0 -z-10 rounded-full bg-token-main-surface-primary"
        }) : null]
    })
}

function At({
    value: s,
    onChange: t
}) {
    const {
        isV2ToggleLabelsEnabled: a
    } = lt();
    return e.jsx(gi, {
        value: s,
        onChange: t,
        ariaLabel: be.toggleArialabel,
        leftItem: {
            ariaLabel: a ? be.toggleForIndividualsArialabel : be.togglePersonalArialabel,
            label: a ? be.toggleForIndividualsLabel : be.togglePersonalLabel,
            value: "personal"
        },
        rightItem: {
            ariaLabel: a ? be.toggleForTeamsArialabel : be.toggleBusinessArialabel,
            label: a ? be.toggleForTeamsLabel : be.toggleBusinessLabel,
            value: "business"
        }
    })
}
const be = F({
        toggleArialabel: {
            id: "U4v2Gf",
            defaultMessage: "Toggle for switching between Personal and Business plans"
        },
        togglePersonalArialabel: {
            id: "6Wikht",
            defaultMessage: "Toggle for switching to Personal plans"
        },
        toggleForIndividualsArialabel: {
            id: "DNEy0d",
            defaultMessage: "Toggle for switching to plans for individuals"
        },
        toggleBusinessArialabel: {
            id: "uzlEV0",
            defaultMessage: "Toggle for switching to Business plans"
        },
        toggleForTeamsArialabel: {
            id: "ADnxet",
            defaultMessage: "Toggle for switching to plans for teams"
        },
        togglePersonalLabel: {
            id: "cGDsaD",
            defaultMessage: "Personal"
        },
        toggleForIndividualsLabel: {
            id: "FLfLeO",
            defaultMessage: "For Individuals"
        },
        toggleBusinessLabel: {
            id: "sgisa2",
            defaultMessage: "Business"
        },
        toggleForTeamsLabel: {
            id: "VKVfzi",
            defaultMessage: "For Teams"
        }
    }),
    xa = () => {
        w.logEvent(A.clickAccountPaymentGetHelp)
    };

function mi(s, t) {
    switch (s) {
        case de.FREE:
            return "green";
        case de.PLUS:
            return "green";
        case de.TEAM:
            return t ? "primary" : "blue";
        case de.ENTERPRISE:
            return "secondary";
        case de.EDU:
            return "secondary"
    }
}

function Oe({
    isCurrentPlan: s,
    planType: t,
    disabled: a,
    onClick: n,
    children: i,
    testId: l,
    isProduceDesign: r,
    activeColor: u,
    ...c
}) {
    return e.jsx(K, {
        fullWidth: !0,
        size: "large",
        color: s ? "secondary" : u || mi(t, r),
        disabled: a,
        onClick: n,
        "data-testid": l,
        className: r && a ? "border-none bg-token-sidebar-surface-tertiary font-semibold text-token-text-primary hover:bg-token-sidebar-surface-tertiary dark:bg-token-text-tertiary" : r ? "font-semibold" : "",
        ...c,
        children: i
    })
}
const fi = le.div `${s=>s.plusInactiveProduce?"mt-4":""} text-sm relative flex-1 flex gap-5 flex-col border-token-border-light ${s=>{const t=s.isModalFullscreen?"border-t border-l border-r border-b rounded-xl md:min-h-[30rem] md:rounded-none md:border-r-0 md:last:border-r md:first:rounded-tl-xl md:first:rounded-bl-xl md:last:rounded-tr-xl md:last:rounded-br-xl md:max-w-96 justify-center px-6 pt-6 pb-10 md:pb-6":"md:border-r last:border-r-0 md:border-t-0 border-t py-4 px-6",a=s.plusInactiveProduce?"border-t border-l border-r border-b rounded-xl md:first:rounded-tl-xl md:first:rounded-bl-xl md:last:rounded-tr-xl md:last:rounded-br-xl md:max-w-96 justify-center px-6 pt-6 pb-10 md:pb-6 md:min-h-[20rem] -mt-1 -mb-4 border-green-600 bg-green-600 bg-opacity-5":"";return`${s.plusInactiveProduce?a:t}`}}`,
    us = le.div `
  relative flex flex-col ${s=>s.plusInactiveProduce?"":"bg-token-main-surface-primary"}
`,
    pi = le.div `flex flex-col flex-grow gap-2`,
    xi = le.div `
  relative ${s=>s.plusInactiveProduce?"":"bg-token-main-surface-primary"}
`,
    Et = le.div `
  relative flex flex-col text-xs text-token-text-secondary ${s=>s.plusInactiveProduce?"":"bg-token-main-surface-primary"}
`,
    Ps = ({
        planName: s,
        pricingPlan: t,
        callToActionButton: a,
        className: n,
        showForLine: i = !0,
        icon: l = void 0,
        additionalLinks: r = [],
        plusInactive: u = !1
    }) => {
        const {
            isModalFullscreen: c
        } = lt(), {
            layer: g
        } = ss("3768341700"), m = g.get("is_produce_design", !1), p = u && m, f = st();
        return e.jsxs(fi, {
            className: n,
            "data-testid": `${s}-pricing-modal-column`,
            isModalFullscreen: c,
            plusInactiveProduce: p,
            children: [m ? e.jsx(us, {
                plusInactiveProduce: p,
                className: p ? "mt-4" : "",
                children: e.jsxs("div", {
                    className: "flex flex-col gap-1",
                    children: [e.jsxs("p", {
                        className: "flex items-center gap-2 text-2xl font-semibold",
                        children: [m ? "" : l ? ? "", e.jsx(o, { ...t.name
                        }), p && e.jsx("span", {
                            className: "ml-1 rounded border border-green-600 px-1 py-0 text-xs font-bold text-green-600",
                            children: e.jsx(o, {
                                id: "popular",
                                defaultMessage: "POPULAR"
                            })
                        })]
                    }), t.costInDollars && e.jsx("div", {
                        className: "ml-4 mt-2 flex items-baseline gap-1.5",
                        children: e.jsxs("div", {
                            className: "relative",
                            children: [e.jsx("p", {
                                className: "absolute -left-4 -top-0 text-2xl text-token-text-secondary",
                                "data-testid": `${s}-pricing-column-cost`,
                                children: e.jsx(o, {
                                    id: "dollarSign",
                                    defaultMessage: "$"
                                })
                            }), e.jsxs("div", {
                                className: "flex items-baseline gap-1.5",
                                children: [e.jsx("p", {
                                    className: "text-5xl text-token-text-primary",
                                    "data-testid": `${s}-pricing-column-cost`,
                                    children: e.jsx(o, { ...t.costInDollars
                                    })
                                }), e.jsxs("div", {
                                    className: "flex flex-col items-start justify-center",
                                    children: [e.jsx("p", {
                                        className: "absolute mb-6 text-xs text-token-text-tertiary",
                                        "data-testid": `${s}-pricing-column-cost`,
                                        children: e.jsx(o, {
                                            id: "dollars",
                                            defaultMessage: "USD/"
                                        })
                                    }), e.jsx("p", {
                                        className: "text-xs text-token-text-tertiary",
                                        "data-testid": `${s}-pricing-column-cost`,
                                        children: e.jsx(o, {
                                            id: "frequency",
                                            defaultMessage: "month"
                                        })
                                    })]
                                })]
                            })]
                        })
                    }), t.costInDollarsSubtitle && f ? e.jsx("p", {
                        className: "mb-3 mt-6 text-sm text-token-text-tertiary",
                        "data-testid": `${s}-pricing-column-cost-subtitle`,
                        children: e.jsx(o, { ...t.costInDollarsSubtitle
                        })
                    }) : null, t.summary ? e.jsx("p", {
                        className: "mr-2 mt-2 text-base text-token-text-primary",
                        "data-testid": `${s}-pricing-column-cost-subtitle`,
                        children: e.jsx(o, { ...t.summary
                        })
                    }) : null]
                })
            }) : e.jsx(us, {
                children: e.jsxs("div", {
                    className: "flex flex-col gap-1",
                    children: [e.jsxs("p", {
                        className: "flex items-center gap-2 text-xl font-semibold",
                        children: [l ? ? "", e.jsx(o, { ...t.name
                        })]
                    }), e.jsxs("div", {
                        className: "flex items-baseline gap-1.5",
                        children: [e.jsx("p", {
                            className: "text-base text-token-text-tertiary",
                            "data-testid": `${s}-pricing-column-cost`,
                            children: e.jsx(o, { ...t.costInDollars
                            })
                        }), t.costInDollarsSubtitle ? e.jsx("p", {
                            className: "text-xs text-token-text-tertiary",
                            "data-testid": `${s}-pricing-column-cost-subtitle`,
                            children: e.jsx(o, { ...t.costInDollarsSubtitle
                            })
                        }) : null]
                    })]
                })
            }), e.jsx(us, {
                children: a
            }), e.jsxs(pi, {
                children: [i && t.forLine && e.jsx(us, {
                    children: e.jsx("p", {
                        className: "text-l font-semibold",
                        children: e.jsx(o, { ...t.forLine
                        })
                    })
                }), t.advertisedFeatures ? .map((h, j) => e.jsx(xi, {
                    plusInactiveProduce: p,
                    children: e.jsxs("div", {
                        className: "text-l flex justify-start gap-2",
                        children: [e.jsx(jn, {
                            className: "mt-0.5 h-4 w-4 shrink-0"
                        }), e.jsx("span", {
                            children: e.jsx(o, { ...h,
                                values: {
                                    link: M => e.jsx(se, {
                                        className: "underline",
                                        target: "_blank",
                                        rel: "noreferrer",
                                        to: h.link ? ? "",
                                        children: M
                                    }),
                                    article: M => e.jsx(se, {
                                        className: "underline",
                                        target: "_blank",
                                        rel: "noreferrer",
                                        to: h.article ? ? "",
                                        children: M
                                    }),
                                    modelName: "GPT‑4o"
                                }
                            })
                        })]
                    })
                }, j))]
            }), e.jsxs("div", {
                children: [r.length > 0 && e.jsx(Et, {
                    plusInactiveProduce: p,
                    children: r.map((h, j) => e.jsx("div", {
                        children: h
                    }, j))
                }), t.disclaimer && e.jsx(Et, {
                    plusInactiveProduce: p,
                    children: e.jsx("div", {
                        children: e.jsx(o, { ...t.disclaimer,
                            values: {
                                link: h => e.jsx(se, {
                                    className: "underline",
                                    target: "_blank",
                                    rel: "noreferrer",
                                    to: t.disclaimer ? .link ? ? "",
                                    children: h
                                }),
                                article: h => e.jsx(se, {
                                    className: "underline",
                                    target: "_blank",
                                    rel: "noreferrer",
                                    to: t ? .disclaimer ? .article ? ? "",
                                    children: h
                                })
                            }
                        })
                    })
                })]
            })]
        })
    },
    Nt = de.ENTERPRISE,
    hi = {
        [q.Default]: C.enterprise,
        [q.Scallion]: C.enterprise,
        [q.Chive]: C.enterprise,
        [q.ProduceDesign]: C.enterpriseProduceExp
    },
    bi = ({
        isProduceDesign: s = !1,
        enterprisePricingPlanProduce: t = null
    }) => {
        const n = ge() ? .isEnterprisey(),
            i = nt(),
            l = t || Qs(hi[i]);
        return e.jsx(Ps, {
            icon: e.jsx(la, {
                className: "icon-md text-brand-purple"
            }),
            planName: "enterprise",
            pricingPlan: l,
            showForLine: !0,
            callToActionButton: n ? e.jsx(K, {
                color: "secondary",
                disabled: !0,
                size: "large",
                className: s ? "border-none bg-token-sidebar-surface-tertiary font-semibold text-token-text-primary hover:bg-token-sidebar-surface-tertiary dark:bg-token-text-tertiary dark:text-token-text-primary dark:hover:bg-token-text-tertiary" : "",
                children: e.jsx(o, { ...C.free.callToAction.inactive
                })
            }) : e.jsx(Oe, {
                planType: Nt,
                as: "link",
                to: zs,
                openNewTab: !0,
                onClick: () => {
                    w.logEvent(A.clickEnterpriseContactSalesButton), ne.logEvent("chatgpt_account_payment_modal_enterprise_sales_button_clicked", Nt)
                },
                isCurrentPlan: !1,
                testId: "select-plan-button-enterprise",
                isProduceDesign: s,
                children: e.jsx("div", {
                    className: "flex items-center gap-1",
                    children: e.jsx(o, { ...C.enterprise.callToAction.inactive
                    })
                })
            })
        })
    },
    Mi = {
        [q.Default]: C.freeDefault,
        [q.Scallion]: C.freeNeptune,
        [q.Chive]: C.freeChive,
        [q.ProduceDesign]: C.freeProduceExp
    },
    yi = ({
        isProduceDesign: s = !1,
        freePricingPlanProduce: t = null
    }) => {
        const a = tt(),
            n = nt(),
            i = t || Qs(Mi[n]);
        return e.jsx(Ps, {
            planName: "free",
            pricingPlan: i,
            icon: e.jsx(vn, {
                className: "icon-md"
            }),
            showForLine: !a,
            callToActionButton: e.jsx(K, {
                color: "secondary",
                disabled: !0,
                size: "large",
                className: s ? "border-none bg-token-sidebar-surface-tertiary font-semibold text-token-text-primary hover:bg-token-sidebar-surface-tertiary dark:bg-token-text-tertiary dark:text-token-text-primary dark:hover:bg-token-text-tertiary" : "",
                children: e.jsx(o, { ...C.free.callToAction.inactive
                })
            }),
            additionalLinks: [e.jsx(o, { ...ji.haveExistingPlan,
                values: {
                    link: l => e.jsx(se, {
                        target: "_blank",
                        to: qt,
                        onClick: xa,
                        className: "font-semibold underline",
                        children: l
                    }, "row-plus-plan-help-link")
                }
            }, "existing-plan-help")]
        })
    },
    ji = F({
        haveExistingPlan: {
            id: "FreeColumn.haveExistingPlan",
            defaultMessage: "Have an existing plan? See <link>billing help</link>"
        }
    });

function vi({
    isOpen: s,
    onClose: t,
    onContinue: a
}) {
    return e.jsx(L, {
        isOpen: s,
        onClose: t,
        type: "warning",
        icon: ra,
        title: e.jsx(o, { ...gs.checkSubscriptionHeader
        }),
        primaryButton: e.jsx(R.Button, {
            title: gs.dismissModal.defaultMessage,
            color: "primary",
            onClick: t
        }),
        secondaryButton: e.jsx(R.Button, {
            title: gs.continueToNextStep.defaultMessage,
            color: "secondary",
            onClick: a
        }),
        children: e.jsx("span", {
            className: "gap-2 text-gray-600",
            children: gs.checkSubscriptionBody.defaultMessage
        })
    })
}
const gs = F({
        checkSubscriptionHeader: {
            id: "mobileSubscriptionWarningModal.checkSubscriptionHeader",
            defaultMessage: "Check your App Store subscription"
        },
        checkSubscriptionBody: {
            id: "mobileSubscriptionWarningModal.checkSubscriptionBody",
            defaultMessage: "Your subscription through the Apple App Store is currently on pause due to a payment issue. Please resolve that issue to resume using ChatGPT Plus and avoid duplicate charges."
        },
        dismissModal: {
            id: "mobileSubscriptionWarningModal.dismissModal",
            defaultMessage: "Cancel"
        },
        continueToNextStep: {
            id: "mobileSubscriptionWarningModal.continueToNextStep",
            defaultMessage: "I understand, continue anyways"
        }
    }),
    Ci = de.PLUS;

function ki({
    isOpen: s,
    onClose: t,
    onCancelationComplete: a,
    analyticsParams: n
}) {
    const i = y(),
        l = Q(),
        r = ge(),
        {
            data: u,
            isLoading: c
        } = qn(),
        g = Qn(r ? .id),
        m = d.useMemo(() => ({ ...n,
            planType: Ci
        }), [n]),
        p = d.useCallback(() => {
            t(), g.isSuccess || w.logEventWithStatsig(A.cancelPlusAbort, "cancel_plus_modal_abort", m)
        }, [t, g.isSuccess, m]),
        f = async () => {
            if (!r) throw new Error("No account!");
            w.logEventWithStatsig(A.cancelPlusConfirm, "cancel_plus_modal_confirm", m), await g.mutateAsync(r ? .id, {
                onError: () => {
                    l.danger(i.formatMessage(Z.cancelFailure), {
                        duration: 2
                    }), w.logEventWithStatsig(A.cancelPlusError, "cancel_plus_modal_error", m)
                },
                onSuccess: () => {
                    w.logEventWithStatsig(A.cancelPlusSuccess, "cancel_plus_modal_success", m), a ? .(), l.info(i.formatMessage(Z.cancelSuccess), {
                        duration: 2
                    }), t()
                }
            })
        };
    d.useEffect(() => {
        g.isSuccess
    }, [g.isSuccess, t]);
    const h = u ? .active_until;
    return e.jsx(L, {
        type: "success",
        onClose: p,
        isOpen: s,
        className: "",
        title: e.jsx(o, { ...Z.cancelPlan
        }),
        children: c || !r ? e.jsx(He, {}) : g.isSuccess ? e.jsx(o, { ...Z.cancelSuccess
        }) : e.jsxs("div", {
            children: [e.jsxs("div", {
                className: "text-sm",
                children: [!!h && e.jsx("p", {
                    className: "mb-4",
                    children: e.jsx(o, { ...Z.planActiveUntil,
                        values: {
                            expirationDate: new Date(h)
                        }
                    })
                }), e.jsx("p", {
                    className: "mb-2",
                    children: e.jsx(o, { ...Z.cancelListHeader
                    })
                }), e.jsx("div", {
                    children: Ti.map(j => e.jsxs("div", {
                        className: "text-l mb-2 flex justify-start gap-2",
                        children: [e.jsx(ca, {
                            className: "h-5 w-5 flex-shrink-0 align-top text-gray-500"
                        }), e.jsx("span", {
                            children: e.jsx(o, { ...j,
                                values: {
                                    learnMoreLink: Si,
                                    mainModel: wi
                                }
                            })
                        })]
                    }, j.id))
                })]
            }), e.jsxs("div", {
                className: "mt-8 flex justify-end gap-2",
                children: [e.jsx(K, {
                    onClick: p,
                    color: "secondary",
                    children: e.jsx(o, { ...Z.closeModal
                    })
                }), e.jsx(K, {
                    color: "danger",
                    onClick: f,
                    disabled: g.isPending || g.isSuccess,
                    children: e.jsx(o, { ...g.isPending ? Z.cancellingInProgress : Z.cancelButton
                    })
                })]
            })]
        })
    })
}
const Si = s => e.jsx("a", {
        target: "_blank",
        href: "https://help.openai.com/en/articles/9280126-what-happens-to-my-gpts-if-i-cancel-my-subscription",
        rel: "noreferrer",
        className: "underline",
        children: s
    }),
    wi = "GPT-4",
    Z = F({
        cancelPlan: {
            id: "cancelPlusModal.cancelPlan",
            defaultMessage: "Cancel your Plus subscription?"
        },
        cancelListHeader: {
            id: "cancelPlusModal.cancelText",
            defaultMessage: "When your subscription ends, you'll no longer have:"
        },
        planActiveUntil: {
            id: "cancelPlusModal.planActiveUntil",
            defaultMessage: "If you cancel your subscription, you’ll be downgraded to the free plan on {expirationDate, date, long}."
        },
        cancelButton: {
            id: "cancelPlusModal.cancelButton",
            defaultMessage: "Cancel subscription"
        },
        cancellingInProgress: {
            id: "cancelPlusModal.cancellingInProgress",
            defaultMessage: "Cancelling..."
        },
        cancelSuccess: {
            id: "cancelPlusModal.cancelSuccess",
            defaultMessage: "Successfully cancelled your plan. Sorry to see you go!"
        },
        cancelFailure: {
            id: "cancelPlusModal.cancelFailure",
            defaultMessage: "Something went wrong while cancelling your plan. Please reach out to support"
        },
        lostFeatureGPTModels: {
            id: "0w7d5w",
            defaultMessage: "Access to {mainModel} and {liteModel}"
        },
        lostFeatureGPTModelSingular: {
            id: "cancelPlusModal.lostFeature.gptModelSingular",
            defaultMessage: "Access to {mainModel}"
        },
        lostFeatureNewModelUsageLimits: {
            id: "TjftEV",
            defaultMessage: "Higher usage limits for {limitedModel}"
        },
        lostFeatureDataAnalysisV2: {
            id: "cancelPlusModal.lostFeature.dataAnalysisV2",
            defaultMessage: "Access to advanced data analysis, file uploads, vision, and web browsing"
        },
        lostFeatureDataAnalysisLimits: {
            id: "dlGufV",
            defaultMessage: "Higher usage limits for advanced data analysis, file uploads, vision, and web browsing"
        },
        lostFeatureImageGeneration: {
            id: "cancelPlusModal.lostFeature.imageGeneration",
            defaultMessage: "DALL·E image generation"
        },
        lostFeatureCustomGPTs: {
            id: "cancelPlusModal.lostFeature.customGPTs",
            defaultMessage: "Custom GPT creation"
        },
        lostFeaturePersonalGPTs: {
            id: "cancelPlusModal.lostFeature.personalGPTs",
            defaultMessage: "GPTs you’ve created (<learnMoreLink>learn more</learnMoreLink>)"
        },
        closeModal: {
            id: "cancelPlusModal.close",
            defaultMessage: "Close"
        }
    }),
    Ti = [Z.lostFeatureGPTModelSingular, Z.lostFeatureDataAnalysisV2, Z.lostFeatureImageGeneration, Z.lostFeatureCustomGPTs, Z.lostFeaturePersonalGPTs],
    Ai = Xe.HasDismissedUpgradeInviteModal,
    Ei = {
        hasDismissedUpgradeInviteModal: !!bs.getItem(Ai)
    };
ao()(() => ({ ...Ei
}));
const Ni = () => {
        const {
            isUnauthenticated: s,
            isLoading: t
        } = ws();
        return Ge({
            queryKey: ["updateInvites", s],
            queryFn: async () => s ? {
                plus: null,
                team: null
            } : await P.getUpgradeInvites(),
            enabled: !t
        })
    },
    _t = F({
        plusWaitlistSignupSuccess: {
            id: "pricingPlanConstants.plusWaitlistSignupSuccess",
            defaultMessage: "You've been added to the waitlist to upgrade to Plus"
        },
        teamWaitlistSignupSuccess: {
            id: "pricingPlanConstants.teamWaitlistSignupSuccess",
            defaultMessage: "You've been added to the waitlist to upgrade to Team"
        }
    }),
    _i = {
        [de.PLUS]: {
            localStorageKeyByVersion: {
                V1: Xe.HasSignedUpForPlusUpgradeWaitlistV1,
                V2: Xe.HasSignedUpForPlusUpgradeWaitlistV2
            },
            onSuccessMessage: _t.plusWaitlistSignupSuccess
        },
        [de.TEAM]: {
            localStorageKeyByVersion: {
                V1: Xe.HasSignedUpForTeamUpgradeWaitlistV1,
                V2: Xe.HasSignedUpForTeamUpgradeWaitlistV2
            },
            onSuccessMessage: _t.teamWaitlistSignupSuccess
        }
    },
    ha = s => {
        const t = y(),
            a = Q(),
            {
                localStorageKeyByVersion: n,
                onSuccessMessage: i
            } = _i[s],
            l = n.V1,
            r = n.V2,
            [u] = d.useState(!!bs.getItem(l)),
            [c, g] = d.useState(!!bs.getItem(r)),
            {
                data: m
            } = Ni(),
            p = () => {
                g(!0), bs.setItem(r, !0), a.success(t.formatMessage(i), {
                    hasCloseButton: !0,
                    duration: 5
                }), w.logEvent(A.upgradePlanWaitlistSignup, {
                    plan: s
                })
            };
        return {
            hasSignedUpForWaitlist: u || c,
            isEligibleToUpgrade: !!m ? .plus || u,
            signUpForWaitlist: p
        }
    },
    Pi = () => Ge({
        queryKey: ["has-app-store-subscription-in-billing-retry"],
        queryFn: async () => await P.hasAppStoreSubscriptionInBillingRetryResponse()
    }),
    Li = {
        [q.Default]: C.plusDefaultForFreeUsers,
        [q.Scallion]: C.plusNeptuneForFreeUsers,
        [q.Chive]: C.plusChiveForFreeUsers,
        [q.ProduceDesign]: C.plusProduceForFreeUsersExp
    },
    Di = {
        [q.Default]: C.plusDefaultForPlusUsers,
        [q.Scallion]: C.plusNeptuneForPlusUsers,
        [q.Chive]: C.plusChiveForPlusUsers,
        [q.ProduceDesign]: C.plusProduceForPlusUsersExp
    },
    Ii = ({
        currentAccount: s,
        pricingType: t
    }) => {
        const {
            data: {
                subscriptionStatus: a
            }
        } = s;
        return a.hasPaidSubscription && a.subscriptionPlan === oo.PLUS ? a.billingPeriod === "yearly" ? C.plusYearly : Di[t] : Li[t]
    },
    Le = de.PLUS,
    Fi = ({
        analyticsParams: s,
        currentAccount: t,
        isPlanLoading: a,
        onSubmit: n,
        setIsPlanLoading: i,
        shouldShowAdditionalLinks: l = !0,
        upgradeButtonText: r = C.plus.callToAction.inactive,
        isProduceDesign: u = !1,
        plusPricingPlanProduce: c = null
    }) => {
        const {
            data: g,
            isError: m
        } = Pi(), p = t.features, f = y(), h = Q(), [j, M] = d.useState(!1), [k, B] = d.useState(!1), [D, U] = d.useState(!1), I = [], T = t.isOrWasPaidCustomer(), G = t.hasPaidSubscription() && t.isPlus(), re = t.getLastActiveSubscription(), {
            hasSignedUpForWaitlist: me,
            signUpForWaitlist: he
        } = ha(Le), z = tt(), Me = p.includes("disable_plus_upgrade_ui") && !T, _e = p.includes("show_cancel_plus_ui"), N = { ...s,
            planType: Le,
            isUpgradeUiDisabled: Me
        }, _ = async () => {
            i(!0), w.logEvent(A.clickAccountPaymentCheckout, N), ne.logEvent("chatgpt_account_payment_modal_upgrade_button_click", Le);
            try {
                const fe = await P.getCheckoutLink(p);
                n ? .(), w.logEvent(A.navigatingToAccountPaymentCheckout, { ...N,
                    url: fe.url
                }), ne.logEvent("chatgpt_account_payment_modal_navigating_to_checkout", Le, {
                    url: fe.url
                }), window.location.href = fe.url
            } catch {
                h.warning(f.formatMessage(ms.paymentErrorWarning), {
                    hasCloseButton: !0
                })
            }
            i(!1)
        }, W = () => {
            M(!0), w.logEventWithStatsig(A.cancelPlusStart, "cancel_plus_start", { ...N,
                cancel_start_source: "manage plan"
            })
        }, ct = async () => {
            i(!0), w.logEvent(A.clickAccountCustomerPortal, N);
            try {
                const fe = await P.fetchCustomerPortalUrl();
                w.logEvent(A.navigatingToAccountCustomerPortal, N), location.href = fe.url
            } catch {
                h.warning(f.formatMessage(ms.accountErrorWarning), {
                    hasCloseButton: !0
                })
            }
            i(!1)
        }, ns = () => {
            w.logEvent(A.clickAccountManageIos, N)
        }, Ls = () => {
            w.logEvent(A.clickAccountManageAndroid, N)
        }, Ke = G && re.purchase_origin_platform === Ie.MOBILE_IOS, Ds = G && re.purchase_origin_platform === Ie.MOBILE_ANDROID, ze = (re.purchase_origin_platform === Ie.WEBAPP || re.purchase_origin_platform === Ie.GRANTED) && t ? .hasCustomerObject(), Pe = ze && !k && G && t.willRenewSubscription(), Te = nt(), is = c || Qs(Ii({
            currentAccount: t,
            pricingType: Te
        }));
        z && !G && I.push(e.jsx(se, {
            to: Ao,
            target: "_blank",
            className: "px-2 underline",
            children: e.jsx(o, { ...ms.limitsApply
            })
        }, "row-plus-plan-usage-limits")), Ke && I.push(e.jsx(se, {
            to: Eo,
            target: "_blank",
            onClick: ns,
            className: "px-2 underline",
            children: f.formatMessage(C.manageSubscriptionIos.callToAction)
        }, "row-plus-plan-manage-ios")), Ds && I.push(e.jsx(se, {
            to: No,
            target: "_blank",
            onClick: Ls,
            children: f.formatMessage(C.manageSubscriptionAndroid.callToAction)
        }, "row-plus-plan-manage-android")), ze && (I.push(e.jsx(se, {
            to: "#",
            onClick: ct,
            className: "px-2 underline",
            children: e.jsx(o, { ...C.manageSubscriptionWeb.callToAction
            })
        }, "row-manage-subscription-link")), Pe && _e && I.push(e.jsxs("button", {
            children: [e.jsx("span", {
                onClick: W,
                className: "cursor-pointer px-2 underline",
                children: e.jsx(o, { ...C.cancelSubscriptionWeb.callToAction
                })
            }), e.jsx(ki, {
                isOpen: j,
                onClose: () => M(!1),
                onCancelationComplete: () => B(!0),
                analyticsParams: N
            })]
        }, "row-cancel-subscription-link"))), T && I.push(e.jsx(se, {
            target: "_blank",
            to: qt,
            onClick: xa,
            className: "px-2 underline",
            children: e.jsx(o, { ...ms.billingHelp
            })
        }, "row-plus-plan-help-link"));
        const Ye = function() {
                U(!D)
            },
            ls = m || !g || !g.value ? _ : () => {
                Ye()
            };
        return e.jsx(Ps, {
            planName: "plus",
            pricingPlan: is,
            icon: e.jsx(Cn, {
                className: "icon-md text-green-600"
            }),
            showForLine: !G && !z,
            callToActionButton: Me ? e.jsx("div", {
                className: "relative w-full",
                children: e.jsx(ue, {
                    side: "bottom",
                    sideOffset: 20,
                    label: f.formatMessage(C.disabledHighDemand.hoverText),
                    children: e.jsx(Oe, {
                        planType: Le,
                        disabled: me,
                        onClick: he,
                        isCurrentPlan: G,
                        testId: "select-plan-button-plus-waitlist",
                        isProduceDesign: u,
                        children: e.jsx(o, { ...me ? C.signUpForWaitlist.inactive : C.signUpForWaitlist.active
                        })
                    })
                })
            }) : e.jsxs("div", {
                children: [e.jsx(Oe, {
                    planType: Le,
                    isCurrentPlan: G,
                    disabled: G || a,
                    onClick: ls,
                    testId: "select-plan-button-plus-upgrade",
                    isProduceDesign: u,
                    children: G ? f.formatMessage(C.plus.callToAction.active) : f.formatMessage(r)
                }), e.jsx(vi, {
                    isOpen: D,
                    onClose: Ye,
                    onContinue: _
                })]
            }),
            additionalLinks: l ? I : []
        })
    },
    ms = F({
        haveExistingPlan: {
            id: "AccountPaymentModal.haveExistingPlan",
            defaultMessage: "Have an existing plan?"
        },
        billingHelp: {
            id: "AccountPaymentModel.billingHelp",
            defaultMessage: "I need help with a billing issue"
        },
        paymentErrorWarning: {
            id: "AccountPaymentModal.paymentErrorWarning",
            defaultMessage: "The payments page encountered an error. Please try again. If the problem continues, please visit help.openai.com."
        },
        accountErrorWarning: {
            id: "AccountPaymentModal.accountErrorWarning",
            defaultMessage: "The account management page encountered an error. Please try again. If the problem continues, please visit help.openai.com."
        },
        limitsApply: {
            id: "xda4i3",
            defaultMessage: "Limits apply"
        }
    }),
    De = de.TEAM,
    Bi = ({
        analyticsParams: s,
        isPlanLoading: t,
        isProduceDesign: a = !1,
        teamPricingPlanProduce: n = null
    }) => {
        const l = Ts() ? .includes("disable_team_upgrade_ui"),
            r = y(),
            u = ge(),
            c = as(),
            {
                hasSignedUpForWaitlist: g,
                signUpForWaitlist: m
            } = ha(De),
            p = u && u.isTeam(),
            f = u && u.isPlus(),
            h = { ...s,
                planType: De,
                isUpgradeUiDisabled: l
            },
            j = tt(),
            M = n || (a ? C.teamsProduceExp : j ? C.teamsNeptune : C.teams),
            k = () => {
                w.logEvent(A.clickAccountPaymentCheckout, h), ne.logEvent("chatgpt_account_payment_modal_upgrade_button_click", De), J.setPurchaseWorkspaceData({
                    minimumSeats: Ys
                }), Qt(c)
            };
        return e.jsx(Ps, {
            planName: "team",
            pricingPlan: M,
            icon: e.jsx(kn, {
                className: "icon-md text-brand-blue-800"
            }),
            callToActionButton: e.jsxs("div", {
                className: "flex flex-col gap-2",
                children: [p && e.jsx(Oe, {
                    planType: De,
                    isCurrentPlan: !0,
                    disabled: t || p,
                    onClick: k,
                    testId: "select-plan-button-teams-upgrade",
                    isProduceDesign: a,
                    children: r.formatMessage(C.teams.callToAction.active)
                }), l ? e.jsx("div", {
                    className: "relative w-full",
                    children: e.jsx(ue, {
                        side: "bottom",
                        sideOffset: 20,
                        label: r.formatMessage(C.disabledHighDemand.hoverText),
                        children: e.jsx(Oe, {
                            planType: De,
                            isCurrentPlan: !1,
                            disabled: g,
                            onClick: m,
                            testId: "select-plan-button-teams-waitlist",
                            isProduceDesign: a,
                            children: e.jsx(o, { ...g ? C.signUpForWaitlist.inactive : C.signUpForWaitlist.active
                            })
                        })
                    })
                }) : e.jsx("div", {
                    className: "w-full",
                    children: e.jsx(Oe, {
                        planType: De,
                        isCurrentPlan: !1,
                        disabled: t,
                        onClick: k,
                        testId: "select-plan-button-teams-create",
                        isProduceDesign: a,
                        children: p || f ? r.formatMessage(M.callToAction.create) : r.formatMessage(M.callToAction.inactive)
                    })
                })]
            })
        })
    };

function Oi(s) {
    return s.split("#")[1] === _o
}

function Us(s) {
    return s.split("#")[1] === Po
}
const Ui = () => {
    const {
        layer: s
    } = ss("4250072504"), {
        layer: t
    } = ss("685344542"), a = Lo(), [n, i] = d.useState(!1);
    return d.useEffect(() => {
        a && i(t.get("is_enterprise_enabled", !1))
    }, [a, t]), {
        isEnterpriseEnabled: n,
        checkEnterpriseEnabled: r => {
            r && i(s.get("is_enterprise_enabled", !1))
        }
    }
};

function Wi({
    currentAccount: s,
    initTab: t
}) {
    const [a, n] = d.useState(!1), {
        isEnterpriseEnabled: i,
        checkEnterpriseEnabled: l
    } = Ui(), {
        layer: r
    } = ss("3768341700"), u = r.get("is_produce_design", !1), c = d.useMemo(() => s.subscriptionAnalyticsParams, [s]), g = as(), m = Q(), p = () => {
        w.logEvent(A.closeAccountPaymentModal, c), Qt(g)
    };
    d.useEffect(() => {
        const v = Do();
        w.logEvent(A.accountPaymentModalShow, { ...c,
            location: v
        }), ne.logEvent("chatgpt_account_payment_modal_show", null, {
            location: v ? ? ""
        })
    }, [c]), d.useEffect(() => {
        const v = localStorage.getItem(`subscriptionUpdateMessage_${s.id}`);
        v && (m.success(v, {
            hasCloseButton: !0
        }), localStorage.removeItem(`subscriptionUpdateMessage_${s.id}`))
    }, [s.id, m]);
    const f = t ? ? (s.isPersonalAccount() ? "personal" : "business"),
        {
            isSplitBetweenPersonalAndBusinessEnabled: h,
            isModalFullscreen: j,
            isTeamEnabled: M
        } = lt(),
        [k, B] = d.useState(f),
        D = st(),
        U = h && D,
        I = v => {
            B(v), v === "business" && l(D), w.logEvent(A.accountPaymentModalToggleClicked, {
                selectedTab: v
            }), ne.logEvent("chatgpt_account_payment_modal_toggle_clicked", null, {
                selectedTab: v
            })
        };
    ys("1028682714");
    const T = Ri({
        analyticsParams: c,
        currentAccount: s,
        isModalFullscreen: j,
        isPlanLoading: a,
        isTeamEnabled: M,
        selectedTab: k,
        setIsPlanLoading: n,
        shouldSplitBetweenPersonalAndBusiness: U,
        isProduceDesign: u,
        isEnterpriseEnabled: i
    });
    return j ? e.jsxs(L, {
        size: "fullscreen",
        isOpen: !0,
        onClose: p,
        type: "success",
        className: "flex flex-col",
        isProduceDesign: u,
        children: [e.jsxs("div", {
            className: "relative grid grid-cols-[1fr_auto_1fr] px-6 py-4 md:pb-10 md:pt-[4.5rem]",
            children: [e.jsx("div", {}), e.jsx("span", {
                className: "mb-1 mt-1 text-2xl font-semibold md:mb-0 md:mt-0 md:text-3xl",
                children: e.jsx(o, { ...qe.modalTitle
                })
            }), e.jsx("button", {
                className: "justify-self-end text-token-text-primary opacity-50 transition hover:opacity-75 md:absolute md:right-6 md:top-6",
                onClick: () => {
                    p()
                },
                children: e.jsx(ca, {
                    className: we({
                        "h-5 w-5": !D,
                        "icon-lg": D
                    })
                })
            })]
        }), s.isPersonalAccount() && U ? e.jsx("div", {
            className: "mb-3 flex justify-center md:mb-6",
            children: e.jsx("div", {
                className: "w-[fit-content]",
                children: e.jsx(At, {
                    value: k,
                    onChange: I
                })
            })
        }) : null, e.jsx("div", {
            children: e.jsx("div", {
                className: "flex flex-col justify-center gap-4 px-3 py-3 md:min-h-[30rem] md:flex-row md:gap-0 md:py-0",
                children: T
            })
        }), !i && e.jsxs("div", {
            className: "mb-12 mt-8 flex flex-col items-center justify-center gap-2 text-sm text-token-text-secondary md:mb-8 md:mt-8",
            children: [e.jsx(la, {}), e.jsxs("div", {
                className: "flex flex-col items-center justify-center",
                children: [e.jsx(o, { ...qe.needMoreCapabilities
                }), e.jsx("div", {
                    children: e.jsx(o, { ...qe.seeChatGptEnterprise,
                        values: {
                            link: v => e.jsx(se, {
                                target: "_blank",
                                to: zs,
                                onClick: () => {
                                    w.logEvent(A.clickSeeEnterpriseLink), ne.logEvent("chatgpt_account_payment_modal_enterprise_link_clicked")
                                },
                                className: "mx-1 underline",
                                children: v
                            })
                        }
                    })
                })]
            })]
        })]
    }) : e.jsx(L, {
        size: "custom",
        noPadding: !0,
        isOpen: !0,
        onClose: p,
        type: "success",
        className: we("focus-none !bg-transparent !shadow-none outline-none transition-width duration-0", T.length === 1 && "md:max-w-lg", T.length === 2 && "md:max-w-3xl", T.length === 3 && "md:max-w-5xl"),
        children: e.jsxs("div", {
            className: "popover relative flex grow flex-col items-start justify-center overflow-hidden rounded-md border border-token-border-light bg-token-main-surface-primary shadow-md",
            children: [e.jsxs("div", {
                className: "flex w-full flex-row items-center justify-between border-b border-token-border-light px-8 py-6",
                children: [e.jsx("span", {
                    className: "text-xl font-semibold",
                    children: e.jsx(o, { ...qe.modalTitle
                    })
                }), e.jsxs("div", {
                    className: "flex gap-4",
                    children: [s.isPersonalAccount() && U ? e.jsx(At, {
                        value: k,
                        onChange: I
                    }) : null, e.jsx(no, {
                        onClick: () => {
                            p()
                        }
                    })]
                })]
            }), U ? e.jsx(Xt, {
                children: e.jsx("div", {
                    className: "w-full",
                    children: e.jsx(ot.div, {
                        initial: {
                            opacity: 0
                        },
                        animate: {
                            opacity: 1
                        },
                        transition: {
                            duration: .2
                        },
                        exit: {
                            opacity: 0
                        },
                        children: e.jsx("div", {
                            className: "center flex flex-col md:min-h-[30rem] md:flex-row",
                            children: T
                        })
                    }, k)
                })
            }) : e.jsxs(e.Fragment, {
                children: [e.jsx("div", {
                    className: "flex w-full flex-col md:flex-row",
                    children: T
                }), e.jsx("div", {
                    className: "flex w-full items-center justify-center border-t border-token-border-light px-8 py-6",
                    children: e.jsx("div", {
                        className: "text-sm text-token-text-primary sm:flex sm:items-center",
                        children: e.jsx(o, { ...qe.modalFooterCapabilities,
                            values: {
                                link: v => e.jsx(se, {
                                    target: "_blank",
                                    to: zs,
                                    onClick: () => {
                                        w.logEvent(A.clickSeeEnterpriseLink), ne.logEvent("chatgpt_account_payment_modal_enterprise_link_clicked")
                                    },
                                    className: "mx-1 underline",
                                    children: v
                                })
                            }
                        })
                    })
                })]
            })]
        })
    })
}

function Ri({
    analyticsParams: s,
    currentAccount: t,
    isPlanLoading: a,
    isModalFullscreen: n,
    isTeamEnabled: i,
    selectedTab: l,
    setIsPlanLoading: r,
    shouldSplitBetweenPersonalAndBusiness: u,
    isProduceDesign: c,
    isEnterpriseEnabled: g
}) {
    const m = [],
        p = t.hasPaidSubscription();
    return u ? l === "personal" ? (p || m.push("free"), m.push("plus")) : (i && m.push("team"), (!n || g) && m.push("enterprise")) : (p || m.push("free"), t.isTeam() || m.push("plus"), i && m.push("team"), g && m.push("enterprise")), m.length === 0 && Se.addError(new Error("Account payment modal missing columns")), m.map(f => {
        switch (f) {
            case "free":
                return e.jsx(yi, {
                    isProduceDesign: c
                }, f);
            case "plus":
                return e.jsx(Fi, {
                    analyticsParams: s,
                    currentAccount: t,
                    setIsPlanLoading: r,
                    isPlanLoading: a,
                    isProduceDesign: c
                }, f);
            case "team":
                return e.jsx(Bi, {
                    analyticsParams: s,
                    isPlanLoading: a,
                    isProduceDesign: c
                }, f);
            case "enterprise":
                return e.jsx(bi, {
                    isProduceDesign: c
                }, f)
        }
    })
}
const qe = F({
    modalTitle: {
        id: "AccountPaymentModal.modalTitle",
        defaultMessage: "Upgrade your plan"
    },
    modalFooterCapabilities: {
        id: "AccountPaymentModal.modalFooterCapabilities",
        defaultMessage: "Need more capabilities? See <link> ChatGPT Enterprise </link>"
    },
    needMoreCapabilities: {
        id: "SdJWr7",
        defaultMessage: "Need more capabilities for your business?"
    },
    seeChatGptEnterprise: {
        id: "7C5fuF",
        defaultMessage: "See<link>ChatGPT Enterprise</link>"
    }
});

function Gi({
    workspaceName: s,
    onChangeWorkspaceName: t
}) {
    const a = y();
    return e.jsxs(e.Fragment, {
        children: [e.jsxs("div", {
            className: "mb-4 flex-wrap",
            children: [e.jsx("label", {
                htmlFor: "workspace-name",
                className: "block pb-1 text-lg font-semibold text-token-text-primary",
                children: e.jsx(o, { ...Ws.workspaceNameLabel
                })
            }), e.jsx("p", {
                className: "font-base text-sm text-token-text-secondary",
                children: e.jsx(o, { ...Ws.workspaceNameDescription
                })
            })]
        }), e.jsx(vs, {
            type: "text",
            name: "workspace-name",
            placeholder: a.formatMessage(Ws.exampleTeamWorkspaceName),
            value: s,
            onChange: n => t(n.target.value),
            maxLength: 64
        })]
    })
}
const Ws = F({
    workspaceNameLabel: {
        id: "createWorkspace.workspaceNameLabel",
        defaultMessage: "Workspace name"
    },
    workspaceNameDescription: {
        id: "createWorkspace.workspaceNameDescription",
        defaultMessage: "Set a workspace name for your team. The name can be changed at any time."
    },
    exampleTeamWorkspaceName: {
        id: "createWorkspace.exampleTeamWorkspaceName",
        defaultMessage: "Acme Inc."
    }
});
var ba = (s => (s.FLEXIBLE = "month", s.ANNUAL = "year", s))(ba || {});
const Hi = 25 * 12,
    Vi = 30,
    Ki = Xn(ba),
    zi = ({
        isOpen: s,
        onClose: t,
        onSubmit: a
    }) => {
        const [n, i] = d.useState(""), l = y();
        return e.jsxs(L, {
            type: "success",
            isOpen: s,
            onClose: t,
            className: "max-w-lg",
            showCloseButton: !0,
            title: e.jsx(o, { ...ee.createWorkspace
            }),
            children: [e.jsx("div", {
                className: "flex flex-col justify-center bg-token-main-surface-primary pb-2",
                children: e.jsx(Gi, {
                    workspaceName: n,
                    onChangeWorkspaceName: i
                })
            }), e.jsxs("div", {
                className: "mt-4 flex flex-row justify-end",
                children: [e.jsx(Gs, {
                    title: l.formatMessage(ee.cancel),
                    onClick: t
                }), e.jsx(Gs, {
                    title: l.formatMessage(ee.selectBillingOption),
                    onClick: () => {
                        a(n)
                    },
                    disabled: n == "",
                    color: "primary",
                    className: "ml-4"
                })]
            })]
        })
    },
    Yi = le.p `text-base font-semibold mb-3 mt-3`,
    $i = ({
        isOpen: s,
        onClose: t,
        onSubmit: a,
        minimumSeats: n
    }) => {
        const [i, l] = d.useState("year"), [r, u] = d.useState(!1), c = y(), [g, m] = d.useState(n), [p] = d.useState(new Date), f = Qi[i], h = n > Ys ? n : Ys;
        return e.jsx(L, {
            type: "success",
            isOpen: s,
            onClose: t,
            size: "custom",
            noPadding: !0,
            className: "max-w-3xl",
            showCloseButton: !0,
            title: c.formatMessage(ee.selectTeamPlanModalTitle),
            children: e.jsxs("div", {
                className: "grid grid-flow-row grid-cols-3",
                children: [e.jsxs(Fo, {
                    className: "col-span-3 grid md:col-span-2 md:grid-cols-2",
                    defaultValue: i,
                    onValueChange: j => {
                        Ki(j) && l(j)
                    },
                    children: [e.jsx(bt, {
                        billingType: "month",
                        ...Bo
                    }), e.jsx(bt, {
                        billingType: "year",
                        ...Oo
                    })]
                }), e.jsxs("div", {
                    className: "col-span-3 overflow-hidden border-l border-token-main-surface-tertiary bg-token-main-surface-secondary p-6 md:col-span-1",
                    children: [e.jsx("label", {
                        className: "mb-3 block text-base font-semibold",
                        htmlFor: "seats",
                        children: e.jsx(o, { ...ee.seatsTitle
                        })
                    }), e.jsx(Uo, {
                        numSeats: g,
                        minSeats: h,
                        setNumSeats: m
                    }), e.jsx(Wo, {}), e.jsx(Yi, {
                        children: e.jsx(o, { ...ee.summaryTitle
                        })
                    }), e.jsxs("div", {
                        className: "text-sm",
                        children: [e.jsx("p", {
                            className: "mb-2",
                            children: e.jsx(o, { ...f.name
                            })
                        }), e.jsxs(Ro, {
                            children: [e.jsx(Mt, {
                                children: e.jsx(o, { ...f.billed,
                                    values: {
                                        date: e.jsx(Xs, {
                                            value: p
                                        })
                                    }
                                })
                            }), e.jsx(Mt, {
                                children: e.jsx("b", {
                                    children: e.jsx(o, { ...f.total,
                                        values: {
                                            totalCost: (g || 0) * (i === "year" ? Hi : Vi)
                                        }
                                    })
                                })
                            })]
                        })]
                    }), e.jsx("div", {
                        className: "mt-4 flex justify-end",
                        children: e.jsx(Gs, {
                            title: c.formatMessage(ee.continueToBillingButton),
                            onClick: () => {
                                u(!0), a(i, g)
                            },
                            disabled: !1,
                            loading: r,
                            color: "primary"
                        })
                    })]
                })]
            })
        })
    };

function qi({
    isOpen: s,
    onClose: t,
    minimumSeats: a,
    existingAccount: n = void 0
}) {
    const i = y(),
        l = Q(),
        [r, u] = d.useState(n ? Io(i, n) : ""),
        c = Ts(),
        g = async (m, p) => {
            try {
                const f = await P.getCheckoutLink(c, {
                    plan_name: "chatgptteamplan",
                    team_plan_data: {
                        workspace_name: r,
                        price_interval: m,
                        seat_quantity: p,
                        existing_workspace_id: n ? .id
                    }
                });
                window.location.href = f.url
            } catch {
                l.warning(i.formatMessage(ee.paymentErrorWarning), {
                    hasCloseButton: !0
                })
            }
        };
    return r == "" ? e.jsx(zi, {
        isOpen: s,
        onClose: t,
        onSubmit: m => {
            u(m)
        }
    }) : e.jsx($i, {
        isOpen: s,
        onClose: t,
        onSubmit: (m, p) => {
            g(m, p)
        },
        minimumSeats: a
    })
}
const Qi = {
    month: {
        name: ee.flexiblePlanSelected,
        billed: ee.flexiblePlanBilled,
        total: ee.flexiblePlanTotal
    },
    year: {
        name: ee.annualPlanSelected,
        billed: ee.annualPlanBilled,
        total: ee.annualPlanTotal
    }
};

function Xi() {
    const {
        isUnauthenticated: s
    } = ws(), t = as(), {
        pathname: a,
        hash: n
    } = Kt(), i = $t(), l = Us(n) ? "3686510565" : "423371448", {
        config: r
    } = io(l), u = r.get("enabled", !1), c = Us(n) && u, g = (Oi(n) || Us(n)) && !s;
    return d.useEffect(() => {
        !c || !s || i({
            authType: "signup",
            callbackUrl: window.location.href
        })
    }, [c, s, i]), d.useEffect(() => {
        a.startsWith("/auth") || Ue.getCookie(We.ShowPaymentModal) && (Ue.deleteCookie(We.ShowPaymentModal), Go(t, "Show payment modal cookie"))
    }, []), d.useEffect(() => {
        g ? (J.closeAllActiveModals(), J.openModal(ie.AccountPayment)) : J.closeModal(ie.AccountPayment)
    }, [g]), {
        isOpen: g,
        isTeamAccountIntent: c
    }
}

function Ji(s) {
    return s.type === Re.GDRIVE_SYNC_CONNECTOR || s.type === Re.SLACK_SYNC_CONNECTOR ? `${window.location.origin}/ca/${s.id}/oauth/callback` : `${window.location.origin}/ccc/${s.id}/oauth/callback`
}
const Ma = ({
        entry: s,
        isConnected: t,
        onDisconnect: a,
        onConnect: n,
        redirectUri: i
    }) => t ? e.jsx(K, {
        onClick: () => a(s ? .type),
        color: "danger-outline",
        size: "small",
        children: e.jsx(o, { ...Pt.disconnect
        })
    }) : e.jsx(K, {
        onClick: () => n({
            id: s.id
        }, "settings_connected_apps", Ji(s), i),
        color: "secondary",
        size: "small",
        children: e.jsx(o, { ...Pt.connect
        })
    }),
    Pt = F({
        connect: {
            id: "connectorSettings.connect",
            defaultMessage: "Connect"
        },
        disconnect: {
            id: "connectorSettings.disconnect",
            defaultMessage: "Disconnect"
        }
    });

function Rs({
    entry: s,
    description: t
}) {
    let a;
    switch (s.type) {
        case $.GDRIVE:
            a = da;
            break;
        case $.O365:
        case $.O365_PERSONAL:
        case $.O365_BUSINESS:
            a = wn;
            break;
        case $.CONFLUENCE:
        case $.JIRA:
            a = Sn;
            break
    }
    const n = y();
    return e.jsx(E, {
        children: e.jsxs("div", {
            className: "flex flex-col gap-2 pb-1 pt-3",
            children: [e.jsxs("div", {
                className: "flex flex-row items-center gap-2",
                children: [e.jsx(a, {
                    className: "icon-lg"
                }), e.jsx("p", {
                    className: "text-md flex-1 font-semibold text-token-text-primary",
                    children: Ho(s.type, n)
                }), e.jsx(Ma, {
                    entry: s,
                    isConnected: !!s.access_token,
                    onDisconnect: Jt,
                    onConnect: Zt,
                    redirectUri: "#settings/ConnectorSettings"
                })]
            }), e.jsx("p", {
                className: "text-token-text-secondary",
                children: e.jsx(o, { ...t
                })
            })]
        })
    })
}

function Lt({
    type: s
}) {
    let t, a = Fe.googleDriveSyncName,
        n = Fe.googleDriveSyncDesc;
    switch (s) {
        case Re.GDRIVE_SYNC_CONNECTOR:
            t = da;
            break;
        case Re.SLACK_SYNC_CONNECTOR:
            t = g => e.jsx("img", {
                src: Ko,
                ...g
            }), a = Fe.slackSyncName, n = Fe.slackSyncDesc;
            break
    }
    const [i] = lo(), l = i.get("model") ? ? "gpt-4o-gdrive", r = y(), {
        connectors: u
    } = Vo([s]), c = u.get(s);
    return c ? e.jsx("div", {
        children: e.jsx(E, {
            children: e.jsxs("div", {
                className: "flex flex-col gap-2 pb-1 pt-3",
                children: [e.jsxs("div", {
                    className: "flex flex-row items-center gap-2",
                    children: [e.jsx(t, {
                        className: "icon-lg"
                    }), e.jsx("p", {
                        className: "text-md flex-1 font-semibold text-token-text-primary",
                        children: r ? .formatMessage(a)
                    }), e.jsx(Ma, {
                        entry: c,
                        isConnected: !!c.access_token,
                        onDisconnect: Jt,
                        onConnect: Zt,
                        redirectUri: `?model=${l}#settings/ConnectorSettings`
                    })]
                }), e.jsx("p", {
                    className: "text-xs text-token-text-secondary",
                    children: e.jsx(o, { ...n
                    })
                })]
            })
        })
    }) : null
}

function Zi() {
    return e.jsx("div", {
        children: e.jsxs(E, {
            children: [e.jsx("div", {
                className: "my-2 font-bold text-token-text-primary",
                children: e.jsx(o, { ...Fe.knowledgeDesc
                })
            }), e.jsx("p", {
                className: "text-token-text-secondary",
                children: e.jsx(o, { ...Fe.contextualAnswerDesc
                })
            })]
        })
    })
}
const Fe = F({
    knowledgeDesc: {
        id: "connectorSettings.knowledgeDesc.1",
        defaultMessage: "Knowledge"
    },
    contextualAnswerDesc: {
        id: "connectorSettings.contextualAnswerDesc.1",
        defaultMessage: "Add context to your ChatGPT's knowledge."
    },
    googleDriveSyncDesc: {
        id: "connectorSettings.googleDriveSyncDesc.1",
        defaultMessage: "Sync Google Docs, Sheets, Slides and other files to your ChatGPT workspace."
    },
    googleDriveSyncName: {
        id: "connectorSettings.googleDriveSyncName.1",
        defaultMessage: "Google Drive"
    },
    slackSyncDesc: {
        id: "connectorSettings.slackSyncDesc.1",
        defaultMessage: "Sync Slack public channels, private channels, and direct messages to your ChatGPT workspace."
    },
    slackSyncName: {
        id: "connectorSettings.slackSyncName.1",
        defaultMessage: "Slack"
    }
});

function el({
    clientApplications: s,
    isGdriveEnabled: t,
    isO365Enabled: a,
    isConfluenceEnabled: n,
    isJiraEnabled: i
}) {
    const {
        connectorConfig: l,
        isLoading: r
    } = ea();
    return r ? e.jsx("div", {
        className: "flex justify-center",
        children: e.jsx(He, {})
    }) : !l.size && !s ? .length ? e.jsx(Ns, {
        type: "info",
        children: e.jsx(o, { ...Ne.noConnectorSettings
        })
    }) : e.jsx(sl, {
        clientApplications: s,
        connectorConfig: l,
        isGdriveEnabled: t,
        isO365Enabled: a,
        isConfluenceEnabled: n,
        isJiraEnabled: i
    })
}

function sl({
    clientApplications: s,
    connectorConfig: t,
    isGdriveEnabled: a,
    isO365Enabled: n,
    isConfluenceEnabled: i,
    isJiraEnabled: l
}) {
    const r = t.get($.GDRIVE),
        u = t.get($.O365_PERSONAL),
        c = t.get($.O365_BUSINESS);
    t.get($.CONFLUENCE), t.get($.JIRA);
    const g = a && !!r,
        m = n && !!u,
        p = n && !!c,
        {
            config: f
        } = ro("1001765573"),
        h = f.get("ca_enabled", !1),
        j = f.get("ca_sk_enabled", !1),
        [M, k] = d.useState(!1),
        [B, D] = d.useState(!1),
        [U, I] = d.useState(!1);
    d.useEffect(() => {
        (async () => {
            if (h) try {
                const [re, me, he] = await Promise.all([P.checkOrgExist(), P.getKnowledgeStoreStatus("google_drive"), P.getKnowledgeStoreStatus("slack")]);
                k(re.exist), D(me.credential_type === "user_oauth"), I(he.credential_type === "user_oauth")
            } catch {
                k(!1), D(!1), I(!1)
            }
        })()
    }, [h]);
    const T = s ? .filter(({
            type: G
        }) => G === "apple"),
        v = M && (B || U);
    return e.jsxs("div", {
        className: "flex flex-col",
        children: [e.jsx(E, {
            children: e.jsx("div", {
                className: "my-2",
                children: e.jsx(o, { ...Ne.connectorsTitle
                })
            })
        }), r && g && e.jsx(Rs, {
            entry: r,
            description: Ne.googleDriveDesc
        }), u && m && e.jsx(Rs, {
            entry: u,
            description: Ne.o365Desc
        }), c && p && e.jsx(Rs, {
            entry: c,
            description: Ne.o365BusinessDesc
        }), !1, !1, T && e.jsx(tl, {
            clientApplications: T
        }), h && v && e.jsxs(e.Fragment, {
            children: [e.jsx(Zi, {}), B && e.jsx(Lt, {
                type: Re.GDRIVE_SYNC_CONNECTOR
            }), j && U && e.jsx(Lt, {
                type: Re.SLACK_SYNC_CONNECTOR
            })]
        })]
    })
}

function tl({
    clientApplications: s
}) {
    const {
        mutate: t,
        isPending: a
    } = zo();
    return e.jsx(e.Fragment, {
        children: s.map(n => e.jsx(al, {
            clientApplication: n,
            disabled: a,
            onDisconnect: () => {
                w.logEventWithStatsig(A.connectorSettingsClientApplicationDisconnectButtonClicked, "chatgpt_connector_settings_client_application_disconnect_button_clicked", {
                    id: n.id,
                    name: n.name,
                    type: n.type
                }), t(n.id)
            }
        }, n.id))
    })
}

function al({
    clientApplication: s,
    disabled: t,
    onDisconnect: a
}) {
    return e.jsx(E, {
        children: e.jsxs("div", {
            className: "flex flex-col gap-2 pb-1 pt-3",
            children: [e.jsxs("div", {
                className: "flex flex-row items-center gap-2",
                children: [e.jsx(Tn, {
                    className: "icon-lg"
                }), e.jsx("p", {
                    className: "text-md flex-1 font-semibold text-token-text-primary",
                    children: s.name
                }), e.jsx(K, {
                    onClick: a,
                    color: "danger-outline",
                    size: "small",
                    disabled: t,
                    children: e.jsx(o, { ...Ne.disconnect
                    })
                })]
            }), e.jsx("p", {
                className: "text-token-text-secondary",
                children: e.jsx(o, { ...Ne.appleDesc
                })
            })]
        })
    })
}
const Ne = F({
    connectorsTitle: {
        id: "connectorSettings.connectorsTitle",
        defaultMessage: "Connect apps to access their information in ChatGPT."
    },
    googleDriveDesc: {
        id: "connectorSettings.googleDriveDesc.1",
        defaultMessage: "Upload Google Docs, Sheets, Slides and other files."
    },
    o365Desc: {
        id: "connectorSettings.o365Desc.1",
        defaultMessage: "Upload Microsoft Word, Excel, PowerPoint and other files."
    },
    o365BusinessDesc: {
        id: "connectorSettings.o365BusinessDesc.1",
        defaultMessage: "Upload Microsoft Word, Excel, PowerPoint, and other files, including those from SharePoint sites."
    },
    noConnectorSettings: {
        id: "connectorSettings.noConnectorSettings",
        defaultMessage: "Unable to get connected apps"
    },
    appleDesc: {
        id: "P5OVxG",
        defaultMessage: "Get personalized ChatGPT responses and Plus benefits when using Siri and Writing Tools."
    },
    disconnect: {
        id: "connectorSettings.disconnectButton",
        defaultMessage: "Disconnect"
    }
});

function ol() {
    return new URL(window.location.href).searchParams.get("disable_mfa") != null
}

function nl({
    onClose: s,
    onConfirm: t
}) {
    const a = y();
    return e.jsx(sa, {
        isOpen: !0,
        title: a.formatMessage(Dt.disableConfimationTitle),
        confirmText: a.formatMessage(Dt.disable),
        onConfirm: t,
        onClose: s,
        primaryButtonColor: "danger",
        children: e.jsx("div", {
            children: e.jsx(o, {
                id: "postSigninDisableConfimationModal.description.1",
                defaultMessage: "Are you sure you want to disable multi-factor authentication? You will no longer need to provide a verification code when you log into your account."
            })
        })
    })
}

function il(s) {
    const t = s.map(a => it[a]).filter(a => a !== void 0);
    return t.length === 1 ? t[0] : e.jsx(o, {
        id: "confirmEnableMfaForByPassModal.otherAccount",
        defaultMessage: "another account"
    })
}

function ll({
    mfaInfo: s,
    onEnableMFA: t,
    onCancel: a
}) {
    const n = y(),
        {
            session: i
        } = As(),
        r = i ? .user ? .idp,
        u = (r ? it[r] : void 0) ? ? e.jsx(o, {
            id: "confirmEnableMfaForByPassModal.yourAccount",
            defaultMessage: "your current account"
        }),
        c = il(s.otherProvidersWithoutMfa ? ? []);
    return e.jsx(sa, {
        isOpen: !0,
        title: n.formatMessage({
            id: "confirmEnableMfaForByPassModal.title",
            defaultMessage: "Enable multi-factor authentication (MFA)"
        }),
        confirmText: n.formatMessage({
            id: "confirmEnableMfaForByPassModal.enableMfa",
            defaultMessage: "Enable MFA"
        }),
        onConfirm: t,
        onClose: a,
        primaryButtonColor: "primary",
        children: e.jsxs("div", {
            children: [e.jsx("p", {
                className: "mb-6",
                children: e.jsx(o, {
                    id: "confirmEnableMfaForByPassModal.description0",
                    defaultMessage: "You'll only be able to log in using {currentIdp} while MFA is on.",
                    values: {
                        currentIdp: u
                    }
                })
            }), e.jsx("p", {
                children: e.jsx(o, {
                    id: "confirmEnableMfaForByPassModal.description1",
                    defaultMessage: "If you prefer to have MFA enabled for your account when logging in with {otherNonMfaIdp}, please sign out and log in again through that method before enabling.",
                    values: {
                        otherNonMfaIdp: c
                    }
                })
            })]
        })
    })
}
const Dt = F({
    disableConfimationTitle: {
        id: "mfaDisableConfirmationModal.title.0",
        defaultMessage: "Disable multi-factor authentication (MFA)"
    },
    disable: {
        id: "mfaDisableConfirmationModal.button",
        defaultMessage: "Disable MFA"
    }
});

function ya() {
    const {
        theme: s,
        setTheme: t
    } = co(), a = y();
    return e.jsxs("div", {
        className: "flex items-center justify-between",
        children: [e.jsx("div", {
            children: e.jsx(o, { ...fs.theme
            })
        }), e.jsx(Jn, {
            value: s,
            onValueChange: n => t(n),
            options: [{
                label: a.formatMessage(fs.system),
                value: "system"
            }, {
                label: a.formatMessage(fs.dark),
                value: "dark"
            }, {
                label: a.formatMessage(fs.light),
                value: "light"
            }]
        })]
    })
}
const fs = F({
    theme: {
        id: "settingsModal.theme",
        defaultMessage: "Theme"
    },
    system: {
        id: "settingsModal.system",
        defaultMessage: "System"
    },
    dark: {
        id: "settingsModal.dark",
        defaultMessage: "Dark"
    },
    light: {
        id: "settingsModal.light",
        defaultMessage: "Light"
    }
});
async function rl() {
    let s;
    "keyboard" in navigator && (s = navigator.keyboard);
    const t = await s ? .getLayoutMap() ? ? new Map;
    return s ? .lock && await s ? .lock(), new Promise(a => {
        const n = new Set,
            i = new Set;
        let l = !0;
        const r = f => {
                const h = It(f, t);
                h && !n.has(h) && (n.add(h), i.add(h))
            },
            u = f => {
                const h = It(f, t);
                h && n.delete(h), n.size === 0 && l && m()
            },
            c = f => {
                l && (g(), a(void 0))
            },
            g = () => {
                window.removeEventListener("keydown", r), window.removeEventListener("keyup", u), window.removeEventListener("mousedown", c), window.removeEventListener("click", c), window.removeEventListener("blur", c), clearTimeout(p), s ? .unlock && s ? .unlock(), l = !1
            },
            m = () => {
                g();
                const f = cl(Array.from(i));
                a(ja({
                    webKeys: f
                }))
            };
        window.addEventListener("keydown", r), window.addEventListener("keyup", u), window.addEventListener("mousedown", c), window.addEventListener("click", c), window.addEventListener("blur", c);
        const p = setTimeout(() => {
            l && (g(), a(void 0))
        }, 1e4)
    })
}

function cl(s) {
    return s.toSorted((t, a) => {
        const n = Object.values(Ss).indexOf(t),
            i = n === -1 ? Number.MAX_SAFE_INTEGER : n,
            l = Object.values(Ss).indexOf(a),
            r = l === -1 ? Number.MAX_SAFE_INTEGER : l;
        return i === r ? t.charCodeAt(0) - a.charCodeAt(0) : i - r
    })
}
const dl = s => /^[a-zA-Z]$/.test(s);

function It(s, t) {
    const a = t.get(s.code) ? ? s.key;
    let n;
    return b[s.key] ? n = b[s.key] : dl(a) ? n = a.toUpperCase() : n = a, n
}

function ja(s) {
    return s.webKeys ? (s.electronAcceleratorKeys = s.webKeys.map(gl), s.electronAcceleratorString = Ft(s.electronAcceleratorKeys)) : s.electronAcceleratorKeys ? (s.webKeys = s.electronAcceleratorKeys.map(ul), s.electronAcceleratorString = Ft(s.electronAcceleratorKeys)) : s = {
        webKeys: [],
        electronAcceleratorKeys: [],
        electronAcceleratorString: void 0
    }, s
}

function ul(s) {
    return Ss[s] ? ? s
}

function gl(s) {
    return fl[s] ? ? s
}

function va(s) {
    const t = new Set(Object.keys(Ca)),
        a = s.filter(i => !t.has(i)).length,
        n = s.length - a;
    return a === 1 && n > 0
}
const ml = s => {
        const t = s.split("+");
        return va(t) ? t : void 0
    },
    Ft = s => va(s) ? s.join("+") : void 0,
    Ca = {
        Meta: b.Meta,
        CmdOrCtrl: b.Mod,
        CommandOrControl: b.Mod,
        Ctrl: b.Control,
        Control: b.Control,
        Cmd: b.Mod,
        Command: b.Mod,
        Alt: b.Alt,
        Option: b.Alt,
        AltGr: b.AltGraph,
        Shift: b.Shift,
        Super: b.Super
    },
    Ss = { ...Ca,
        Capslock: b.CapsLock,
        Space: b.Space,
        Tab: b.Tab,
        Numlock: b.NumLock,
        Scrolllock: b.ScrollLock,
        Backspace: b.Backspace,
        Delete: b.Delete,
        Insert: b.Insert,
        Return: b.Enter,
        Enter: b.Enter,
        Home: b.Home,
        End: b.End,
        PageUp: b.PageUp,
        PageDown: b.PageDown,
        Up: b.ArrowUp,
        Down: b.ArrowDown,
        Left: b.ArrowLeft,
        Right: b.ArrowRight,
        Esc: b.Escape,
        Escape: b.Escape,
        VolumeUp: b.AudioVolumeUp,
        VolumeDown: b.AudioVolumeDown,
        VolumeMute: b.AudioVolumeMute,
        MediaNextTrack: b.MediaTrackNext,
        MediaPreviousTrack: b.MediaTrackPrevious,
        MediaStop: b.MediaStop,
        MediaPlayPause: b.MediaPlayPause,
        PrintScreen: b.PrintScreen,
        numadd: b.Add,
        numsub: b.Subtract,
        nummult: b.Multiply,
        numdiv: b.Divide,
        numdec: b.Decimal,
        F1: b.F1,
        F2: b.F2,
        F3: b.F3,
        F4: b.F4,
        F5: b.F5,
        F6: b.F6,
        F7: b.F7,
        F8: b.F8,
        F9: b.F9,
        F10: b.F10,
        F11: b.F11,
        F12: b.F12,
        F13: b.F13,
        F14: b.F14,
        F15: b.F15,
        F16: b.F16,
        F17: b.F17,
        F18: b.F18,
        F19: b.F19,
        F20: b.F20
    },
    fl = Object.fromEntries(Object.entries(Ss).map(([s, t]) => [t, s]));

function pl() {
    const s = ta(),
        t = ka(),
        a = Sa();
    return s && (t || a)
}

function xl() {
    return e.jsxs(e.Fragment, {
        children: [e.jsx(bl, {}), e.jsx(yl, {}), e.jsx(jl, {})]
    })
}

function ka() {
    const {
        value: s
    } = Js("2923133196");
    return s
}
async function hl() {
    await Ze ? .checkForUpdates()
}

function bl() {
    const s = ka(),
        [t, a] = d.useState(!1);
    return s && e.jsx(e.Fragment, {
        children: e.jsx(E, {
            children: e.jsx(ae, {
                label: e.jsx(o, { ...ke.updatesSettingLabel
                }),
                disabled: t,
                buttonLabel: t ? e.jsx(o, { ...ke.updateInProgressButtonLabel
                }) : e.jsx(o, { ...ke.updateButtonLabel
                }),
                onClick: async () => {
                    try {
                        a(!0), await hl()
                    } catch (n) {
                        Se.addError(new Error("Sidetron Settings: Error checking for updates"), {
                            cause: n
                        })
                    } finally {
                        a(!1)
                    }
                },
                description: e.jsx(o, { ...ke.updateSettingDescription,
                    values: {
                        version: uo(navigator.userAgent) ? ? "Unknown"
                    }
                })
            })
        })
    })
}
const Ml = async () => {
    let s = "";
    const t = await Ze ? .getSettingValue("companionWindowShortcut");
    t ? s = t : Se.addError(new Error("Sidetron Settings: No companion chat hotkey found over IPC"));
    const a = ml(s);
    return Promise.resolve(ja({
        electronAcceleratorKeys: a
    }))
};

function Sa() {
    const {
        value: s
    } = Js("603035019");
    return s
}

function yl() {
    const s = Sa(),
        [t, a] = d.useState(!1),
        [n, i] = d.useState(void 0);
    return d.useEffect(() => {
        (async () => {
            const r = await Ml();
            i(r)
        })()
    }, []), d.useEffect(() => {
        Ze ? .publish(xt.HOTKEY_RECORDING_STATE, {
            inProgress: t
        })
    }, [t]), s && e.jsx(e.Fragment, {
        children: e.jsx(E, {
            children: e.jsx(ae, {
                label: e.jsx(o, { ...ke.companionChatHotkeyLabel
                }),
                disabled: n === void 0 || t,
                buttonLabel: t ? e.jsx(o, { ...ke.companionChatHotkeyRecordingLabel
                }) : n ? e.jsx(vl, {
                    keyboardBinding: n.webKeys
                }) : e.jsx(o, { ...ke.companionChatHotkeyLoadingLabel
                }),
                onClick: async () => {
                    a(!0);
                    const l = await rl();
                    l ? l.electronAcceleratorString ? (i(l), Ze && (Ze.publish(xt.DESKTOP_SETTING_CHANGED, {
                        setting: "companionWindowShortcut",
                        value: l.electronAcceleratorString
                    }), Se.addAction(`Sidetron Settings: User recorded a new hotkey: ${l.electronAcceleratorString}`))) : Se.addError(new Error(`Sidetron Settings: Invalid companion chat hotkey registered: ${l}`)) : Se.addAction("Sidetron Settings: User did not record a hotkey"), a(!1)
                }
            })
        })
    })
}

function jl() {
    return e.jsx(e.Fragment, {
        children: e.jsx(E, {
            children: e.jsx(ya, {})
        })
    })
}

function vl({
    keyboardBinding: s
}) {
    return e.jsx(e.Fragment, {
        children: Yo(s).map((t, a) => e.jsxs("span", {
            className: "text-xs",
            children: [t, a < s.length - 1 && e.jsx(Cl, {})]
        }, a))
    })
}

function Cl() {
    return e.jsx("span", {
        className: "mx-1",
        children: e.jsx(o, { ...ke.hotkeySeparator
        })
    })
}
const ke = F({
    updatesSettingLabel: {
        id: "desktopAppSettingsModal.updatesSettingLabel",
        defaultMessage: "App updates"
    },
    updateButtonLabel: {
        id: "desktopAppSettingsModal.updateButtonLabel",
        defaultMessage: "Check for updates"
    },
    updateInProgressButtonLabel: {
        id: "desktopAppSettingsModal.updateInProgressButtonLabel",
        defaultMessage: "Checking for updates..."
    },
    updateSettingDescription: {
        id: "desktopAppSettingsModal.updateSettingDescription",
        defaultMessage: "Current version: {version}"
    },
    companionChatHotkeyLabel: {
        id: "desktopAppSettingsModal.companionChatHotkeyLabel",
        defaultMessage: "Companion window hotkey"
    },
    companionChatHotkeyLoadingLabel: {
        id: "desktopAppSettingsModal.companionChatHotkeyLoadingLabel",
        defaultMessage: "Loading..."
    },
    companionChatHotkeyRecordingLabel: {
        id: "desktopAppSettingsModal.companionChatHotkeyRecordingLabel",
        defaultMessage: "Recording..."
    },
    hotkeySeparator: {
        id: "desktopAppSettingsModal.hotkeySeparator",
        defaultMessage: "+"
    }
});

function kl() {
    const t = Ts() ? .includes(zt);
    return Ge({
        queryKey: ["mfaInfo"],
        queryFn: () => P.getMfaInfo(),
        enabled: t
    })
}
var Y = (s => (s.DISABLED = "DISABLED", s.ENABLED = "ENABLED", s.LOADING = "LOADING", s))(Y || {});

function Sl() {
    const s = kl();
    let t;
    return s.isLoading ? t = "LOADING" : s.data ? .mfa_enabled ? t = "ENABLED" : t = "DISABLED", {
        status: t,
        otherProvidersWithoutMfa: s.data ? .other_providers_without_mfa,
        use_native_mfa: !!s.data ? .use_native_mfa,
        native_default_factor_id: s.data ? .native_default_factor_id,
        auth0_user_exists: !!s.data ? .auth0_user_exists
    }
}
const wl = new Set(["google-oauth2", "windowslive", "apple"]),
    Tl = "Username-Password-Authentication",
    Al = 4 * 60;

function ps(s) {
    return s ? .idp && wl.has(s.idp) ? {
        connection: s.idp,
        login_hint: s.email
    } : s ? .idp === "auth0" ? {
        connection: Tl,
        login_hint: s.email
    } : s ? .email ? {
        login_hint: s.email
    } : {}
}

function Bt(s) {
    if (!s) throw new Error("No session found, cannot enable MFA");
    if (s.authProvider === "mocked") throw new Error("Mock users can't enable MFA! Please setup Auth0 following the instructions in the README")
}

function Ot(s) {
    try {
        return ei(s)
    } catch {
        throw new Error("Unable to decode access token")
    }
}

function El(s) {
    return s.pwd_auth_time
}

function Ut(s) {
    const t = El(s);
    if (!t) return !0;
    const a = t / 1e3;
    return Date.now() / 1e3 - a > Al
}

function Nl(s) {
    return s[go] ? .required === "yes"
}

function _l(s) {
    return s === je.OpenAI ? je.LoginWebAuth0 : s === je.OpenAIDev ? je.LoginWebAuth0Dev : s === je.OpenAISidetron ? je.Auth0Sidetron : s === je.OpenAISidetronDev ? je.Auth0SidetronDev : s
}

function Pl(s) {
    const {
        session: t
    } = As(), a = as(), n = t ? .user ? .idp === "auth0", i = !!t ? .user ? .mfa, l = t ? .authProvider ? _l(t ? .authProvider) : void 0, {
        useNativeProvider: r,
        auth0UserExists: u
    } = s, c = d.useCallback(async () => {
        Bt(t);
        const m = new URL("/auth/enroll_mfa", window.location.origin).toString();
        let p = !0;
        if (t ? .accessToken) {
            const h = Ot(t.accessToken);
            p = Ut(h) || !u
        }
        if (r && p) {
            rs.signIn(l, {
                callbackUrl: m
            }, {
                max_age: "0",
                ...ds(cs()),
                ...ps(t ? .user)
            });
            return
        }
        if (r) {
            window.location.href = m;
            return
        }
        const f = new URL(Hs(Vs.MFA_ENABLED, "/#settings/Security"), location.origin).toString();
        rs.signIn(l, {
            callbackUrl: f
        }, { ...ps(t ? .user),
            max_age: "0",
            oai_enforce_mfa: "true",
            ...ds(cs())
        })
    }, [t, r, u, l]), g = d.useCallback(async () => {
        Bt(t);
        const m = new URL("/auth/disable_mfa", window.location.origin).toString();
        let p = !0;
        if (t ? .accessToken) {
            const f = Ot(t.accessToken);
            p = Ut(f) || !Nl(f)
        }
        if (r && p) {
            rs.signIn(t ? .authProvider, {
                callbackUrl: m
            }, {
                max_age: "0",
                ...ps(t ? .user),
                ...ds(cs())
            });
            return
        }
        if (r) {
            a("/?disable_mfa=true#settings/Security");
            return
        }
        rs.signIn(t ? .authProvider, {
            callbackUrl: m
        }, { ...ps(t ? .user),
            max_age: "0",
            ...ds(cs())
        })
    }, [t, a, r]);
    return {
        setupMfa: c,
        isUsernamePassword: n,
        isLoggedInWithMfa: i,
        removeMfa: g
    }
}
const Ll = () => {
    const {
        openSettings: s
    } = os();
    return e.jsx("button", {
        onClick: () => s(H.BuilderProfile),
        children: e.jsx(ua, {
            className: "icon-sm"
        })
    })
};

function Dl({
    gizmoId: s,
    gizmoName: t,
    gizmoAvatar: a,
    canEdit: n,
    socials: i
}) {
    const {
        data: l,
        isLoading: r
    } = at();
    return r ? null : l ? e.jsxs(e.Fragment, {
        children: [n && s && e.jsx("span", {
            className: "absolute right-2 top-2",
            children: e.jsx(Ll, {})
        }), e.jsx($o, {
            src: a,
            isFirstParty: !1,
            className: "h-8 w-8"
        }), e.jsx("div", {
            className: "mt-1 text-center text-sm font-semibold text-token-text-primary",
            children: t
        }), e.jsx(qo, {
            builderName: l.display_name,
            builderUrl: l.website_url,
            socials: i,
            className: "text-xs"
        })]
    }) : e.jsx(Ns, {
        type: "info",
        children: e.jsx(o, {
            id: "gizmo.builderProfile.unableToLoadProfile",
            defaultMessage: "Unable to load your builder profile"
        })
    })
}

function Il() {
    const {
        data: s,
        isLoading: t
    } = at(), a = ge();
    return t ? e.jsx("div", {
        className: "flex justify-center",
        children: e.jsx(He, {})
    }) : s === void 0 || a ? .canInteractWithGizmos() === !1 ? e.jsx(Ns, {
        type: "info",
        children: e.jsx(o, { ...V.noCreatorProfile
        })
    }) : e.jsx(Ol, {
        data: s
    })
}

function Fl({
    gizmoName: s,
    canEdit: t,
    gizmoAvatar: a
}) {
    const n = y(),
        {
            openSettings: i
        } = os(),
        {
            data: l
        } = at();
    return l ? e.jsxs("div", {
        className: "relative flex w-full flex-col items-center justify-stretch rounded-lg bg-token-main-surface-primary p-4",
        children: [e.jsx(Dl, {
            gizmoAvatar: a,
            gizmoName: s ? ? n.formatMessage(V.placeholderGPT),
            canEdit: t,
            socials: [l.socials.linkedin, l.socials.github, l.socials.twitter]
        }), e.jsx("div", {
            className: "absolute right-4 top-3 text-xs text-token-text-tertiary",
            children: t ? e.jsx("button", {
                onClick: () => {
                    i(H.BuilderProfile)
                },
                children: e.jsx(ua, {
                    className: "icon-sm"
                })
            }) : e.jsx(o, { ...V.preview
            })
        })]
    }) : null
}

function Bl(s, t) {
    if (s.website_url && t.length > 0) {
        const a = t.find(n => n.url === s.website_url);
        return a ? a.hostname : t[0].hostname
    } else {
        if (t.length > 0) return t[0].hostname;
        if (s.website_url) return
    }
}

function Ol({
    data: s
}) {
    const t = y(),
        a = Qo(),
        n = ge() ? .isEnterprisey(),
        i = ge() ? .isWorkspaceAccount(),
        l = et(),
        r = s.domains.reduce((p, f) => f.status === "verified" ? [...p, {
            id: f.id,
            hostname: f.hostname,
            url: f.hostname
        }] : p, []),
        u = Bl(s, r),
        {
            value: c
        } = Js("2256850471"),
        g = s.name == null || a.isPending,
        m = e.jsx(ks, {
            size: "small",
            onChange: p => {
                a.mutateAsync({
                    hideName: !p
                })
            },
            disabled: g,
            enabled: !s.hide_name,
            label: s.hide_name ? t.formatMessage(V.showNameToggle) : t.formatMessage(V.hideNameToggle)
        });
    return e.jsxs("div", {
        className: "flex flex-col items-stretch",
        children: [e.jsx("div", {
            className: "mb-2",
            children: e.jsx(o, { ...V.creatorProfileDescription
            })
        }), e.jsx(Fl, {
            canEdit: !1
        }), e.jsx(E, {
            children: e.jsxs("div", {
                className: "flex flex-col",
                children: [!s.is_verified && e.jsxs(Ns, {
                    type: "info",
                    children: [e.jsx("div", {
                        children: e.jsx(o, { ...V.creatorProfileUnverifiedDisclaimer
                        })
                    }), e.jsx("div", {
                        children: i ? e.jsx(o, { ...V.creatorProfileBusinessUnverifiedDisclaimer
                        }) : e.jsx(o, { ...V.creatorProfilePersonalUnverifiedDisclaimer
                        })
                    })]
                }), s.name && e.jsxs("div", {
                    className: "mt-4 flex flex-col gap-2",
                    children: [e.jsxs("div", {
                        className: "flex flex-row justify-between",
                        children: [e.jsx("b", {
                            children: e.jsx(o, { ...V.creatorProfileNameLabel
                            })
                        }), g ? e.jsx(ue, {
                            side: "left",
                            label: t.formatMessage(V.linkDisabledTooltip),
                            children: m
                        }) : m]
                    }), e.jsxs("div", {
                        className: "flex flex-row items-center space-x-2",
                        children: [e.jsx("span", {
                            children: s.name
                        }), e.jsx(ue, {
                            side: "top",
                            className: "ml-auto",
                            label: t.formatMessage(V.nameSourceReason),
                            children: e.jsx(ga, {
                                className: "icon-sm text-token-text-tertiary"
                            })
                        })]
                    })]
                }), !n && e.jsxs("div", {
                    className: "flex flex-col justify-center gap-2",
                    children: [e.jsx("hr", {
                        className: "my-3 border-token-border-light"
                    }), e.jsx("div", {
                        className: "flex flex-row justify-between",
                        children: e.jsx("b", {
                            children: e.jsx(o, { ...V.creatorProfileLinkHeader
                            })
                        })
                    }), e.jsxs("div", {
                        className: "flex flex-row items-center justify-between space-x-2",
                        children: [e.jsx($s, {
                            className: "icon-sm"
                        }), e.jsx("div", {
                            children: e.jsx(Xo, {
                                selectedDomain: u,
                                domains: s.domains,
                                verifiedDomains: r,
                                onChangeDomain: p => {
                                    a.mutateAsync({
                                        websiteUrl: p
                                    })
                                }
                            })
                        })]
                    }), c && e.jsxs(e.Fragment, {
                        children: [e.jsx(Os, {
                            socialData: s.socials.linkedin,
                            icon: An
                        }), e.jsx(Os, {
                            socialData: s.socials.github,
                            icon: En
                        }), e.jsx(Os, {
                            socialData: s.socials.twitter,
                            icon: Nn
                        })]
                    })]
                }), !n && l && e.jsxs("div", {
                    className: "flex flex-col justify-center gap-2",
                    children: [e.jsx("hr", {
                        className: "my-3 border-token-border-light"
                    }), e.jsx("div", {
                        className: "flex flex-row justify-between",
                        children: e.jsx("b", {
                            children: e.jsx(o, { ...V.creatorProfileEmailHeader
                            })
                        })
                    }), e.jsxs("div", {
                        className: "my-1 flex flex-row items-center space-x-2",
                        children: [e.jsx(_n, {
                            className: "icon-sm"
                        }), e.jsx("span", {
                            children: l.email
                        })]
                    }), e.jsx(ue, {
                        label: t.formatMessage(V.feedbackEmailTooltip),
                        children: e.jsx(aa, {
                            className: "rounded-xl",
                            id: "receive-support-emails",
                            onChange: p => {
                                a.mutateAsync({
                                    willReceiveSupportEmails: p.currentTarget.checked
                                })
                            },
                            checked: s.will_receive_support_emails,
                            label: t.formatMessage(V.receiveFeedbackEmails)
                        })
                    })]
                })]
            })
        })]
    })
}
const V = F({
    gizmoTab: {
        id: "settingsModal.gizmoTab",
        defaultMessage: "Builder profile"
    },
    creatorProfileDescription: {
        id: "settingsModal.creatorProfileDescription",
        defaultMessage: "Personalize your builder profile to connect with users of your GPTs. These settings apply to publicly shared GPTs."
    },
    creatorProfileUnverifiedDisclaimer: {
        id: "settingsModal.createrProfileUnverifiedDisclaimer",
        defaultMessage: "Complete verification to publish GPTs to everyone."
    },
    creatorProfilePersonalUnverifiedDisclaimer: {
        id: "settingsModal.creatorProfilePersonalUnverifiedDisclaimer",
        defaultMessage: "Verify your identity by adding billing details or verifying ownership of a public domain name."
    },
    creatorProfileBusinessUnverifiedDisclaimer: {
        id: "settingsModal.creatorProfileBusinessUnverifiedDisclaimer",
        defaultMessage: "Contact your workspace administrator to set up a builder profile"
    },
    creatorProfileNameLabel: {
        id: "settingsModal.creatorProfileNameLabel",
        defaultMessage: "Name"
    },
    placeholderGPT: {
        id: "settingsModal.placeholderGPT",
        defaultMessage: "PlaceholderGPT"
    },
    byName: {
        id: "settingsModal.byName",
        defaultMessage: "by {name}"
    },
    preview: {
        id: "settingsModal.preview",
        defaultMessage: "Preview"
    },
    noCreatorProfile: {
        id: "settingsModal.noCreatorProfile",
        defaultMessage: "Unable to retrieve builder profile"
    },
    creatorProfileLinkHeader: {
        id: "settingsModal.creatorProfileLinkHeader.1",
        defaultMessage: "Links"
    },
    creatorProfileEmailHeader: {
        id: "settingsModal.creatorProfileEmailHeader.0",
        defaultMessage: "Email"
    },
    nameDisabledTooltip: {
        id: "settingsModal.nameDisabledTooltip",
        defaultMessage: "You must have a verified name to enable displaying a name"
    },
    linkDisabledTooltip: {
        id: "settingsModal.linkDisabledTooltip",
        defaultMessage: "You must have a verified domain to enable displaying a link"
    },
    addDomain: {
        id: "settingsModal.addDomain",
        defaultMessage: "Verify new domain"
    },
    nameSourceReason: {
        id: "settingsModal.nameSourceReason",
        defaultMessage: "Name is populated from your billing details"
    },
    hideNameToggle: {
        id: "settingsModal.hideNameToggle",
        defaultMessage: "Hide your name in your builder profile"
    },
    showNameToggle: {
        id: "settingsModal.showNameToggle",
        defaultMessage: "Show your name in your builder profile"
    },
    hideWebsiteToggle: {
        id: "settingsModal.hideWebsiteToggle",
        defaultMessage: "Hide your website in your builder profile"
    },
    showWebsiteToggle: {
        id: "settingsModal.showWebsiteToggle",
        defaultMessage: "Show your website in your builder profile"
    },
    feedbackEmailTooltip: {
        id: "settingsModal.feedbackEmailTooltip",
        defaultMessage: "Allow users of your GPTs to send feedback to your ChatGPT login email. Your email will never be shared publicly."
    },
    receiveFeedbackEmails: {
        id: "settingsModal.receiveFeedbackEmails.1",
        defaultMessage: "Receive feedback emails"
    }
});

function Ul() {
    return e.jsx(o, { ...V.gizmoTab
    })
}
const wa = ["archivedConversations"],
    Wl = 30,
    Rl = 3;

function Gl({
    conversation: s,
    elementRef: t,
    closeParentModal: a
}) {
    const n = y(),
        i = Q(),
        l = Ve(),
        {
            mutate: r,
            isPending: u
        } = Es({
            mutationFn: async ({
                conversationId: p,
                ...f
            }) => P.patchConversation(p, f),
            onSettled: () => {
                l.invalidateQueries({
                    queryKey: [wa]
                }), l.invalidateQueries({
                    queryKey: [Jo]
                })
            },
            onError: () => {
                i.danger(n.formatMessage(oe.deleteFailed))
            }
        }),
        [c, g] = d.useState(!1),
        m = `/c/${s.id}`;
    return e.jsxs(e.Fragment, {
        children: [e.jsxs(O.Row, {
            disabled: u,
            children: [e.jsx(O.Cell, {
                children: e.jsxs("a", {
                    href: m,
                    rel: "noreferrer",
                    className: "inline-flex items-center gap-2 align-top text-blue-500 dark:text-blue-400",
                    ref: t,
                    children: [e.jsx(ma, {
                        className: "icon-md flex-shrink-0"
                    }), s.title]
                })
            }), e.jsx(O.Cell, {
                children: s.create_time != null ? e.jsx(Xs, {
                    value: s.create_time,
                    month: "long",
                    year: "numeric",
                    day: "numeric"
                }) : null
            }), e.jsx(O.Cell, {
                textAlign: "right",
                children: e.jsxs(O.Actions, {
                    children: [e.jsx(ue, {
                        label: n.formatMessage(oe.unarchiveConversation),
                        sideOffset: 4,
                        side: "top",
                        children: e.jsx("button", {
                            "aria-label": n.formatMessage(oe.unarchiveConversation),
                            className: "cursor-pointer text-[18px] text-token-text-tertiary hover:text-token-text-secondary",
                            onClick: () => {
                                r({
                                    conversationId: s.id,
                                    is_archived: !1
                                })
                            },
                            children: e.jsx(Pn, {
                                className: "icon-sm"
                            })
                        })
                    }), e.jsx(ue, {
                        label: n.formatMessage(oe.deleteConversation),
                        sideOffset: 4,
                        side: "top",
                        children: e.jsx("button", {
                            onClick: () => g(!0),
                            "aria-label": n.formatMessage(oe.deleteConversation),
                            className: "text-token-text-tertiary hover:text-token-text-secondary",
                            children: e.jsx(fa, {
                                className: "icon-sm"
                            })
                        })
                    })]
                })
            })]
        }), c && e.jsx(Zo, {
            title: s.title,
            handleDelete: () => {
                r({
                    conversationId: s.id,
                    is_visible: !1
                })
            },
            onClose: () => {
                g(!1), a()
            }
        })]
    })
}

function Hl({
    onClose: s
}) {
    const {
        data: t,
        isLoading: a,
        isError: n,
        refetch: i,
        fetchNextPage: l,
        hasNextPage: r
    } = mo({
        queryKey: [wa],
        queryFn: ({
            pageParam: f
        }) => P.getConversations({
            offset: f,
            limit: Wl,
            isArchived: !0
        }),
        initialPageParam: 0,
        getNextPageParam: f => {
            const h = f.offset + f.limit;
            return h < f.total ? h : void 0
        },
        refetchOnMount: "always"
    }), u = d.useRef(null), c = d.useCallback(f => {
        a || f == null || (u.current ? .disconnect(), u.current = new IntersectionObserver(h => {
            h[0].isIntersecting && r && l()
        }), u.current.observe(f))
    }, [a, r, l]);
    d.useEffect(() => () => {
        u.current ? .disconnect()
    }, []);
    const g = d.useMemo(() => t ? .pages.flatMap(f => f.items) ? ? [], [t]),
        m = y();
    let p;
    return a ? p = e.jsx("div", {
        className: "pb-8 text-token-text-secondary",
        children: e.jsx(o, { ...oe.loading
        })
    }) : n ? p = e.jsxs("div", {
        children: [e.jsx("div", {
            className: "mb-4 text-red-500",
            children: e.jsx(o, { ...oe.somethingWentWrong
            })
        }), e.jsx("div", {
            children: e.jsx(K, {
                color: "secondary",
                onClick: () => {
                    i()
                },
                children: e.jsx(o, { ...oe.retry
                })
            })
        })]
    }) : g.length === 0 ? p = e.jsx("div", {
        className: "pb-8 text-token-text-tertiary",
        children: e.jsx(o, { ...oe.noArchivedConversations
        })
    }) : p = e.jsxs(O.Root, {
        className: "max-h-[28rem]",
        size: "compact",
        children: [e.jsxs(O.Header, {
            children: [e.jsx(O.HeaderCell, {
                children: e.jsx(o, { ...oe.name
                })
            }), e.jsx(O.HeaderCell, {
                children: e.jsx(o, { ...oe.dateCreated
                })
            }), e.jsx(O.HeaderCell, {})]
        }), e.jsx(O.Body, {
            children: g.map((f, h) => e.jsx(Gl, {
                conversation: f,
                elementRef: h === g.length - Rl ? c : void 0,
                closeParentModal: s
            }, f.id))
        })]
    }), e.jsx(L, {
        isOpen: !0,
        onClose: s,
        size: "custom",
        className: "max-w-5xl",
        type: "success",
        title: m.formatMessage(oe.title),
        showCloseButton: !0,
        children: p
    })
}
const oe = F({
        name: {
            id: "archivedConversationsModal.name",
            defaultMessage: "Name"
        },
        dateCreated: {
            id: "archivedConversationsModal.dateCreated",
            defaultMessage: "Date created"
        },
        loading: {
            id: "archivedConversationsModal.loading",
            defaultMessage: "Loading..."
        },
        somethingWentWrong: {
            id: "archivedConversationsModal.somethingWentWrong",
            defaultMessage: "Something went wrong..."
        },
        retry: {
            id: "archivedConversationsModal.retry",
            defaultMessage: "Retry"
        },
        noArchivedConversations: {
            id: "archivedConversationsModal.noArchivedConversations",
            defaultMessage: "You have no archived conversations."
        },
        title: {
            id: "archivedConversationsModal.title",
            defaultMessage: "Archived Chats"
        },
        unarchiveConversation: {
            id: "archivedConversationsModal.unarchiveConversation",
            defaultMessage: "Unarchive conversation"
        },
        deleteConversation: {
            id: "archivedConversationsModal.deleteConversation",
            defaultMessage: "Delete conversation"
        },
        deleteFailed: {
            id: "archivedConversationsModal.deleteFailed",
            defaultMessage: "Deleting failed"
        }
    }),
    Ta = en.FirstTimeUsingUserContext;

function Vl() {
    const {
        eligible: s
    } = oa(Ta);
    return s
}
const Kl = ({
        onClose: s
    }) => {
        const t = y(),
            {
                markAsViewed: a
            } = oa(Ta),
            n = d.useCallback(() => {
                a(), s()
            }, [a, s]);
        return e.jsxs(L, {
            isOpen: !0,
            onClose: qs,
            size: "custom",
            className: "max-w-xl",
            type: "success",
            title: t.formatMessage(Qe.title),
            primaryButton: e.jsx(R.Button, {
                onClick: n,
                title: t.formatMessage(Qe.ok),
                color: "primary"
            }),
            children: [e.jsxs("div", {
                className: "mb-6 flex flex-col gap-3",
                children: [e.jsx("p", {
                    children: e.jsx(o, { ...Qe.body1
                    })
                }), e.jsx("p", {
                    children: e.jsx(o, { ...Qe.body2
                    })
                })]
            }), e.jsx("div", {
                className: "flex flex-col gap-3 text-sm text-token-text-tertiary",
                children: e.jsx("p", {
                    children: e.jsx(o, { ...Qe.legal1,
                        values: {
                            article: i => e.jsx("a", {
                                href: pa,
                                target: "_blank",
                                className: "underline",
                                rel: "noopener noreferrer",
                                children: i
                            })
                        }
                    })
                })
            })]
        })
    },
    Qe = F({
        title: {
            id: "UserContextFirstTimeModal.title",
            defaultMessage: "Introducing Custom Instructions"
        },
        body1: {
            id: "UserContextFirstTimeModal.body1",
            defaultMessage: "Customize your interactions with ChatGPT by providing specific details and guidelines for your chats."
        },
        body2: {
            id: "UserContextFirstTimeModal.body2",
            defaultMessage: "Whenever you edit your custom instructions, they'll take effect in all new chats you create. Existing chats won't be updated."
        },
        legal1: {
            id: "UserContextFirstTimeModal.legal1",
            defaultMessage: "Your instructions will be used to make our models better unless you've opted out and may be shared with any plugins you've enabled. Visit our <article>Help Center</article> to learn more."
        },
        ok: {
            id: "UserContextFirstTimeModal.ok",
            defaultMessage: "OK"
        }
    });

function zl({
    onSuccess: s,
    onError: t
}) {
    const a = Ve();
    return Es({
        mutationFn: ({
            userContext: n
        }) => P.createOrUpdateUserSystemMessage(n),
        onSettled: (n, i) => {
            const l = ["userContext"];
            n !== null && !i ? a.setQueryData(l, n) : a.invalidateQueries({
                queryKey: l
            })
        },
        onSuccess: s,
        onError: t
    })
}

function Aa(s) {
    const t = y(),
        a = Q();
    return Ge({
        queryKey: ["userContext"],
        queryFn: () => P.getUserSystemMessage().catch(n => {
            throw a.danger(t.formatMessage({
                id: "userContextModal.getCustomInstructionsError",
                defaultMessage: "Failed to get your settings"
            })), n
        }),
        enabled: s,
        select: n => ({
            aboutUserMessage: n ? .about_user_message ? ? "",
            aboutModelMessage: n ? .about_model_message ? ? "",
            disabledTools: n ? .disabled_tools ? ? [],
            enabled: n ? .enabled ? ? !0
        })
    })
}
const Wt = {
    aboutUserMessage: void 0,
    aboutModelMessage: void 0,
    disabledTools: void 0,
    enabled: void 0
};

function Yl({
    isModalOpen: s
}) {
    const t = y(),
        a = Q(),
        n = Vl(),
        [i, l] = d.useState(!1),
        {
            isLoading: r,
            data: u
        } = Aa(s),
        {
            aboutUserMessage: c = "",
            aboutModelMessage: g = "",
            disabledTools: m = [],
            enabled: p
        } = u ? ? {},
        [f, h] = d.useState(Wt),
        {
            aboutUserMessage: j,
            aboutModelMessage: M,
            disabledTools: k,
            enabled: B
        } = f,
        D = B ? ? !!p,
        [U, I] = d.useState(null),
        T = d.useCallback(() => {
            J.closeModal(ie.UserContext), h(Wt), I(null)
        }, []),
        {
            isPending: v,
            mutate: G
        } = zl({
            onSuccess: () => {
                T()
            },
            onError: _ => (_.response ? .reason === "content_policy" && _.response ? .field ? I(_.response ? .field) : a.danger(t.formatMessage({
                id: "userContextModal.saveError",
                defaultMessage: "Failed to update settings"
            })), _)
        }),
        [re, me] = d.useState(!1),
        he = Je(j ? ? "") || Je(M ? ? ""),
        z = M !== void 0 && M !== g || j !== void 0 && j !== c || k !== void 0 && !fo(k, m) || B !== void 0 && B !== p,
        Me = d.useCallback(() => {
            z ? me(!0) : T()
        }, [T, z]),
        _e = d.useCallback(async () => {
            v || (I(null), G({
                userContext: {
                    aboutUserMessage: j ? ? "",
                    aboutModelMessage: M ? ? "",
                    disabledTools: k ? ? [],
                    enabled: !!B
                }
            }))
        }, [v, M, j, k, B, G]),
        N = d.useCallback(() => {
            if (he) {
                const _ = Je(j ? ? ""),
                    W = Je(M ? ? "");
                _ && (ne.logEvent("chatgpt_user_context_modal__message_past_limit", void 0, {
                    type: "about_user_message",
                    limit: Ee.toString(),
                    character_length: j ? .length.toString() ? ? ""
                }), w.logEvent(A.userContextModelMessagePastLimit, {
                    type: "about_user_message",
                    limit: Ee.toString(),
                    character_length: j ? .length.toString() ? ? ""
                })), W && (ne.logEvent("chatgpt_user_context_modal__message_past_limit", void 0, {
                    type: "about_model_message",
                    limit: Ee.toString(),
                    character_length: M ? .length.toString() ? ? ""
                }), w.logEvent(A.userContextModelMessagePastLimit, {
                    type: "about_model_message",
                    limit: Ee.toString(),
                    character_length: M ? .length.toString() ? ? ""
                })), a.danger(t.formatMessage(S.messageLimitError, {
                    limit: Ee
                }), {
                    duration: 4,
                    hasCloseButton: !0
                });
                return
            }
            _e()
        }, [t, he, M, j, _e, a]);
    if (s && n && !i) return e.jsx(Kl, {
        onClose: () => {
            l(!0)
        }
    });
    if (s && re) {
        const _ = () => {
            me(!1)
        };
        return e.jsx(L, {
            isOpen: !0,
            onClose: _,
            type: "success",
            title: t.formatMessage(S.confirmCloseTitle),
            primaryButton: e.jsx(R.Button, {
                title: t.formatMessage(S.confirmCloseOk),
                color: "danger",
                onClick: () => {
                    T(), _()
                }
            }),
            secondaryButton: e.jsx(R.Button, {
                title: t.formatMessage(S.confirmCloseCancel),
                color: "secondary",
                onClick: _
            }),
            children: e.jsx("div", {
                className: "text-sm",
                children: e.jsx(o, { ...S.confirmCloseBody
                })
            })
        }, "confirm-close")
    }
    return e.jsxs(L, {
        isOpen: s,
        onClose: Me,
        type: "success",
        size: "custom",
        className: "max-w-lg xl:max-w-xl",
        title: e.jsx(o, { ...S.profileTitle
        }),
        children: [r ? e.jsx("div", {
            className: "flex h-14 items-center justify-center",
            children: e.jsx(He, {})
        }) : e.jsxs("div", {
            className: "max-h-[60vh] overflow-y-auto md:max-h-[calc(100vh-300px)]",
            children: [e.jsxs("div", {
                className: "flex items-center gap-1",
                children: [e.jsx("div", {
                    className: "text-sm font-semibold",
                    children: e.jsx(o, { ...S.customInstructionsTitle
                    })
                }), e.jsx(Ea, {
                    label: e.jsx(o, { ...S.customInstructionsTooltip,
                        values: {
                            article: _ => e.jsx("a", {
                                href: pa,
                                target: "_blank",
                                className: "underline",
                                rel: "noreferrer",
                                children: _
                            })
                        }
                    })
                })]
            }), e.jsx("p", {
                className: "text-muted pb-3 pt-2 text-sm text-token-text-primary",
                children: e.jsx(o, { ...S.aboutYouHelpText
                })
            }), e.jsx(Gt, {
                className: "mb-3",
                onSubmit: N,
                disabled: !D,
                tip: e.jsx(Rt, {
                    children: e.jsxs("ul", {
                        className: "list-disc pl-5",
                        children: [e.jsx("li", {
                            children: e.jsx(o, { ...S.aboutUserTip1
                            })
                        }), e.jsx("li", {
                            children: e.jsx(o, { ...S.aboutUserTip2
                            })
                        }), e.jsx("li", {
                            children: e.jsx(o, { ...S.aboutUserTip3
                            })
                        }), e.jsx("li", {
                            children: e.jsx(o, { ...S.aboutUserTip4
                            })
                        }), e.jsx("li", {
                            children: e.jsx(o, { ...S.aboutUserTip5
                            })
                        })]
                    })
                }),
                hasModError: U === "about_user_message",
                value: j ? ? c,
                onChange: _ => h(W => ({
                    aboutModelMessage: W.aboutModelMessage ? ? g,
                    aboutUserMessage: _.target.value,
                    enabled: W.enabled ? ? D,
                    disabledTools: W.disabledTools ? ? m
                }))
            }), e.jsx("p", {
                className: "text-muted py-3 text-sm text-token-text-primary",
                children: e.jsx(o, { ...S.modelHelpText
                })
            }), e.jsx(Gt, {
                onSubmit: N,
                disabled: !D,
                tip: e.jsx(Rt, {
                    children: e.jsxs("ul", {
                        className: "list-disc pl-5",
                        children: [e.jsx("li", {
                            children: e.jsx(o, { ...S.modelTip1
                            })
                        }), e.jsx("li", {
                            children: e.jsx(o, { ...S.modelTip2
                            })
                        }), e.jsx("li", {
                            children: e.jsx(o, { ...S.modelTip3
                            })
                        }), e.jsx("li", {
                            children: e.jsx(o, { ...S.modelTip4
                            })
                        })]
                    })
                }),
                hasModError: U === "about_model_message",
                value: M ? ? g,
                onChange: _ => h(W => ({
                    aboutUserMessage: W.aboutUserMessage ? ? c,
                    aboutModelMessage: _.target.value,
                    enabled: W.enabled ? ? D,
                    disabledTools: W.disabledTools ? ? m
                }))
            }), e.jsx("div", {
                className: "my-6 h-px bg-token-border-light"
            }), e.jsx($l, {
                disabledTools: f.disabledTools ? ? m ? ? [],
                onDisabledToolsChanged: _ => h(W => ({
                    aboutUserMessage: W.aboutUserMessage ? ? c,
                    aboutModelMessage: W.aboutModelMessage ? ? g,
                    enabled: W.enabled ? ? D,
                    disabledTools: _
                }))
            })]
        }), e.jsx("div", {
            className: "mt-4 md:mt-5",
            children: e.jsxs("div", {
                className: "flex flex-grow flex-col items-stretch justify-between gap-0 sm:flex-row sm:items-center sm:gap-3",
                children: [e.jsxs("label", {
                    className: "mt-5 flex cursor-pointer flex-row justify-between gap-2 sm:mt-4",
                    children: [e.jsx("div", {
                        className: "self-center text-sm text-token-text-primary",
                        children: e.jsx(o, { ...S.chatPreferencesEnable
                        })
                    }), e.jsx(ks, {
                        enabled: D,
                        onChange: _ => {
                            h(W => ({
                                aboutUserMessage: W.aboutUserMessage ? ? c,
                                aboutModelMessage: W.aboutModelMessage ? ? g,
                                enabled: _,
                                disabledTools: W.disabledTools ? ? m
                            }))
                        },
                        label: D ? t.formatMessage(S.disableToggleLabel) : t.formatMessage(S.enableToggleLabel)
                    })]
                }), e.jsx(R.Actions, {
                    secondaryButton: e.jsx(R.Button, {
                        onClick: Me,
                        children: e.jsx(o, { ...S.cancel
                        })
                    }),
                    primaryButton: e.jsx(R.Button, {
                        loading: v,
                        onClick: N,
                        color: "primary",
                        visuallyDisabled: he,
                        disabled: !z,
                        children: e.jsx(o, { ...S.save
                        })
                    })
                })]
            })
        })]
    }, "user-context")
}
const Rt = ({
        children: s
    }) => e.jsx("div", {
        className: "whitespace-pre-line",
        children: s
    }),
    Ee = 1500,
    Je = s => s.length > Ee,
    Gt = ({
        disabled: s,
        onChange: t,
        onSubmit: a,
        placeholder: n,
        value: i,
        tip: l,
        hasModError: r,
        className: u
    }) => {
        const c = y(),
            g = d.useRef(null),
            m = sn(),
            p = tn(),
            f = !m,
            [h, j] = d.useState(!1),
            [M, k] = d.useState(f),
            B = !f && h && !M,
            D = f && !M,
            U = Je(i),
            I = v => {
                !s && v.key === "Enter" && v.metaKey && !v.shiftKey && !v.nativeEvent.isComposing && (v.preventDefault(), a())
            },
            T = d.useRef(null);
        return e.jsxs(e.Fragment, {
            children: [e.jsx(L, {
                isOpen: D,
                type: "success",
                size: "custom",
                className: "max-w-lg",
                title: c.formatMessage(S.tipsHeader),
                showCloseButton: !0,
                onClose: () => {
                    k(!0)
                },
                children: l
            }), e.jsxs(an, {
                open: B,
                children: [e.jsxs("div", {
                    className: u,
                    ref: T,
                    children: [e.jsx(on, {
                        asChild: !0,
                        children: e.jsx("textarea", {
                            ref: g,
                            className: we("w-full resize-none rounded bg-token-main-surface-primary p-4 placeholder:text-gray-300", {
                                "border-orange-400 focus:border-orange-400": r,
                                "border-red-500 focus:border-red-500": U && !r,
                                "focus-token-border-heavy border-token-border-light": !U && !r,
                                "opacity-30": s
                            }),
                            disabled: s,
                            placeholder: n,
                            onKeyDown: I,
                            rows: m && !p ? 6 : 5,
                            value: i,
                            onChange: t,
                            onBlur: () => {
                                j(!1)
                            },
                            onFocus: () => {
                                j(!0)
                            }
                        })
                    }), e.jsx("div", {
                        className: we("flex items-center justify-between px-1 text-xs tabular-nums", U ? "text-red-600" : "text-token-text-tertiary"),
                        children: r ? e.jsx("div", {
                            className: "visible mt-2 text-left text-xs text-orange-400",
                            children: e.jsx(o, { ...S.modApiVoilation,
                                values: {
                                    policyLink: v => e.jsx("a", {
                                        href: "https://platform.openai.com/docs/usage-policies/content-policy",
                                        className: "underline",
                                        target: "_blank",
                                        rel: "noreferrer",
                                        children: v
                                    }),
                                    feedbackLink: v => e.jsx("a", {
                                        href: "https://forms.gle/3gyAMj5r5rTEcgbs5",
                                        className: "underline",
                                        target: "_blank",
                                        rel: "noreferrer",
                                        children: v
                                    })
                                }
                            })
                        }) : e.jsxs(e.Fragment, {
                            children: [e.jsx("div", {
                                children: `${i.length}/${Ee}`
                            }), e.jsx("button", {
                                className: "flex items-center gap-1",
                                onClick: () => {
                                    g.current ? .focus(), k(!M)
                                },
                                tabIndex: -1,
                                children: e.jsx(Xt, {
                                    initial: !1,
                                    children: h && e.jsx(ot.div, {
                                        className: "flex items-center gap-1",
                                        initial: {
                                            opacity: 0
                                        },
                                        animate: {
                                            opacity: 1,
                                            transition: {
                                                duration: .2,
                                                ease: "easeIn"
                                            }
                                        },
                                        exit: {
                                            opacity: 0,
                                            transition: {
                                                duration: .2,
                                                ease: "easeIn"
                                            }
                                        },
                                        children: M ? e.jsxs(e.Fragment, {
                                            children: [e.jsx(o, { ...S.showTips
                                            }), e.jsx(Ln, {
                                                className: "icon-xs"
                                            })]
                                        }) : e.jsxs(e.Fragment, {
                                            children: [e.jsx(o, { ...S.hideTips
                                            }), e.jsx(Dn, {
                                                className: "icon-xs"
                                            })]
                                        })
                                    }, "show-hide")
                                })
                            })]
                        })
                    })]
                }), e.jsx(nn, {
                    container: T.current ? .ownerDocument.body,
                    children: e.jsx(ln, {
                        side: "right",
                        align: "start",
                        sideOffset: 12,
                        className: "popover relative z-50 max-w-[220px] animate-slideLeftAndFade select-none rounded-xl border border-token-border-light bg-token-main-surface-primary p-4 text-sm text-token-text-primary shadow-[0px_4px_14px_rgba(0,0,0,0.06)] xl:max-w-xs",
                        onOpenAutoFocus: v => {
                            v.preventDefault()
                        },
                        onCloseAutoFocus: v => {
                            v.preventDefault()
                        },
                        children: e.jsxs("div", {
                            className: "flex flex-col gap-1",
                            children: [e.jsx("strong", {
                                children: e.jsx(o, { ...S.tipsHeader
                                })
                            }), l]
                        })
                    })
                })]
            })]
        })
    };

function Ea({
    label: s,
    side: t = "bottom"
}) {
    return e.jsx(ue, {
        sideOffset: 4,
        interactive: !0,
        label: e.jsx("div", {
            children: s
        }),
        side: t,
        children: e.jsx(ga, {
            className: "h-4 w-4 text-token-text-tertiary"
        })
    })
}

function $l({
    disabledTools: s,
    onDisabledToolsChanged: t
}) {
    d.useEffect(() => {
        w.logEvent(A.userContextGpt4CapabilitiesShown)
    }, []);
    const n = ge() ? .isEnterprisey() ? ? !1,
        i = !po(Ms.BrowsingAvailable) && n,
        l = c => {
            const g = s.includes(c) ? s.filter(m => m !== c) : [...s, c];
            t(g)
        },
        r = Ts();
    var u;
    return r ? .includes(Ms.SearchTool) && !r ? .includes(Ms.SearchToolHoldout) ? u = e.jsx(xs, {
        title: e.jsx(o, {
            id: "userContextModal.tools.web",
            defaultMessage: "Web Search"
        }),
        tooltipLabel: i ? e.jsx(o, {
            id: "Osf0vy",
            defaultMessage: "Web Search is disabled by your organization"
        }) : e.jsx(o, {
            id: "userContexModal.tools.webSearchTooltip",
            defaultMessage: "Automatically search the web to get answers"
        }),
        tool: ve.BROWSER,
        onClick: l,
        Icon: $s,
        checked: !s.includes(ve.BROWSER) && !i,
        disabled: i
    }) : u = e.jsx(xs, {
        title: e.jsx(o, {
            id: "userContextModal.tools.browse",
            defaultMessage: "Browsing"
        }),
        tooltipLabel: i ? e.jsx(o, {
            id: "5SuA2c",
            defaultMessage: "Browsing is disabled by your organization"
        }) : e.jsx(o, {
            id: "userContexModal.tools.browserTooltip",
            defaultMessage: "Browse the internet to find answers"
        }),
        tool: ve.BROWSER,
        onClick: l,
        Icon: $s,
        checked: !s.includes(ve.BROWSER) && !i,
        disabled: i
    }), e.jsxs("div", {
        className: "flex flex-col gap-2",
        children: [e.jsxs("div", {
            className: "flex items-center gap-1",
            children: [e.jsx("div", {
                className: "text-sm font-semibold",
                children: e.jsx(o, {
                    id: "userContextModal.gpt4CapabilitiesTitle",
                    defaultMessage: "GPT-4 Capabilities"
                })
            }), e.jsx(Ea, {
                label: e.jsx(o, {
                    id: "userContextModal.tools.capabilitiesInfo.1",
                    defaultMessage: "Choose which tools can be used with GPT-4"
                }),
                side: "top"
            })]
        }), e.jsxs("div", {
            className: "mt-2 flex flex-col gap-3 md:flex-row",
            children: [u, e.jsx(xs, {
                title: e.jsx(o, {
                    id: "userContextModal.tools.dalle",
                    defaultMessage: "DALL·E"
                }),
                tooltipLabel: e.jsx(o, {
                    id: "userContextModal.tools.dalleTooltip",
                    defaultMessage: "Generate images using DALL·E"
                }),
                tool: ve.DALLE,
                onClick: l,
                Icon: In,
                checked: !s.includes(ve.DALLE)
            }), e.jsx(xs, {
                title: e.jsx(o, {
                    id: "userContextModal.tools.codeInterpreter.1",
                    defaultMessage: "Code"
                }),
                tooltipLabel: e.jsx(o, {
                    id: "userContextModal.tools.codeInterpreterTooltip",
                    defaultMessage: "Execute code using Code Interpreter"
                }),
                tool: ve.PYTHON,
                onClick: l,
                Icon: Fn,
                checked: !s.includes(ve.PYTHON)
            })]
        })]
    })
}

function xs({
    tool: s,
    title: t,
    tooltipLabel: a,
    Icon: n,
    onClick: i,
    checked: l,
    disabled: r
}) {
    return e.jsx(ue, {
        className: "block flex-1",
        label: a,
        side: "top",
        sideOffset: 4,
        children: e.jsxs("button", {
            className: we("flex w-full items-center justify-between rounded border border-token-border-medium p-2", {
                "cursor-not-allowed text-token-text-quaternary": r
            }),
            onClick: () => i(s),
            disabled: r,
            children: [e.jsxs("div", {
                className: "flex items-center gap-2",
                children: [e.jsx(n, {
                    className: "h-4 w-4 text-token-text-tertiary"
                }), e.jsx("div", {
                    className: "text-sm font-semibold",
                    children: t
                })]
            }), e.jsx(aa, {
                id: s,
                checked: l && !r,
                disabled: r
            })]
        })
    })
}
const S = F({
    tipsHeader: {
        id: "userContextModal.tipsHeader",
        defaultMessage: "Thought starters"
    },
    aboutUserTip1: {
        id: "userContextModal.aboutUserTip1",
        defaultMessage: "Where are you based?"
    },
    aboutUserTip2: {
        id: "userContextModal.aboutUserTip2",
        defaultMessage: "What do you do for work?"
    },
    aboutUserTip3: {
        id: "userContextModal.aboutUserTip3",
        defaultMessage: "What are your hobbies and interests?"
    },
    aboutUserTip4: {
        id: "userContextModal.aboutUserTip4",
        defaultMessage: "What subjects can you talk about for hours?"
    },
    aboutUserTip5: {
        id: "userContextModal.aboutUserTip5",
        defaultMessage: "What are some goals you have?"
    },
    modelTip1: {
        id: "userContextModal.modelTip1",
        defaultMessage: "How formal or casual should ChatGPT be?"
    },
    modelTip2: {
        id: "userContextModal.modelTip2",
        defaultMessage: "How long or short should responses generally be?"
    },
    modelTip3: {
        id: "userContextModal.modelTip3",
        defaultMessage: "How do you want to be addressed?"
    },
    modelTip4: {
        id: "userContextModal.modelTip4",
        defaultMessage: "Should ChatGPT have opinions on topics or remain neutral?"
    },
    save: {
        id: "userContextModal.save",
        defaultMessage: "Save"
    },
    chatPreferencesEnable: {
        id: "userContextModal.chatPreferencesEnable",
        defaultMessage: "Enable for new chats"
    },
    enableToggleLabel: {
        id: "userContextModal.enableToggleLabel",
        defaultMessage: "Enable chat preferences"
    },
    disableToggleLabel: {
        id: "userContextModal.disableToggleLabel",
        defaultMessage: "Disable chat preferences"
    },
    cancel: {
        id: "userContextModal.cancel",
        defaultMessage: "Cancel"
    },
    aboutYouHelpText: {
        id: "userContextModal.aboutYouHelpText",
        defaultMessage: "What would you like ChatGPT to know about you to provide better responses?"
    },
    modelHelpText: {
        id: "userContextModal.modelHelpText",
        defaultMessage: "How would you like ChatGPT to respond?"
    },
    profileTitle: {
        id: "userContextModal.title.1",
        defaultMessage: "Customize ChatGPT"
    },
    customInstructionsTitle: {
        id: "userContextModal.customInstructionsTitle",
        defaultMessage: "Custom Instructions"
    },
    customInstructionsTooltip: {
        id: "userContextModal.customInstructionsTooltip",
        defaultMessage: "<article>Learn more</article> about Custom Instructions and how they’re used to help ChatGPT provide better responses."
    },
    messageLimitError: {
        id: "userContextModal.messageLimitError",
        defaultMessage: "Please limit your responses to {limit} characters or less."
    },
    showTips: {
        id: "userContextModal.showTips",
        defaultMessage: "Show tips"
    },
    hideTips: {
        id: "userContextModal.hideTips",
        defaultMessage: "Hide tips"
    },
    confirmCloseTitle: {
        id: "userContextModal.confirmCloseTitle",
        defaultMessage: "You have unsaved changes."
    },
    confirmCloseBody: {
        id: "userContextModal.confirmCloseBody",
        defaultMessage: "Are you sure you want to exit? Any changes you made will be permanently lost."
    },
    confirmCloseCancel: {
        id: "userContextModal.confirmCloseCancel",
        defaultMessage: "Back"
    },
    confirmCloseOk: {
        id: "userContextModal.confirmCloseOk",
        defaultMessage: "Exit"
    },
    modApiVoilation: {
        id: "userContextModal.modApiVoilation",
        defaultMessage: "This content may violate our <policyLink>content policy</policyLink>. If you believe this to be in error, please <feedbackLink>submit your feedback</feedbackLink> — your input will aid our research in this area."
    },
    browser: {
        id: "userContexModal.tools.browserTooltip",
        defaultMessage: "Browse the internet to find answers"
    },
    dalle: {
        id: "userContexModal.tools.dalleTooltip",
        defaultMessage: "Generate images using DALL·E"
    },
    python: {
        id: "userContexModal.tools.codeInterpreterTooltip",
        defaultMessage: "Execute code using Code Interpreter"
    }
});

function hs({
    children: s
}) {
    return e.jsxs("li", {
        children: ["“", s, "”"]
    })
}

function ql() {
    const [s, t] = d.useState(!1), a = y(), n = rn(), {
        isLoading: i,
        data: l
    } = Aa(!0), r = Zs(), {
        data: u
    } = cn(void 0, !1, n);
    return i ? e.jsx("div", {
        className: "flex justify-center",
        children: e.jsx(He, {})
    }) : e.jsxs(e.Fragment, {
        children: [e.jsx(E, {
            children: e.jsx(na, {
                label: e.jsx(o, { ...ce.customInstructions
                }),
                stateLabel: l ? .enabled ? a.formatMessage(ce.on) : a.formatMessage(ce.off),
                onClick: () => J.openModal(ie.UserContext)
            })
        }), e.jsxs(E, {
            children: [e.jsx(_s, {
                label: a.formatMessage(ce.toggleLabel),
                enabled: n,
                onChange: c => {
                    r.mutate({
                        setting: ts.Sunshine,
                        value: c
                    })
                },
                description: e.jsxs(e.Fragment, {
                    children: [e.jsx("p", {
                        children: e.jsx(o, { ...ce.exampleDescription1,
                            values: {
                                link: c => e.jsx("a", {
                                    href: "https://help.openai.com/en/articles/8590148-memory-in-chatgpt-faq",
                                    target: "_blank",
                                    className: "underline",
                                    rel: "noreferrer",
                                    children: c
                                })
                            }
                        })
                    }), e.jsx("p", {
                        className: "mt-3",
                        children: e.jsx(o, { ...ce.exampleDescription2
                        })
                    }), e.jsxs("ul", {
                        className: "my-2 flex list-disc flex-col gap-1 pl-5",
                        children: [e.jsx(hs, {
                            children: e.jsx(o, { ...ce.exampleMessage1
                            })
                        }), e.jsx(hs, {
                            children: e.jsx(o, { ...ce.exampleMessage2
                            })
                        }), e.jsx(hs, {
                            children: e.jsx(o, { ...ce.exampleMessage3
                            })
                        }), e.jsx(hs, {
                            children: e.jsx(o, { ...ce.exampleMessage4
                            })
                        })]
                    })]
                })
            }), e.jsxs("div", {
                className: "mt-4 flex items-center gap-2",
                children: [e.jsx(K, {
                    onClick: () => {
                        t(!0), w.logEvent(A.memorySettingsManageClicked)
                    },
                    color: "secondary",
                    children: e.jsx(o, { ...ce.manageMemoriesButton
                    })
                }), e.jsx(si, {
                    memoryFullPct: u ? .memoryFullPct
                }), s && e.jsx(ti, {
                    onClose: () => t(!1)
                })]
            })]
        }), e.jsx("span", {
            children: e.jsx(ai, {
                memoryName: "ChatGPT"
            })
        })]
    })
}
const ce = F({
        toggleLabel: {
            id: "settingsModal.myChagtGptToggleLabel.2",
            defaultMessage: "Memory"
        },
        exampleDescription1: {
            id: "settingsModal.exampleDescription1.1",
            defaultMessage: "ChatGPT will become more helpful as you chat, picking up on details and preferences to tailor its responses to you. <link>Learn more</link>"
        },
        exampleDescription2: {
            id: "settingsModal.exampleDescription2.2",
            defaultMessage: "To understand what ChatGPT remembers or teach it something new, just chat with it:"
        },
        exampleMessage1: {
            id: "settingsModal.exampleMessage1.1",
            defaultMessage: "Remember that I like concise responses."
        },
        exampleMessage2: {
            id: "settingsModal.exampleMessage2.1",
            defaultMessage: "I just got a puppy!"
        },
        exampleMessage3: {
            id: "settingsModal.exampleMessage3.2",
            defaultMessage: "What do you remember about me?"
        },
        exampleMessage4: {
            id: "settingsModal.exampleMessage4",
            defaultMessage: "Where did we leave off on my last project?"
        },
        reset: {
            id: "settingsModal.reset",
            defaultMessage: "Reset memories"
        },
        resetModalTitle: {
            id: "settingsModal.resetModalTitle",
            defaultMessage: "Are you sure?"
        },
        resetModalDescription: {
            id: "settingsModal.resetModalDescription",
            defaultMessage: "Your GPT will forget what it has learned from your previous chats. This can't be undone."
        },
        resetModalConfirm: {
            id: "settingsModal.resetModalConfirm",
            defaultMessage: "Confirm reset"
        },
        resetModalCancel: {
            id: "settingsModal.resetModalCancel",
            defaultMessage: "Cancel"
        },
        resetSuccessful: {
            id: "settingsModal.resetSuccessful",
            defaultMessage: "Your GPT's memory has been reset."
        },
        resetFailed: {
            id: "settingsModal.resetFailed",
            defaultMessage: "Failed to reset your GPT's memory."
        },
        on: {
            id: "personalizationSettings.on",
            defaultMessage: "On"
        },
        off: {
            id: "personalizationSettings.off",
            defaultMessage: "Off"
        },
        customInstructions: {
            id: "personalizationSettings.customInstructions",
            defaultMessage: "Custom instructions"
        },
        manageMemoriesButton: {
            id: "personalizationSettings.manageMemoriesButton",
            defaultMessage: "Manage"
        }
    }),
    rt = ["sharedConversations"],
    X = F({
        name: {
            id: "sharedConversationModal.name",
            defaultMessage: "Name"
        },
        dateShared: {
            id: "sharedConversationModal.dateShared",
            defaultMessage: "Date shared"
        },
        loading: {
            id: "sharedConversationModal.loading",
            defaultMessage: "Loading..."
        },
        somethingWentWrong: {
            id: "sharedConversationModal.somethingWentWrong",
            defaultMessage: "Something went wrong..."
        },
        retry: {
            id: "sharedConversationModal.retry",
            defaultMessage: "Retry"
        },
        noSharedConversations: {
            id: "sharedConversationModal.noSharedConversations",
            defaultMessage: "You have no shared links."
        },
        title: {
            id: "sharedConversationModal.title",
            defaultMessage: "Shared Links"
        },
        goToOriginConversation: {
            id: "sharedConversationModal.goToOriginConversation",
            defaultMessage: "View source chat"
        },
        deleteSharedLink: {
            id: "sharedConversationModal.deleteSharedLink",
            defaultMessage: "Delete shared link"
        },
        deleteSharedLinkFailed: {
            id: "sharedConversationModal.deleteSharedLinkFailed",
            defaultMessage: "Deleting shared link failed"
        },
        deleteAllSharedLinks: {
            id: "sharedConversationModal.deleteSharedAllConversations",
            defaultMessage: "Delete all shared links"
        },
        deleteAllSharedLinksConfirm: {
            id: "sharedConversationModal.deleteSharedAllConversationsConfirm",
            defaultMessage: "Are you sure you want to delete all your shared links?"
        },
        deleteAllSharedLinksFailed: {
            id: "sharedConversationModal.deleteSharedAllConversationsFailed",
            defaultMessage: "Deleting shared links failed"
        }
    });

function Ql() {
    const s = Ve(),
        t = y(),
        a = Q(),
        {
            mutate: n
        } = Es({
            mutationFn: () => P.deleteAllSharedConversations(),
            onSettled: () => {
                s.invalidateQueries({
                    queryKey: rt
                })
            },
            onError: () => {
                a.danger(t.formatMessage(X.deleteAllSharedLinksFailed))
            }
        });
    return e.jsx(xo, {
        side: "bottom",
        sideOffset: 4,
        triggerButton: e.jsx("button", {
            className: "text-token-text-tertiary hover:text-token-text-secondary radix-state-open:text-token-text-tertiary dark:radix-state-open:text-gray-400",
            children: e.jsx(Bn, {
                className: "icon-sm"
            })
        }),
        children: e.jsx(ho.Item, {
            onClick: () => {
                window.confirm(t.formatMessage(X.deleteAllSharedLinksConfirm)) && n()
            },
            color: "danger",
            children: e.jsx(o, { ...X.deleteAllSharedLinks
            })
        })
    })
}

function Xl() {
    return P.getSharedConversations()
}

function Jl() {
    return Ge({
        queryKey: rt,
        queryFn: Xl,
        refetchOnMount: "always"
    })
}

function Zl({
    sharedConversation: s
}) {
    const t = y(),
        a = Q(),
        n = Ve(),
        {
            mutate: i,
            isPending: l
        } = Es({
            mutationFn: async ({
                sharedConversationId: u
            }) => P.deleteShareLink({
                share_id: u
            }),
            onSettled: () => {
                n.invalidateQueries({
                    queryKey: rt
                })
            },
            onError: () => {
                a.danger(t.formatMessage(X.deleteSharedLinkFailed))
            }
        }),
        r = s.workspace_id != null ? `/share/e/${s.id}` : `/share/${s.id}`;
    return e.jsxs(O.Row, {
        disabled: l,
        children: [e.jsx(O.Cell, {
            children: e.jsxs("a", {
                href: r,
                target: "_blank",
                rel: "noreferrer",
                className: "inline-flex items-center gap-2 align-top text-blue-500 dark:text-blue-400",
                children: [e.jsx(On, {
                    className: "icon-sm flex-shrink-0"
                }), s.title]
            })
        }), e.jsx(O.Cell, {
            children: s.create_time != null ? e.jsx(Xs, {
                value: s.create_time,
                month: "long",
                year: "numeric",
                day: "numeric"
            }) : null
        }), e.jsx(O.Cell, {
            textAlign: "right",
            children: e.jsxs(O.Actions, {
                children: [e.jsx(ue, {
                    label: t.formatMessage(X.goToOriginConversation),
                    sideOffset: 4,
                    side: "top",
                    children: e.jsx("a", {
                        href: dn(s.conversation_id),
                        target: "_blank",
                        rel: "noreferrer",
                        "aria-label": t.formatMessage(X.goToOriginConversation),
                        className: "cursor-pointer text-token-text-tertiary hover:text-token-text-secondary",
                        children: e.jsx(ma, {
                            className: "icon-sm"
                        })
                    })
                }), e.jsx(ue, {
                    label: t.formatMessage(X.deleteSharedLink),
                    sideOffset: 4,
                    side: "top",
                    children: e.jsx("button", {
                        onClick: () => {
                            i({
                                sharedConversationId: s.id
                            })
                        },
                        "aria-label": t.formatMessage(X.deleteSharedLink),
                        className: "text-token-text-tertiary hover:text-token-text-secondary",
                        children: e.jsx(fa, {
                            className: "icon-sm"
                        })
                    })
                })]
            })
        })]
    })
}

function er({
    onClose: s
}) {
    const {
        data: t,
        isLoading: a,
        isError: n,
        refetch: i
    } = Jl(), l = y();
    let r;
    return a ? r = e.jsx("div", {
        className: "pb-8 text-token-text-secondary",
        children: e.jsx(o, { ...X.loading
        })
    }) : n ? r = e.jsxs("div", {
        children: [e.jsx("div", {
            className: "mb-4 text-red-500",
            children: e.jsx(o, { ...X.somethingWentWrong
            })
        }), e.jsx("div", {
            children: e.jsx(K, {
                color: "secondary",
                onClick: () => {
                    i()
                },
                children: e.jsx(o, { ...X.retry
                })
            })
        })]
    }) : t ? .total === 0 ? r = e.jsx("div", {
        className: "pb-8 text-token-text-tertiary",
        children: e.jsx(o, { ...X.noSharedConversations
        })
    }) : r = e.jsxs(O.Root, {
        className: "max-h-[28rem]",
        size: "compact",
        children: [e.jsxs(O.Header, {
            children: [e.jsx(O.HeaderCell, {
                children: e.jsx(o, { ...X.name
                })
            }), e.jsx(O.HeaderCell, {
                children: e.jsx(o, { ...X.dateShared
                })
            }), e.jsx(O.HeaderCell, {
                textAlign: "right",
                children: e.jsx(Ql, {})
            })]
        }), e.jsx(O.Body, {
            children: t ? .items.map(u => e.jsx(Zl, {
                sharedConversation: u
            }, u.id))
        })]
    }), e.jsx(L, {
        isOpen: !0,
        onClose: s,
        size: "custom",
        className: "max-w-5xl",
        type: "success",
        title: l.formatMessage(X.title),
        showCloseButton: !0,
        children: r
    })
}
const Na = "https://help.openai.com/en/articles/5722486";

function sr() {
    const s = Be(es.isBusinessWorkspace),
        t = ge(),
        {
            value: a
        } = ys("3650277116");
    return a ? (t == null ? !0 : t.isPermittedToImproveModel()) ? "enabled" : "disabled" : !s ? "enabled" : "disabled"
}

function tr() {
    const s = y(),
        t = Be(es.isBusinessWorkspace),
        [a, n] = d.useState(!1),
        i = Be(es.isTeamPlan),
        l = Be(es.isEduPlan),
        {
            data: r
        } = Yt(ts.TrainingAllowed),
        u = Zs(),
        c = sr(),
        g = c === "disabled" ? !1 : !!r;
    return e.jsxs(E, {
        children: [e.jsx(na, {
            onClick: () => n(!0),
            label: s.formatMessage(x.chatTrainingAllowedToggleLabel),
            stateLabel: g ? s.formatMessage({
                id: "settingsModal.trainingEnabled",
                defaultMessage: "On"
            }) : s.formatMessage({
                id: "settingsModal.trainingDisabled",
                defaultMessage: "Off"
            }),
            testId: "improve-model-open-modal-button"
        }), a && e.jsx(L, {
            isOpen: !0,
            onClose: () => n(!1),
            title: s.formatMessage({
                id: "settingsModal.trainingToggleModalTitle",
                defaultMessage: "Model improvement"
            }),
            type: "success",
            secondaryButton: e.jsx(K, {
                color: "secondary",
                onClick: () => n(!1),
                "data-testid": "improve-model-done-button",
                children: e.jsx(o, {
                    id: "settingsModal.trainingToggleModalDoneButton",
                    defaultMessage: "Done"
                })
            }),
            children: e.jsx(_s, {
                label: s.formatMessage(x.chatTrainingAllowedToggleLabel),
                disabled: c === "disabled",
                enabled: g,
                onChange: m => {
                    u.mutate({
                        setting: ts.TrainingAllowed,
                        value: m
                    })
                },
                toggleTooltip: t ? e.jsx(o, { ...i ? x.chatTrainingTeamsTooltip : l ? x.chatTrainingEduTooltip : x.chatTrainingEnterpriseTooltip
                }) : null,
                description: e.jsx(o, { ...x.trainingAllowedDescription,
                    values: {
                        link: m => e.jsx("a", {
                            href: Na,
                            target: "_blank",
                            className: "underline",
                            rel: "noreferrer",
                            children: m
                        })
                    }
                }),
                testId: "improve-model-toggle"
            })
        })]
    })
}
const ar = () => {
    const s = y(),
        t = Q(),
        a = st(),
        {
            pathname: n
        } = Kt(),
        i = as(),
        {
            closeSettings: l,
            currentTab: r,
            openSettings: u
        } = os(),
        [c, g] = d.useState(!1),
        [m, p] = d.useState(!1),
        [f, h] = d.useState(!1),
        [j, M] = d.useState(!1),
        [k, B] = d.useState(!1),
        [D, U] = d.useState(!1),
        [I, T] = d.useState(!1),
        [v, G] = d.useState(!1),
        [re, me] = d.useState(!1),
        he = ol(),
        z = Sl(),
        {
            setupMfa: Me,
            removeMfa: _e
        } = Pl({
            useNativeProvider: z.use_native_mfa,
            auth0UserExists: z.auth0_user_exists
        }),
        N = z.status,
        _ = z.otherProvidersWithoutMfa && z.otherProvidersWithoutMfa.length > 0,
        {
            session: W
        } = As(),
        ns = W ? .user ? .idp,
        Ls = (ns ? it[ns] : void 0) ? ? e.jsx(o, {
            id: "confirmEnableMfaForByPassModal.yourAccount",
            defaultMessage: "your current account"
        }),
        Ke = ge(),
        Ds = Ke ? .features,
        ze = Be(es.isBusinessWorkspace),
        Pe = ta(),
        {
            connectorConfig: Te
        } = ea(),
        is = Te.has($.GDRIVE) && !Pe,
        Ye = (Te.has($.O365_PERSONAL) || Te.has($.O365_BUSINESS)) && !Pe,
        ls = Te.has($.CONFLUENCE) && !Pe,
        fe = Te.has($.JIRA) && !Pe,
        _a = is || Ye || ls || fe,
        {
            clientApplications: Is
        } = un(),
        dt = Is != null && Is.length > 0 || _a,
        Pa = gn(Ms.WorkspaceShareLinks),
        La = Cs(ie.CookieManagement),
        {
            data: $e
        } = Yt(ts.ShowExpandedCodeView),
        ut = $e === void 0,
        [Da, gt] = d.useState(ut ? !1 : $e),
        Ia = Zs(),
        mt = ia(),
        Fa = Ke ? .isTeam(),
        {
            data: Ba
        } = Vt(),
        Oa = Ba ? .accountItems.some(ye => ye.isPersonalAccount()),
        Ua = Ds ? .includes(zt) && (N === Y.LOADING || N === Y.DISABLED) || N === Y.ENABLED,
        Fs = pl();
    d.useEffect(() => {
        $e !== void 0 && gt($e)
    }, [$e]);
    const Wa = d.useCallback(() => {
            g(!1)
        }, []),
        Ra = d.useCallback(() => {
            p(!1)
        }, []),
        Ga = d.useCallback(() => {
            M(!1)
        }, []),
        Ha = d.useCallback(() => {
            g(!0)
        }, []),
        Va = d.useCallback(() => {
            p(!0)
        }, []),
        Ka = d.useCallback(() => {
            h(!0)
        }, []),
        za = d.useCallback(() => {
            M(!0)
        }, []),
        Ya = d.useCallback(() => {
            me(!0)
        }, []),
        $a = d.useCallback(() => {
            G(!0), P.logoutAll().then(() => {
                t.success(s.formatMessage(x.logoutAllSuccess), {
                    testId: "logout-all-success-toaster"
                }), js()
            }).catch(ye => {
                Se.addError(new Error("Failed logging out all accounts: ", {
                    cause: ye
                })), t.danger(s.formatMessage(x.logoutAllFailed), {
                    hasCloseButton: !0
                }), G(!1)
            })
        }, [s, t]),
        Bs = Ve(),
        qa = () => {
            P.deleteConversations().then(() => {
                yt(Bs)
            }), n !== "/" && i("/", {
                replace: !0
            })
        },
        Qa = () => {
            P.archiveConversations().then(() => {
                t.info(s.formatMessage(x.archiveHistorySuccess)), yt(Bs)
            }), n !== "/" && i("/", {
                replace: !0
            })
        },
        Xa = z.status !== Y.LOADING,
        {
            native_default_factor_id: ft,
            use_native_mfa: Ja
        } = z,
        Za = () => {
            if (z.status !== Y.ENABLED) throw new Error("MFA is not enabled");
            if (Ja) {
                if (!ft) throw new Error("No factor ID found");
                return P.disableNativeMFA(ft)
            } else return P.disableMfa()
        },
        eo = () => {
            Za().then(() => {
                Bs.invalidateQueries({
                    queryKey: ["mfaInfo"]
                }), i(Hs(Vs.DISABLE_MFA_SUCCESS, "/#settings/Security"))
            }).catch(() => {
                i(Hs(Vs.DISABLE_MFA_TIMEOUT, "/#settings/Security"))
            })
        };
    return ys("730601627"), ys("3325813340"), c ? e.jsx(cr, {
        onClose: Wa
    }) : m ? e.jsx(lr, {
        onClose: Ra,
        onDeleteHistory: qa
    }) : f ? e.jsx(rr, {
        onClose: () => h(!1),
        onArchiveHistory: Qa
    }) : j ? e.jsx(dr, {
        onClose: Ga
    }) : k ? e.jsx(er, {
        onClose: () => {
            B(!1)
        }
    }) : re ? e.jsx(ll, {
        mfaInfo: z,
        onCancel: () => {
            me(!1)
        },
        onEnableMFA: Me
    }) : he ? Xa ? e.jsx(nl, {
        onClose: () => i("/", {
            replace: !0
        }),
        onConfirm: eo
    }) : null : D ? e.jsx(mn, {
        onClose: () => {
            U(!1)
        },
        fromSettings: !0
    }) : I ? e.jsx(Hl, {
        onClose: () => {
            T(!1)
        }
    }) : La ? null : e.jsx(L, {
        isOpen: !0,
        onClose: l,
        size: "custom",
        className: "md:max-w-[680px]",
        type: "success",
        title: s.formatMessage(x.settings),
        showCloseButton: !0,
        noPadding: !0,
        children: e.jsxs(fn, {
            className: "flex flex-col gap-6 md:flex-row",
            defaultValue: r,
            orientation: a ? "vertical" : void 0,
            onValueChange: ye => {
                u(ye)
            },
            children: [e.jsxs(pn, {
                className: we("m-2 md:m-0 md:px-4 md:pl-6 md:pt-4", "flex flex-shrink-0 flex-wrap md:ml-[-8px] md:min-w-[180px]", a ? "max-w-[200px] flex-col gap-2" : "flex-row overflow-x-auto rounded-lg bg-token-main-surface-secondary"),
                children: [e.jsx(Ae, {
                    value: H.General,
                    icon: e.jsx(Un, {
                        className: "icon-sm"
                    }),
                    label: e.jsx(o, { ...x.generalTab
                    })
                }), !1, Fs && e.jsx(Ae, {
                    value: H.DesktopApp,
                    icon: e.jsx(Wn, {
                        className: "icon-sm"
                    }),
                    label: e.jsx(o, { ...x.desktopAppTab
                    }),
                    testId: "desktop-app-tab"
                }), mt && e.jsx(Ae, {
                    value: H.Personalization,
                    icon: e.jsx(Rn, {
                        className: "icon-sm"
                    }),
                    label: e.jsx(o, { ...x.personalizationTab
                    }),
                    testId: "personalization-tab"
                }), e.jsx(jt.Trigger, {}), e.jsx(Ae, {
                    value: H.DataControls,
                    icon: e.jsx(Gn, {
                        className: "icon-sm"
                    }),
                    label: e.jsx(o, { ...x.dataControlsTab
                    }),
                    testId: "data-controls-tab"
                }), Ke ? .canInteractWithGizmos() && e.jsx(Ae, {
                    value: H.BuilderProfile,
                    icon: e.jsx(Hn, {
                        className: "icon-sm"
                    }),
                    label: e.jsx(Ul, {})
                }), dt && e.jsx(Ae, {
                    value: H.ConnectorSettings,
                    icon: e.jsx(Vn, {
                        className: "icon-sm"
                    }),
                    label: e.jsx(o, { ...x.connectorsTab
                    })
                }), e.jsx(Ae, {
                    value: H.Security,
                    icon: e.jsx(Kn, {
                        className: "icon-sm"
                    }),
                    label: e.jsx(o, { ...x.securityTab
                    }),
                    testId: "security-tab"
                })]
            }), e.jsxs(Ce, {
                value: H.General,
                children: [!Fs && e.jsx(E, {
                    children: e.jsx(ya, {})
                }), !1, e.jsx(E, {
                    children: e.jsx(_s, {
                        label: s.formatMessage(x.alwaysExpandCodeOutput),
                        enabled: Da,
                        isLoading: ut,
                        onChange: ye => {
                            Ia.mutate({
                                setting: ts.ShowExpandedCodeView,
                                value: ye
                            }), gt(ye)
                        }
                    })
                }), e.jsx(E, {
                    children: e.jsx(nr, {})
                }), e.jsx(E, {
                    children: e.jsx(ae, {
                        label: s.formatMessage(x.archivedConversations),
                        buttonLabel: s.formatMessage(x.manageButton),
                        onClick: () => {
                            T(!0)
                        },
                        testId: "manage-archived-conversations-button"
                    })
                }), e.jsx(E, {
                    children: e.jsx(ae, {
                        label: s.formatMessage(x.archiveChatsLabel),
                        buttonLabel: s.formatMessage(x.archiveChatsButton),
                        onClick: Ka,
                        testId: "archive-all-chats-button"
                    })
                }), e.jsx(E, {
                    children: e.jsx(ae, {
                        color: "danger",
                        label: s.formatMessage(x.deleteChatLabel),
                        buttonLabel: s.formatMessage(x.deleteChatButton),
                        onClick: Va,
                        testId: "delete-all-chats-button"
                    })
                }), e.jsx(E, {
                    children: e.jsx(ae, {
                        label: s.formatMessage(x.logOutLabel),
                        buttonLabel: s.formatMessage(x.logOutButton),
                        onClick: () => js(),
                        testId: "logout-button"
                    })
                })]
            }), !1, Fs && e.jsx(Ce, {
                value: H.DesktopApp,
                children: e.jsx(xl, {})
            }), !ze && e.jsx(Ce, {
                value: H.BetaFeatures,
                children: e.jsx(or, {})
            }), e.jsxs(Ce, {
                value: H.DataControls,
                children: [e.jsx(tr, {}), Pa && e.jsx(E, {
                    children: e.jsx(ae, {
                        label: s.formatMessage(x.sharedConversations),
                        buttonLabel: s.formatMessage(x.manageButton),
                        onClick: () => {
                            B(!0)
                        },
                        testId: "manage-shared-conversations-button"
                    })
                }), Fa && Oa && e.jsx(E, {
                    children: e.jsx(ae, {
                        label: s.formatMessage(x.mergePersonalData),
                        buttonLabel: s.formatMessage(x.mergeButton),
                        onClick: () => {
                            U(!0)
                        }
                    })
                }), !ze && e.jsxs(e.Fragment, {
                    children: [e.jsx(E, {
                        children: e.jsx(ae, {
                            label: s.formatMessage(x.exportData),
                            buttonLabel: s.formatMessage(x.exportButton),
                            onClick: Ha,
                            testId: "export-data-button"
                        })
                    }), e.jsx(E, {
                        children: e.jsx(ae, {
                            label: s.formatMessage(x.deleteAccount),
                            buttonLabel: s.formatMessage(x.deleteAccountButton),
                            color: "danger",
                            onClick: za,
                            testId: "delete-account-button"
                        })
                    })]
                })]
            }), mt && e.jsx(Ce, {
                value: H.Personalization,
                children: e.jsx(ql, {})
            }), e.jsx(Ce, {
                value: H.BuilderProfile,
                children: e.jsx(Il, {})
            }), dt && e.jsx(Ce, {
                value: H.ConnectorSettings,
                children: e.jsx(el, {
                    clientApplications: Is,
                    isGdriveEnabled: is,
                    isO365Enabled: Ye,
                    isConfluenceEnabled: ls,
                    isJiraEnabled: fe
                })
            }), e.jsx(jt.Content, {}), e.jsxs(Ce, {
                value: H.Security,
                children: [Ua && e.jsx(E, {
                    children: e.jsx(ae, {
                        label: e.jsxs(e.Fragment, {
                            children: [e.jsx(o, {
                                id: "settingsModal.toggleMfa",
                                defaultMessage: "Multi-factor authentication"
                            }), N === Y.ENABLED && e.jsx("span", {
                                className: "mx-1.5 rounded bg-green-50 px-1 py-0.5 text-xs font-semibold text-green-700",
                                children: e.jsx(o, {
                                    id: "settingsModal.mfaEnabled",
                                    defaultMessage: "Enabled"
                                })
                            })]
                        }),
                        disabled: N === Y.LOADING,
                        buttonLabel: e.jsxs(e.Fragment, {
                            children: [N === Y.LOADING && e.jsx(o, {
                                id: "settingsModal.loadingMfa",
                                defaultMessage: "Loading..."
                            }), N === Y.ENABLED && e.jsx(o, {
                                id: "settingsModal.disable",
                                defaultMessage: "Disable"
                            }), N === Y.DISABLED && e.jsx(o, {
                                id: "settingsModal.enable",
                                defaultMessage: "Enable"
                            })]
                        }),
                        onClick: () => {
                            N === Y.ENABLED ? _e() : N === Y.DISABLED && _ ? Ya() : N === Y.DISABLED && Me()
                        },
                        description: e.jsxs(e.Fragment, {
                            children: [N === Y.DISABLED && e.jsx(o, {
                                id: "settingsModal.toggleMfaDescriptionDisabled",
                                defaultMessage: "Require an extra security challenge when logging in. If you are unable to pass this challenge, you will have the option to recover your account via email."
                            }), N === Y.ENABLED && e.jsxs(e.Fragment, {
                                children: [e.jsx(o, {
                                    id: "settingsModal.toggleMfaDescriptionEnabled",
                                    defaultMessage: "You'll only be able to log in using {currentIdp} while this is on.",
                                    values: {
                                        currentIdp: Ls
                                    }
                                }), " ", e.jsx("a", {
                                    className: "underline",
                                    target: "_blank",
                                    rel: "noreferrer",
                                    href: Zn,
                                    children: e.jsx(o, {
                                        id: "settingsModal.toggleMfaDescriptionLearnMore",
                                        defaultMessage: "Learn more"
                                    })
                                }), "."]
                            })]
                        })
                    })
                }), e.jsx(E, {
                    children: e.jsx(ae, {
                        label: e.jsx(o, {
                            id: "settingsModal.logoutAllLabel",
                            defaultMessage: "Log out of all devices"
                        }),
                        buttonLabel: e.jsx("div", {
                            style: {
                                whiteSpace: "nowrap"
                            },
                            children: e.jsx(o, {
                                id: "settingsModal.logoutAllButton",
                                defaultMessage: "Log out all"
                            })
                        }),
                        description: e.jsx(o, {
                            id: "settingsModal.logoutAllDescription",
                            defaultMessage: "Log out of all active sessions across all devices, including your current session. It may take up to 30 minutes for other devices to be logged out."
                        }),
                        onClick: () => {
                            w.logLogOutButtonClicked({
                                location: "settings_modal_log_out_all"
                            }), $a()
                        },
                        disabled: v,
                        testId: "logout-all-button"
                    })
                })]
            })]
        })
    })
};

function or() {
    return e.jsx(e.Fragment, {
        children: e.jsx(E, {
            children: e.jsx("p", {
                children: e.jsx(o, { ...x.betaIntro
                })
            })
        })
    })
}

function nr() {
    const {
        localeList: s,
        localPreferenceLocale: t,
        setLocale: a,
        suggestedLocale: n,
        currentLocale: i,
        unsanitizedBrowserLocale: l
    } = bo(), r = [...new Set([t, n])].filter(c => c != null), u = s.filter(c => !r.includes(c));
    return e.jsxs("div", {
        className: "flex items-center justify-between",
        children: [e.jsx("div", {
            children: e.jsx(o, { ...x.locale
            })
        }), e.jsxs(pe.Root, {
            value: t ? ? "auto",
            onValueChange: c => {
                w.logEvent(A.localeUpdatedByUser, {
                    from_locale: i,
                    to_locale: c,
                    raw_browser_locale: l ? ? "",
                    suggested_locale: n ? ? ""
                }), ne.logEvent("chatgpt_locale_updated_by_user", c, {
                    from_locale: i,
                    to_locale: c,
                    raw_browser_locale: l ? ? "",
                    suggested_locale: n ? ? ""
                }), a(c === "auto" ? null : c)
            },
            children: [e.jsxs(pe.Trigger, {
                children: [e.jsx(pe.Value, {}), e.jsx(pe.Icon, {})]
            }), e.jsx(pe.Portal, {
                children: e.jsxs(pe.Content, {
                    side: void 0,
                    sideOffset: void 0,
                    position: "item-aligned",
                    children: [e.jsx(pe.Item, {
                        value: "auto",
                        children: e.jsx(o, { ...x.localeAuto
                        })
                    }), r.map(c => e.jsx(pe.Item, {
                        value: c,
                        children: ht[c] ? ? c
                    }, c)), e.jsx(pe.Separator, {}), u.map(c => e.jsx(pe.Item, {
                        value: c,
                        children: ht[c] ? ? c
                    }, c))]
                })
            })]
        })]
    })
}

function ir() {
    const s = y(),
        t = Mo(),
        {
            closeSettings: a
        } = os();
    return d.useEffect(() => {
        ne.logEvent("chatgpt_unauthenticated_settings_modal_shown"), w.logEvent(A.unauthSettingsModal)
    }, []), e.jsx(L, {
        isOpen: !0,
        onClose: a,
        type: "success",
        showCloseButton: !0,
        title: s.formatMessage(x.settings),
        children: e.jsx(E, {
            children: e.jsx(_s, {
                label: s.formatMessage({
                    id: "settingsModal.unauthChatTrainingToggleLabel",
                    defaultMessage: "Improve the model for everyone"
                }),
                enabled: t,
                onChange: n => {
                    yo.setIsNoAuthChatTrainingEnabled(n), w.logEvent(A.noAuthChatTrainingToggled, {
                        isEnabled: n
                    })
                },
                description: e.jsx(o, {
                    id: "rtxsI1",
                    defaultMessage: "Allow your content to be used to train our models, which makes ChatGPT better for you and everyone who uses it. We take steps to protect your privacy. <link>Learn more</link>.",
                    values: {
                        link: n => e.jsx("a", {
                            href: Na,
                            target: "_blank",
                            className: "underline",
                            rel: "noreferrer",
                            children: n
                        })
                    }
                })
            })
        })
    })
}

function lr({
    onClose: s,
    onDeleteHistory: t
}) {
    const a = y(),
        n = ia();
    return e.jsx(L, {
        isOpen: !0,
        onClose: s,
        type: "success",
        title: a.formatMessage(x.deleteHistoryModalTitle),
        description: n && e.jsx(o, {
            id: "settingsModal.deleteHistoryModalMemoryDisclaimer",
            defaultMessage: "To clear any memories from your chats, visit your <link>settings</link>.",
            values: {
                link: i => e.jsx(se, {
                    onClick: () => s(),
                    to: "#settings/Personalization",
                    className: "underline",
                    children: i
                })
            }
        }),
        primaryButton: e.jsx(R.Button, {
            title: a.formatMessage(x.deleteHistoryModalConfirm),
            color: "danger",
            onClick: () => {
                t(), s()
            },
            "data-testid": "confirm-delete-all-chats-button"
        }),
        secondaryButton: e.jsx(R.Button, {
            title: a.formatMessage(x.deleteHistoryModalCancel),
            color: "secondary",
            onClick: s
        })
    })
}

function rr({
    onClose: s,
    onArchiveHistory: t
}) {
    const a = y();
    return e.jsx(L, {
        isOpen: !0,
        onClose: s,
        type: "success",
        title: a.formatMessage(x.archiveHistoryModalTitle),
        primaryButton: e.jsx(R.Button, {
            title: a.formatMessage(x.archiveHistoryModalConfirm),
            color: "primary",
            onClick: () => {
                t(), s()
            }
        }),
        secondaryButton: e.jsx(R.Button, {
            title: a.formatMessage(x.archiveHistoryModalCancel),
            color: "secondary",
            onClick: s
        })
    })
}

function cr({
    onClose: s
}) {
    const t = y(),
        a = Q(),
        n = d.useCallback(() => {
            try {
                P.submitDataExport().then(() => {
                    a.success(t.formatMessage(x.dataExportRequested), {
                        testId: "data-export-success-toaster"
                    }), s()
                })
            } catch {
                a.warning(t.formatMessage(x.dataExportFailed), {
                    hasCloseButton: !0
                })
            }
        }, [t, a, s]);
    return e.jsx(L, {
        isOpen: !0,
        onClose: s,
        type: "success",
        title: t.formatMessage(x.dataExportModalTitle),
        primaryButton: e.jsx(R.Button, {
            title: t.formatMessage(x.dataExportModalConfirm),
            color: "primary",
            onClick: n,
            "data-testid": "confirm-data-export-button"
        }),
        secondaryButton: e.jsx(R.Button, {
            title: t.formatMessage(x.dataExportModalCancel),
            color: "secondary",
            onClick: s
        }),
        children: e.jsxs("div", {
            className: "text-sm",
            children: [e.jsxs("ul", {
                className: "my-3 flex list-disc flex-col gap-1 pl-3",
                children: [e.jsx("li", {
                    children: e.jsx(o, { ...x.dataExportModalDescription1
                    })
                }), e.jsx("li", {
                    children: e.jsx(o, { ...x.dataExportModalDescription2
                    })
                }), e.jsx("li", {
                    children: e.jsx(o, { ...x.dataExportModalDescription3
                    })
                }), e.jsx("li", {
                    children: e.jsx(o, { ...x.dataExportModalDescription4
                    })
                })]
            }), e.jsx("div", {
                children: e.jsx(o, { ...x.dataExportModalDescription5
                })
            })]
        })
    })
}

function dr({
    onClose: s
}) {
    const t = y(),
        a = Q(),
        {
            session: n
        } = As(),
        l = et() ? .email,
        [r, u] = d.useState(""),
        [c, g] = d.useState(""),
        m = d.useCallback(() => {
            const B = n ? .user ? .iat;
            return B === void 0 || Date.now() / 1e3 - B < 600
        }, [n]),
        p = d.useCallback(() => {
            try {
                m() ? P.deactivateAccount().then(() => {
                    js()
                }) : a.warning(t.formatMessage(x.deleteAccountSessionTooOld), {
                    hasCloseButton: !0
                })
            } catch {
                a.warning(t.formatMessage(x.deleteAccountFailed), {
                    hasCloseButton: !0
                })
            }
        }, [t, a, m]),
        f = d.useCallback(() => {
            js()
        }, []),
        h = c === "DELETE" && (l === void 0 || r.toLowerCase() === l.toLowerCase()),
        [j] = d.useState(() => m()),
        M = xn();
    return e.jsx(L, {
        isOpen: !0,
        onClose: s,
        type: "success",
        title: t.formatMessage(x.deleteAccountTitle),
        showCloseButton: !0,
        children: e.jsxs("div", {
            className: "text-sm",
            children: [e.jsxs("ul", {
                className: "mb-6 mt-4 flex list-disc flex-col gap-1 pl-3",
                children: [e.jsx("li", {
                    children: e.jsx(o, { ...x.deleteAccountWarning
                    })
                }), e.jsx("li", {
                    children: e.jsx(o, { ...x.apiAccessDeletionWarning
                    })
                }), e.jsx("li", {
                    children: e.jsx(o, { ...x.reuseEmailPhoneWarning
                    })
                }), e.jsx("li", {
                    children: e.jsx(o, { ...x.dataRemovalWarning
                    })
                }), M ? .purchase_origin_platform === Ie.MOBILE_IOS && e.jsx("li", {
                    children: e.jsx(o, { ...x.iapSubscriptionWarning
                    })
                }), M ? .purchase_origin_platform === Ie.MOBILE_ANDROID && e.jsx("li", {
                    children: e.jsx(o, { ...x.playStoreSubscriptionWarning
                    })
                }), e.jsx("li", {
                    children: e.jsx(o, { ...x.deleteHelpCenter,
                        values: {
                            article: k => e.jsx("a", {
                                href: "https://help.openai.com/en/articles/6378407-how-to-delete-your-account",
                                target: "_blank",
                                className: "underline",
                                rel: "noopener noreferrer",
                                children: k
                            })
                        }
                    })
                })]
            }), j ? e.jsxs(e.Fragment, {
                children: [l !== void 0 ? e.jsxs("div", {
                    className: "mb-4",
                    children: [e.jsx(Ht, {
                        children: e.jsx(o, { ...x.typeEmailLabel
                        })
                    }), e.jsx(vs, {
                        value: r,
                        placeholder: l,
                        name: "email",
                        onChange: k => {
                            u(k.target.value)
                        }
                    })]
                }) : null, e.jsxs("div", {
                    className: "mb-4",
                    children: [e.jsx(Ht, {
                        children: e.jsx(o, { ...x.typeDeleteInputLabel
                        })
                    }), e.jsx(vs, {
                        value: c,
                        onChange: k => {
                            g(k.target.value)
                        },
                        name: "delete",
                        className: "mb-4"
                    })]
                }), e.jsx(K, {
                    color: h ? "danger" : "disabled",
                    onClick: p,
                    disabled: !h,
                    fullWidth: !0,
                    icon: h ? ra : zn,
                    children: h ? e.jsx(o, { ...x.deleteAccountButtonLabel
                    }) : e.jsx(o, { ...x.lockedButtonLabel
                    })
                })]
            }) : e.jsxs(e.Fragment, {
                children: [e.jsx("p", {
                    className: "pb-4 text-xs text-token-text-tertiary",
                    children: e.jsx(o, { ...x.recentLoginMessage
                    })
                }), e.jsx(K, {
                    color: "primary",
                    onClick: f,
                    fullWidth: !0,
                    children: e.jsx(o, { ...x.refreshLoginButtonLabel
                    })
                })]
            })]
        })
    })
}
const Ht = le.label `block text-sm font-semibold mb-1`,
    x = F({
        settings: {
            id: "settingsModal.settings",
            defaultMessage: "Settings"
        },
        locale: {
            id: "settingsModal.locale_alpha",
            defaultMessage: "Language"
        },
        localeAuto: {
            id: "settingsModal.localeAuto",
            defaultMessage: "Auto-detect"
        },
        archivedConversations: {
            id: "settingsModal.archivedConversations",
            defaultMessage: "Archived chats"
        },
        sharedConversations: {
            id: "settingsModal.sharedConversations",
            defaultMessage: "Shared links"
        },
        manageButton: {
            id: "settingsModal.manageButton",
            defaultMessage: "Manage"
        },
        mergePersonalData: {
            id: "settingsModal.mergePersonalData",
            defaultMessage: "Merge data from your personal workspace"
        },
        mergeButton: {
            id: "settingsModal.mergeButton",
            defaultMessage: "Merge"
        },
        cookieManagement: {
            id: "settingsModal.cookieManagement",
            defaultMessage: "Cookie preferences"
        },
        cookieManagementButton: {
            id: "settingsModal.cookieManagementButton",
            defaultMessage: "Manage"
        },
        exportData: {
            id: "settingsModal.exportData",
            defaultMessage: "Export data"
        },
        exportButton: {
            id: "settingsModal.exportButton",
            defaultMessage: "Export"
        },
        deleteAccount: {
            id: "settingsModal.deleteAccount",
            defaultMessage: "Delete account"
        },
        deleteAccountButton: {
            id: "settingsModal.deleteButton",
            defaultMessage: "Delete"
        },
        alwaysExpandCodeOutput: {
            id: "settingsModal.alwaysShowDataAnalystOutput",
            defaultMessage: "Always show code when using data analyst"
        },
        trainingAllowedDescription: {
            id: "Qalmv5",
            defaultMessage: "Allow your content to be used to train our models, which makes ChatGPT better for you and everyone who uses it. We take steps to protect your privacy. <link>Learn more</link>"
        },
        deleteHistoryModalTitle: {
            id: "settingsModal.deleteHistoryModalTitle",
            defaultMessage: "Clear your chat history - are you sure?"
        },
        deleteHistoryModalConfirm: {
            id: "settingsModal.deleteHistoryModalConfirm",
            defaultMessage: "Confirm deletion"
        },
        deleteHistoryModalCancel: {
            id: "settingsModal.deleteHistoryModalCancel",
            defaultMessage: "Cancel"
        },
        archiveHistoryModalTitle: {
            id: "settingsModal.archiveHistoryModalTitle",
            defaultMessage: "Archive your chat history - are you sure?"
        },
        archiveHistoryModalConfirm: {
            id: "settingsModal.archiveHistoryModalConfirm",
            defaultMessage: "Confirm archive"
        },
        archiveHistoryModalCancel: {
            id: "settingsModal.archiveHistoryModalCancel",
            defaultMessage: "Cancel"
        },
        archiveHistorySuccess: {
            id: "settingsModal.archiveHistorySuccess",
            defaultMessage: "Successfully archived chats. You can view your archived chats in Settings."
        },
        dataExportRequested: {
            id: "settingsModal.dataExportRequested",
            defaultMessage: "Successfully exported data. You should receive an email shortly with your data."
        },
        dataExportFailed: {
            id: "settingsModal.dataExportFailed",
            defaultMessage: "We were unable to process your export at this time. Please try again later."
        },
        dataExportModalTitle: {
            id: "settingsModal.dataExportModalTitle",
            defaultMessage: "Request data export - are you sure?"
        },
        dataExportModalConfirm: {
            id: "settingsModal.dataExportModalConfirm",
            defaultMessage: "Confirm export"
        },
        dataExportModalCancel: {
            id: "settingsModal.dataExportModalCancel",
            defaultMessage: "Cancel"
        },
        dataExportModalDescription1: {
            id: "settingsModal.dataExportModalDescription1",
            defaultMessage: "Your account details and chats will be included in the export."
        },
        dataExportModalDescription2: {
            id: "settingsModal.dataExportModalDescription2",
            defaultMessage: "The data will be sent to your registered email in a downloadable file."
        },
        dataExportModalDescription3: {
            id: "settingsModal.dataExportModalDescription3",
            defaultMessage: "The download link will expire 24 hours after you receive it."
        },
        dataExportModalDescription4: {
            id: "settingsModal.dataExportModalDescription4",
            defaultMessage: "Processing may take some time. You'll be notified when it's ready."
        },
        dataExportModalDescription5: {
            id: "settingsModal.dataExportModalDescription5",
            defaultMessage: 'To proceed, click "Confirm export" below.'
        },
        deleteAccountSessionTooOld: {
            id: "settingsModal.deleteAccountSessionTooOld",
            defaultMessage: "Your login session is too old. Please log in again before deleting your account."
        },
        deleteAccountFailed: {
            id: "settingsModal.deleteAccountFailed",
            defaultMessage: "Failed to delete account. Please try again later."
        },
        deleteAccountTitle: {
            id: "settingsModal.deleteAccountTitle",
            defaultMessage: "Delete account - are you sure?"
        },
        deleteAccountWarning: {
            id: "settingsModal.deleteAccountWarning",
            defaultMessage: "Deleting your account is permanent and cannot be undone."
        },
        reuseEmailPhoneWarning: {
            id: "settingsModal.reuseEmailPhoneWarning-2",
            defaultMessage: "You cannot create a new account using the same email address."
        },
        dataRemovalWarning: {
            id: "settingsModal.dataRemovalWarning-2",
            defaultMessage: "Your data will be deleted within 30 days, except we may retain a limited set of data for longer where required or permitted by law."
        },
        apiAccessDeletionWarning: {
            id: "settingsModal.apiAccessDeletionWarning-2",
            defaultMessage: "Deletion will prevent you from accessing OpenAI services, including ChatGPT, API, and DALL·E."
        },
        deleteHelpCenter: {
            id: "settingsModal.deleteHelpCenter",
            defaultMessage: "Read our <article>help center article</article> for more information."
        },
        iapSubscriptionWarning: {
            id: "settingsModal.iapSubscriptionWarning",
            defaultMessage: "You will need to cancel your in-app purchase subscription in the Apple App Store. We cannot cancel your subscription for you."
        },
        playStoreSubscriptionWarning: {
            id: "settingsModal.playStoreSubscriptionWarning",
            defaultMessage: "You will need to cancel your in-app purchase subscription in the Google Play Store. We cannot cancel your subscription for you."
        },
        typeEmailLabel: {
            id: "settingsModal.typeEmailLabel",
            defaultMessage: "Please type your account email."
        },
        typeDeleteInputLabel: {
            id: "settingsModal.typeDeleteInputLabel",
            defaultMessage: 'To proceed, type "DELETE" in the input field below.'
        },
        lockedButtonLabel: {
            id: "settingsModal.lockedButtonLabel",
            defaultMessage: "Locked"
        },
        deleteAccountButtonLabel: {
            id: "settingsModal.deleteAccountButtonLabel",
            defaultMessage: "Permanently delete my account"
        },
        recentLoginMessage: {
            id: "settingsModal.recentLoginMessage",
            defaultMessage: "You may only delete your account if you have logged in within the last 10 minutes. Please log in again, then return here to continue."
        },
        refreshLoginButtonLabel: {
            id: "settingsModal.refreshLoginButtonLabel",
            defaultMessage: "Refresh login"
        },
        chatTrainingAllowedToggleLabel: {
            id: "settingsModal.trainingAllowedToggleLabel",
            defaultMessage: "Improve the model for everyone"
        },
        chatTrainingEnterpriseTooltip: {
            id: "settingsModal.chatTrainingEnterpriseTooltip",
            defaultMessage: "ChatGPT Enterprise automatically disables training."
        },
        chatTrainingEduTooltip: {
            id: "settingsModal.chatTrainingEduTooltip",
            defaultMessage: "ChatGPT Edu automatically disables training."
        },
        chatTrainingTeamsTooltip: {
            id: "settingsModal.chatTrainingTeamsTooltip",
            defaultMessage: "ChatGPT Team automatically disables training."
        },
        dataControlsTab: {
            id: "settingsModal.dataControls",
            defaultMessage: "Data controls"
        },
        cookiesTab: {
            id: "settingsModal.cookies",
            defaultMessage: "Cookie Preferences"
        },
        personalizationTab: {
            id: "settingsModal.personalization",
            defaultMessage: "Personalization"
        },
        betaIntro: {
            id: "settingsModal.betaIntro",
            defaultMessage: "As a Plus user, enjoy early access to experimental new features, which may change during development."
        },
        betaSettingsUpdateFailed: {
            id: "settingsModal.betaSettingsUpdateFailed",
            defaultMessage: "Failed to update your beta setting"
        },
        generalTab: {
            id: "settingsModal.generalTab",
            defaultMessage: "General"
        },
        desktopAppTab: {
            id: "settingsModal.desktopAppTab",
            defaultMessage: "App"
        },
        betaTab: {
            id: "settingsModal.betaTab",
            defaultMessage: "Beta features"
        },
        connectorsTab: {
            id: "settingsModal.connectorsTab",
            defaultMessage: "Connected apps"
        },
        securityTab: {
            id: "settingsModal.securityTab",
            defaultMessage: "Security"
        },
        logoutAllSuccess: {
            id: "settingsModal.logoutAllSuccess",
            defaultMessage: "Successfully logged out of all devices."
        },
        logoutAllFailed: {
            id: "settingsModal.logoutAllFailed",
            defaultMessage: "We were unable to process your request at this time. Please try again later."
        },
        deleteChatLabel: {
            id: "settingsModal.deleteChatLabel",
            defaultMessage: "Delete all chats"
        },
        deleteChatButton: {
            id: "settingsModal.deleteChatButton",
            defaultMessage: "Delete all"
        },
        logOutLabel: {
            id: "settingsModal.logOutLabel",
            defaultMessage: "Log out on this device"
        },
        logOutButton: {
            id: "settingsModal.logoutButton",
            defaultMessage: "Log out"
        },
        archiveChatsLabel: {
            id: "settingsModal.archiveChatsLabel",
            defaultMessage: "Archive all chats"
        },
        archiveChatsButton: {
            id: "settingsModal.archiveChatsButton",
            defaultMessage: "Archive all"
        },
        chatHistoryDescription: {
            id: "settingsModal.chatHistoryDescription",
            defaultMessage: "Save new chats on this browser to your history and allow them to be used to improve our models. Unsaved chats will be deleted from our systems within 30 days. This setting does not sync across browsers or devices. <link>Learn more</link>"
        }
    });

function ur() {
    const {
        isOpen: s
    } = os(), {
        isUnauthenticated: t
    } = ws();
    return s ? t ? e.jsx(ir, {}) : e.jsx(ar, {}) : null
}
const gr = jo(() => vo(() =>
    import ("./k4qvr2xancusigzk.js"), __vite__mapDeps([0, 1, 2, 3, 4, 5, 6, 7, 8])).then(s => s.FannyPackModalContainer));

function Er() {
    const s = Ks(g => g.purchaseWorkspaceData),
        t = Ks(g => g.leaveWorkspaceData),
        a = s != null,
        n = Cs(ie.UserContext),
        i = Cs(ie.GlobalMemoryOnboarding),
        l = ge();
    let {
        isOpen: r,
        isTeamAccountIntent: u
    } = Xi();
    const {
        isFannyPackEnabled: c
    } = hn();
    return e.jsxs(e.Fragment, {
        children: [e.jsx(ur, {}), e.jsx(ci, {}), r && l && e.jsx(Wi, {
            currentAccount: l,
            initTab: u ? "business" : void 0
        }), e.jsx(bn, {}), e.jsx(di, {}), a && e.jsx(qi, {
            isOpen: a,
            onClose: () => J.setPurchaseWorkspaceData(null),
            ...s
        }), t && e.jsx(ni, {
            workspace: t
        }), n && e.jsx(Yl, {
            isModalOpen: n
        }), i && e.jsx(Mn, {
            onClose: () => J.closeModal(ie.GlobalMemoryOnboarding)
        }), c && e.jsx(gr, {})]
    })
}
export {
    Er as GlobalModalsComponent
};
//# sourceMappingURL=e65vcq3qpq9bfeq2.js.map