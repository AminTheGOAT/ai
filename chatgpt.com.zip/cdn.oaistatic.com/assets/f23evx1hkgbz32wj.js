const __vite__mapDeps = (i, m = __vite__mapDeps, d = (m.f || (m.f = ["assets/d0bj0ou1aof4ttdr.js", "assets/hbhpmx2ipkndwudc.js", "assets/mgr0w69u3c317psp.js", "assets/root-ncdra6h0.css", "assets/b1o0aiuwbdsksxg2.js", "assets/ifiyfjejhvqnsz2u.js", "assets/ab2oz9enzsoo3wow.js", "assets/conversation-small-h7jqffb1.css", "assets/f9c2acih0kknf1nx.js", "assets/mco6ffvkuw2vrlq8.js", "assets/c4bxzbp1808foto4.js", "assets/iec0jq58jdzn3hjh.js", "assets/nqxrsem62j81khrd.js", "assets/m7u5z7sua6e1c9ci.js", "assets/ex1buqdicemvrfma.js", "assets/m0s651bq7jimn9ko.js", "assets/nb6f1twu9li01ii9.js", "assets/ect6g376vgkivy11.js", "assets/jxwx6dawz4c8avao.js", "assets/n5mnsu7wpta2bimq.js", "assets/f7nbupjo85mkhxu0.js", "assets/jcsi40okkq20gpy2.js", "assets/4zht2gtq035rojzq.js", "assets/h6hbjef4sz0t99sv.js", "assets/oo6z5nmlqv9shej7.js", "assets/oyxkk1iypfvnpu9i.js", "assets/b565qz6knniq0qla.js", "assets/jahrkw92yzxlxku3.js", "assets/fzrn137102spawew.js", "assets/e9lafxuzyeh4418f.js", "assets/ecsmtmpgv59no4oe.js", "assets/bj1vddbqqdzc1nw2.js", "assets/n4doychnm4y0og7a.js", "assets/eomgak7isz9y8t2v.js"]))) => i.map(i => d[i]);
import {
    r as u,
    aL as Se,
    hM as Qi,
    m as s,
    P as oe,
    d as ne,
    aR as O,
    bH as fa,
    aA as Bs,
    aB as ut,
    hN as oo,
    cq as ga,
    c as Zi,
    j as Ji,
    d2 as Ge,
    bZ as un,
    G as ze,
    F as He,
    dK as dn,
    a$ as We,
    ay as mt,
    d8 as Rt,
    y as J,
    o as Ce,
    b4 as er,
    aD as P,
    c2 as io,
    bR as ro,
    bq as ts,
    aX as It,
    ac as An,
    aJ as Rn,
    eo as Dt,
    a8 as lo,
    aW as pa,
    go as tr,
    gm as sr,
    Z as Os,
    H as En,
    a4 as nr,
    a3 as ar,
    bf as co,
    ap as ss,
    ee as or,
    gl as Nn,
    hO as ir,
    am as dt,
    ez as rr,
    b1 as hn,
    ci as lr,
    cj as cr,
    ck as ur,
    b3 as dr,
    hP as hr,
    aE as Oe,
    ab as Et,
    hQ as mr,
    S as me,
    D as mn,
    aq as Pn,
    gJ as In,
    x as Dn,
    a7 as Xe,
    aT as xa,
    gb as uo,
    an as ho,
    gX as mo,
    fm as fr,
    $ as gr,
    a9 as va,
    t as fo,
    hR as pr,
    hS as xr,
    gk as Fn,
    gd as vr,
    hT as go,
    aV as zs,
    fV as Sr,
    gc as Ln,
    aQ as Qe,
    u as Bn,
    as as js,
    L as ht,
    v as po,
    n as Mt,
    aH as ns,
    aI as as,
    d0 as br,
    aa as yr,
    Y as xo,
    br as Ne,
    f2 as vo,
    Q as wr,
    hU as Tr,
    fe as Mr,
    ff as _r,
    fi as At,
    fg as Sa,
    fh as jr,
    ba as _t,
    hV as Cr,
    aK as So,
    c5 as kr,
    fb as Ar,
    cd as Rr,
    hW as ba,
    fa as fn,
    e0 as Er,
    l as Ke,
    cv as Nr,
    hw as Rs,
    M as bo,
    az as Pr,
    hX as Ir,
    aG as Dr,
    ce as Fr,
    hY as Lr,
    hZ as Br,
    h_ as yo,
    gS as wo,
    bp as Or,
    fq as zr,
    h$ as Hr,
    i0 as Ur,
    cF as Gr,
    eQ as Wr
} from "./hbhpmx2ipkndwudc.js";
import {
    e3 as Hs,
    k_ as Vr,
    at as os,
    e5 as qr,
    k$ as $r,
    l0 as Kr,
    ay as is,
    l1 as Yr,
    iN as To,
    iQ as Mo,
    dA as Xr,
    B as Qr,
    cn as Zr,
    iM as Jr,
    l2 as be,
    l3 as Nt,
    l4 as el,
    l5 as tl,
    l6 as sl,
    l7 as nl,
    l8 as al,
    l9 as ol,
    la as il,
    lb as rl,
    lc as ll,
    ld as se,
    le as _o,
    lf as jo,
    cg as cl,
    cb as ul,
    lg as dl,
    lh as hl,
    li as Co,
    jT as ml,
    fv as fl,
    lj as gl,
    lk as pl,
    ll as ko,
    lm as xl,
    ln as Ao,
    ak as Ze,
    lo as vl,
    lp as On,
    lq as Sl,
    m as bl,
    b$ as Pt,
    lr as Ro,
    ls as Eo,
    bX as Us,
    bi as Qt,
    lt as Es,
    lu as Le,
    lv as No,
    lw as yl,
    lx as wl,
    ly as Ns,
    lz as Tl,
    lA as Ml,
    lB as _l,
    lC as jl,
    lD as Cl,
    dC as kl,
    lE as Al,
    lF as Rl,
    lG as El,
    lH as Nl,
    lI as zn,
    e1 as Hn,
    lJ as Pl,
    bK as Po,
    bL as Un,
    bO as Io,
    lK as Il,
    lL as Dl,
    hd as Do,
    lM as Fl,
    lN as Ll,
    lO as Ps,
    b2 as Gn,
    b5 as Fo,
    cF as Bl,
    cl as Ol,
    cG as Lo,
    fc as Bo,
    b7 as Oo,
    lP as ya,
    lQ as zl,
    lR as Hl,
    bc as wa,
    b9 as Ul,
    jw as Gl,
    jo as Ta,
    lS as Wl,
    lT as Vl,
    lU as ql,
    lV as $l,
    eY as zo,
    lW as Kl,
    lX as Yl,
    bg as Ho,
    eZ as Uo,
    it as Wn,
    lY as Ma,
    i4 as Xl,
    b8 as Ql,
    lZ as Zl,
    fk as Jl,
    ju as ec,
    fl as tc,
    fm as sc,
    f5 as Go,
    ba as gn,
    l_ as nc,
    l$ as ac,
    m0 as oc,
    m1 as ic,
    m2 as rc,
    m3 as lc,
    bS as Vn,
    U as Is,
    bu as qn,
    c2 as cc,
    m4 as uc,
    m5 as dc,
    m6 as hc,
    m7 as mc,
    m8 as fc,
    m9 as gc,
    ma as pc,
    bT as Wo,
    mb as xc,
    mc as vc,
    cC as Sc,
    fn as bc,
    md as yc,
    me as wc,
    i2 as Tc,
    mf as Mc,
    mg as _c,
    e2 as jc,
    mh as Cc,
    mi as kc,
    mj as Ac,
    mk as Rc,
    ml as Vo,
    mm as $n,
    c0 as Zt,
    mn as Ec,
    mo as Nc,
    mp as Pc,
    mq as pn,
    hs as Ic,
    mr as Dc,
    bZ as xn,
    ms as Fc,
    mt as Lc,
    hz as Bc,
    hT as Oc,
    mu as vn,
    i as qo,
    mv as _a,
    mw as zc,
    mx as Hc,
    my as Uc,
    bW as Gc,
    mz as Wc,
    mA as Vc,
    dG as qc,
    mB as $c,
    dY as Kc,
    hQ as Yc,
    mC as Xc,
    fb as Qc,
    mD as Zc,
    bP as Jc,
    kX as eu,
    mE as tu,
    fj as su,
    mF as nu,
    mG as $o,
    mH as Ko,
    mI as Yo,
    mJ as jt,
    mK as au,
    mL as ou,
    mM as iu,
    jh as ru,
    bz as Xo,
    mN as lu,
    mO as Kt,
    jx as cu,
    mP as Qo,
    mQ as uu,
    fG as Ds,
    mR as Sn,
    mS as bn,
    mT as du,
    mU as hu,
    mV as mu,
    mW as fu,
    mX as ja,
    mY as ys,
    by as Ca,
    bH as Zo,
    bI as Jo,
    mZ as gu,
    m_ as pu,
    fw as xu,
    m$ as vu,
    n0 as Su,
    bY as ei,
    n1 as bu,
    n2 as yu,
    n3 as wu,
    n4 as Tu,
    n5 as Mu,
    b1 as _u,
    cB as ju,
    fF as Cu,
    n6 as ku,
    n7 as Au,
    n8 as Ru,
    n9 as Eu,
    na as Nu,
    nb as Pu,
    nc as Iu,
    nd as Du,
    ne as Fu,
    nf as Lu,
    ng as Bu,
    be as Ou,
    jl as zu,
    jk as Hu,
    nh as Uu,
    b6 as Gu,
    fR as Wu,
    ni as Vu,
    nj as qu,
    l as $u,
    ko as Ku,
    f6 as sn,
    nk as Yu,
    f7 as Xu,
    bh as Qu,
    eV as Zu,
    nl as Ju,
    nm as ed,
    nn as td,
    fh as sd,
    ca as nd,
    fg as ad,
    fi as od,
    no as id,
    e$ as ka,
    d_ as rd,
    bv as ld,
    bw as cd,
    np as ud,
    nq as dd,
    il as hd
} from "./ab2oz9enzsoo3wow.js";
import {
    e as ft,
    P as Ft,
    d as md,
    D as fd,
    T as yn,
    M as gd,
    g as pd,
    E as xd,
    h as vd
} from "./bv1tgraszqspgaxz.js";
import {
    p as Sd,
    k as wn,
    c as Aa,
    g as bd,
    i as yd,
    n as wd
} from "./t7u8ciwlz2voun1n.js";
import {
    bU as Td,
    d as ti,
    bH as Md,
    bq as si,
    bV as Kn,
    af as _d,
    ak as jd,
    bW as Cd,
    bX as ni,
    aw as Yn,
    ad as kd,
    aO as Ad,
    bY as Rd,
    aM as Ed,
    bg as ai,
    bi as oi,
    b as Nd,
    bf as Pd,
    bh as Id,
    b0 as Dd,
    y as Fd,
    bl as Ld,
    G as Bd,
    bC as Od
} from "./mgr0w69u3c317psp.js";
import {
    m as ae
} from "./m0s651bq7jimn9ko.js";
import {
    b as zd
} from "./hxvlxwkzr288aynn.js";
import {
    S as ii,
    a as Hd,
    b as Ud,
    G as Gd,
    L as Wd,
    c as Vd
} from "./n5mnsu7wpta2bimq.js";
import {
    C as qd,
    f as $d
} from "./m7u5z7sua6e1c9ci.js";
import {
    B as Kd
} from "./le5v2hqvx6xa2eig.js";
const ri = new ft("transactionEventPlugin"),
    Tn = "prosemirrorDispatchTransaction";

function Ra(e, t) {
    const {
        eventTarget: n
    } = ri.getState(e.state);
    return n.addEventListener(Tn, t), () => {
        n.removeEventListener(Tn, t)
    }
}

function Yd(e) {
    return new Ft({
        key: ri,
        state: {
            init() {
                return {
                    eventTarget: e
                }
            },
            apply(t, n) {
                return n
            }
        }
    })
}
const Cs = new ft("customKeymapPlugin");

function Xd(e, t) {
    e.dispatch(e.state.tr.setMeta(Cs, {
        handlers: t
    }))
}

function Qd(e = {
    handlers: {}
}) {
    return new Ft({
        key: Cs,
        state: {
            init() {
                return { ...e
                }
            },
            apply(t, n) {
                const a = t.getMeta(Cs);
                return a ? { ...n,
                    ...a
                } : n
            }
        },
        props: {
            handleKeyDown(t, n) {
                const o = Cs.getState(t.state).handlers[n.key];
                return o ? o(n) : !1
            }
        }
    })
}
const lt = new ft("menuSelectorPlugin");

function Ct(e) {
    e.dispatch(e.state.tr.setMeta(lt, {
        active: !1,
        onMenuAction: void 0
    }))
}

function Zd(e, t) {
    e.dispatch(e.state.tr.setMeta(lt, {
        active: !0,
        onMenuAction: t
    }))
}

function Jd(e = {
    submitKeys: ["Enter", "Tab"],
    cancelKeys: ["Escape"],
    checkStrictMatchKeys: []
}) {
    return new Ft({
        key: lt,
        state: {
            init() {
                return { ...e,
                    active: !1
                }
            },
            apply(t, n) {
                const a = t.getMeta(lt);
                return a ? { ...n,
                    ...a
                } : n
            }
        },
        props: {
            handleKeyDown(t, n) {
                const a = lt.getState(t.state);
                return a.active ? a.submitKeys.includes(n.key) ? (n.preventDefault(), n.stopPropagation(), n.stopImmediatePropagation(), a.onMenuAction ? .("submit"), Ct(t), !0) : a.cancelKeys.includes(n.key) ? (n.preventDefault(), a.onMenuAction ? .("cancel"), Ct(t), !0) : n.key === "ArrowUp" ? (n.preventDefault(), a.onMenuAction ? .("up"), !0) : n.key === "ArrowDown" ? (n.preventDefault(), a.onMenuAction ? .("down"), !0) : (a.checkStrictMatchKeys.includes(n.key) && a.onMenuAction ? .("checkMatch"), !1) : !1
            },
            handleDOMEvents: {
                blur: t => {
                    lt.getState(t.state).onMenuAction ? .("cancel")
                }
            }
        }
    })
}
const Yt = new ft("placeholderPlugin");

function eh(e) {
    return new Ft({
        key: Yt,
        state: {
            init() {
                return {
                    placeholder: e
                }
            },
            apply(t, n) {
                return t.getMeta(Yt) ? {
                    placeholder: t.getMeta(Yt).placeholder
                } : n
            }
        },
        props: {
            decorations(t) {
                const {
                    doc: n
                } = t;
                if (n.childCount === 1 && n.firstChild ? .isTextblock && n.firstChild.content.size === 0) {
                    const o = [],
                        {
                            placeholder: i
                        } = Yt.getState(t);
                    return t.doc.descendants((r, l) => {
                        const c = md.node(l, l + r.nodeSize, {
                            class: "placeholder",
                            "data-placeholder": i
                        });
                        o.push(c)
                    }), fd.create(n, o)
                }
            }
        }
    })
}
const Gs = "command_token",
    th = {
        group: "inline",
        inline: !0,
        atom: !0,
        content: "text*",
        attrs: {
            id: "",
            hint: ""
        },
        selectable: !1,
        draggable: !1,
        toDOM: e => ["span", {
            "data-mention-id": e.attrs.id,
            "data-mention-hint": e.attrs.hint,
            class: "hint-pill"
        }, e.attrs.hint],
        parseDOM: [{
            tag: "span[data-mention-id][data-mention-hint]",
            getAttrs: e => {
                const t = e.getAttribute("data-mention-id"),
                    n = e.getAttribute("data-mention-hint");
                return {
                    id: t,
                    hint: n
                }
            }
        }]
    };

function li(e, t) {
    if (e.depth === 0) return;
    const n = e.before(),
        o = e.doc.textBetween(n, e.pos, `
`, "\0").match(new RegExp(/(^|\s)\/(\w*)$/));
    if (o && o.index !== void 0) {
        const i = o[0].startsWith(" ") ? o.index + 1 : o.index,
            r = o[0].startsWith(" ") ? o[0].length - 1 : o[0].length,
            l = e.start() + i,
            c = l + r,
            m = l === t ? .from;
        return {
            range: {
                from: l,
                to: c
            },
            queryText: o[2],
            isDismissed: m
        }
    }
}
const Jt = new ft("slashCommandPlugin");

function sh(e) {
    const n = e.state.selection.$from,
        a = li(n, void 0);
    if (!a) return;
    const o = e.state.tr;
    e.dispatch(o.setMeta(Jt, { ...o.getMeta(Jt),
        dismissedRange: a.range
    }))
}

function Ea() {
    return {
        queryText: "",
        active: !1,
        range: void 0
    }
}

function nh(e, t, n, a, o, i) {
    let r;
    if (t.id === Hs.Search && o) r = e.state.tr.delete(n.from, n.to), i(!0);
    else {
        const l = e.state.schema.nodes[Gs].create({ ...t
        }, e.state.schema.text(t.hint));
        r = e.state.tr.replaceWith(n.from, n.to, l), a && r.insertText(" ", n.from + l.nodeSize)
    }
    e.dispatch(r)
}

function Na(e) {
    const {
        active: t,
        range: n,
        queryText: a,
        onHintMatch: o,
        dismissedRange: i
    } = e;
    if (o) return !t || !n || i ? .from === n.from ? o(void 0) : o({
        text: a,
        range: n
    })
}

function ah(e) {
    const t = [];
    return e.descendants(n => {
        n.type.name === Gs && typeof n.attrs ? .id == "string" && t.push(n.attrs.id)
    }), t
}

function oh(e) {
    const t = e.state.tr;
    t.doc.descendants((n, a) => {
        n.type.name === Gs && t.insertText(n.textContent, a, a + n.nodeSize)
    }), t.steps.length > 0 && e.dispatch(t)
}

function ih() {
    return new Ft({
        key: Jt,
        state: {
            init() {
                return Ea()
            },
            apply(e, t) {
                const n = e.getMeta(Jt),
                    a = e.selection,
                    o = a.$from,
                    i = li(o, t.dismissedRange),
                    r = { ...Ea(),
                        ...t,
                        ...n
                    };
                return a.from !== a.to ? (Na(r), r) : (r.active = !!i, i && (r.queryText = i.queryText, r.range = i.range, i.isDismissed && (i.queryText === "" && t.queryText !== "" ? r.dismissedRange = void 0 : r.dismissedRange = i.range)), Na(r), r)
            }
        }
    })
}
class Ws extends Vr {
    constructor(t) {
        super(), this.view = t
    }
    get document() {
        return this.view.dom.ownerDocument
    }
    isEmpty() {
        return this.view.state.doc.textContent.trim().length === 0
    }
    trimLeadingText(t) {
        const a = this.view.state.tr;
        let o = !1,
            i = !1;
        return a.doc.descendants((r, l) => {
            o || !r.isText || (o = !0, r.text ? .startsWith(t) && (i = !0, a.insertText(r.text.replace(t, ""), l, l + r.text.length)))
        }), i && this.view.dispatch(a), i
    }
    replaceAll(t, n) {
        const o = this.view.state.tr,
            i = [];
        o.doc.descendants((r, l) => {
            !r.isText || r.text === void 0 || i.push({
                node: r,
                pos: l
            })
        }), i.reverse(), i.forEach(({
            node: r,
            pos: l
        }) => {
            !r.isText || r.text === void 0 || r.text.includes(t) && o.insertText(r.text.replaceAll(t, n), l, l + r.text.length)
        }), this.view.dispatch(o)
    }
    appendText(t) {
        this.view.dispatch(this.view.state.tr.insertText(t))
    }
    focus() {
        this.view.focus(), this.view.dispatch(this.view.state.tr.setSelection(yn.atEnd(this.view.state.doc)))
    }
    setText(t) {
        const {
            tr: n,
            schema: a
        } = this.view.state, o = t ? a.nodes.paragraph.create(null, a.text(t)) : a.nodes.paragraph.create();
        this.view.dispatch(n.replaceWith(0, this.view.state.doc.content.size, o)), this.view.hasFocus() && this.view.dispatch(this.view.state.tr.setSelection(yn.atEnd(this.view.state.doc)))
    }
    getCurrentText() {
        return this.view.state.doc.textContent
    }
    hasMultipleLines() {
        let t = 0;
        return this.view.state.doc.descendants(n => {
            n.isBlock && t++
        }), t > 1
    }
    getContentToSend() {
        return Sd(this.view)
    }
    resize() {}
    isReady() {
        return !!this.view.state.doc
    }
    setPlaceholder(t) {
        this.view.dispatch(this.view.state.tr.setMeta(Yt, {
            placeholder: t
        }))
    }
    getSelectionStart() {
        return this.view.state.selection.ranges[0].$from.pos
    }
    isMenuSelectorActive() {
        return lt.getState(this.view.state).active
    }
    registerKeyHandlers(t) {
        Xd(this.view, t)
    }
    acceptLegacyKeydown() {
        return !1
    }
    subscribe(t, n) {
        if (t === "change") {
            const a = () => n(void 0);
            return Ra(this.view, a)
        }
        return this.view.dom ? .addEventListener(t, n), () => {
            this.view.dom ? .removeEventListener(t, n)
        }
    }
    useState(t) {
        return u.useSyncExternalStore(n => Ra(this.view, n), () => t(this), () => t(this))
    }
    getSystemHintsFromDoc() {
        return ah(this.view.state.tr.doc)
    }
    getSystemHints() {
        const t = this.getSystemHintsFromDoc();
        return t.length ? [t[0]] : []
    }
    replaceSlashCommandTokensWithText() {
        oh(this.view)
    }
    canShowAutocompletion() {
        return !this.isMenuSelectorActive() && !this.getSystemHintsFromDoc().length
    }
}
const Pa = Se.div `m-8 flex flex-col items-center`;

function Ia(e) {
    return s.jsx(ae.div, {
        initial: {
            opacity: 0,
            translateY: 20
        },
        animate: {
            opacity: 1,
            translateY: 0,
            transition: {
                duration: .5,
                ease: "easeIn"
            }
        },
        ...e
    })
}

function rh({
    clientThreadId: e
}) {
    const n = Qi(e) ? .gizmoId,
        {
            data: a
        } = os(n);
    return n == null || a == null || !qr(a) ? null : s.jsx(lh, {
        gizmoId: n
    })
}

function lh({
    gizmoId: e
}) {
    const [t, n] = u.useState(!1), [a, o] = u.useState(!1), i = $r(e), r = async c => {
        n(!0), setTimeout(() => {
            o(!0)
        }, 5e3), oe.logEvent(ne.submitInlineRating, {
            gizmo_id: e,
            rating: c
        }), await i.mutateAsync({
            rating: c
        })
    }, l = async () => {
        o(!0), oe.logEvent(ne.dismissInlineRating, {
            gizmo_id: e
        }), await i.mutateAsync({})
    };
    return u.useEffect(() => {
        a || oe.logEvent(ne.showInlineRating, {
            gizmo_id: e
        })
    }, [a, e]), a ? null : t ? s.jsx(Pa, {
        children: s.jsxs(Ia, {
            className: "flex flex-col items-center gap-4",
            children: [s.jsx("div", {
                className: "rounded-lg border border-token-border-heavy p-4",
                children: s.jsxs("div", {
                    className: "flex justify-between gap-2",
                    children: [s.jsx(O, {
                        id: "gizmo.inlineReview.reviewLeft",
                        defaultMessage: "Feedback sent"
                    }), s.jsx(fa, {
                        onClick: () => {
                            o(!0)
                        }
                    })]
                })
            }), s.jsx("div", {
                className: "text-xs text-token-text-tertiary",
                children: s.jsx(O, {
                    id: "gizmo.inlineReview.reviewLeftSubtext",
                    defaultMessage: 'To update your rating, click "Send Feedback" in the GPT Menu'
                })
            })]
        })
    }) : s.jsx(Pa, {
        children: s.jsxs(Ia, {
            className: "flex flex-col items-center gap-4 rounded-lg border border-token-border-heavy p-4",
            children: [s.jsxs("div", {
                className: "flex justify-between gap-2",
                children: [s.jsx(O, {
                    id: "gizmo.inlineReview.prompt",
                    defaultMessage: "How would you rate this GPT so far?"
                }), s.jsx(fa, {
                    onClick: l
                })]
            }), s.jsx(Kr, {
                rating: void 0,
                onRating: r
            })]
        })
    })
}
const ch = ({
    clientThreadId: e
}) => {
    const t = oo(),
        n = Bs(e),
        a = ut(n);
    u.useEffect(() => {
        a && ga.dismissBanner()
    }, [a]);
    const o = t ? .is_dismissible ? () => ga.dismissBanner() : void 0;
    return s.jsx(is, {
        children: t && s.jsx(ae.div, {
            transition: {
                type: "tween",
                ease: "easeInOut",
                duration: .1
            },
            initial: {
                opacity: 0,
                transform: "translateY(8px)"
            },
            animate: {
                opacity: 1,
                transform: "translateY(0px)"
            },
            exit: {
                opacity: 0,
                transform: "translateY(8px)"
            },
            children: s.jsx(Yr, {
                clientThreadId: e,
                rateLimitInfo: t,
                onDismiss: o
            })
        })
    })
};

function uh(e) {
    const t = Bs(e),
        n = ut(t),
        a = oo();
    return !n && a != null
}
const Mn = window.sessionStorage,
    _n = Zi(Ji(() => ({
        memoryFullBannerDismissed: !!Mn ? .getItem(un.MemoryFullBannerDismissed)
    }))),
    ci = {
        dismissBanner() {
            _n.setState(e => {
                e.memoryFullBannerDismissed = !0
            }), Mn ? .setItem(un.MemoryFullBannerDismissed, "true")
        },
        clearDismissedBanner() {
            _n.setState(e => {
                e.memoryFullBannerDismissed = !1
            }), Mn ? .removeItem(un.MemoryFullBannerDismissed)
        }
    };

function dh(e) {
    const t = Ge(e),
        n = To(),
        {
            data: a
        } = Mo(t, !1, n),
        o = a != null,
        i = o && a.memoryFullPct >= 100,
        [r, l] = u.useState(!1);
    u.useEffect(() => {
        !i && o && (l(!0), ci.clearDismissedBanner())
    }, [i, o]);
    const c = _n(m => m.memoryFullBannerDismissed);
    return i && r && !c
}

function hh() {
    const e = ze(),
        {
            openSettings: t
        } = Xr();
    return s.jsx(ae.div, {
        initial: {
            opacity: 0
        },
        animate: {
            opacity: 1
        },
        children: s.jsx(Qr, {
            title: e.formatMessage(ws.memoryFullTitle),
            content: e.formatMessage(ws.memoryFullTooltip, ws.memoryFullTooltip.values),
            primaryCtaText: e.formatMessage(ws.memoryManageButton),
            onPrimaryCtaClick: () => t(Zr.Personalization),
            onDismiss: () => ci.dismissBanner()
        })
    })
}
const ws = He({
        memoryFullTitle: {
            id: "yRGU2/",
            defaultMessage: "Memory is full."
        },
        memoryManageButton: {
            id: "a5A88o",
            defaultMessage: "Manage"
        },
        memoryFullTooltip: {
            id: "neUc+N",
            defaultMessage: "New memories won’t be created until you make space. <a>Learn more</a>",
            values: {
                a: e => s.jsx("a", {
                    href: Jr,
                    target: "_blank",
                    rel: "noopener noreferrer",
                    className: "underline",
                    children: e
                })
            }
        }
    }),
    mh = u.memo(function(t) {
        return fh(t), gh(t), ph(), null
    });

function fh(e) {
    const {
        store: t
    } = be(), n = t.useSetSharedProps();
    dn(() => {
        n(e)
    }, [e, n])
}

function gh(e) {
    const {
        clientThreadId: t,
        canContinue: n
    } = e, {
        store: a
    } = be(), o = u.useRef({
        top: a.useContentAreaApi(Nt.HeaderTop),
        bottom: a.useContentAreaApi(Nt.HeaderBottom)
    }).current, i = Sh(e), r = el(t), {
        shouldShowBannerSignup: l,
        shouldShowBannerTermsDisclaimer: c
    } = bh(t), m = uh(t), d = tl(e), h = sl(e), g = nl(e), p = dh(t), b = al(), f = ol(e);
    dn(() => {
        f.eligible ? o.top.set(se.AdvancedVoiceOnMobileAnnouncement) : b ? o.top.set(se.ParagenControls) : c ? o.top.set(se.BannerTermsDisclaimer) : m ? o.top.set(se.BannersRateLimit) : d.eligible ? o.top.set(se.BannerSidekickAnnouncement) : h ? o.top.set(se.SearchBrowserExtensionAnnouncement) : g ? o.top.set(se.SearchBrowserExtensionReactiveAnnouncement) : i ? o.top.set(se.ItemActions) : n ? o.top.set(se.PromptTextareaAction) : l ? o.top.set(se.BannerSignup) : p ? o.top.set(se.BannerMemoryFull) : o.top.set(null)
    }, [o, i, n, c, l, m, d, p, b, f]), dn(() => {
        r && o.bottom.set(_o.DallePromptControls)
    }, [o, r])
}

function ph() {
    const {
        store: e
    } = be();
    u.useEffect(() => () => {
        e.reset()
    }, [e])
}

function xh(e) {
    const t = jo(),
        n = mt(e),
        a = J.getTree(e).getLastValidNode(n) ? .message ? .id;
    return t ? .messageId === a ? t.suggestions : []
}

function vh(e) {
    return xh(e).length > 0
}

function Sh(e) {
    const t = il(e.clientThreadId),
        n = vh(e.clientThreadId);
    return e.isDisabled ? !1 : e.isNewThread || t || n
}

function bh(e) {
    const {
        isUnauthenticated: t
    } = We(), n = mt(e), {
        layer: a
    } = Rt("3637408529"), o = a.get("should_show_no_auth_signup_banner", !0), i = rl(g => g.bannerDisclaimerClientThreadId), r = ll(), l = {
        shouldShowBannerTermsDisclaimer: !1,
        shouldShowBannerSignup: !1
    };
    if (!e) return l;
    const c = J.getTree(e),
        m = c.countMessagesByAuthor(Ce.User),
        d = c.getNodeByIdOrMessageId(n),
        h = d ? .message ? .author.role === Ce.Assistant && er(d.message);
    return l.shouldShowBannerTermsDisclaimer = h && t && m === 1 && !r && (i == null || i === e), l.shouldShowBannerSignup = o && h && t && m > 0 && m % 5 === 0, l
}

function yh({
    children: e,
    className: t,
    showBackground: n
}) {
    return s.jsxs("div", {
        className: "relative",
        children: [e, n && s.jsx(ae.div, {
            initial: {
                scale: 0
            },
            animate: {
                scale: 1
            },
            transition: {
                type: "spring",
                stiffness: 260,
                damping: 20
            },
            className: P("pointer-events-none absolute bottom-0 top-0 h-8 w-8 rounded-full", t)
        })]
    })
}

function wh({
    clientThreadId: e,
    uploadType: t,
    modelAcceptedMimeTypes: n,
    modelSupportedImageMimeTypes: a,
    attachmentsProductFeature: o,
    getInputProps: i,
    openFileDialog: r,
    onOauthRedirect: l,
    historyDisabled: c,
    isDisabled: m,
    highlightTooltip: d
}) {
    const h = cl(),
        {
            gdriveStatus: g,
            o365Status: p
        } = ul(),
        b = s.jsx(Td, {
            className: c ? "text-white" : d ? "text-brand-blue-800" : void 0
        }),
        f = g !== "false" || p !== "false" || h;
    return s.jsx("div", {
        className: "relative",
        children: s.jsx(yh, {
            showBackground: d,
            className: "bg-brand-blue-800/20",
            children: f ? s.jsx(dl, {
                clientThreadId: e,
                icon: b,
                modelAcceptedMimeTypes: n,
                modelSupportedImageMimeTypes: a,
                attachmentsProductFeature: o,
                onOauthRedirect: l,
                uploadType: t,
                openFileDialog: r,
                getInputProps: i,
                isDisabled: m,
                highlightTooltip: d
            }) : s.jsx(hl, {
                clientThreadId: e,
                uploadType: t,
                openFileDialog: r,
                getInputProps: i,
                icon: b,
                isDisabled: m,
                highlightTooltip: d
            })
        })
    })
}
const Th = 500;
class De {
    constructor(t, n) {
        this.items = t, this.eventCount = n
    }
    popEvent(t, n) {
        if (this.eventCount == 0) return null;
        let a = this.items.length;
        for (;; a--)
            if (this.items.get(a - 1).selection) {
                --a;
                break
            }
        let o, i;
        n && (o = this.remapping(a, this.items.length), i = o.maps.length);
        let r = t.tr,
            l, c, m = [],
            d = [];
        return this.items.forEach((h, g) => {
            if (!h.step) {
                o || (o = this.remapping(a, g + 1), i = o.maps.length), i--, d.push(h);
                return
            }
            if (o) {
                d.push(new Be(h.map));
                let p = h.step.map(o.slice(i)),
                    b;
                p && r.maybeStep(p).doc && (b = r.mapping.maps[r.mapping.maps.length - 1], m.push(new Be(b, void 0, void 0, m.length + d.length))), i--, b && o.appendMap(b, i)
            } else r.maybeStep(h.step);
            if (h.selection) return l = o ? h.selection.map(o.slice(i)) : h.selection, c = new De(this.items.slice(0, a).append(d.reverse().concat(m)), this.eventCount - 1), !1
        }, this.items.length, 0), {
            remaining: c,
            transform: r,
            selection: l
        }
    }
    addTransform(t, n, a, o) {
        let i = [],
            r = this.eventCount,
            l = this.items,
            c = !o && l.length ? l.get(l.length - 1) : null;
        for (let d = 0; d < t.steps.length; d++) {
            let h = t.steps[d].invert(t.docs[d]),
                g = new Be(t.mapping.maps[d], h, n),
                p;
            (p = c && c.merge(g)) && (g = p, d ? i.pop() : l = l.slice(0, l.length - 1)), i.push(g), n && (r++, n = void 0), o || (c = g)
        }
        let m = r - a.depth;
        return m > _h && (l = Mh(l, m), r -= m), new De(l.append(i), r)
    }
    remapping(t, n) {
        let a = new gd;
        return this.items.forEach((o, i) => {
            let r = o.mirrorOffset != null && i - o.mirrorOffset >= t ? a.maps.length - o.mirrorOffset : void 0;
            a.appendMap(o.map, r)
        }, t, n), a
    }
    addMaps(t) {
        return this.eventCount == 0 ? this : new De(this.items.append(t.map(n => new Be(n))), this.eventCount)
    }
    rebased(t, n) {
        if (!this.eventCount) return this;
        let a = [],
            o = Math.max(0, this.items.length - n),
            i = t.mapping,
            r = t.steps.length,
            l = this.eventCount;
        this.items.forEach(g => {
            g.selection && l--
        }, o);
        let c = n;
        this.items.forEach(g => {
            let p = i.getMirror(--c);
            if (p == null) return;
            r = Math.min(r, p);
            let b = i.maps[p];
            if (g.step) {
                let f = t.steps[p].invert(t.docs[p]),
                    v = g.selection && g.selection.map(i.slice(c + 1, p));
                v && l++, a.push(new Be(b, f, v))
            } else a.push(new Be(b))
        }, o);
        let m = [];
        for (let g = n; g < r; g++) m.push(new Be(i.maps[g]));
        let d = this.items.slice(0, o).append(m).append(a),
            h = new De(d, l);
        return h.emptyItemCount() > Th && (h = h.compress(this.items.length - a.length)), h
    }
    emptyItemCount() {
        let t = 0;
        return this.items.forEach(n => {
            n.step || t++
        }), t
    }
    compress(t = this.items.length) {
        let n = this.remapping(0, t),
            a = n.maps.length,
            o = [],
            i = 0;
        return this.items.forEach((r, l) => {
            if (l >= t) o.push(r), r.selection && i++;
            else if (r.step) {
                let c = r.step.map(n.slice(a)),
                    m = c && c.getMap();
                if (a--, m && n.appendMap(m, a), c) {
                    let d = r.selection && r.selection.map(n.slice(a));
                    d && i++;
                    let h = new Be(m.invert(), c, d),
                        g, p = o.length - 1;
                    (g = o.length && o[p].merge(h)) ? o[p] = g: o.push(h)
                }
            } else r.map && a--
        }, this.items.length, 0), new De(Co.from(o.reverse()), i)
    }
}
De.empty = new De(Co.empty, 0);

function Mh(e, t) {
    let n;
    return e.forEach((a, o) => {
        if (a.selection && t-- == 0) return n = o, !1
    }), e.slice(n)
}
class Be {
    constructor(t, n, a, o) {
        this.map = t, this.step = n, this.selection = a, this.mirrorOffset = o
    }
    merge(t) {
        if (this.step && t.step && !t.selection) {
            let n = t.step.merge(this.step);
            if (n) return new Be(n.getMap().invert(), n, this.selection)
        }
    }
}
class Ye {
    constructor(t, n, a, o, i) {
        this.done = t, this.undone = n, this.prevRanges = a, this.prevTime = o, this.prevComposition = i
    }
}
const _h = 20;

function jh(e, t, n, a) {
    let o = n.getMeta(ct),
        i;
    if (o) return o.historyState;
    n.getMeta(Ah) && (e = new Ye(e.done, e.undone, null, 0, -1));
    let r = n.getMeta("appendedTransaction");
    if (n.steps.length == 0) return e;
    if (r && r.getMeta(ct)) return r.getMeta(ct).redo ? new Ye(e.done.addTransform(n, void 0, a, ks(t)), e.undone, Da(n.mapping.maps), e.prevTime, e.prevComposition) : new Ye(e.done, e.undone.addTransform(n, void 0, a, ks(t)), null, e.prevTime, e.prevComposition);
    if (n.getMeta("addToHistory") !== !1 && !(r && r.getMeta("addToHistory") === !1)) {
        let l = n.getMeta("composition"),
            c = e.prevTime == 0 || !r && e.prevComposition != l && (e.prevTime < (n.time || 0) - a.newGroupDelay || !Ch(n, e.prevRanges)),
            m = r ? nn(e.prevRanges, n.mapping) : Da(n.mapping.maps);
        return new Ye(e.done.addTransform(n, c ? t.selection.getBookmark() : void 0, a, ks(t)), De.empty, m, n.time, l ? ? e.prevComposition)
    } else return (i = n.getMeta("rebased")) ? new Ye(e.done.rebased(n, i), e.undone.rebased(n, i), nn(e.prevRanges, n.mapping), e.prevTime, e.prevComposition) : new Ye(e.done.addMaps(n.mapping.maps), e.undone.addMaps(n.mapping.maps), nn(e.prevRanges, n.mapping), e.prevTime, e.prevComposition)
}

function Ch(e, t) {
    if (!t) return !1;
    if (!e.docChanged) return !0;
    let n = !1;
    return e.mapping.maps[0].forEach((a, o) => {
        for (let i = 0; i < t.length; i += 2) a <= t[i + 1] && o >= t[i] && (n = !0)
    }), n
}

function Da(e) {
    let t = [];
    for (let n = e.length - 1; n >= 0 && t.length == 0; n--) e[n].forEach((a, o, i, r) => t.push(i, r));
    return t
}

function nn(e, t) {
    if (!e) return null;
    let n = [];
    for (let a = 0; a < e.length; a += 2) {
        let o = t.map(e[a], 1),
            i = t.map(e[a + 1], -1);
        o <= i && n.push(o, i)
    }
    return n
}

function kh(e, t, n) {
    let a = ks(t),
        o = ct.get(t).spec.config,
        i = (n ? e.undone : e.done).popEvent(t, a);
    if (!i) return null;
    let r = i.selection.resolve(i.transform.doc),
        l = (n ? e.done : e.undone).addTransform(i.transform, t.selection.getBookmark(), o, a),
        c = new Ye(n ? l : i.remaining, n ? i.remaining : l, null, 0, -1);
    return i.transform.setSelection(r).setMeta(ct, {
        redo: n,
        historyState: c
    })
}
let an = !1,
    Fa = null;

function ks(e) {
    let t = e.plugins;
    if (Fa != t) {
        an = !1, Fa = t;
        for (let n = 0; n < t.length; n++)
            if (t[n].spec.historyPreserveItems) {
                an = !0;
                break
            }
    }
    return an
}
const ct = new ft("history"),
    Ah = new ft("closeHistory");

function Rh(e = {}) {
    return e = {
        depth: e.depth || 100,
        newGroupDelay: e.newGroupDelay || 500
    }, new Ft({
        key: ct,
        state: {
            init() {
                return new Ye(De.empty, De.empty, null, 0, -1)
            },
            apply(t, n, a) {
                return jh(n, a, t, e)
            }
        },
        config: e,
        props: {
            handleDOMEvents: {
                beforeinput(t, n) {
                    let a = n.inputType,
                        o = a == "historyUndo" ? di : a == "historyRedo" ? jn : null;
                    return o ? (n.preventDefault(), o(t.state, t.dispatch)) : !1
                }
            }
        }
    })
}

function ui(e, t) {
    return (n, a) => {
        let o = ct.getState(n);
        if (!o || (e ? o.undone : o.done).eventCount == 0) return !1;
        if (a) {
            let i = kh(o, n, e);
            i && a(t ? i.scrollIntoView() : i)
        }
        return !0
    }
}
const di = ui(!1, !0),
    jn = ui(!0, !0);

function Eh() {
    return wn({
        "Shift-Enter": (e, t) => Aa(e, t),
        Enter: (e, t) => window.innerWidth > ml[fl.Medium] || io ? !1 : Aa(e, t)
    })
}
const Nh = ["p", 0],
    Ph = ["br"],
    Ih = new pd({
        nodes: {
            paragraph: {
                content: "inline*",
                group: "block",
                parseDOM: [{
                    tag: "p",
                    preserveWhitespace: "full"
                }],
                toDOM() {
                    return Nh
                }
            },
            text: {
                group: "inline"
            },
            hard_break: {
                inline: !0,
                group: "inline",
                selectable: !1,
                parseDOM: [{
                    tag: "br"
                }],
                toDOM() {
                    return Ph
                }
            },
            [Gs]: th,
            doc: {
                content: "block+"
            }
        },
        marks: {}
    });

function Dh() {
    const e = new EventTarget,
        t = new xd(null, {
            state: vd.create({
                schema: Ih,
                plugins: [Rh(), Jd({
                    submitKeys: ["Enter", "Tab"],
                    cancelKeys: ["Escape"],
                    checkStrictMatchKeys: [" "]
                }), eh(""), ih(), Eh(), wn({
                    "Mod-z": di,
                    "Mod-y": jn,
                    "Mod-Shift-z": jn
                }), Qd(), wn(zd), Yd(e), bd()]
            }),
            dispatchTransaction(n) {
                const a = t.state.apply(n);
                t.updateState(a), n.docChanged && e.dispatchEvent(new Event(Tn))
            },
            handlePaste(n, a) {
                const o = a.clipboardData ? .getData("text/plain");
                return o === void 0 ? !1 : (gl(o) || yd(n, o), !0)
            },
            clipboardTextSerializer(n) {
                return wd(n.content).content
            }
        });
    return t
}

function Fh() {
    try {
        return navigator.userAgent.toLocaleLowerCase().includes("firefox")
    } catch {
        return !1
    }
}
const Lh = [P([pl["prosemirror-parent"], "text-token-text-primary", "max-h-[25dvh]", "max-h-52", "overflow-auto", Fh() ? "firefox" : "default-browser"])],
    Bh = ({
        children: e
    }) => {
        const [t] = u.useState(() => new Ws(Dh()));
        return e(t)
    },
    Oh = ({
        composerController: e,
        placeholder: t
    }) => {
        const n = u.useContext(ro),
            a = u.useRef(null),
            o = u.useRef(null),
            i = u.useRef(!1);
        return u.useEffect(() => {
            if (i.current) return;
            if (!(e instanceof Ws)) throw new Error(`Expected instance of ProseMirrorComposerController but got ${e.constructor.name}`);
            i.current = !0;
            const r = o.current;
            if (r != null) {
                const {
                    value: l,
                    selectionStart: c,
                    selectionEnd: m
                } = r;
                e.view.dispatch(e.view.state.tr.insertText(l)), e.view.dispatch(e.view.state.tr.setSelection(yn.create(e.view.state.doc, c + 1, m + 1))), r.style.display = "none", r.value = ""
            }
            a.current.appendChild(e.view.dom), e.view.dom.id = ko, xl(e.view.dom), Ao() || e.view.focus()
        }, [e]), u.useEffect(() => {
            e.setPlaceholder(t)
        }, [t, e]), u.useEffect(() => {
            e.logPageMount()
        }, []), s.jsxs("div", {
            ref: a,
            className: P(Lh),
            children: [s.jsx("textarea", {
                className: "block h-10 w-full resize-none border-0 bg-transparent px-0 py-2 text-token-text-primary placeholder:text-token-text-secondary",
                autoFocus: !0,
                placeholder: t,
                ref: o
            }), s.jsx("script", {
                nonce: n.cspScriptNonce,
                suppressHydrationWarning: !0,
                children: "window.__oai_logHTML?window.__oai_logHTML():window.__oai_SSR_HTML=window.__oai_SSR_HTML||Date.now();requestAnimationFrame((function(){window.__oai_logTTI?window.__oai_logTTI():window.__oai_SSR_TTI=window.__oai_SSR_TTI||Date.now()}))"
            })]
        })
    },
    zh = u.forwardRef(function({
        type: t,
        placeholder: n,
        replyRegions: a,
        state: o,
        renderFiles: i,
        leftSideActions: r,
        onSubmit: l,
        inputState: c,
        currentLeafId: m,
        composerController: d,
        clientThreadId: h,
        gizmoId: g,
        disableReason: p
    }, b) {
        const f = Ze(),
            v = vl();
        u.useEffect(() => {
            Ao() || d.focus()
        }, [v ? .modelId, d]);
        const x = M => {
            qh({
                target: M.target,
                rootId: "composer-background",
                additonalInteractiveIds: ["reply-regions"]
            }) || d.focus()
        };
        return s.jsxs("div", {
            id: "composer-background",
            ref: b,
            className: P("flex w-full cursor-text flex-col rounded-3xl px-2.5 py-1 transition-colors contain-inline-size", f && "backdrop-blur-2xl no-transparency:backdrop-blur-none", f && t !== "temporary" && "bg-token-composer-surface", !f && t !== "temporary" && "bg-[#f4f4f4] dark:bg-token-main-surface-secondary", t === "temporary" && "dark bg-black"),
            onClick: x,
            children: [s.jsx(is, {
                initial: !1,
                children: a.length > 0 && s.jsx(ae.div, {
                    initial: {
                        opacity: 0,
                        height: 0
                    },
                    animate: {
                        opacity: 1,
                        height: "auto"
                    },
                    exit: {
                        opacity: 0,
                        height: 0,
                        transition: {
                            duration: .06
                        }
                    },
                    transition: {
                        ease: "easeOut",
                        duration: .1
                    },
                    id: "reply-regions",
                    children: s.jsx(Uh, {
                        replyRegions: a
                    })
                })
            }), s.jsxs(s.Fragment, {
                children: [i, s.jsx("div", {
                    className: "flex min-h-[44px] items-center px-2",
                    children: s.jsx("div", {
                        className: "max-w-full flex-1",
                        children: d instanceof On ? s.jsx(Hh, {
                            composerController: d,
                            currentLeafId: m,
                            placeholder: n,
                            inputState: c
                        }) : s.jsx(Oh, {
                            composerController: d,
                            placeholder: n
                        })
                    })
                }), s.jsxs("div", {
                    className: "flex h-[44px] items-center justify-between",
                    children: [s.jsx("div", {
                        className: "flex gap-x-1",
                        children: r
                    }), s.jsx(Sl, {
                        inputState: c,
                        state: o,
                        onSubmit: l,
                        composerController: d,
                        clientThreadId: h,
                        gizmoId: g,
                        disableReason: p
                    })]
                })]
            })]
        })
    });

function Hh({
    composerController: e,
    currentLeafId: t,
    placeholder: n,
    inputState: a
}) {
    const o = u.useContext(ro);
    return s.jsxs(s.Fragment, {
        children: [s.jsx(bl, {
            id: ko,
            autoFocus: !0,
            tabIndex: 0,
            "data-id": t,
            dir: "auto",
            ref: i => {
                if (!(e instanceof On)) throw new Error("Expected TextAreaComposerController");
                i != null && (e.textArea = i, e.logPageMount())
            },
            rows: 1,
            placeholder: n,
            disabled: a !== "default",
            className: P("m-0 resize-none border-0 bg-transparent px-0 text-token-text-primary focus:ring-0 focus-visible:ring-0", a === "disabled" && "text-center", ["max-h-[25dvh]", "max-h-52"])
        }), s.jsx("script", {
            nonce: o.cspScriptNonce,
            suppressHydrationWarning: !0,
            children: "requestAnimationFrame((function(){window.__oai_logTTI?window.__oai_logTTI():window.__oai_SSR_TTI=window.__oai_SSR_TTI??Date.now()}))"
        })]
    })
}

function Uh({
    replyRegions: e
}) {
    return s.jsx("div", {
        className: "flex cursor-auto flex-col divide-y divide-token-border-light overflow-hidden rounded-b-lg rounded-t-[20px] bg-token-main-surface-primary",
        children: e.map((t, n) => {
            switch (t.type) {
                case "text":
                    return s.jsx(Gh, {
                        value: t.value,
                        onRemoveRegion: t.onRemoveRegion
                    }, n);
                case "object":
                    return s.jsx(Wh, {
                        value: t.value,
                        onRemoveRegion: t.onRemoveRegion
                    }, n);
                case "mention":
                case "system_hint":
                    return s.jsx(Vh, {
                        value: t.value,
                        icon: t.icon,
                        onRemoveRegion: t.onRemoveRegion
                    }, n)
            }
        })
    })
}

function Gh({
    value: e,
    onRemoveRegion: t
}) {
    return s.jsxs(Qn, {
        className: "text-token-text-secondary",
        children: [s.jsx(Zn, {
            children: s.jsx(ti, {
                className: "icon-lg-heavy"
            })
        }), s.jsx(Jn, {
            children: `“${e}”`
        }), s.jsx(Xn, {
            onClick: t
        })]
    })
}

function Wh({
    value: e,
    onRemoveRegion: t
}) {
    return s.jsxs(Qn, {
        className: "text-blue-selection",
        children: [s.jsx(Zn, {
            children: s.jsx(ti, {
                className: "icon-lg-heavy"
            })
        }), s.jsx(Jn, {
            className: "font-semibold",
            children: e
        }), s.jsx(Xn, {
            onClick: t
        })]
    })
}

function Vh({
    value: e,
    icon: t,
    onRemoveRegion: n
}) {
    return s.jsxs(Qn, {
        children: [s.jsx(Zn, {
            className: "mt-0",
            children: t
        }), s.jsx(Jn, {
            className: "font-semibold text-token-text-primary",
            children: e
        }), s.jsx(Xn, {
            onClick: n
        })]
    })
}

function Xn({
    onClick: e
}) {
    return s.jsx("button", {
        onClick: e,
        type: "button",
        className: "flex-shrink-0 text-token-text-secondary",
        children: s.jsx(Md, {
            className: "icon-lg"
        })
    })
}
const Qn = Se.div `flex items-start py-2.5 gap-3 pl-3 pr-1.5 text-sm`,
    Zn = Se.span `flex-shrink-0 mt-0.5 w-7 h-6 flex justify-center items-center`,
    Jn = Se.span `flex-1 line-clamp-3 py-0.5`;

function qh({
    target: e,
    rootId: t,
    additonalInteractiveIds: n
}) {
    let a = e;
    for (; a && a != null;) {
        if (a.tagName === "BUTTON" || a.tagName === "INPUT" || a.tagName === "TEXTAREA" || a.isContentEditable || n.includes(a.id)) return !0;
        if (a.id === t) return !1;
        a = a.parentElement
    }
    return !1
}
const Ts = {
        initial: {
            opacity: 0,
            y: 20,
            scale: .9
        },
        animate: {
            opacity: 1,
            y: 0,
            scale: 1
        },
        transition: {
            delay: .1
        },
        exit: {
            opacity: 0,
            scale: .5,
            transition: {
                duration: .2
            }
        }
    },
    $h = ({
        suggestions: e,
        onSelectingSuggestedReply: t
    }) => s.jsx("div", {
        className: "absolute bottom-full flex w-full max-w-[100vw] grow gap-2 overflow-auto px-1 pb-1 contain-inline-size sm:mb-0 sm:justify-start sm:px-2 sm:pb-0 md:static md:mb-2 md:max-w-none md:justify-center md:overflow-visible",
        children: e.slice(0, 2).map((n, a) => s.jsx(ae.div, {
            initial: Ts.initial,
            animate: Ts.animate,
            transition: {
                delay: (a - 1) * Ts.transition.delay
            },
            exit: Ts.exit,
            children: s.jsx(It, {
                as: "button",
                color: "secondary",
                size: "small",
                onClick: () => {
                    t(n, e, a)
                },
                className: "group whitespace-nowrap md:whitespace-normal",
                children: s.jsx(Yh, {
                    suggestion: n
                })
            }, a)
        }, a))
    });

function Kh({
    suggestions: e,
    onSelectingSuggestedReply: t,
    clientThreadId: n
}) {
    const a = e ? .length > 0;
    u.useEffect(() => {
        a && Pt(e, n)
    }, [a, n]);
    const {
        isUnauthenticated: o
    } = We();
    return a ? e.every(Ro) ? s.jsxs(ae.div, {
        initial: {
            opacity: 0
        },
        animate: {
            opacity: 1
        },
        transition: {
            duration: .3
        },
        className: "flex flex-col items-center",
        children: [o && s.jsx(ts, {
            className: "mb-6 h-12 w-12 sm:hidden"
        }), s.jsx(ii, {
            starterPrompts: e,
            onSelectStarterPrompt: t
        })]
    }) : e.every(Eo) ? s.jsx($h, {
        suggestions: e,
        onSelectingSuggestedReply: t
    }) : null : null
}

function Yh({
    suggestion: e
}) {
    return Eo(e) ? s.jsx(s.Fragment, {
        children: e.text
    }) : Ro(e) ? s.jsxs("div", {
        className: "flex flex-col overflow-hidden",
        children: [e.title && s.jsx("div", {
            className: "truncate font-semibold",
            children: e.title
        }), s.jsx("div", {
            className: P("truncate font-normal", e.title ? "opacity-50" : ""),
            children: e.body
        })]
    }) : null
}

function Xh() {
    const {
        store: e
    } = be(), t = e.useSharedProps();
    return t ? s.jsx(Qh, { ...t
    }) : null
}

function Qh({
    clientThreadId: e,
    suggestions: t
}) {
    const n = Us();
    return t === void 0 || t.length === 0 ? null : s.jsx("div", {
        children: s.jsx(Zh, {
            children: s.jsx("div", {
                className: "grow",
                children: t !== void 0 && s.jsx(Kh, {
                    suggestions: t,
                    onSelectingSuggestedReply: n,
                    clientThreadId: e
                })
            })
        })
    })
}
const Zh = Se.div `h-full flex ml-1 md:w-full md:m-auto gap-0 md:gap-2 justify-center`,
    hi = ({
        className: e,
        children: t
    }) => s.jsx(ae.div, {
        className: e,
        initial: {
            opacity: 0
        },
        animate: {
            opacity: 1
        },
        exit: {
            opacity: 0,
            transition: {
                duration: .1,
                delay: 0
            }
        },
        transition: {
            type: "tween",
            duration: .3,
            delay: .2
        },
        children: t
    });

function Jh({
    currentLeafId: e,
    canContinue: t,
    onContinueGenerating: n
}) {
    const a = u.useCallback(() => {
        const i = new Qt;
        n(e, i), Es()
    }, [n, e]);
    let o = null;
    return t && (o = s.jsx(tm, {
        onHandleContinueGenerating: a
    })), o && s.jsx("div", {
        className: "flex h-full w-full items-center justify-end gap-0 py-4 md:gap-2",
        children: o
    })
}

function em({
    className: e
}) {
    return s.jsx(si, {
        className: P("-rotate-180", e)
    })
}
const tm = ({
        onHandleContinueGenerating: e
    }) => s.jsx(hi, {
        children: s.jsx(It, {
            as: "button",
            color: "secondary",
            onClick: e,
            className: "whitespace-nowrap py-2",
            icon: em,
            size: "small",
            children: s.jsx(O, { ...Le.continueGenerating
            })
        })
    }),
    sm = () => {
        const {
            shouldShowSkipButton: e
        } = No();
        return e ? s.jsx(hi, {
            className: "flex justify-center",
            children: s.jsx(It, {
                as: "button",
                color: "secondary",
                onClick: () => yl.skipParagen(),
                children: s.jsx(O, { ...nm.skip
                })
            })
        }) : null
    },
    nm = He({
        skip: {
            id: "dvcUbp",
            defaultMessage: "Skip"
        }
    }),
    mi = u.memo(function({
        className: t
    }) {
        const {
            store: n
        } = be(), a = n.useIsHeaderContentAreaPopulated();
        return s.jsx("div", {
            className: P(t ? ? "absolute bottom-full left-0 right-0", Ns.PromptTextareaHeader),
            children: s.jsx(wl, {
                shouldRender: a,
                contentArea: Nt.Header,
                children: s.jsxs("div", {
                    className: "mb-2 flex flex-col gap-3.5 pt-2",
                    children: [s.jsx(fi, {}), s.jsx(gi, {})]
                })
            })
        })
    });

function fi() {
    const {
        store: e
    } = be(), t = e.useSharedProps(o => o ? .clientThreadId), n = e.useContentAreaId(Nt.HeaderTop);
    let a;
    switch (n) {
        case se.AdvancedVoiceOnMobileAnnouncement:
            a = s.jsx(jl, {
                clientThreadId: t
            });
            break;
        case se.ParagenControls:
            a = s.jsx(sm, {});
            break;
        case se.ItemActions:
            a = s.jsx(Xh, {});
            break;
        case se.BannerSignup:
            a = s.jsx(om, {});
            break;
        case se.BannerTermsDisclaimer:
            a = s.jsx(im, {});
            break;
        case se.PromptTextareaAction:
            a = s.jsx(rm, {});
            break;
        case se.BannersRateLimit:
            a = s.jsx(lm, {});
            break;
        case se.BannerSidekickAnnouncement:
            a = s.jsx(_l, {});
            break;
        case se.SearchBrowserExtensionAnnouncement:
            a = s.jsx(Ml, {});
            break;
        case se.SearchBrowserExtensionReactiveAnnouncement:
            a = s.jsx(Tl, {});
            break;
        case se.BannerMemoryFull:
            a = s.jsx(hh, {});
            break;
        case se.Box:
            a = s.jsxs("div", {
                className: "flex h-20 w-full items-center justify-center gap-2 bg-red-500 p-2",
                children: ["box", s.jsxs("div", {
                    className: "flex h-full w-full items-center justify-center gap-2 bg-blue-500 p-2",
                    children: ["inner", s.jsx("div", {
                        className: "flex h-full w-full items-center justify-center bg-yellow-400 text-center",
                        children: "actual content"
                    })]
                })]
            });
            break;
        default:
            a = null;
            break
    }
    return a
}

function gi() {
    const {
        store: e
    } = be(), t = e.useContentAreaId(Nt.HeaderBottom);
    let n;
    switch (t) {
        case _o.DallePromptControls:
            n = s.jsx(am, {});
            break;
        default:
            n = null;
            break
    }
    return n
}

function am() {
    const {
        store: e
    } = be(), t = e.useSharedProps(n => n ? .composerController);
    return t ? s.jsx(Cl, {
        composerController: t
    }) : null
}

function om() {
    const {
        store: e
    } = be(), t = e.useSharedProps(o => o ? .clientThreadId), n = kl(), a = Al();
    return t ? n ? s.jsx(Rl, {
        threadId: t,
        showSignUp: a
    }) : s.jsx(El, {
        threadId: t,
        showLogin: a
    }) : null
}

function im() {
    const {
        store: e
    } = be(), t = e.useSharedProps(n => n ? .clientThreadId);
    return t ? s.jsx(Nl, {
        threadId: t
    }) : null
}

function rm() {
    const {
        store: e
    } = be(), t = e.useSharedProps();
    return t ? s.jsx(Jh, { ...t
    }) : null
}

function lm() {
    const {
        store: e
    } = be(), t = e.useSharedProps(n => n ? .clientThreadId);
    return t ? s.jsx(ch, {
        clientThreadId: t
    }) : null
}

function cm({
    composerController: e,
    isDisabled: t,
    highlightTooltip: n,
    clientThreadId: a
}) {
    const {
        setThreadSearchMode: o
    } = zn(), i = Hn(), r = Pl(), [l, c] = u.useState(!1), m = ze(), d = {
        clientThreadId: a
    };
    return s.jsx(dm, {
        highlightTooltip: n,
        analyticsMetadata: d,
        isThreadUsingSearchMode: i,
        isDisabled: t,
        children: s.jsxs("button", {
            className: P("flex h-8 min-w-8 items-center justify-center rounded-lg p-1 text-xs font-semibold", l && "transition-all duration-150", i || n ? "!rounded-2xl bg-blue-250 text-blue-1000 hover:bg-[#BDDCF4] dark:bg-[#2A4A6D] dark:text-[#48AAFF] dark:hover:bg-[#1A416A]" : t ? "opacity-30" : "hover:bg-black/10 focus-visible:outline-black dark:focus-visible:outline-white"),
            "aria-pressed": i,
            "aria-label": m.formatMessage({
                id: "Sl1VH/",
                defaultMessage: "Search the web"
            }),
            disabled: t,
            onTransitionEnd: () => c(!1),
            onClick: h => {
                h.stopPropagation(), h.preventDefault(), c(!0), oe.logEventWithStatsig(ne.composerSearchButtonClicked, "composer_search_button_clicked", d), o(!i, d, An.CONVERSATION_COMPOSER_WEB_ICON), /^search\s?$/i.test(e.getCurrentText()) && e.setText(""), e.replaceSlashCommandTokensWithText(), e.focus()
            },
            children: [s.jsx(Kn, {}), s.jsx(is, {
                children: i && s.jsx(ae.span, {
                    initial: {
                        x: -10,
                        width: 0,
                        opacity: 0
                    },
                    animate: {
                        x: 0,
                        width: "fit-content",
                        opacity: 1
                    },
                    exit: {
                        x: -10,
                        width: 0,
                        opacity: 0
                    },
                    transition: {
                        ease: "easeOut",
                        duration: r ? 0 : .15
                    },
                    children: s.jsx("div", {
                        className: "pl-1 pr-2",
                        children: s.jsx(O, {
                            id: "TbHx8d",
                            defaultMessage: "Search"
                        })
                    })
                })
            })]
        })
    })
}

function um() {
    const e = Po(Un.hasSeenComposerSearchButtonTooltip);
    return !e.isLoading && e.eligible
}

function dm({
    children: e,
    highlightTooltip: t,
    analyticsMetadata: n,
    isThreadUsingSearchMode: a,
    isDisabled: o
}) {
    const i = um() && !a,
        r = Po(Un.hasSeenComposerSearchButtonTooltip);
    return i ? s.jsx(Io, {
        side: "right",
        show: !0,
        theme: "bright",
        dismissOnOutsideClick: !0,
        badge: "new",
        title: s.jsx(O, {
            id: "Yjduqi",
            defaultMessage: "Search the web"
        }),
        onDismiss: r.markAsViewed,
        sideOffset: 0,
        className: "!max-w-2xs xs:!max-w-sm",
        description: s.jsx(O, {
            id: "W51Aei",
            defaultMessage: "Get fast answers with trusted sources. {learnMore}",
            values: {
                learnMore: s.jsx(Il, {
                    href: "https://openai.com/index/introducing-chatgpt-search",
                    className: "underline",
                    children: s.jsx(O, {
                        id: "stA7F4",
                        defaultMessage: "Learn more"
                    })
                })
            }
        }),
        children: s.jsx("div", {
            children: e
        })
    }) : s.jsx("div", {
        children: s.jsx(Rn, {
            sideOffset: 0,
            label: o ? s.jsx(O, {
                id: "GpDAWD",
                defaultMessage: "Search is unavailable"
            }) : s.jsx(O, {
                id: "c+4o2s",
                defaultMessage: "Search the web"
            }),
            side: "right",
            open: t || (a ? !1 : void 0),
            onOpenChange: l => {
                l && oe.logEventWithStatsig(ne.composerSearchButtonHovered, "composer_search_button_hovered", n)
            },
            children: e
        })
    })
}

function hm({
    composerController: e,
    clientThreadId: t
}) {
    const n = Dt(t),
        {
            setThreadSearchMode: a
        } = zn(),
        i = Dl().size > 0,
        r = Do(t, lo.Search),
        l = Fl(t),
        [c, m] = u.useState([]),
        [d, h] = u.useState(void 0),
        [g, p] = u.useState(0);
    u.useEffect(() => {
        m(d ? l.filter(T => T.name.toLocaleLowerCase().startsWith(d.text.toLocaleLowerCase()) || T.systemHint.toLocaleLowerCase().startsWith(d.text.toLocaleLowerCase())) : [])
    }, [d]);
    const b = e.useState(T => T.getSystemHints().length > 0);
    u.useEffect(() => {
        const T = _ => {
            h(A => !A || !_ ? _ : A.text === _.text && A.range.from === _.range.to && A.range.to ? A : _)
        };
        e.view.dispatch(e.view.state.tr.setMeta(Jt, {
            onHintMatch: T
        }))
    }, [e]);
    const f = i || b || !l.length || !c.length || !d;
    u.useEffect(() => {
        f && p(0)
    }, [f]);
    const v = c.length,
        x = u.useCallback(T => {
            p(_ => (T(_) % v + v) % v)
        }, [v]),
        M = c[g],
        S = ({
            hintToSave: T = M,
            expectPerfectMatch: _,
            appendSpace: A = !0
        }) => {
            if (!d || !M || _ && T.name.toLowerCase() !== d.text.toLowerCase()) return;
            oe.logEvent(ne.systemHintSelected, {
                system_hint: T.systemHint,
                conversation_id: n ? ? pa
            });
            const F = d.text + T.name.slice(d.text.length),
                L = {
                    clientThreadId: t
                };
            nh(e.view, {
                id: T.systemHint,
                hint: F
            }, d.range, A, r, R => a(R, L, An.CONVERSATION_COMPOSER_SLASH_SEARCH)), Ct(e.view)
        },
        y = u.useRef(S);
    y.current = S;
    const w = u.useRef(x);
    w.current = x;
    const N = u.useRef(d);
    N.current = d;
    const E = e.view;
    return u.useEffect(() => (f || Zd(E, T => {
        T === "up" ? w.current(_ => _ - 1) : T === "down" ? w.current(_ => _ + 1) : T === "cancel" ? (Ct(E), sh(E)) : T === "submit" ? (y.current({
            expectPerfectMatch: !1
        }), Ct(E)) : T === "checkMatch" && y.current({
            expectPerfectMatch: !0,
            appendSpace: !1
        })
    }), () => Ct(E)), [f, E]), u.useEffect(() => {
        f || oe.logEvent(ne.systemHintListOpened, {
            conversation_id: n ? ? pa
        })
    }, [f]), f ? null : s.jsx(tr, {
        className: "max-w-60",
        onMouseDown: T => {
            T.preventDefault()
        },
        children: c.map((T, _) => s.jsx("div", {
            onMouseOver: () => p(_),
            onClick: () => {
                S({
                    hintToSave: T,
                    expectPerfectMatch: !1
                }), e.focus()
            },
            children: s.jsx(sr, {
                autoFocus: !1,
                className: "group rounded-lg px-1 py-2 hover:bg-token-hint-text",
                spoofHovered: _ === g,
                children: s.jsx(mm, {
                    title: T.name,
                    description: T.description,
                    icon: s.jsx(Ll, {
                        svgString: T.logo,
                        className: "icon-lg text-token-text-secondary group-hover:text-white"
                    }),
                    checked: !1
                })
            })
        }, T.systemHint))
    })
}

function mm({
    title: e,
    description: t,
    icon: n,
    checked: a
}) {
    return s.jsxs("div", {
        className: "group inline-flex w-full items-center justify-start gap-1.5 pl-1.5 pr-3",
        children: [s.jsx("div", {
            className: "flex h-7 w-7 items-center justify-center gap-2.5",
            children: n
        }), s.jsxs("div", {
            className: "shrink grow basis-0",
            children: [s.jsx("p", {
                className: "text-sm font-normal leading-tight text-token-text-primary group-hover:text-white",
                children: e
            }), !!t && s.jsx("p", {
                className: "text-[13px] font-normal leading-[18px] text-token-text-secondary group-hover:text-white",
                children: t
            })]
        }), a && s.jsx(_d, {
            className: P("icon-md text-token-text-primary", {
                "group-hover:hidden": !a
            })
        })]
    })
}

function fm({
    composerController: e,
    clientThreadId: t
}) {
    return e instanceof Ws ? s.jsx(hm, {
        composerController: e,
        clientThreadId: t
    }) : null
}

function gm({
    suggestions: e,
    composerController: t,
    onSelect: n,
    onChange: a
}) {
    const o = Us(),
        i = u.useCallback((d, h, g) => {
            n ? .(d, h, g), o(d, h, g)
        }, [n, o]),
        [r, l] = u.useState(-1),
        [c, m] = u.useState(!1);
    return u.useEffect(() => {
        const d = h => {
            if (h.key === "ArrowDown") {
                const g = r === e.length - 1 ? 0 : r + 1;
                l(g), a ? .(g, !0, e[g])
            } else if (h.key === "ArrowUp") {
                h.preventDefault();
                const g = r <= 0 ? e.length - 1 : r - 1;
                l(g), a ? .(g, !0, e[g])
            } else h.key === "Enter" && !h.shiftKey && e[r] && i(e[r], e, r)
        };
        return t.subscribe("keydown", d)
    }, [e, r, a, i, t]), u.useEffect(() => t.subscribe("blur", () => {
        l(-1), a ? .(-1, !1)
    }), [t, a]), u.useEffect(() => {
        if (!c) {
            const d = () => {
                m(!0), window.removeEventListener("mousemove", d)
            };
            return window.addEventListener("mousemove", d), () => {
                window.removeEventListener("mousemove", d)
            }
        }
    }, [c]), u.useEffect(() => {
        l(-1), a ? .(-1, !1), m(!1)
    }, [e, a]), s.jsx(ae.ul, {
        initial: {
            opacity: 0
        },
        animate: {
            opacity: 1
        },
        exit: {
            opacity: 0
        },
        className: "hidden w-full flex-col p-2.5 group-focus-within:flex group-focus-within:max-lg:flex-col-reverse",
        children: e.map((d, h) => s.jsxs(ae.li, {
            initial: {
                opacity: 0,
                translateY: 4
            },
            animate: {
                opacity: 1,
                translateY: 0
            },
            transition: {
                delay: h * .03
            },
            exit: {
                opacity: 0,
                translateY: 4
            },
            className: "w-full",
            children: [h > 0 && s.jsx("div", {
                className: P("h-[1px] opacity-60 max-lg:hidden", r === h || r === h - 1 ? "mx-2 bg-token-main-surface-secondary" : "bg-token-border-light")
            }), s.jsxs("button", {
                className: P("flex w-full cursor-pointer items-center justify-start whitespace-pre-wrap rounded-lg px-2.5 py-3 text-start", r === h ? "bg-token-main-surface-secondary" : "bg-token-main-surface-primary"),
                onClick: g => {
                    g.preventDefault(), i(d, e, h)
                },
                onMouseDown: g => {
                    g.preventDefault()
                },
                onMouseEnter: () => {
                    c && (l(h), a ? .(h, !1, d))
                },
                onMouseLeave: () => {
                    l(-1), a ? .(-1, !1, d)
                },
                children: [d.icon ? s.jsx("span", {
                    className: "mr-4 h-6 w-6 text-token-text-secondary",
                    children: d.icon
                }) : null, s.jsx("span", {
                    className: "whitespace-pre-wrap",
                    children: d.autocompletionChunks && d.autocompletionChunks.length > 0 ? s.jsx(s.Fragment, {
                        children: d.autocompletionChunks.map((g, p) => s.jsx("span", {
                            className: P(g.isMatched ? "text-token-text-tertiary" : "text-token-text-primary"),
                            children: g.text
                        }, p))
                    }) : s.jsxs(s.Fragment, {
                        children: [s.jsx("span", {
                            className: P(d.type === Ps.Starter ? "text-token-text-secondary" : "text-token-text-tertiary"),
                            children: d.title
                        }), s.jsx("span", {
                            className: "text-token-text-primary",
                            children: d.body
                        })]
                    })
                })]
            }), h > 0 && s.jsx("div", {
                className: P("h-[1px] opacity-60 lg:hidden", r === h || r === h - 1 ? "mx-2 bg-token-main-surface-secondary" : "bg-token-border-light")
            })]
        }, d.id ? ? h))
    })
}

function pm(e, t) {
    e = e.toLocaleLowerCase();
    const n = t;
    t = t.toLocaleLowerCase();
    const a = [];
    let o = 0;
    for (let l = 0; l < t.length && (o < e.length && e[o] === t[l] && (a.push(l), o++), o !== e.length); l++);
    const i = [];
    let r = 0;
    if (a.forEach(l => {
            if (l > r) {
                const c = n.slice(r, l);
                c && i.push({
                    text: c,
                    isMatched: !1
                })
            }
            i.push({
                text: n[l],
                isMatched: !0
            }), r = l + 1
        }), r < t.length) {
        const l = n.slice(r);
        l && i.push({
            text: l,
            isMatched: !1
        })
    }
    return xm(i)
}

function xm(e) {
    if (e.length === 0) return e;
    let t = [e[0]];
    for (let a = 1; a < e.length; a++) {
        const o = t[t.length - 1],
            i = e[a];
        o.isMatched === i.isMatched ? o.text += i.text : t.push(i)
    }
    const n = t.filter(a => a.isMatched).reduce((a, o) => a + o.text.trim().length, 0);
    return t.length <= 4 && n >= 2 ? t : [{
        text: t.map(a => a.text).join(""),
        isMatched: !1
    }]
}
const vm = 1,
    Sm = 3e3;

function bm({
    files: e,
    className: t
}) {
    const n = Wo(),
        a = Fo(),
        o = xc();
    return s.jsxs("div", {
        className: t,
        children: [o.map(i => s.jsx(vc, {
            pastedTextdoc: i,
            textdocId: i.tempId
        }, i.tempId)), e.map(i => s.jsx(Sc, {
            borderRadius: "2xl",
            useV2Style: !0,
            width: n ? "normal" : "wide",
            onRemoveFileClick: () => gn.remove(a, i.tempId, "none"),
            file: i.file,
            fileId: i.fileId ? ? void 0,
            contextConnectorInfo: i.contextConnectorInfo,
            loadingPercentage: i.status === bc.Uploading ? i.progress : void 0
        }, i.tempId))]
    })
}

function ym({
    onAbortCompletion: e,
    onCreateNewCompletion: t,
    onContinueGenerating: n,
    currentModelId: a,
    clientThreadId: o,
    isNewThread: i,
    isCompletionInProgress: r,
    className: l,
    disabled: c = !1,
    disabledReason: m,
    canPause: d = !1,
    canContinue: h = !1,
    suggestions: g,
    isInteractableSharedThread: p,
    composerContainerRef: b,
    composerController: f,
    autocompletions: v,
    requiresFileUpload: x,
    onComposerInput: M,
    onComposerChange: S,
    onAutocompleteSelect: y,
    headerClassName: w,
    hideHeader: N,
    setComposerBarElement: E,
    onTaggingDropdownOpen: T,
    onTaggingDropdownClose: _
}) {
    const A = Gn(),
        F = Os(),
        {
            isUnauthenticated: L
        } = We(),
        R = ze(),
        I = En(),
        U = Fo(),
        C = mt(o),
        B = Bs(o),
        [k] = nr(),
        W = ar(),
        {
            gizmoEditorData: Z,
            mode: $,
            getGizmoId: Y
        } = Bl(),
        fe = co(),
        ye = Ol(),
        ee = ss(),
        re = Lo(),
        ie = Dt(o),
        Pe = !!or(),
        we = !!Nn(),
        [ke, ge] = u.useState({}),
        {
            setThreadSearchMode: Ae,
            clearSearchModeTrigger: Te,
            getSearchModeTrigger: Fe
        } = zn(),
        ue = Hn(),
        [z, D] = u.useState(!1),
        [te, X] = u.useState(!1),
        Q = Ze(),
        V = u.useRef(!1),
        G = Bo(),
        K = a !== null ? G[a] : void 0,
        Me = ir(o);
    let q = Oo(o),
        de = q && "gizmo" in q ? q.gizmo : void 0;
    const [le, _e] = u.useState(null);
    le !== null && (q = {
        gizmo: le,
        gizmo_id: le.gizmo.id,
        kind: dt.GizmoInteraction
    }, de = le);
    const Ie = ya(K, q);
    let gt = !1;
    zl(q) && de ? .gizmo.id === Hl && (gt = !0);
    const Vs = rr(),
        je = !c && !gt && Ie !== wa.None && !L,
        Je = Ul(K, q),
        rs = Gl(K, q);
    let pe = Ta(j => j.files);
    const [Lt] = u.useState(() => Wl());
    $ === "magic" ? pe = pe.filter(j => j.gizmoId != null) : pe = pe.filter(j => j.gizmoId == null);
    const ls = Vl(),
        et = pe.length > 0 || ls,
        tt = Ta(ql.hasUploadInProgress),
        Bt = f.useState(j => {
            const ce = $l(j);
            return typeof K ? .maxTokens == "number" && ce > K.maxTokens
        }),
        pt = f.useState(j => !j.isEmpty()),
        xt = !Bt && !tt && (pt || et);
    zo(pe.length > 0 || tt || pt);
    const cs = (Ie === wa.Multimodal ? Kl : Yl) - pe.length,
        us = cs <= 0,
        Ve = xt && !c && !r && !we,
        [ds, qs] = u.useState(!1),
        vt = Ho(),
        Ot = a || vt.id,
        $s = Do(o, lo.Search),
        st = !c && !de && fe ? .includes(hn.SearchTool) && (fe ? .includes(hn.BrowsingAvailable) || !F ? .isEnterprisey()),
        zt = st && $s,
        St = G[Ot] ? .tags,
        {
            targetedContent: bt,
            setTargetedContent: Ue
        } = Uo(),
        he = bt ? .isFocusedViewContent && !re ? void 0 : bt,
        {
            rebaseSystemMessageContent: hs
        } = Wn();
    u.useEffect(() => {
        if (!A ? .id) return;
        const j = Ma.getAndReset(A ? .id, ie);
        j && f.setText(j.inputText)
    }, [A ? .id, ie, f]), u.useEffect(() => {
        ds !== Ve && (qs(Ve), Ve && lr(!0).then(j => {
            cr.startEnforcement(j), Xl.startEnforcement(j), ur.startEnforcement(j)
        }))
    }, [Ve, ds, q ? .kind, fe]);
    const Ht = Ql(K, q),
        {
            handleFileAccepted: aa
        } = Zl(R, ya(K, q), Je, "mouse", Y, Ht ? .attachments),
        {
            getInputProps: ms,
            open: oa
        } = Jl({
            disabled: c || !je || us,
            noClick: !0,
            onDropAccepted: aa,
            onDropRejected: j => ec(j, R, I, Ie),
            multiple: !0,
            maxSize: tc,
            maxFiles: cs,
            ...sc(rs)
        }),
        fs = dr(Lt),
        Ut = u.useCallback(() => {
            f.eraseContent(), fs.clearMessages(), f.resize(vm), J.clearOverrideModelId(o), Go();
            for (const j of pe) gn.remove(U, j.tempId, "none");
            nc.markAllAsSent()
        }, [f, fs, pe, U, o]),
        Gt = async (j, ce) => {
            if (j ? .preventDefault(), c || !xt && !ce || !q || Et.isLoading(o) !== !1) return;
            const Re = new Qt;
            D(!0);
            const ve = f.getContentToSend(),
                ot = yc(ve.content),
                Js = `${C}-nextPrompt`,
                qt = new wc(Tc.CompletionRequest, {
                    expectedTimingLogs: [{
                        name: "prompt_submitted",
                        expectedInMs: 3e3
                    }]
                }),
                {
                    content: Yi,
                    attachments: ca
                } = Mc(U, ot, K, q),
                ua = [],
                en = [];
            hs && en.push(mr(hs));
            const tn = { ...q
            };
            "gizmo" in tn && delete tn.gizmo;
            let bs = f.getSystemHints();
            ue && (bs = [Hs.Search]);
            const da = Fe(),
                Xi = ue ? da ? ? An.CONVERSATION_COMPOSER_WEB_ICON : void 0,
                ha = _c(),
                ma = jc();
            let $t = {
                promptId: Js,
                content: Yi,
                eventMetadata: {
                    eventSource: j ? "mouse" : "keyboard"
                },
                completionMetadata: {
                    suggestions: g,
                    conversationMode: tn,
                    systemHints: bs,
                    searchSource: Xi
                },
                messageMetadata: { ...ca.length > 0 && {
                        attachments: ca
                    },
                    ...le && {
                        gizmo_id: le ? .gizmo.id
                    },
                    ...ke,
                    ...bs.length > 0 && {
                        system_hints: bs
                    },
                    ...!!ve.metadata && {
                        serialization_metadata: ve.metadata
                    },
                    ...ha.length > 0 && {
                        canvas: {
                            pasted_textdocs: ha
                        }
                    },
                    ...Object.keys(ma).length > 0 && {
                        __internal: {
                            search_settings: ma
                        }
                    }
                },
                prependMessages: ua.length > 0 ? ua : void 0,
                appendMessages: en.length > 0 ? en : void 0,
                turnTracker: Re,
                profiler: qt,
                requestedModelId: Me
            };
            $t = Cc($t), he ? .createNewCompletionParams && ($t = await he.createNewCompletionParams($t)), qt.logTiming("request_params_ready"), await t($t), he ? .onCreateCompletion ? .({
                serverThreadId: ie,
                currentLeafId: C
            }), he ? .shouldPersistAcrossMessages !== !0 && Ue(void 0), Is.hideThreadHeader(), Ut(), D(!1), qt.logTiming("prompt_submitted"), g !== void 0 && (me.logEvent("chatgpt_prompt_ignore_suggestions"), oe.logEvent(ne.promptIgnoreSuggestions)), ue && da && Te()
        },
        Ks = u.useRef(Gt);
    u.useEffect(() => {
        Ks.current = Gt
    });
    const Ys = j => {
            Ue(j.targetedReply), j.targetedReply && (f.focus(), oe.logEvent(ne.targetedReplyButtonClicked, {
                conversationId: ie,
                sourceMessageId: j.messageId
            }))
        },
        gs = u.useCallback(() => {
            he ? .onCleared ? .({
                serverThreadId: ie,
                currentLeafId: C
            }), Ue(void 0), f.focus()
        }, [C, ie, he, Ue, f]),
        ps = {
            Enter: {
                validator: j => {
                    const ce = j.isComposing || j.keyCode === 229;
                    return !(te && V.current) && (j.metaKey || (ye || io) && !j.shiftKey && !ce)
                },
                handler: j => {
                    if (!Ve) {
                        Bt && I.danger("The message you submitted was too long, please submit something shorter.", {
                            hasCloseButton: !0
                        });
                        return
                    }
                    j.preventDefault(), Gt()
                }
            },
            Escape: {
                validator: j => !j.isComposing,
                handler: j => {
                    d && r && (e("", B), oe.logEvent(ne.pauseCompletion, {
                        threadId: J.getServerThreadId(o),
                        currentLeafId: J.getTree(o).getMessageId(C),
                        eventSource: "keyboard"
                    })), j.target.value === "" && gs()
                }
            }
        },
        nt = u.useRef(ps);
    nt.current = ps;
    const xs = u.useRef(null),
        at = ac(St, q ? .kind),
        [Wt, yt] = u.useState(!1),
        [H, xe] = u.useState(!1),
        qe = at && Wt,
        vs = f.isReady();
    u.useEffect(() => f.subscribe("keydown", j => {
        f.acceptLegacyKeydown() && nt.current[j.key] ? .validator(j) && nt.current[j.key].handler(j);
        const Re = f.getCurrentText();
        if (j.key === "@") {
            const ve = f.getSelectionStart(),
                ot = Re.substring(0, ve);
            (!ot || /\s$/.test(ot) || ve === 0) && (xs.current ? .handleClose(), setTimeout(() => yt(!0), 10))
        } else Wt && yt(!1);
        if (j.key === "Escape" && (_e(null), X(!1)), zt && !ue) {
            let ve;
            j.key === "Backspace" ? ve = Re.substring(0, Re.length - 1) : ve = Re + j.key, /^search\s?$/i.test(ve) ? xe(!0) : H && xe(!1)
        }
        ue && j.key === "Escape" && Ae(!1, {
            clientThreadId: o
        })
    }), [f, vs, Wt, H, zt, ue, Ae, o]), u.useEffect(() => {
        const j = Object.fromEntries(Object.keys(nt.current).map(ce => [ce, ve => {
            const ot = nt.current[ce];
            if (!ot || f.acceptLegacyKeydown()) return !1;
            const {
                validator: Js,
                handler: qt
            } = ot;
            return Js(ve) ? (qt(ve), !0) : !1
        }]));
        f.registerKeyHandlers(j)
    }, [f, vs]), u.useEffect(() => f.subscribe("paste", j => {
        oc({
            filePickerStore: U,
            event: j,
            intl: R,
            toaster: I,
            clientThreadId: o,
            conversationMode: q,
            currentModelConfig: K,
            getEditorGizmoId: Y,
            modelSupportedImageMimeTypes: Je
        })
    }), [R, o, q, K, Y, Je, f, I, U]);
    const Xs = j => {
            Pe || _e(j), f.trimLeadingText("@"), Es(), yt(!1)
        },
        Ri = ic(o, Lt, R, Je, Ht ? .attachments),
        Ei = u.useCallback(j => {
            j ? .preventDefault(), e("", B), oe.logEvent(ne.pauseCompletion, {
                threadId: J.getServerThreadId(o),
                currentLeafId: J.getTree(o).getMessageId(C),
                eventSource: "mouse"
            }), Es()
        }, [e, o, B, C]),
        ia = u.useCallback(() => {
            Ma.set(A ? .id, ie, f.getCurrentText())
        }, [ie, A ? .id, f]);
    u.useEffect(() => {
        Z || !z && !rc() && f.focus()
    }, [z, f]), u.useEffect(() => {
        Z || gn.reset(U)
    }, [a, U, Z]), u.useEffect(() => {
        (!at && le || Pe) && _e(null)
    }, [at, le, Pe]);
    const [Ni, Pi] = (() => {
        switch (m) {
            case "workspaceDisallowsGizmo":
                return [Le.disallowedByWorkspacePlaceholder, !0];
            case "feedbackRequired":
                return [Le.disabledFeedbackPlaceholder, !0];
            case "noModelsAvailable":
                return [Le.noModelsAvailablePlaceholder, !0];
            case "requiresPluginsToBeInstalled":
                return [Le.requiresPluginsToBeInstalled, !0];
            case "loadingPlugins":
                return [Le.loading, !0];
            case "noTestGizmoId":
                return [Le.noTestGizmoId, !0];
            default:
                return p ? [Le.placeholderWithName, !1] : he ? .placeholderTextOverride != null ? [he.placeholderTextOverride, !1] : [Le.placeholderWithName, !1]
        }
    })(), Ii = R.formatMessage(Ni, {
        name: Z != null ? $ === "magic" ? lc : Z.name || "GPT" : de ? .gizmo.display.name ? ? "ChatGPT"
    });
    u.useEffect(() => f.subscribe("input", () => {
        Vn.getState().isThreadHeaderVisible && Is.hideThreadHeader(), X(!0)
    }), [f]), u.useEffect(() => {
        if (M) return f.subscribe("input", () => {
            M ? .()
        })
    }, [f, M]), u.useEffect(() => {
        if (S) return f.subscribe("change", () => {
            S ? .()
        })
    }, [f, S]), u.useEffect(() => f.subscribe("focus", () => {
        X(!0)
    }), [f]);
    const Di = {
            clientThreadId: o,
            uploadType: Ie,
            modelAcceptedMimeTypes: rs,
            modelSupportedImageMimeTypes: Je,
            attachmentsProductFeature: Ht ? .attachments,
            getInputProps: ms,
            openFileDialog: oa,
            historyDisabled: ee,
            onOauthRedirect: ia,
            highlightTooltip: x && !et
        },
        Qs = [],
        Fi = !c && !us && (je || Vs != null) && !ue;
    Qs.push(s.jsx(wh, { ...Di,
        isDisabled: !Fi
    }, "file-upload-button")), st && Qs.push(s.jsx(cm, {
        composerController: f,
        highlightTooltip: H,
        clientThreadId: o,
        isDisabled: !zt || et
    }, "search-button"));
    const Li = et && s.jsxs(s.Fragment, {
            children: [$ === "magic" && s.jsx("div", {
                className: "m-2 mb-0 rounded-lg bg-token-main-surface-secondary p-2 text-xs text-token-text-secondary",
                children: s.jsx(O, { ...Le.gizmoKnowledgeWarning
                })
            }), s.jsx(bm, {
                files: pe,
                className: "flex flex-nowrap gap-2 overflow-x-auto p-1.5"
            })]
        }),
        Bi = Pi ? "disabled" : "default",
        Oi = r && d,
        zi = hr(),
        Hi = !Ve || z || zi,
        Ui = kc(tt, pt, Bt),
        Ss = Oi ? "streaming" : Hi ? "disabled" : "idle",
        Vt = u.useRef(null),
        wt = u.useRef(null),
        {
            layer: Gi
        } = Oe("387752763"),
        {
            layer: Wi
        } = Oe("51287004"),
        Vi = Gi.get("enable_slash_commands", !1) && (L || !F ? .isFree() || Wi.get("enable", !1)),
        qi = a && [Ac, Rc].includes(a),
        $i = Vi && q ? .kind === dt.PrimaryAssistant && !ue;
    u.useEffect(() => {
        const j = () => {
            Vt.current != null && mn.addAction("composer_state_disabled", {
                threadId: J.getServerThreadId(o),
                disabledReason: Vt.current
            })
        };
        if (xt && Ss === "disabled") {
            let ce = "unknown";
            c ? ce = m ? ? "component_disabled_unknown" : r ? ce = "completion_in_progress" : we ? ce = "thread_hard_blocked" : z && (ce = "starting_new_completion_request"), Vt.current !== ce && (wt.current && clearTimeout(wt.current), wt.current = setTimeout(j, Sm)), Vt.current = ce
        } else Vt.current = null;
        return () => {
            wt.current && (clearTimeout(wt.current), wt.current = null)
        }
    }, [o, xt, Ss, c, m, r, we, z]);
    const Zs = [];
    if (he ? .label && Zs.push({
            type: he.type,
            value: he.label,
            onRemoveRegion: gs
        }), le !== null) {
        const j = !!le.gizmo.tags ? .includes(qn.FirstParty);
        Zs.push({
            type: "mention",
            value: le.gizmo.display.name,
            icon: s.jsx(cc, {
                isFirstParty: j,
                src: le.gizmo.display.profile_picture_url,
                className: "icon-md"
            }),
            onRemoveRegion: () => {
                _e(null), f.focus()
            }
        })
    }
    u.useEffect(() => {
        (!v || v.length === 0 || !te) && (V.current = !1)
    }, [v, te]);
    const Ki = (j, ce, Re) => {
            V.current = j >= 0, ce && f.setText(Re ? `${Re.title}${Re.body}` : "")
        },
        ra = te && v && v.length > 0 && !qe && !f.hasMultipleLines() && f.canShowAutocompletion();
    u.useEffect(() => {
        qe ? T ? .() : _ ? .()
    }, [qe, T, _]);
    const la = Ss === "streaming" ? Ei : Gt;
    return s.jsxs(uc.Provider, {
        value: Lt,
        children: [s.jsx(dc, {
            onOauthRedirect: ia,
            children: s.jsx("form", {
                className: l,
                onSubmit: la,
                children: s.jsxs("div", {
                    className: "relative flex h-full max-w-full flex-1 flex-col",
                    children: [!N && !Q && s.jsx(mi, {
                        className: w
                    }), s.jsxs("div", {
                        className: "relative h-0",
                        children: [qe && s.jsx("div", {
                            className: P("absolute bottom-3 w-full space-y-2", Ns.TagGpt),
                            children: s.jsx(hc, {
                                onClick: j => Xs(j),
                                onClose: () => {
                                    yt(!1), f.focus()
                                }
                            })
                        }), $i && s.jsx("div", {
                            className: P("absolute bottom-3 space-y-2", Ns.TagGpt),
                            children: s.jsx(fm, {
                                composerController: f,
                                clientThreadId: o
                            })
                        })]
                    }), s.jsxs("div", {
                        ref: b,
                        className: "group relative flex w-full items-center",
                        children: [i && k.has("from_template_row") && s.jsx("button", {
                            type: "button",
                            onClick: () => {
                                W("/")
                            },
                            className: "mr-2 flex h-8 w-8 items-center justify-center text-token-text-tertiary hover:text-token-text-secondary",
                            children: s.jsx(jd, {
                                className: "icon-lg"
                            })
                        }), at && !!ie && s.jsx(mc, {
                            ref: xs
                        }), s.jsx(zh, {
                            type: ee ? "temporary" : "default",
                            ref: E,
                            replyRegions: Zs,
                            placeholder: Ii,
                            inputState: Bi,
                            composerController: f,
                            leftSideActions: Qs,
                            state: Ss,
                            onSubmit: la,
                            renderFiles: Li,
                            currentLeafId: C,
                            clientThreadId: o,
                            gizmoId: de ? .gizmo.id,
                            disableReason: Ui,
                            modelId: Ot
                        }), ra && s.jsx("div", {
                            className: "absolute left-0 z-10 box-border w-full bg-token-main-surface-primary pl-0 max-lg:bottom-full lg:top-full",
                            children: s.jsx(gm, {
                                suggestions: v,
                                composerController: f,
                                onSelect: y,
                                onChange: Ki
                            })
                        })]
                    }), s.jsx(fc, {
                        composerController: f,
                        parsedDocumentHandler: Ri
                    })]
                })
            })
        }), s.jsx(mh, {
            canUseInlineTagging: at,
            isDisabled: c,
            clientThreadId: o,
            currentLeafId: C,
            currentRequestId: B,
            canContinue: h,
            composerController: f,
            setPromptInputMetadata: ge,
            suggestions: g,
            isNewThread: i,
            onCreateNewCompletion: t,
            onContinueGenerating: n,
            onResetState: Ut,
            conversationMode: q,
            isShowingAutocomplete: !!ra
        }), q != null && !qi && gc.includes(q.kind) && s.jsx(pc, {
            onTargetedReply: Ys
        })]
    })
}
const wm = ({
        children: e
    }) => {
        const [t] = u.useState(() => new On);
        return e(t)
    },
    pi = ({
        children: e
    }) => {
        const {
            layer: t
        } = Oe("387752763");
        return t.get("enable_rich_text_composer", !1) ? s.jsx(Bh, {
            children: e
        }) : s.jsx(wm, {
            children: e
        })
    };

function Tm(e) {
    const t = e.message ? .author.role === Ce.User,
        n = e.metadata ? .err != null && e.metadata ? .errCode !== xa.ContentPolicy,
        a = e.metadata ? .errCode === xa.ModelIncompatibility;
    return e.metadata ? .canRetry === !1 || a ? !1 : t || n
}

function Mm(e) {
    return e.composerController ? s.jsx(La, { ...e,
        composerController: e.composerController
    }) : s.jsx(pi, {
        children: t => s.jsx(La, { ...e,
            composerController: t
        })
    })
}

function La({
    clientThreadId: e,
    isNewThread: t,
    currentModelId: n,
    showPromptStarters: a,
    noWrap: o,
    onRequestCompletion: i,
    composerContainerRef: r,
    composerController: l
}) {
    const c = Pn(),
        m = In(),
        d = Dn(g => {
            const p = Et.getCurrentNode(e, g);
            return Tm(p)
        });
    if (Vo(l), !m && d) return s.jsx(_m, {
        clientThreadId: e
    });
    const h = s.jsx(s.Fragment, {
        children: s.jsx(xi, {
            composerContainerRef: r,
            composerController: l,
            clientThreadId: e,
            currentModelId: n,
            isNewThread: t,
            showPromptStarters: a,
            onRequestCompletion: i
        })
    });
    return o ? h : s.jsxs(s.Fragment, {
        children: [s.jsx(rh, {
            clientThreadId: e
        }), s.jsx($n, {
            clientThreadId: e,
            isStaticSharedThread: c,
            withVerticalPadding: !1,
            withHorizontalPadding: !0,
            children: s.jsx(Zt, {
                children: h
            })
        })]
    })
}

function _m({
    clientThreadId: e
}) {
    const t = Ec(e),
        n = Dn(i => Et.getCurrentNode(e, i).metadata ? .errCode === Nc),
        a = Pc(i => i.isoDate),
        o = mt(e);
    return n && a != null && a !== "" ? null : s.jsxs("div", {
        children: [s.jsx("div", {
            className: "mb-3 text-center text-xs",
            children: s.jsx(O, { ...Ba.errorGeneratingResponse
            })
        }), s.jsx("div", {
            className: "flex items-center md:mb-4",
            children: s.jsx(It, {
                as: "button",
                color: "primary",
                onClick: () => {
                    const i = new Qt;
                    me.logEvent("chatgpt_regenerate_due_to_error_button_clicked", void 0, Xe({
                        clientThreadId: e
                    })), t({
                        id: o,
                        eventMetadata: {
                            eventSource: "mouse"
                        },
                        conversationMode: Et.getConversationMode(e),
                        turnTracker: i
                    })
                },
                className: "m-auto",
                icon: si,
                "data-testid": "regenerate-thread-error-button",
                children: s.jsx(O, { ...Ba.regenerateResponse
                })
            })
        })]
    })
}

function xi({
    clientThreadId: e,
    currentModelId: t,
    isNewThread: n,
    onRequestCompletion: a,
    showPromptStarters: o,
    composerContainerRef: i,
    composerController: r,
    autocompletions: l,
    requiresFileUpload: c,
    onComposerInput: m,
    onComposerChange: d,
    onAutocompleteSelect: h,
    headerClassName: g,
    hideHeader: p,
    onTaggingDropdownClose: b,
    onTaggingDropdownOpen: f
}) {
    const v = mt(e),
        x = Bs(e),
        M = pn(),
        {
            isUnauthenticated: S
        } = We(),
        w = uo(e) === ho.STREAMING,
        N = mo({
            clientThreadId: e,
            conversationLeafId: v
        }),
        E = ut(x),
        T = fr({
            clientThreadId: e
        }),
        _ = !S,
        A = gr(),
        {
            isOpen: F,
            onClose: L
        } = Ic({
            type: "just-hit-rate-limit"
        }),
        R = u.useCallback((X, Q) => {
            oe.logEvent(ne.continueCompletion), a({
                type: va.Continue,
                promptId: X,
                eventMetadata: {
                    eventSource: "mouse"
                },
                cancelActiveRequests: !1,
                completionMetadata: {
                    conversationMode: Et.getConversationMode(e)
                },
                turnTracker: Q
            })
        }, [a, e]),
        I = fo(),
        U = u.useCallback(async (X, Q) => Dc({
            clientThreadId: e,
            currentRequestId: Q,
            isHistoryAndTrainingDisabled: A,
            queryClient: I
        }), [e, A, I]),
        C = u.useCallback(async ({
            promptId: X,
            content: Q,
            eventMetadata: V,
            completionMetadata: G,
            messageMetadata: K,
            prependMessages: Me,
            appendMessages: q,
            turnTracker: de,
            profiler: le,
            requestedModelId: _e
        }) => {
            const Ie = J.getThreadCurrentLeafId(e);
            J.updateTree(e, gt => {
                gt.addNode(X, Q, Ie, Ce.User, void 0, K)
            }), await a({
                type: va.Next,
                promptId: X,
                eventMetadata: V,
                cancelActiveRequests: !0,
                completionMetadata: G,
                prependMessages: Me,
                appendMessages: q,
                turnTracker: de,
                profiler: le,
                ..._e ? {
                    requestedModelId: _e
                } : {}
            })
        }, [e, a]),
        B = pr(e, v),
        k = xr(e, v),
        W = !N && (E || w),
        Z = u.useMemo(() => W ? !1 : !B && k, [B, k, W]),
        $ = W && t !== "gpt-4-pbrowse",
        Y = Fn(e),
        fe = Ge(e),
        ye = os(fe).data,
        {
            promptStarters: ee,
            isSuccess: re
        } = xn(n && !Y, e, 4),
        ie = jo(),
        Pe = (() => {
            if (ie ? .messageId === J.getTree(e).getLastValidNode(v) ? .message ? .id) return ie ? .suggestions;
            if (o && !Y && re && !_) return ee
        })(),
        we = Fc(),
        ke = vr(),
        ge = (() => {
            if (ye ? .gizmo.tags ? .includes(qn.WorkspaceDisabled) && !ke) return "workspaceDisallowsGizmo";
            if (we.size) {
                if (M.displayingSideBySideFeedback && M.unskippable) return "feedbackRequired"
            } else return "noModelsAvailable";
            const Q = Et.getConversationMode(e);
            return Q ? .kind === dt.GizmoTest && Q.gizmo_id == null ? "noTestGizmoId" : null
        })(),
        Ae = go(e),
        Te = zs(e),
        Fe = Bn("15117983") ? .value,
        ue = Sr(),
        z = Ln(),
        D = ue.action === "moderate",
        {
            value: te
        } = Qe("1860647109");
    return s.jsxs(s.Fragment, {
        children: [s.jsx("div", {
            className: "flex justify-center",
            children: z && D && te ? s.jsx(Lc, {}) : null
        }), F ? s.jsx(Bc, {
            onClose: L
        }) : null, Fe && Te && Te.kind === dt.PrimaryAssistant && Te.plugin_ids && Te.plugin_ids.length > 0 ? s.jsx(jm, {}) : s.jsx(ym, {
            composerContainerRef: i,
            composerController: r,
            clientThreadId: e,
            onCreateNewCompletion: C,
            onAbortCompletion: U,
            onContinueGenerating: R,
            currentModelId: t,
            isNewThread: n,
            isCompletionInProgress: T,
            className: "w-full",
            canContinue: Z,
            suggestions: Pe ? ? [],
            disabled: !!ge,
            disabledReason: ge ? ? void 0,
            canPause: $,
            isInteractableSharedThread: Ae,
            autocompletions: l,
            requiresFileUpload: c,
            onComposerInput: m,
            onComposerChange: d,
            onAutocompleteSelect: h,
            headerClassName: g,
            hideHeader: p,
            onTaggingDropdownClose: b,
            onTaggingDropdownOpen: f
        }, e)]
    })
}

function jm() {
    return s.jsxs("div", {
        className: "mx-auto flex max-w-md flex-col items-center justify-center gap-2 rounded-xl border border-token-border-light bg-token-main-surface-primary p-6 shadow-lg",
        children: [s.jsx("span", {
            className: "text-token-text-primary",
            children: s.jsx(O, {
                id: "PluginsDecrepatedNotice.pluginsDeprecationTitle",
                defaultMessage: "Conversations with plugins are archived"
            })
        }), s.jsx("span", {
            className: "text-token-text-secondary",
            children: s.jsx(O, {
                id: "PluginsDecrepatedNotice.pluginsDeprecationSubtitle",
                defaultMessage: "Explore GPT Store to find a replacement"
            })
        }), s.jsxs("a", {
            href: "https://chat.openai.com/gpts",
            className: "text-green-500 hover:cursor-pointer dark:text-green-400",
            children: [s.jsx(O, {
                id: "PluginsDecrepatedNotice.pluginsDeprecationGptStoreLink",
                defaultMessage: "Explore GPTs"
            }), s.jsx("span", {
                className: "ml-2",
                children: s.jsx(O, {
                    id: "PluginsDecrepatedNotice.pluginsDeprecationGptStoreLinkArrow",
                    defaultMessage: "→"
                })
            })]
        })]
    })
}
const Ba = He({
        errorGeneratingResponse: {
            id: "PromptTextarea.errorGeneratingResponse",
            defaultMessage: "There was an error generating a response"
        },
        regenerateResponse: {
            id: "PromptTextarea.regenerateResponse",
            defaultMessage: "Regenerate"
        }
    }),
    vi = u.memo(function() {
        return s.jsxs("div", {
            className: `flex flex-col gap-2 ${Ns.PromptTextareaHeader}`,
            children: [s.jsx(fi, {}), s.jsx(gi, {})]
        })
    }),
    Vf = Object.freeze(Object.defineProperty({
        __proto__: null,
        ChatScreenComposerAlerts: vi
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    on = 4;

function Cm(e) {
    const {
        layer: t
    } = Oe("3533083032"), {
        layer: n
    } = Rt("3533083032"), {
        value: a,
        isLoading: o
    } = Qe("3006519778");
    return o || !a ? !1 : e ? t.get("enable_new_homepage_anon", !1) : n.get("enable_new_homepage_anon", !1)
}

function km() {
    const {
        layer: e
    } = Rt("4031588851"), t = e.get("autocomplete_qualified_start_date", "2099-09-13T00:00:00Z"), n = Gn();
    return !!n && n.created * 1e3 >= new Date(t).getTime()
}

function Am(e) {
    const {
        layer: t
    } = Oe("4031588851"), {
        layer: n
    } = Rt("4031588851"), {
        value: a,
        isLoading: o
    } = Qe("633009675");
    return o || !a ? !1 : e ? t.get("enable_new_autocomplete_homepage", !1) : n.get("enable_new_autocomplete_homepage", !1)
}
const rn = e => `${e.title}${e.body}`.toLocaleLowerCase();

function Rm(e) {
    return Ge(e.clientThreadId), s.jsx(pi, {
        children: t => s.jsx(Dm, { ...e,
            composerController: t
        })
    })
}

function Em({
    children: e,
    composerController: t
}) {
    const {
        store: n
    } = be(), [a, o] = u.useState(!1);
    u.useEffect(() => t.subscribe("focus", () => {
        o(!0)
    }), [t]), u.useEffect(() => t.subscribe("blur", () => {
        o(!1)
    }), [t]);
    const r = !!n.useSharedProps() ? .isShowingAutocomplete;
    return e(r && a)
}

function Nm({
    isUnauthenticated: e,
    shouldShowLegacyStarterPrompts: t,
    legacyPromptStarters: n,
    isSendBlocked: a,
    clientThreadId: o
}) {
    return s.jsxs("div", {
        className: P(e ? "justify-end lg:justify-center" : "justify-center", "flex h-full flex-shrink flex-col items-center overflow-y-hidden text-token-text-primary lg:hidden"),
        children: [s.jsx("div", {
            className: P(e && "flex sm:items-center md:flex-1", "flex-shrink-0"),
            children: s.jsx(ts, {
                className: "mb-6 h-12 w-12"
            })
        }), t && (n && n.length > 0 ? s.jsx(Om, {
            initial: {
                opacity: 0
            },
            animate: {
                opacity: 1
            },
            transition: {
                duration: .3
            },
            promptStarters: n,
            isSendBlocked: a,
            clientThreadId: o,
            isSquare: e
        }) : s.jsx(Hd, {}))]
    })
}

function Pm({
    composerController: e,
    isSendBlocked: t,
    clientThreadId: n,
    isModelLoaded: a,
    headlineOption: o,
    enableNewMobileDesign: i,
    shouldShowStarterPrompts: r,
    promptChips: l,
    onSelectStarterPrompt: c,
    starterPromptExpanded: m,
    setStarterPromptExpanded: d
}) {
    return s.jsx(Em, {
        composerController: e,
        children: h => s.jsxs(ae.div, {
            initial: {
                opacity: 0
            },
            animate: {
                opacity: h ? 0 : 1
            },
            exit: {
                opacity: 0
            },
            transition: {
                duration: .1
            },
            className: P("justify-center", h ? "pointer-events-none" : "", "mt-[var(--screen-optical-compact-offset-amount)] flex h-full flex-shrink flex-col items-center overflow-hidden text-token-text-primary lg:hidden"),
            children: [o === "CHATGPT_LOGO" ? s.jsx(ts, {
                className: "inline-block h-12 w-12"
            }) : s.jsx(Si, {
                headlineOption: o,
                isModelLoaded: a
            }), s.jsx(ae.div, {
                initial: {
                    opacity: 0
                },
                animate: {
                    opacity: 1
                },
                transition: {
                    duration: .3
                },
                className: P(!i && "lg:hidden", !m && "h-[116px]"),
                children: r && s.jsx(yi, {
                    starterPrompts: l,
                    onSelectStarterPrompt: c,
                    disabled: t,
                    clientThreadId: n,
                    onExpand: () => d(!0),
                    mobileLayout: !0
                })
            })]
        })
    })
}

function Im(e, t, n) {
    const a = Qe("1468311859").value,
        o = Qe("3664702598").value,
        {
            layer: i
        } = Oe("4031588851"),
        r = km(),
        l = e || t,
        c = l && a,
        m = l && o && r;
    let d = "HARDCODED";
    if (l)
        if (n) {
            const h = i.get("search_autocomplete_mode", "");
            c && h && (d = h)
        } else m && (d = i.get("autocomplete_mode", "HARDCODED"));
    return d
}

function Dm({
    clientThreadId: e,
    currentModelId: t,
    isModelLoaded: n,
    onRequestCompletion: a,
    composerController: o,
    v2HomepageDisclaimer: i
}) {
    const r = js(e),
        l = Fn(e),
        c = Nn(),
        [m, d] = u.useState([]),
        {
            trendingSuggestions: h,
            fetchTrendingSuggestions: g
        } = zm(on),
        p = u.useRef(!1),
        {
            isUnauthenticated: b
        } = We(),
        f = Oc(),
        [v, x] = u.useState(!1),
        M = Hn(),
        S = Ze();
    Vo(o);
    const y = Qe("589604007").value,
        {
            layer: w
        } = Rt("4031588851"),
        {
            layer: N
        } = Oe("4031588851"),
        {
            layer: E
        } = Rt("3533083032"),
        {
            layer: T
        } = Oe("3533083032"),
        {
            promptStarters: _,
            isSuccess: A
        } = xn(r && !l && n, e, 8, y, !0, t ? ? void 0),
        {
            promptStarters: F,
            isSuccess: L,
            isError: R
        } = xn(r && !l && n, e, 4, void 0, void 0, t ? ? void 0),
        I = f && !!m.find(z => !!z.requires_file_upload),
        U = u.useCallback(z => {
            const D = o.getCurrentText();
            return D && rn(z).startsWith(D.toLocaleLowerCase())
        }, [o]),
        C = u.useCallback(z => {
            const D = o.getCurrentText(),
                te = z.title + z.body;
            return U(z) ? { ...z,
                title: D,
                body: te.slice(D.length)
            } : { ...z,
                title: te,
                body: ""
            }
        }, [o, U]),
        B = u.useCallback((z = !1) => {
            d(D => !D.some(U) && D.length > 0 ? [] : z ? D : D.map(C))
        }, [U, C]),
        k = (z, D, te) => {
            const X = z.title;
            d([]), o.focus(), o.setText(X), requestAnimationFrame(() => {
                const Q = (_ ? .filter(V => V.theme === z.theme) ? ? []).map(V => {
                    const G = Mt(V.oneliner),
                        K = G.startsWith(V.title);
                    return { ...V,
                        title: K ? `${V.title} ` : "",
                        body: K ? V.body : G,
                        autocompletionChunks: pm(X, G),
                        type: Ps.Autocomplete
                    }
                });
                d(Q), Q.length > 0 && Pt(Q, e), Hc(z, te, e)
            })
        };
    u.useEffect(() => {
        const z = m.some(D => D.theme === vn.Search);
        M && o.getCurrentText() === "" ? h.length > 0 ? d(h) : g() : z && !M && d(D => D.filter(te => te.theme !== vn.Search))
    }, [m, M, h, g, o]);
    const W = _ ? .reduce((z, D) => (D.theme && !z[D.theme] && (z[D.theme] = D), z), {}),
        Z = [];
    if (W)
        for (const z in W) Z.push(W[z]);
    const $ = Z && Z.length > 0,
        Y = !!(A && $ && n),
        fe = !!((L || R) && n),
        ye = on - m.filter(U).length,
        ee = b ? T.get("enable_new_mobile", !1) : N.get("enable_new_mobile", !1),
        re = Im(ee, f, M),
        ie = b ? E.get("headline_option", "HELP_WITH") : w.get("headline_option", "HELP_WITH"),
        Pe = w.get("autocomplete_min_char", 4),
        we = w.get("autocomplete_fetch_interval", 200),
        ke = u.useRef(null),
        ge = u.useCallback(qo(async z => {
            const D = o.getCurrentText();
            if (!D || D.length < Pe || D.length > 80 || o.hasMultipleLines()) {
                d([]);
                return
            }
            if (!p.current && !(ke.current && ke.current.length > Pe && D.startsWith(ke.current))) try {
                const te = await ht.generateAutocompletions(D, z, M);
                if (te.completions.length === 0) {
                    ke.current = D;
                    return
                }
                const X = te.completions.map(Q => ({
                    id: po(),
                    type: Ps.Autocomplete,
                    title: Q.slice(0, D.length),
                    body: Q.slice(D.length),
                    oneliner: Q,
                    prompt: Q,
                    source: re
                })).filter(U).map(C);
                d(Q => {
                    const V = Q.filter(U),
                        G = X.filter(K => {
                            const Me = rn(K);
                            return !V.some(q => {
                                const de = rn(q);
                                if (Me === de) return !0;
                                const le = /[\p{P}\p{S}]$/u,
                                    _e = Me.replace(le, ""),
                                    Ie = de.replace(le, "");
                                return _e === de || Me === Ie || _e === Ie
                            })
                        }).slice(0, on - V.length);
                    return [...V, ...G]
                }), X.length > 0 && Pt(X, e)
            } catch {}
        }, re === "BING" ? 150 : we), [o, re, C, we]),
        Ae = u.useCallback(() => {
            B(), ye > 0 && ge(ye)
        }, [ge, B, ye]);
    u.useEffect(() => {
        p.current && d([])
    }, [p]);
    const Te = u.useMemo(() => re === "HARDCODED" ? B : Ae, [re, Ae, B]),
        Fe = u.useCallback(() => {
            o instanceof Ws && B(!0), o.getCurrentText().indexOf(`
`) > 0 && d([])
        }, [o, B]),
        ue = u.useCallback((z, D, te) => {
            D.forEach(X => {
                X.id === z.id && (X.userInput = o.getCurrentText())
            }), d([D[te]])
        }, [o]);
    return s.jsx(s.Fragment, {
        children: s.jsx(is, {
            children: s.jsx("div", {
                className: "h-full w-full lg:py-[18px]",
                children: s.jsx($n, {
                    isStaticSharedThread: !1,
                    withVerticalPadding: !1,
                    withHorizontalPadding: !0,
                    clientThreadId: e,
                    fullHeight: !0,
                    children: s.jsxs(_a, {
                        children: [s.jsx("div", {
                            className: "mb-7 hidden text-center lg:block",
                            children: ie === "CHATGPT_LOGO" ? s.jsx(ts, {
                                className: "inline-block h-12 w-12"
                            }) : s.jsx(Si, {
                                headlineOption: ie,
                                isModelLoaded: n
                            })
                        }), !ee && s.jsx(Nm, {
                            isUnauthenticated: b,
                            shouldShowLegacyStarterPrompts: fe,
                            legacyPromptStarters: F,
                            isSendBlocked: c,
                            clientThreadId: e
                        }), ee && s.jsx(Pm, {
                            composerController: o,
                            isModelLoaded: n,
                            headlineOption: ie,
                            enableNewMobileDesign: ee,
                            shouldShowStarterPrompts: Y,
                            promptChips: Z,
                            onSelectStarterPrompt: k,
                            starterPromptExpanded: v,
                            setStarterPromptExpanded: x,
                            isSendBlocked: c,
                            clientThreadId: e
                        }), s.jsx("div", {
                            className: P("lg:w-full", "lg:absolute lg:bottom-8 lg:left-0"),
                            children: s.jsx(_a, {
                                children: S ? s.jsx(vi, {}) : s.jsx(mi, {
                                    className: "block"
                                })
                            })
                        }), s.jsx("div", {
                            className: "w-full",
                            children: s.jsx(xi, {
                                clientThreadId: e,
                                isNewThread: r,
                                currentModelId: t,
                                onRequestCompletion: a,
                                showPromptStarters: !1,
                                composerController: o,
                                autocompletions: m,
                                requiresFileUpload: I,
                                onComposerInput: Te,
                                onComposerChange: Fe,
                                onAutocompleteSelect: ue,
                                onTaggingDropdownClose: () => {
                                    p.current = !1
                                },
                                onTaggingDropdownOpen: () => {
                                    p.current = !0
                                },
                                hideHeader: !0
                            })
                        }), s.jsx(ae.div, {
                            initial: {
                                opacity: 0
                            },
                            animate: {
                                opacity: 1
                            },
                            transition: {
                                duration: .3
                            },
                            className: P("hidden lg:block", i && b && v ? "" : "h-[70px]"),
                            children: Y && s.jsx(yi, {
                                starterPrompts: Z,
                                onSelectStarterPrompt: k,
                                disabled: c,
                                clientThreadId: e,
                                onExpand: () => x(!0)
                            })
                        }), i && s.jsx("div", {
                            className: "w-full px-2 py-2 text-center text-xs text-token-text-secondary empty:hidden md:px-[60px] lg:absolute lg:bottom-0 lg:left-0",
                            children: s.jsx("div", {
                                className: "min-h-4",
                                children: i
                            })
                        })]
                    })
                })
            })
        })
    })
}

function Si({
    headlineOption: e,
    isModelLoaded: t
}) {
    const n = ze(),
        [a, o] = u.useState(0),
        [i, r] = u.useState(!0),
        l = 20,
        c = n.formatMessage(Hm[e] || Xt.whatCanIHelpWith);
    return u.useEffect(() => {
        if (!t) return;
        let m;
        return a < c.length ? m = setTimeout(() => {
            o(a + 1)
        }, l) : i && (m = setTimeout(() => {
            r(!1)
        }, 500)), () => clearTimeout(m)
    }, [c, a, i, t]), s.jsxs("div", {
        className: "relative inline-flex justify-center text-center text-2xl font-semibold leading-9",
        children: [s.jsx("h1", {
            children: c.substring(0, a) || "​"
        }), s.jsx("h1", {
            className: "result-streaming absolute left-full transition-opacity",
            style: {
                opacity: i ? 1 : 0
            },
            children: s.jsx("span", {})
        })]
    })
}

function bi({
    label: e,
    onClick: t,
    disabled: n = !1,
    icon: a
}) {
    return s.jsxs("button", {
        className: "group relative flex h-[42px] items-center gap-1.5 rounded-full border border-token-border-light px-3 py-2 text-start text-[13px] shadow-xxs transition enabled:hover:bg-token-main-surface-secondary disabled:cursor-not-allowed xl:gap-2 xl:text-[14px]",
        disabled: n,
        onClick: t,
        children: [a, s.jsx("span", {
            className: "max-w-full select-none whitespace-nowrap text-gray-600 transition group-hover:text-token-text-primary dark:text-gray-500",
            children: e
        })]
    })
}

function Fm({
    starterPrompt: e,
    starterPrompts: t,
    index: n,
    disabled: a,
    onSelectStarterPrompt: o
}) {
    const i = e.theme ? ? e.title,
        r = Us(),
        {
            mutate: l
        } = Uc(),
        c = e.category === "onboarding" ? () => {
            l({
                key: Un.hasUsedConversationalOnboardingStarterPrompt
            }), r(e, t, n)
        } : () => o(e, t, n);
    return s.jsx(bi, {
        disabled: a,
        onClick: c,
        icon: s.jsx(Gc, {
            starterPrompt: e,
            useV2Colors: !0
        }),
        label: i
    })
}

function Oa({
    clientThreadId: e,
    onClick: t
}) {
    u.useEffect(() => {
        Wc(e)
    }, [e]);
    const n = ze();
    return s.jsx(ae.div, {
        initial: {
            opacity: 0,
            translateY: 5
        },
        animate: {
            opacity: 1,
            translateY: 0
        },
        exit: {
            opacity: 0,
            translateY: 5
        },
        transition: {
            duration: .3,
            ease: "easeOut"
        },
        className: "inline-block",
        children: s.jsx(bi, {
            onClick: () => {
                Vc(e), t()
            },
            label: n.formatMessage(Xt.moreStarterPrompts)
        })
    })
}
const Lm = 5,
    Bm = 3;

function yi({
    starterPrompts: e,
    onSelectStarterPrompt: t,
    disabled: n,
    clientThreadId: a,
    onExpand: o,
    mobileLayout: i = !1
}) {
    const r = i ? Bm : Lm,
        [l, c] = u.useState(r),
        [m, d] = u.useState(r),
        [h, g] = u.useState(!1),
        p = u.useRef(null),
        b = e.length <= l;
    u.useEffect(() => {
        Pt(e.slice(0, r), a)
    }, [a]), u.useEffect(() => {
        if (!h && !b && p.current) {
            const v = p.current,
                x = v.getBoundingClientRect(),
                M = x.width,
                S = Array.from(v.children);
            let y = 0;
            for (let w = 0; w < S.length && S[w].getBoundingClientRect().right - x.left <= M; w++) y++;
            c(y), d(y), g(!0)
        }
    }, [e, b, h]);
    const f = () => {
        const v = e.slice(l, e.length).map(x => ({ ...x,
            isAdditional: !0
        }));
        v.length > 0 && Pt(v, a), c(e.length), o()
    };
    return s.jsxs("div", {
        className: P("mt-5 flex items-center justify-center gap-x-2 transition-opacity xl:gap-x-2.5", h && e.length > 0 ? "opacity-100" : "opacity-[0.01]", i ? "flex-wrap" : "flex-nowrap"),
        children: [s.jsxs("ul", {
            className: P("relative flex items-stretch gap-x-2 gap-y-4 overflow-hidden py-2 sm:gap-y-2 xl:gap-x-2.5 xl:gap-y-2.5", b || i ? "flex-wrap justify-center" : "flex-nowrap justify-start"),
            ref: p,
            children: [e.slice(0, l).map((v, x) => s.jsx(ae.li, {
                initial: {
                    opacity: 0,
                    ...x < m ? {
                        translateY: 5
                    } : {}
                },
                animate: {
                    opacity: 1,
                    ...x < m ? {
                        translateY: 0
                    } : {}
                },
                exit: {
                    opacity: 0,
                    ...x < m ? {
                        translateY: 5
                    } : {}
                },
                transition: {
                    duration: .3,
                    delay: x >= m ? (x - m) * .06 : 0,
                    ease: "easeOut"
                },
                children: s.jsx(Fm, {
                    starterPrompt: v,
                    starterPrompts: e,
                    index: x,
                    disabled: n,
                    onSelectStarterPrompt: t
                })
            }, v.id ? ? x)), i && e.length > l && s.jsx(Oa, {
                clientThreadId: a,
                onClick: f
            })]
        }), !i && e.length > l && s.jsx(Oa, {
            clientThreadId: a,
            onClick: f
        })]
    })
}

function Om({
    promptStarters: e,
    isSendBlocked: t,
    clientThreadId: n,
    isSquare: a,
    ...o
}) {
    u.useEffect(() => {
        Pt(e, n)
    }, [n]);
    const i = Us();
    return s.jsx(s.Fragment, {
        children: a ? s.jsx(ae.div, { ...o,
            className: "mb-2 w-full flex-shrink overflow-y-hidden",
            children: s.jsx(Zt, {
                children: s.jsx(ii, {
                    starterPrompts: e,
                    onSelectStarterPrompt: i,
                    disabled: t
                })
            })
        }) : s.jsx(ae.div, { ...o,
            className: "flex-shrink overflow-y-hidden",
            children: s.jsx(Ud, {
                starterPrompts: e,
                onSelectStarterPrompt: i,
                disabled: t,
                cssMobileDisplayLimit: 2,
                marginOverride: "mt-6 lg:mt-12"
            })
        })
    })
}
const zm = e => {
    const [t, n] = u.useState([]), a = u.useCallback(async () => {
        const i = (await ht.generateTrendingSuggestions(e)).suggestions.map((r, l) => ({
            type: Ps.Starter,
            title: za(r),
            body: "",
            icon: s.jsx(Cd, {}),
            prompt: za(r),
            id: `starter-${l}`,
            theme: vn.Search
        }));
        n(i)
    }, [e]);
    return {
        trendingSuggestions: t,
        fetchTrendingSuggestions: a
    }
};

function za(e) {
    return e.split(" ").map(zc).join(" ")
}
const Xt = He({
        whatCanIHelpWith: {
            id: "SplashScreenV2.whatCanIHelpWith",
            defaultMessage: "What can I help with?"
        },
        whereShouldWeStart: {
            id: "SplashScreenV2.whereShouldWeStart",
            defaultMessage: "Where should we start?"
        },
        askChatgptAnything: {
            id: "SplashScreenV2.askChatgptAnything",
            defaultMessage: "Ask ChatGPT anything"
        },
        moreStarterPrompts: {
            id: "SplashScreenV2.moreStarterPrompts",
            defaultMessage: "More"
        }
    }),
    Hm = {
        HELP_WITH: Xt.whatCanIHelpWith,
        WHERE_TO_START: Xt.whereShouldWeStart,
        ASK_CHATGPT: Xt.askChatgptAnything
    },
    Um = ns(() => as(() =>
        import ("./d0bj0ou1aof4ttdr.js"), __vite__mapDeps([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23])).then(e => e.GizmoUsingAsOwnerNotice)),
    Gm = ({
        clientThreadId: e
    }) => {
        const t = Vn(m => m.activeStageSidebar),
            n = J.getServerThreadId(e),
            a = qc(hn.WorkspaceShareLinks),
            {
                isUnauthenticated: o
            } = We(),
            i = ss(),
            r = a && n && !o && !i,
            l = Ze(),
            c = !t && !(l && !o);
        return s.jsx("div", {
            className: P(!l && "gap-2", l && "@lg/screen-composer:gap-2", "flex items-center pr-1 leading-[0]"),
            children: s.jsx(qd, {
                showShareButton: r,
                showProfileDropdown: c,
                clientThreadId: e
            })
        })
    };

function Wm({
    clientThreadId: e,
    gizmoId: t
}) {
    const n = $c(),
        {
            data: a
        } = os(t),
        o = Os();
    return s.jsxs(s.Fragment, {
        children: [s.jsxs(Kc, {
            className: "max-md:hidden",
            children: [s.jsxs("div", {
                className: "absolute start-1/2 ltr:-translate-x-1/2 rtl:translate-x-1/2",
                children: [a != null && o ? .isWorkspaceAccount() && a.gizmo.tags ? .includes(qn.WorkspaceDisabled) && s.jsx(Um, {
                    gizmo: a
                }), s.jsx(Yc, {
                    gizmoId: t,
                    clientThreadId: e
                })]
            }), s.jsx(Xc, {
                children: s.jsxs("div", {
                    className: "flex items-center gap-0 overflow-hidden",
                    children: [s.jsx($d, {
                        clientThreadId: e
                    }), s.jsx(Qc, {
                        clientThreadId: e
                    })]
                })
            }), s.jsx(Gm, {
                clientThreadId: e
            })]
        }), n && s.jsx(Zc, {})]
    })
}

function wi({
    clientThreadId: e
}) {
    const t = Ge(e),
        n = Pn(),
        a = Ze();
    return n || a ? null : s.jsx(Wm, {
        gizmoId: t,
        clientThreadId: e
    })
}

function Vm({
    clientThreadId: e,
    currentModelId: t,
    isModelLoaded: n,
    onRequestCompletion: a,
    enableV2Homepage: o,
    v2HomepageDisclaimer: i
}) {
    const r = ss();
    let l = s.jsx(Wd, {}),
        c;
    return r ? (c = s.jsx(qm, {}), l = s.jsx(ts, {
        className: "mb-6 h-12 w-12"
    })) : e != null ? (c = o ? s.jsx(Rm, {
        clientThreadId: e,
        currentModelId: t,
        isModelLoaded: n,
        onRequestCompletion: a,
        v2HomepageDisclaimer: i
    }) : s.jsx(Vd, {
        clientThreadId: e
    }), l = null) : c = s.jsx($m, {}), s.jsxs("div", {
        className: "flex h-full flex-col items-center justify-center text-token-text-primary",
        children: [l, c]
    })
}

function qm({
    gizmo: e
}) {
    const t = eu(),
        n = e ? tu(e.tools) : !1,
        a = Os();
    return s.jsxs(s.Fragment, {
        children: [s.jsxs("div", {
            className: "mb-5 text-2xl font-semibold",
            "data-testid": "temporary-chat-label",
            children: [s.jsx(su, {
                id: "temporary-chat-checkbox",
                name: "temporary-chat-checkbox",
                checked: !0
            }), s.jsx(O, { ...rt.temporaryChat
            })]
        }), s.jsxs("div", {
            className: "max-w-sm text-center text-sm font-normal text-token-text-tertiary",
            children: [s.jsx(O, { ...a ? .isWorkspaceAccount() ? t ? rt.temporaryChatBizMemoryAvailable : rt.temporaryChatBizMemoryUnavailable : t ? rt.temporaryChatDescriptionMemoryAvailable : rt.temporaryChatDescriptionMemoryUnavailable
            }), n && s.jsx("div", {
                className: "mt-3",
                children: s.jsx(O, { ...rt.temporaryChatDescriptionGptActions,
                    values: {
                        link: o => s.jsx("a", {
                            href: "https://help.openai.com/en/articles/8914046-temporary-chat-faq",
                            target: "_blank",
                            className: "underline",
                            rel: "noreferrer",
                            children: o
                        })
                    }
                })
            })]
        })]
    })
}

function $m() {
    return s.jsx("div", {
        className: "mb-5 text-2xl font-semibold",
        children: s.jsx(O, { ...rt.howCanIHelpYouToday
        })
    })
}

function Km({
    clientThreadId: e,
    currentModelId: t,
    isModelLoaded: n,
    onRequestCompletion: a,
    enableV2Homepage: o,
    v2HomepageDisclaimer: i
}) {
    const r = Ge(e),
        l = br(),
        c = Nn(),
        {
            data: m
        } = os(r),
        d = Jc(),
        h = yr(() => navigator.windowControlsOverlay);
    return (l != null || r != null) && m == null ? null : s.jsxs("div", {
        className: "relative h-full",
        children: [s.jsx("div", {
            className: h ? .visible ? P("absolute right-[calc(100dvw-env(titlebar-area-width,100dvw)-env(titlebar-area-x,0))]", d ? "left-[env(titlebar-area-x,0)]" : "left-0") : "absolute left-0 right-0",
            children: s.jsx(wi, {
                clientThreadId: e
            })
        }), m != null ? s.jsx(Gd, {
            gizmo: m,
            showStarterPrompts: !0,
            disableStarterPrompts: c
        }) : s.jsx(Vm, {
            clientThreadId: e,
            currentModelId: t,
            isModelLoaded: n,
            onRequestCompletion: a,
            enableV2Homepage: o,
            v2HomepageDisclaimer: i
        })]
    })
}
const rt = He({
    temporaryChat: {
        id: "GizmoLanding.temporaryChat",
        defaultMessage: "Temporary Chat"
    },
    temporaryChatBizMemoryAvailable: {
        id: "g1opBW",
        defaultMessage: "This chat won't appear in your history and won't use or create memories."
    },
    temporaryChatBizMemoryUnavailable: {
        id: "fQmbtG",
        defaultMessage: "This chat won't appear your conversation history."
    },
    temporaryChatDescriptionMemoryAvailable: {
        id: "GizmoLanding.temporaryChatDescriptionMemoryAvailable",
        defaultMessage: "This chat won't appear in history, use or create memories, or be used to train our models. For safety purposes, we may keep a copy for up to 30 days."
    },
    temporaryChatDescriptionMemoryUnavailable: {
        id: "GizmoLanding.temporaryChatDescriptionMemoryUnavailable",
        defaultMessage: "This chat won't appear in history or be used to train our models. For safety purposes, we may keep a copy of this chat for up to 30 days."
    },
    temporaryChatDescriptionGptActions: {
        id: "GizmoLanding.temporaryChatDescriptionGptActions",
        defaultMessage: "Any data shared with a third party through GPT actions are subject to the third party's privacy policy. <link>Learn more</link>"
    },
    howCanIHelpYouToday: {
        id: "GizmoLanding.howCanIHelpYouToday",
        defaultMessage: "How can I help you today?"
    }
});

function Ym({
    className: e,
    clientThreadId: t,
    message: n,
    onModelSelect: a,
    onDropdownChange: o
}) {
    const i = ze(),
        [r, l] = u.useState(null),
        [c, m] = u.useState(!1),
        [d, h] = u.useState(!1),
        g = nu(),
        p = $o(t),
        b = Ge(t),
        f = Ko({
            clientThreadId: t,
            message: n
        }),
        v = n.message.metadata ? .model_slug,
        {
            modelOptions: x,
            modelSlug: M,
            animateModelLabelOnRender: S,
            nuxProps: y,
            messageModelEnabledTools: w
        } = f,
        N = Yo(n.message),
        E = w.includes(Hs.Search),
        T = u.useMemo(() => x.find(C => C.value == v), [x, v]),
        {
            doesUserHaveAnyAccountsWithPlusFeatures: _
        } = xo(),
        A = u.useRef(null),
        F = C => {
            C || setTimeout(() => {
                A.current && A.current.blur()
            }, 10)
        };
    if (u.useEffect(() => {
            F(c)
        }, [c]), !g || b) return null;
    const L = [{
        key: "use-search",
        extraStreamParams: {
            forceUseSearch: !0
        },
        label: i.formatMessage(Ha.search),
        icon: s.jsx(Kn, {
            className: "icon-sm"
        }),
        condition: E && !N,
        eventName: "chatgpt_regenerate_with_search_button_clicked"
    }, {
        key: "use-no-search",
        extraStreamParams: {
            forceUseSearch: !1
        },
        label: i.formatMessage(Ha.nosearch),
        icon: s.jsx(ni, {
            className: "icon-sm"
        }),
        condition: E && N,
        eventName: "chatgpt_regenerate_without_search_button_clicked"
    }];
    let R, I;
    y.shouldRenderNux ? (R = Qm, I = {
        title: s.jsx(O, {
            id: "g/+2Hh",
            defaultMessage: "Optimized your response"
        }),
        description: s.jsx(O, {
            id: "H0Flqm",
            defaultMessage: "Used {usedModelName} for a faster response that saves your limited {largestModelName} messages",
            values: {
                usedModelName: y.usedModelName,
                largestModelName: y.largestModelName
            }
        }),
        markAsViewed: y.announcement.markAsViewed
    }) : (R = Xm, I = {
        label: p ? s.jsx(O, {
            id: "LBYK9a",
            defaultMessage: "Change model"
        }) : s.jsx(O, {
            id: "nygjPN",
            defaultMessage: "Used {modelName}",
            values: {
                modelName: y.usedModelName
            }
        })
    });
    const U = p && x.some(C => es(C, _));
    return s.jsxs(Ne.Root, {
        onOpenChange: C => {
            p && (m(C), o(C), F(C)), C && oe.logEvent(ne.conversationOpenMessageModelSelector, {
                has_get_plus_button: U
            })
        },
        children: [s.jsx(R, { ...I,
            children: s.jsx(vo, {
                ref: A,
                className: P("cursor-pointer", e),
                onMouseEnter: () => h(!0),
                onMouseLeave: () => h(!1),
                children: s.jsx(Cn, {
                    modelSlug: M,
                    animateModelLabelOnRender: S,
                    isDropdownOpen: c,
                    isRegenerateEnabled: p,
                    isHovered: d
                })
            })
        }), p && s.jsxs(Ne.Content, {
            className: "z-30 origin-top-right text-token-text-primary",
            side: "bottom",
            align: "start",
            children: [x.map(C => {
                const B = es(C, _),
                    {
                        value: k,
                        ...W
                    } = C;
                return s.jsx(jt, {
                    value: k,
                    onSelect: () => {
                        me.logEvent("chatgpt_regenerate_switch_model_button_clicked", k, {
                            requestedModelId: k,
                            ...Xe({
                                clientThreadId: t
                            })
                        }), a({
                            requestedModelId: k
                        })
                    },
                    onMouseEnter: () => l(k),
                    onMouseLeave: () => l(null),
                    isHovered: r === k,
                    messageModelSlug: n.message.metadata ? .model_slug,
                    shouldShowUpsell: B,
                    ...W
                }, k)
            }), !!T && s.jsxs(s.Fragment, {
                children: [s.jsx(Ne.Separator, {}), L.filter(C => C.condition).map(C => s.jsx(jt, {
                    onSelect: () => {
                        me.logEvent(C.eventName, T.value, {
                            requestedModelId: T.value,
                            ...Xe({
                                clientThreadId: t
                            })
                        }), a({
                            requestedModelId: T.value,
                            extraStreamParams: C.extraStreamParams
                        })
                    },
                    includeRegenerate: !0,
                    onMouseEnter: () => l(C.key),
                    onMouseLeave: () => l(null),
                    isHovered: r === C.key,
                    messageModelSlug: v,
                    includeCheck: !1,
                    ...T,
                    label: C.label,
                    subtitle: "",
                    icon: C.icon
                }, C.key))]
            })]
        })]
    })
}

function Cn({
    modelSlug: e,
    animateModelLabelOnRender: t,
    isDropdownOpen: n,
    isRegenerateEnabled: a,
    isHovered: o,
    isRegenLabel: i = !1,
    animateShortLabel: r,
    omitIcon: l
}) {
    const [c, m] = u.useState("initial"), {
        categories: d
    } = au({
        isRegen: !!i
    });
    u.useEffect(() => {
        if (t) {
            const x = setTimeout(() => m("show"), 500),
                M = setTimeout(() => m("initial"), 2e3);
            return () => {
                clearTimeout(x), clearTimeout(M)
            }
        }
        m("initial")
    }, [t]);
    const h = d.find(({
            defaultModel: x
        }) => x === e),
        g = e === iu ? {
            categoryId: "gpt_3.5",
            shorterLabel: "3.5"
        } : {},
        {
            categoryId: p,
            shorterLabel: b
        } = h ? ? g,
        f = {
            initial: {
                opacity: 0,
                paddingLeft: 0,
                width: "0"
            },
            show: {
                opacity: 1,
                paddingLeft: 2,
                width: "100%"
            },
            visible: {
                opacity: 1,
                paddingLeft: 2,
                width: "100%",
                transition: {
                    delay: 0,
                    duration: 0
                }
            }
        },
        v = n ? "visible" : o ? "show" : c;
    return s.jsxs(ae.div, {
        initial: "initial",
        animate: v,
        className: "flex items-center pb-0",
        children: [!l && (i ? s.jsx(Yn, {
            className: "icon-md"
        }) : p && s.jsx(ou, {
            type: "outline",
            categoryId: p,
            className: "icon-md h-4 w-4"
        })), (a || r) && s.jsx(ae.span, {
            className: "overflow-hidden text-clip whitespace-nowrap text-sm",
            variants: f,
            transition: {
                type: "tween",
                duration: .18
            },
            children: b
        }), a && s.jsx(kd, {
            className: P("icon-sm", {
                "text-token-text-quaternary": !o && !i
            }, {
                "text-token-text-secondary": o && !i
            })
        })]
    })
}

function Xm({
    children: e,
    label: t
}) {
    return s.jsx(Rn, {
        label: t,
        sideOffset: 0,
        children: e
    })
}

function Qm({
    children: e,
    title: t,
    description: n,
    markAsViewed: a
}) {
    return s.jsx(Io, {
        show: !0,
        side: "bottom",
        sideOffset: -4,
        title: t,
        description: n,
        badge: "beta",
        onDismiss: a,
        dismissOnOutsideClick: !0,
        children: e
    })
}

function es(e, t) {
    const {
        modelSwitcherDeny: n,
        subscriptionLevel: a
    } = e;
    return !!n && n.reason === wr.RATE_LIMIT && a === Tr.PLUS && !t
}
const Ha = He({
        search: {
            id: "eTV6j1",
            defaultMessage: "Search the web"
        },
        nosearch: {
            id: "IvLzUk",
            defaultMessage: "Without web search"
        }
    }),
    Zm = u.memo(Ym),
    Tt = typeof performance == "object" && performance && typeof performance.now == "function" ? performance : Date,
    Ti = new Set,
    kn = typeof process == "object" && process ? process : {},
    Mi = (e, t, n, a) => {
        typeof kn.emitWarning == "function" ? kn.emitWarning(e, t, n, a) : console.error(`[${n}] ${t}: ${e}`)
    };
let Fs = globalThis.AbortController,
    Ua = globalThis.AbortSignal;
if (typeof Fs > "u") {
    Ua = class {
        onabort;
        _onabort = [];
        reason;
        aborted = !1;
        addEventListener(a, o) {
            this._onabort.push(o)
        }
    }, Fs = class {
        constructor() {
            t()
        }
        signal = new Ua;
        abort(a) {
            if (!this.signal.aborted) {
                this.signal.reason = a, this.signal.aborted = !0;
                for (const o of this.signal._onabort) o(a);
                this.signal.onabort ? .(a)
            }
        }
    };
    let e = kn.env ? .LRU_CACHE_IGNORE_AC_WARNING !== "1";
    const t = () => {
        e && (e = !1, Mi("AbortController is not defined. If using lru-cache in node 14, load an AbortController polyfill from the `node-abort-controller` package. A minimal polyfill is provided for use by LRUCache.fetch(), but it should not be relied upon in other contexts (eg, passing it to other APIs that use AbortController/AbortSignal might have undesirable effects). You may disable this with LRU_CACHE_IGNORE_AC_WARNING=1 in the env.", "NO_ABORT_CONTROLLER", "ENOTSUP", t))
    }
}
const Jm = e => !Ti.has(e),
    $e = e => e && e === Math.floor(e) && e > 0 && isFinite(e),
    _i = e => $e(e) ? e <= Math.pow(2, 8) ? Uint8Array : e <= Math.pow(2, 16) ? Uint16Array : e <= Math.pow(2, 32) ? Uint32Array : e <= Number.MAX_SAFE_INTEGER ? As : null : null;
class As extends Array {
    constructor(t) {
        super(t), this.fill(0)
    }
}
class kt {
    heap;
    length;
    static# l = !1;
    static create(t) {
        const n = _i(t);
        if (!n) return [];
        kt.#l = !0;
        const a = new kt(t, n);
        return kt.#l = !1, a
    }
    constructor(t, n) {
        if (!kt.#l) throw new TypeError("instantiate Stack using Stack.create(n)");
        this.heap = new n(t), this.length = 0
    }
    push(t) {
        this.heap[this.length++] = t
    }
    pop() {
        return this.heap[--this.length]
    }
}
class ea {#
    l;#
    d;#
    g;#
    p;#
    A;
    ttl;
    ttlResolution;
    ttlAutopurge;
    updateAgeOnGet;
    updateAgeOnHas;
    allowStale;
    noDisposeOnSet;
    noUpdateTTL;
    maxEntrySize;
    sizeCalculation;
    noDeleteOnFetchRejection;
    noDeleteOnStaleGet;
    allowStaleOnFetchAbort;
    allowStaleOnFetchRejection;
    ignoreFetchAbort;#
    a;#
    x;#
    n;#
    s;#
    e;#
    c;#
    h;#
    r;#
    o;#
    v;#
    i;#
    S;#
    b;#
    m;#
    y;#
    _;#
    u;
    static unsafeExposeInternals(t) {
        return {
            starts: t.#b,
            ttls: t.#m,
            sizes: t.#S,
            keyMap: t.#n,
            keyList: t.#s,
            valList: t.#e,
            next: t.#c,
            prev: t.#h,
            get head() {
                return t.#r
            },
            get tail() {
                return t.#o
            },
            free: t.#v,
            isBackgroundFetch: n => t.#t(n),
            backgroundFetch: (n, a, o, i) => t.#N(n, a, o, i),
            moveToTail: n => t.#k(n),
            indexes: n => t.#w(n),
            rindexes: n => t.#T(n),
            isStale: n => t.#f(n)
        }
    }
    get max() {
        return this.#l
    }
    get maxSize() {
        return this.#d
    }
    get calculatedSize() {
        return this.#x
    }
    get size() {
        return this.#a
    }
    get fetchMethod() {
        return this.#A
    }
    get dispose() {
        return this.#g
    }
    get disposeAfter() {
        return this.#p
    }
    constructor(t) {
        const {
            max: n = 0,
            ttl: a,
            ttlResolution: o = 1,
            ttlAutopurge: i,
            updateAgeOnGet: r,
            updateAgeOnHas: l,
            allowStale: c,
            dispose: m,
            disposeAfter: d,
            noDisposeOnSet: h,
            noUpdateTTL: g,
            maxSize: p = 0,
            maxEntrySize: b = 0,
            sizeCalculation: f,
            fetchMethod: v,
            noDeleteOnFetchRejection: x,
            noDeleteOnStaleGet: M,
            allowStaleOnFetchRejection: S,
            allowStaleOnFetchAbort: y,
            ignoreFetchAbort: w
        } = t;
        if (n !== 0 && !$e(n)) throw new TypeError("max option must be a nonnegative integer");
        const N = n ? _i(n) : Array;
        if (!N) throw new Error("invalid max value: " + n);
        if (this.#l = n, this.#d = p, this.maxEntrySize = b || this.#d, this.sizeCalculation = f, this.sizeCalculation) {
            if (!this.#d && !this.maxEntrySize) throw new TypeError("cannot set sizeCalculation without setting maxSize or maxEntrySize");
            if (typeof this.sizeCalculation != "function") throw new TypeError("sizeCalculation set to non-function")
        }
        if (v !== void 0 && typeof v != "function") throw new TypeError("fetchMethod must be a function if specified");
        if (this.#A = v, this.#_ = !!v, this.#n = new Map, this.#s = new Array(n).fill(void 0), this.#e = new Array(n).fill(void 0), this.#c = new N(n), this.#h = new N(n), this.#r = 0, this.#o = 0, this.#v = kt.create(n), this.#a = 0, this.#x = 0, typeof m == "function" && (this.#g = m), typeof d == "function" ? (this.#p = d, this.#i = []) : (this.#p = void 0, this.#i = void 0), this.#y = !!this.#g, this.#u = !!this.#p, this.noDisposeOnSet = !!h, this.noUpdateTTL = !!g, this.noDeleteOnFetchRejection = !!x, this.allowStaleOnFetchRejection = !!S, this.allowStaleOnFetchAbort = !!y, this.ignoreFetchAbort = !!w, this.maxEntrySize !== 0) {
            if (this.#d !== 0 && !$e(this.#d)) throw new TypeError("maxSize must be a positive integer if specified");
            if (!$e(this.maxEntrySize)) throw new TypeError("maxEntrySize must be a positive integer if specified");
            this.#B()
        }
        if (this.allowStale = !!c, this.noDeleteOnStaleGet = !!M, this.updateAgeOnGet = !!r, this.updateAgeOnHas = !!l, this.ttlResolution = $e(o) || o === 0 ? o : 1, this.ttlAutopurge = !!i, this.ttl = a || 0, this.ttl) {
            if (!$e(this.ttl)) throw new TypeError("ttl must be a positive integer if specified");
            this.#P()
        }
        if (this.#l === 0 && this.ttl === 0 && this.#d === 0) throw new TypeError("At least one of max, maxSize, or ttl is required");
        if (!this.ttlAutopurge && !this.#l && !this.#d) {
            const E = "LRU_CACHE_UNBOUNDED";
            Jm(E) && (Ti.add(E), Mi("TTL caching without ttlAutopurge, max, or maxSize can result in unbounded memory consumption.", "UnboundedCacheWarning", E, ea))
        }
    }
    getRemainingTTL(t) {
        return this.#n.has(t) ? 1 / 0 : 0
    }#
    P() {
        const t = new As(this.#l),
            n = new As(this.#l);
        this.#m = t, this.#b = n, this.#I = (i, r, l = Tt.now()) => {
            if (n[i] = r !== 0 ? l : 0, t[i] = r, r !== 0 && this.ttlAutopurge) {
                const c = setTimeout(() => {
                    this.#f(i) && this.delete(this.#s[i])
                }, r + 1);
                c.unref && c.unref()
            }
        }, this.#j = i => {
            n[i] = t[i] !== 0 ? Tt.now() : 0
        }, this.#M = (i, r) => {
            if (t[r]) {
                const l = t[r],
                    c = n[r];
                if (!l || !c) return;
                i.ttl = l, i.start = c, i.now = a || o();
                const m = i.now - c;
                i.remainingTTL = l - m
            }
        };
        let a = 0;
        const o = () => {
            const i = Tt.now();
            if (this.ttlResolution > 0) {
                a = i;
                const r = setTimeout(() => a = 0, this.ttlResolution);
                r.unref && r.unref()
            }
            return i
        };
        this.getRemainingTTL = i => {
            const r = this.#n.get(i);
            if (r === void 0) return 0;
            const l = t[r],
                c = n[r];
            if (!l || !c) return 1 / 0;
            const m = (a || o()) - c;
            return l - m
        }, this.#f = i => {
            const r = n[i],
                l = t[i];
            return !!l && !!r && (a || o()) - r > l
        }
    }#
    j = () => {};#
    M = () => {};#
    I = () => {};#
    f = () => !1;#
    B() {
        const t = new As(this.#l);
        this.#x = 0, this.#S = t, this.#C = n => {
            this.#x -= t[n], t[n] = 0
        }, this.#D = (n, a, o, i) => {
            if (this.#t(a)) return 0;
            if (!$e(o))
                if (i) {
                    if (typeof i != "function") throw new TypeError("sizeCalculation must be a function");
                    if (o = i(a, n), !$e(o)) throw new TypeError("sizeCalculation return invalid (expect positive integer)")
                } else throw new TypeError("invalid size value (must be positive integer). When maxSize or maxEntrySize is used, sizeCalculation or size must be set.");
            return o
        }, this.#R = (n, a, o) => {
            if (t[n] = a, this.#d) {
                const i = this.#d - t[n];
                for (; this.#x > i;) this.#E(!0)
            }
            this.#x += t[n], o && (o.entrySize = a, o.totalCalculatedSize = this.#x)
        }
    }#
    C = t => {};#
    R = (t, n, a) => {};#
    D = (t, n, a, o) => {
        if (a || o) throw new TypeError("cannot set size without setting maxSize or maxEntrySize on cache");
        return 0
    };* #w({
        allowStale: t = this.allowStale
    } = {}) {
        if (this.#a)
            for (let n = this.#o; !(!this.#F(n) || ((t || !this.#f(n)) && (yield n), n === this.#r));) n = this.#h[n]
    }* #T({
        allowStale: t = this.allowStale
    } = {}) {
        if (this.#a)
            for (let n = this.#r; !(!this.#F(n) || ((t || !this.#f(n)) && (yield n), n === this.#o));) n = this.#c[n]
    }#
    F(t) {
        return t !== void 0 && this.#n.get(this.#s[t]) === t
    }* entries() {
        for (const t of this.#w()) this.#e[t] !== void 0 && this.#s[t] !== void 0 && !this.#t(this.#e[t]) && (yield [this.#s[t], this.#e[t]])
    }* rentries() {
        for (const t of this.#T()) this.#e[t] !== void 0 && this.#s[t] !== void 0 && !this.#t(this.#e[t]) && (yield [this.#s[t], this.#e[t]])
    }* keys() {
        for (const t of this.#w()) {
            const n = this.#s[t];
            n !== void 0 && !this.#t(this.#e[t]) && (yield n)
        }
    }* rkeys() {
        for (const t of this.#T()) {
            const n = this.#s[t];
            n !== void 0 && !this.#t(this.#e[t]) && (yield n)
        }
    }* values() {
        for (const t of this.#w()) this.#e[t] !== void 0 && !this.#t(this.#e[t]) && (yield this.#e[t])
    }* rvalues() {
        for (const t of this.#T()) this.#e[t] !== void 0 && !this.#t(this.#e[t]) && (yield this.#e[t])
    }[Symbol.iterator]() {
        return this.entries()
    }[Symbol.toStringTag] = "LRUCache";
    find(t, n = {}) {
        for (const a of this.#w()) {
            const o = this.#e[a],
                i = this.#t(o) ? o.__staleWhileFetching : o;
            if (i !== void 0 && t(i, this.#s[a], this)) return this.get(this.#s[a], n)
        }
    }
    forEach(t, n = this) {
        for (const a of this.#w()) {
            const o = this.#e[a],
                i = this.#t(o) ? o.__staleWhileFetching : o;
            i !== void 0 && t.call(n, i, this.#s[a], this)
        }
    }
    rforEach(t, n = this) {
        for (const a of this.#T()) {
            const o = this.#e[a],
                i = this.#t(o) ? o.__staleWhileFetching : o;
            i !== void 0 && t.call(n, i, this.#s[a], this)
        }
    }
    purgeStale() {
        let t = !1;
        for (const n of this.#T({
                allowStale: !0
            })) this.#f(n) && (this.delete(this.#s[n]), t = !0);
        return t
    }
    info(t) {
        const n = this.#n.get(t);
        if (n === void 0) return;
        const a = this.#e[n],
            o = this.#t(a) ? a.__staleWhileFetching : a;
        if (o === void 0) return;
        const i = {
            value: o
        };
        if (this.#m && this.#b) {
            const r = this.#m[n],
                l = this.#b[n];
            if (r && l) {
                const c = r - (Tt.now() - l);
                i.ttl = c, i.start = Date.now()
            }
        }
        return this.#S && (i.size = this.#S[n]), i
    }
    dump() {
        const t = [];
        for (const n of this.#w({
                allowStale: !0
            })) {
            const a = this.#s[n],
                o = this.#e[n],
                i = this.#t(o) ? o.__staleWhileFetching : o;
            if (i === void 0 || a === void 0) continue;
            const r = {
                value: i
            };
            if (this.#m && this.#b) {
                r.ttl = this.#m[n];
                const l = Tt.now() - this.#b[n];
                r.start = Math.floor(Date.now() - l)
            }
            this.#S && (r.size = this.#S[n]), t.unshift([a, r])
        }
        return t
    }
    load(t) {
        this.clear();
        for (const [n, a] of t) {
            if (a.start) {
                const o = Date.now() - a.start;
                a.start = Tt.now() - o
            }
            this.set(n, a.value, a)
        }
    }
    set(t, n, a = {}) {
        if (n === void 0) return this.delete(t), this;
        const {
            ttl: o = this.ttl,
            start: i,
            noDisposeOnSet: r = this.noDisposeOnSet,
            sizeCalculation: l = this.sizeCalculation,
            status: c
        } = a;
        let {
            noUpdateTTL: m = this.noUpdateTTL
        } = a;
        const d = this.#D(t, n, a.size || 0, l);
        if (this.maxEntrySize && d > this.maxEntrySize) return c && (c.set = "miss", c.maxEntrySizeExceeded = !0), this.delete(t), this;
        let h = this.#a === 0 ? void 0 : this.#n.get(t);
        if (h === void 0) h = this.#a === 0 ? this.#o : this.#v.length !== 0 ? this.#v.pop() : this.#a === this.#l ? this.#E(!1) : this.#a, this.#s[h] = t, this.#e[h] = n, this.#n.set(t, h), this.#c[this.#o] = h, this.#h[h] = this.#o, this.#o = h, this.#a++, this.#R(h, d, c), c && (c.set = "add"), m = !1;
        else {
            this.#k(h);
            const g = this.#e[h];
            if (n !== g) {
                if (this.#_ && this.#t(g)) {
                    g.__abortController.abort(new Error("replaced"));
                    const {
                        __staleWhileFetching: p
                    } = g;
                    p !== void 0 && !r && (this.#y && this.#g ? .(p, t, "set"), this.#u && this.#i ? .push([p, t, "set"]))
                } else r || (this.#y && this.#g ? .(g, t, "set"), this.#u && this.#i ? .push([g, t, "set"]));
                if (this.#C(h), this.#R(h, d, c), this.#e[h] = n, c) {
                    c.set = "replace";
                    const p = g && this.#t(g) ? g.__staleWhileFetching : g;
                    p !== void 0 && (c.oldValue = p)
                }
            } else c && (c.set = "update")
        }
        if (o !== 0 && !this.#m && this.#P(), this.#m && (m || this.#I(h, o, i), c && this.#M(c, h)), !r && this.#u && this.#i) {
            const g = this.#i;
            let p;
            for (; p = g ? .shift();) this.#p ? .(...p)
        }
        return this
    }
    pop() {
        try {
            for (; this.#a;) {
                const t = this.#e[this.#r];
                if (this.#E(!0), this.#t(t)) {
                    if (t.__staleWhileFetching) return t.__staleWhileFetching
                } else if (t !== void 0) return t
            }
        } finally {
            if (this.#u && this.#i) {
                const t = this.#i;
                let n;
                for (; n = t ? .shift();) this.#p ? .(...n)
            }
        }
    }#
    E(t) {
        const n = this.#r,
            a = this.#s[n],
            o = this.#e[n];
        return this.#_ && this.#t(o) ? o.__abortController.abort(new Error("evicted")) : (this.#y || this.#u) && (this.#y && this.#g ? .(o, a, "evict"), this.#u && this.#i ? .push([o, a, "evict"])), this.#C(n), t && (this.#s[n] = void 0, this.#e[n] = void 0, this.#v.push(n)), this.#a === 1 ? (this.#r = this.#o = 0, this.#v.length = 0) : this.#r = this.#c[n], this.#n.delete(a), this.#a--, n
    }
    has(t, n = {}) {
        const {
            updateAgeOnHas: a = this.updateAgeOnHas,
            status: o
        } = n, i = this.#n.get(t);
        if (i !== void 0) {
            const r = this.#e[i];
            if (this.#t(r) && r.__staleWhileFetching === void 0) return !1;
            if (this.#f(i)) o && (o.has = "stale", this.#M(o, i));
            else return a && this.#j(i), o && (o.has = "hit", this.#M(o, i)), !0
        } else o && (o.has = "miss");
        return !1
    }
    peek(t, n = {}) {
        const {
            allowStale: a = this.allowStale
        } = n, o = this.#n.get(t);
        if (o === void 0 || !a && this.#f(o)) return;
        const i = this.#e[o];
        return this.#t(i) ? i.__staleWhileFetching : i
    }#
    N(t, n, a, o) {
        const i = n === void 0 ? void 0 : this.#e[n];
        if (this.#t(i)) return i;
        const r = new Fs,
            {
                signal: l
            } = a;
        l ? .addEventListener("abort", () => r.abort(l.reason), {
            signal: r.signal
        });
        const c = {
                signal: r.signal,
                options: a,
                context: o
            },
            m = (f, v = !1) => {
                const {
                    aborted: x
                } = r.signal, M = a.ignoreFetchAbort && f !== void 0;
                if (a.status && (x && !v ? (a.status.fetchAborted = !0, a.status.fetchError = r.signal.reason, M && (a.status.fetchAbortIgnored = !0)) : a.status.fetchResolved = !0), x && !M && !v) return h(r.signal.reason);
                const S = p;
                return this.#e[n] === p && (f === void 0 ? S.__staleWhileFetching ? this.#e[n] = S.__staleWhileFetching : this.delete(t) : (a.status && (a.status.fetchUpdated = !0), this.set(t, f, c.options))), f
            },
            d = f => (a.status && (a.status.fetchRejected = !0, a.status.fetchError = f), h(f)),
            h = f => {
                const {
                    aborted: v
                } = r.signal, x = v && a.allowStaleOnFetchAbort, M = x || a.allowStaleOnFetchRejection, S = M || a.noDeleteOnFetchRejection, y = p;
                if (this.#e[n] === p && (!S || y.__staleWhileFetching === void 0 ? this.delete(t) : x || (this.#e[n] = y.__staleWhileFetching)), M) return a.status && y.__staleWhileFetching !== void 0 && (a.status.returnedStale = !0), y.__staleWhileFetching;
                if (y.__returned === y) throw f
            },
            g = (f, v) => {
                const x = this.#A ? .(t, i, c);
                x && x instanceof Promise && x.then(M => f(M === void 0 ? void 0 : M), v), r.signal.addEventListener("abort", () => {
                    (!a.ignoreFetchAbort || a.allowStaleOnFetchAbort) && (f(void 0), a.allowStaleOnFetchAbort && (f = M => m(M, !0)))
                })
            };
        a.status && (a.status.fetchDispatched = !0);
        const p = new Promise(g).then(m, d),
            b = Object.assign(p, {
                __abortController: r,
                __staleWhileFetching: i,
                __returned: void 0
            });
        return n === void 0 ? (this.set(t, b, { ...c.options,
            status: void 0
        }), n = this.#n.get(t)) : this.#e[n] = b, b
    }#
    t(t) {
        if (!this.#_) return !1;
        const n = t;
        return !!n && n instanceof Promise && n.hasOwnProperty("__staleWhileFetching") && n.__abortController instanceof Fs
    }
    async fetch(t, n = {}) {
        const {
            allowStale: a = this.allowStale,
            updateAgeOnGet: o = this.updateAgeOnGet,
            noDeleteOnStaleGet: i = this.noDeleteOnStaleGet,
            ttl: r = this.ttl,
            noDisposeOnSet: l = this.noDisposeOnSet,
            size: c = 0,
            sizeCalculation: m = this.sizeCalculation,
            noUpdateTTL: d = this.noUpdateTTL,
            noDeleteOnFetchRejection: h = this.noDeleteOnFetchRejection,
            allowStaleOnFetchRejection: g = this.allowStaleOnFetchRejection,
            ignoreFetchAbort: p = this.ignoreFetchAbort,
            allowStaleOnFetchAbort: b = this.allowStaleOnFetchAbort,
            context: f,
            forceRefresh: v = !1,
            status: x,
            signal: M
        } = n;
        if (!this.#_) return x && (x.fetch = "get"), this.get(t, {
            allowStale: a,
            updateAgeOnGet: o,
            noDeleteOnStaleGet: i,
            status: x
        });
        const S = {
            allowStale: a,
            updateAgeOnGet: o,
            noDeleteOnStaleGet: i,
            ttl: r,
            noDisposeOnSet: l,
            size: c,
            sizeCalculation: m,
            noUpdateTTL: d,
            noDeleteOnFetchRejection: h,
            allowStaleOnFetchRejection: g,
            allowStaleOnFetchAbort: b,
            ignoreFetchAbort: p,
            status: x,
            signal: M
        };
        let y = this.#n.get(t);
        if (y === void 0) {
            x && (x.fetch = "miss");
            const w = this.#N(t, y, S, f);
            return w.__returned = w
        } else {
            const w = this.#e[y];
            if (this.#t(w)) {
                const A = a && w.__staleWhileFetching !== void 0;
                return x && (x.fetch = "inflight", A && (x.returnedStale = !0)), A ? w.__staleWhileFetching : w.__returned = w
            }
            const N = this.#f(y);
            if (!v && !N) return x && (x.fetch = "hit"), this.#k(y), o && this.#j(y), x && this.#M(x, y), w;
            const E = this.#N(t, y, S, f),
                _ = E.__staleWhileFetching !== void 0 && a;
            return x && (x.fetch = N ? "stale" : "refresh", _ && N && (x.returnedStale = !0)), _ ? E.__staleWhileFetching : E.__returned = E
        }
    }
    get(t, n = {}) {
        const {
            allowStale: a = this.allowStale,
            updateAgeOnGet: o = this.updateAgeOnGet,
            noDeleteOnStaleGet: i = this.noDeleteOnStaleGet,
            status: r
        } = n, l = this.#n.get(t);
        if (l !== void 0) {
            const c = this.#e[l],
                m = this.#t(c);
            return r && this.#M(r, l), this.#f(l) ? (r && (r.get = "stale"), m ? (r && a && c.__staleWhileFetching !== void 0 && (r.returnedStale = !0), a ? c.__staleWhileFetching : void 0) : (i || this.delete(t), r && a && (r.returnedStale = !0), a ? c : void 0)) : (r && (r.get = "hit"), m ? c.__staleWhileFetching : (this.#k(l), o && this.#j(l), c))
        } else r && (r.get = "miss")
    }#
    L(t, n) {
        this.#h[n] = t, this.#c[t] = n
    }#
    k(t) {
        t !== this.#o && (t === this.#r ? this.#r = this.#c[t] : this.#L(this.#h[t], this.#c[t]), this.#L(this.#o, t), this.#o = t)
    }
    delete(t) {
        let n = !1;
        if (this.#a !== 0) {
            const a = this.#n.get(t);
            if (a !== void 0)
                if (n = !0, this.#a === 1) this.clear();
                else {
                    this.#C(a);
                    const o = this.#e[a];
                    if (this.#t(o) ? o.__abortController.abort(new Error("deleted")) : (this.#y || this.#u) && (this.#y && this.#g ? .(o, t, "delete"), this.#u && this.#i ? .push([o, t, "delete"])), this.#n.delete(t), this.#s[a] = void 0, this.#e[a] = void 0, a === this.#o) this.#o = this.#h[a];
                    else if (a === this.#r) this.#r = this.#c[a];
                    else {
                        const i = this.#h[a];
                        this.#c[i] = this.#c[a];
                        const r = this.#c[a];
                        this.#h[r] = this.#h[a]
                    }
                    this.#a--, this.#v.push(a)
                }
        }
        if (this.#u && this.#i ? .length) {
            const a = this.#i;
            let o;
            for (; o = a ? .shift();) this.#p ? .(...o)
        }
        return n
    }
    clear() {
        for (const t of this.#T({
                allowStale: !0
            })) {
            const n = this.#e[t];
            if (this.#t(n)) n.__abortController.abort(new Error("deleted"));
            else {
                const a = this.#s[t];
                this.#y && this.#g ? .(n, a, "delete"), this.#u && this.#i ? .push([n, a, "delete"])
            }
        }
        if (this.#n.clear(), this.#e.fill(void 0), this.#s.fill(void 0), this.#m && this.#b && (this.#m.fill(0), this.#b.fill(0)), this.#S && this.#S.fill(0), this.#r = 0, this.#o = 0, this.#v.length = 0, this.#x = 0, this.#a = 0, this.#u && this.#i) {
            const t = this.#i;
            let n;
            for (; n = t ? .shift();) this.#p ? .(...n)
        }
    }
}

function ef({
    conversationId: e,
    messageId: t
}) {
    const [n, a] = u.useState(!1), o = u.useRef({
        isMediaSourceAvailable: ta(),
        mediaSourceFormat: sa() ? ? "n/a",
        playPromise: null,
        shouldAbortQueuedPlayback: !1
    }).current, i = ze(), r = En(), {
        voiceName: l
    } = ru(), c = `${e}.${t}.${l}`, m = Mr(), d = _r(f => f.isPlaying && f.sourceUrl === Ee.get(c) ? .src), h = u.useCallback(async () => {
        if (!m) return;
        a(!0);
        const f = {
            isMediaSourceAvailable: o.isMediaSourceAvailable,
            format: o.mediaSourceFormat
        };
        try {
            const v = await tf({
                key: c,
                message_id: t,
                conversation_id: e,
                voice: l,
                onStreamingError: x => {
                    At.readAloud.error(x, f), a(!1), r.danger(i.formatMessage(Ga.playbackError, {
                        error: x.message
                    }))
                },
                onStreamingStart: () => {
                    a(!1)
                }
            });
            if (o.shouldAbortQueuedPlayback) {
                o.shouldAbortQueuedPlayback = !1;
                return
            }
            m.changeSource(v), o.playPromise = m.play()
        } catch (v) {
            At.readAloud.error(v, f), a(!1), r.danger(i.formatMessage(Ga.playbackError, {
                error: v.message
            }))
        }
    }, [m, o, c, t, e, l, r, i]), g = u.useCallback(() => {
        const f = Sa();
        f && (o.playPromise ? o.playPromise.then(() => {
            f.stop(), o.playPromise = null
        }) : f.stop())
    }, [o]), p = u.useCallback(() => {
        const f = Sa();
        f && (f.state.isPlaying && f.state.sourceUrl === Ee.get(c) ? .src ? g() : (At.readAloud.click({
            isMediaSourceAvailable: o.isMediaSourceAvailable,
            format: o.mediaSourceFormat
        }), h()))
    }, [c, o, h, g]);
    u.useEffect(() => {
        n && d && a(!1)
    }, [n, d]);
    const b = u.useRef(c);
    return u.useEffect(() => {
        b.current = c
    }), u.useEffect(() => (o.shouldAbortQueuedPlayback = !1, () => {
        const f = jr();
        f.isPlaying && f.sourceUrl === Ee.get(b.current) ? .src ? g() : o.shouldAbortQueuedPlayback = !0
    }), [o, g]), {
        togglePlayback: p,
        isPlaying: d,
        isLoading: n
    }
}
async function ji({
    message_id: e,
    conversation_id: t,
    voice: n
}) {
    const a = await ht.synthesize({
            message_id: e,
            conversation_id: t,
            voice: n,
            format: sa()
        }),
        o = a.headers.get("content-type") ? ? "audio/aac";
    return {
        response: a,
        format: o
    }
}
async function tf(e) {
    return ta() ? nf(e) : sf(e)
}
async function sf({
    key: e,
    ...t
}) {
    const n = Ee.get(e);
    if (n ? .blob) return n.src;
    const {
        response: a,
        format: o
    } = await ji(t), i = await a.arrayBuffer(), r = new Blob([i], {
        type: o
    }), l = Ci({
        key: e,
        src: URL.createObjectURL(r),
        format: o,
        blob: r
    });
    return Ee.set(e, l), l.src
}
async function nf({
    key: e,
    onStreamingError: t,
    onStreamingStart: n,
    ...a
}) {
    let o = Ee.get(e);
    o ? .streaming && (Ee.delete(e), o = void 0);
    let i, r;
    const l = of (),
        c = new l;
    if (o) i = o, i.src = URL.createObjectURL(c);
    else {
        const {
            format: h,
            response: g
        } = await ji(a);
        r = g, i = Ci({
            key: e,
            src: URL.createObjectURL(c),
            format: h
        })
    }
    const m = af(i.id),
        d = {
            sourceopen: async () => {
                m("sourceopen");
                const h = c.addSourceBuffer(i.format),
                    g = async () => {
                        h.updating && await new Promise(p => h.addEventListener("updateend", p, {
                            once: !0
                        }))
                    };
                if (i.segments.length && !i.streaming) {
                    m("streaming from cache"), i.streaming = !0, n();
                    for (const p of i.segments) h.appendBuffer(p), await g();
                    c.readyState === "open" && c.endOfStream(), i.streaming = !1, m("done streaming from cache");
                    return
                }
                if (r) {
                    m("fetching audio");
                    try {
                        const p = r.body ? .getReader();
                        if (!p) return;
                        for (; Ee.get(e) ? .id === i.id;) {
                            const {
                                done: b,
                                value: f
                            } = await p.read();
                            if (b) {
                                m("done streaming"), i.streaming = !1, c.readyState === "open" && c.endOfStream();
                                break
                            }
                            if (!Array.from(c.sourceBuffers).includes(h)) {
                                m("stop streaming, source buffer removed"), i.streaming = !1;
                                break
                            }
                            i.streaming || (m("start streaming"), i.streaming = !0, n()), h.appendBuffer(f), i.segments.push(f), await g()
                        }
                    } catch (p) {
                        if (m("error while streaming", p), i.streaming = !1, c.readyState === "open") try {
                            c.endOfStream("network")
                        } catch (b) {
                            At.readAloud.error(b)
                        }
                        Ee.delete(e), t(p)
                    }
                }
            },
            sourceclose: () => {
                m("sourceclose"), i.streaming && (i.streaming = !1, Ee.get(e) ? .id === i.id && (m("sourceclosed while streaming, cleaning up cache"), Ee.delete(e)))
            },
            sourceended: _t
        };
    for (const [h, g] of Object.entries(d)) c.addEventListener(h, () => {
        try {
            return g()
        } catch (p) {
            At.readAloud.error(p)
        }
    });
    return Ee.set(e, i), i.src
}
const Ga = He({
        playbackError: {
            id: "useVoiceReadAloudAudio.playbackError",
            defaultMessage: "Failed to play message"
        }
    }),
    af = e => _t;

function of () {
    return ta() ? window.MediaSource : null
}

function ta() {
    return !!sa()
}

function sa() {
    if ("MediaSource" in window) {
        const e = t => Cr(t) && MediaSource.isTypeSupported(t);
        if (e("audio/aac")) return "aac";
        if (e("audio/mpeg")) return "mp3";
        if (e("audio/ogg")) return "ogg"
    }
}
const Ci = e => ({
        id: po(),
        segments: [],
        streaming: !1,
        ...e
    }),
    Ee = new ea({
        max: 50,
        dispose: e => {
            URL.revokeObjectURL(e.src)
        }
    }),
    rf = u.memo(function(t) {
        const n = Bn("1923022511") ? .value,
            a = Dt(t.conversationId),
            {
                errCode: o
            } = Xo(t.message);
        if (!n || !a || o) return null;
        const i = So.getAudioAssetPointers(t.message.message)[0];
        return i ? s.jsx(lf, {
            audioAssetPointer: i,
            conversationId: a
        }) : s.jsx(cf, { ...t,
            conversationId: a
        })
    });

function lf({
    audioAssetPointer: e,
    conversationId: t
}) {
    const {
        isLoading: n,
        isPlaying: a,
        togglePlayback: o
    } = lu({
        audioAssetPointer: e,
        conversationId: t
    });
    return s.jsx(ki, {
        onClick: o,
        isPlaying: a,
        isLoading: n,
        playText: Ls.replay,
        playIcon: Ad
    })
}

function cf({
    conversationId: e,
    message: t
}) {
    const {
        isLoading: n,
        isPlaying: a,
        togglePlayback: o
    } = ef({
        conversationId: e,
        messageId: t.message.id
    });
    return s.jsx(ki, {
        onClick: o,
        isPlaying: a,
        isLoading: n,
        playText: Ls.play,
        playIcon: Rd
    })
}

function ki({
    onClick: e,
    isPlaying: t,
    isLoading: n,
    playText: a,
    playIcon: o
}) {
    let i, r;
    const l = ze();
    return n ? (i = kr, r = Ls.loading) : t ? (i = Ed, r = Ls.stop) : (i = o, r = a), s.jsx(Kt, {
        icon: i,
        label: r ? l.formatMessage(r) : void 0,
        disabled: n,
        onClick: e,
        style: t || n ? {
            visibility: "visible"
        } : void 0,
        testId: "voice-play-turn-action-button"
    })
}
const Ls = {
        replay: {
            id: "VoiceReadOutLoudButton.replay",
            defaultMessage: "Replay",
            description: "The tooltip for the replay button"
        },
        play: {
            id: "VoiceReadOutLoudButton.play",
            defaultMessage: "Read aloud",
            description: "The tooltip for the read aloud button"
        },
        stop: {
            id: "VoiceReadOutLoudButton.stop",
            defaultMessage: "Stop",
            description: "The tooltip for the stop button"
        },
        loading: {
            id: "VoiceReadOutLoudButton.loading",
            defaultMessage: "Loading",
            description: "The tooltip for the spinner"
        }
    },
    Ms = "rounded-lg radix-disabled:pointer-events-auto radix-disabled:cursor-not-allowed";

function uf({
    className: e,
    clientThreadId: t,
    message: n,
    onModelSelect: a,
    onDropdownChange: o,
    canRegenerateResponse: i
}) {
    const [l, c] = u.useState(null), [m, d] = u.useState(!1), [h, g] = u.useState(!1), p = Ge(t), b = Ko({
        clientThreadId: t,
        message: n
    }), f = n.message.metadata ? .model_slug, v = n.message.id, {
        modelOptions: x,
        modelSlug: M,
        animateModelLabelOnRender: S,
        messageModelEnabledTools: y
    } = b, w = Yo(n.message), N = y.includes(Hs.Search), E = u.useMemo(() => x.find(R => R.value === f), [x, f]), T = u.useRef(null), {
        doesUserHaveAnyAccountsWithPlusFeatures: _
    } = xo(), A = R => {
        R || setTimeout(() => {
            T.current && T.current.blur()
        }, 10)
    };
    if (u.useEffect(() => {
            A(m)
        }, [m]), Ar(t)) return null;
    const L = i && x.some(R => es(R, _));
    return p ? null : s.jsxs(Ne.Root, {
        onOpenChange: R => {
            i && (d(R), o(R), A(R)), R && oe.logEvent(ne.conversationOpenMessageModelSelector, {
                has_get_plus_button: L,
                is_new_regen_dropdown: !0
            })
        },
        children: [i ? s.jsx(hf, {
            label: s.jsx(O, {
                id: "wDs5sz",
                defaultMessage: "Switch model"
            }),
            children: s.jsx(vo, {
                ref: T,
                className: P("cursor-pointer", e),
                onMouseEnter: () => g(!0),
                onMouseLeave: () => g(!1),
                children: s.jsx(Cn, {
                    modelSlug: M,
                    animateModelLabelOnRender: S,
                    isDropdownOpen: m,
                    isRegenerateEnabled: i,
                    isHovered: h,
                    isRegenLabel: !0,
                    omitIcon: !1
                })
            })
        }) : s.jsx("button", {
            className: P("cursor-pointer", e),
            onMouseEnter: () => g(!0),
            onMouseLeave: () => g(!1),
            children: s.jsx(Cn, {
                modelSlug: M,
                animateModelLabelOnRender: S,
                isDropdownOpen: !1,
                isRegenerateEnabled: !1,
                isHovered: h,
                omitIcon: !0,
                animateShortLabel: !0
            })
        }), i && s.jsx(Ne.Portal, {
            children: s.jsxs(Ne.Content, {
                className: "z-30 min-w-fit origin-top-right text-token-text-primary",
                side: "bottom",
                align: "start",
                children: [s.jsx(Ne.Item, {
                    disabled: !0,
                    className: "pb-0 pt-2",
                    children: s.jsx("span", {
                        className: "text-token-text-secondary",
                        children: s.jsx(O, {
                            id: "bFLh5u",
                            defaultMessage: "Switch model"
                        })
                    })
                }), s.jsx(df, {
                    clientThreadId: t,
                    messageId: v,
                    onModelSelect: a,
                    messageModelSlug: f,
                    omitModelIcons: !0,
                    modelOptions: x,
                    setHoveredOption: c,
                    hoveredOption: l,
                    retryOption: E,
                    lastResponseUsedSearch: w,
                    modelSupportsSearch: N,
                    doesUserHaveAnyAccountsWithPlusFeatures: _
                })]
            })
        })]
    })
}

function df({
    clientThreadId: e,
    messageId: t,
    modelOptions: n,
    messageModelSlug: a,
    onModelSelect: o,
    omitModelIcons: i,
    setHoveredOption: r,
    hoveredOption: l,
    retryOption: c,
    lastResponseUsedSearch: m,
    modelSupportsSearch: d,
    doesUserHaveAnyAccountsWithPlusFeatures: h
}) {
    const g = ze(),
        [p, b] = u.useMemo(() => cu(n, S => S.subcategory), [n]),
        f = u.useMemo(() => {
            const S = new Map;
            return p.forEach(y => {
                const w = y.subcategory;
                w && (S.has(w) || S.set(w, []), S.get(w) ? .push(y))
            }), S
        }, [p]),
        v = P("icon-sm", i && "order-10 ml-auto text-token-text-tertiary icon-md"),
        x = i ? "right" : "left",
        M = [{
            key: "use-search",
            extraStreamParams: {
                forceUseSearch: !0
            },
            label: g.formatMessage(ln.search),
            icon: s.jsx(Kn, {
                className: v
            }),
            condition: d && !m,
            eventName: "chatgpt_regenerate_with_search_button_clicked"
        }, {
            key: "use-no-search",
            extraStreamParams: {
                forceUseSearch: !1
            },
            label: g.formatMessage(ln.nosearch),
            icon: s.jsx(ni, {
                className: v
            }),
            condition: d && m,
            eventName: "chatgpt_regenerate_without_search_button_clicked"
        }];
    return s.jsxs(s.Fragment, {
        children: [b.map(S => {
            const {
                value: y,
                ...w
            } = S;
            return s.jsx(jt, {
                value: y,
                onSelect: () => {
                    me.logEvent("chatgpt_regenerate_switch_model_button_clicked", y, {
                        requestedModelId: y,
                        ...Xe({
                            clientThreadId: e,
                            messageId: t
                        })
                    }), o({
                        requestedModelId: y
                    })
                },
                includeRegenerate: !1,
                onMouseEnter: () => r(y),
                onMouseLeave: () => r(null),
                isHovered: l === y,
                messageModelSlug: a,
                includeCheck: !1,
                shouldShowUpsell: es(S, h),
                className: Ms,
                ...w,
                icon: i ? s.jsx("span", {
                    className: v
                }) : w.icon,
                justifyIcon: x,
                wrapIcon: !i
            }, y)
        }), [...f.entries()].map(([S, y]) => s.jsxs(Ne.Sub, {
            children: [s.jsx(Ne.SubMenuTrigger, {
                children: s.jsx("div", {
                    className: "flex grow justify-between gap-2 overflow-hidden",
                    children: S
                })
            }), s.jsx(Ne.Portal, {
                children: s.jsx(Ne.SubContent, {
                    className: "min-w-fit",
                    children: y.map(w => {
                        const {
                            value: N,
                            ...E
                        } = w;
                        return s.jsx(jt, {
                            value: N,
                            onSelect: () => {
                                me.logEvent("chatgpt_regenerate_switch_model_button_clicked", N, {
                                    requestedModelId: N,
                                    ...Xe({
                                        clientThreadId: e,
                                        messageId: t
                                    })
                                }), o({
                                    requestedModelId: N
                                })
                            },
                            includeRegenerate: !1,
                            onMouseEnter: () => r(N),
                            onMouseLeave: () => r(null),
                            isHovered: l === N,
                            messageModelSlug: a,
                            includeCheck: !1,
                            className: Ms,
                            ...E,
                            icon: null,
                            justifyIcon: x,
                            wrapIcon: !i,
                            shouldShowUpsell: es(w, h)
                        }, S + "-" + N)
                    })
                })
            })]
        }, S)), !!c && s.jsxs(s.Fragment, {
            children: [s.jsx(Ne.Separator, {}), s.jsx(jt, {
                onSelect: () => {
                    me.logEvent("chatgpt_regenerate_try_again_button_clicked", c.value, {
                        requestedModelId: c.value,
                        ...Xe({
                            clientThreadId: e,
                            messageId: t
                        })
                    }), o({
                        requestedModelId: c.value
                    })
                },
                includeRegenerate: !0,
                onMouseEnter: () => r(c.value),
                onMouseLeave: () => r(null),
                messageModelSlug: a,
                includeCheck: !1,
                className: Ms,
                ...c,
                label: g.formatMessage(ln.tryAgain),
                subtitle: c.label,
                icon: s.jsx(Yn, {
                    className: v
                }),
                justifyIcon: x,
                wrapIcon: !i
            }, c.value), M.filter(S => S.condition).map(S => s.jsx(jt, {
                onSelect: () => {
                    me.logEvent(S.eventName, c.value, {
                        requestedModelId: c.value,
                        ...Xe({
                            clientThreadId: e,
                            messageId: t
                        })
                    }), o({
                        requestedModelId: c.value,
                        extraStreamParams: S.extraStreamParams
                    })
                },
                includeRegenerate: !1,
                onMouseEnter: () => r(S.key),
                onMouseLeave: () => r(null),
                isHovered: l === S.key,
                messageModelSlug: a,
                includeCheck: !1,
                className: Ms,
                ...c,
                label: S.label,
                subtitle: "",
                icon: S.icon,
                justifyIcon: x,
                wrapIcon: !i
            }, S.key))]
        })]
    })
}

function hf({
    children: e,
    label: t
}) {
    return s.jsx(Rn, {
        label: t,
        sideOffset: 0,
        children: e
    })
}
const ln = He({
        tryAgain: {
            id: "VbsBGW",
            defaultMessage: "Try again"
        },
        search: {
            id: "eTV6j1",
            defaultMessage: "Search the web"
        },
        nosearch: {
            id: "IvLzUk",
            defaultMessage: "Without web search"
        }
    }),
    mf = u.memo(uf),
    Wa = ns(() => as(() =>
        import ("./ab2oz9enzsoo3wow.js").then(e => e.ps), __vite__mapDeps([6, 1, 2, 3, 7])).then(e => e.MemoryActionResult));

function Va(e, t, n) {
    J.updateTree(e, a => {
        a.updateNodeMetadata(t, {
            inlineComparisonRating: n
        })
    })
}

function qa(e) {
    return {
        is_dark_mode: e === "dark",
        time_since_loaded: Math.floor(performance.now() / 1e3),
        page_height: window ? .innerHeight,
        page_width: window ? .innerWidth,
        pixel_ratio: window ? .devicePixelRatio,
        screen_height: window ? .screen ? .height,
        screen_width: window ? .screen ? .width
    }
}
const $a = ({
    messages: e
}) => {
    for (const {
            message: {
                metadata: t
            }
        } of e) {
        const {
            augmented_paragen_prompt_label: n
        } = t ? ? {};
        if (n) return n
    }
};

function ff(e) {
    const t = u.useRef({
            left_visibility_initial: null,
            left_visibility_max: null,
            right_visibility_initial: null,
            right_visibility_max: null
        }),
        n = u.useRef({
            left: null,
            right: null
        });
    return e.stubSideBySideFeedback ? s.jsx(Ai, {
        setPreferredFeedback: () => {},
        leftVariantId: "left-placeholder",
        rightVariantId: "right-placeholder",
        leftTurn: null,
        rightTurn: null,
        originalTurn: null,
        hasActiveRequest: !0,
        visibilityStateRef: t,
        firstVisibleTokenTimestampsRef: n,
        ...e
    }) : s.jsx(gf, { ...e,
        visibilityStateRef: t,
        firstVisibleTokenTimestampsRef: n
    })
}

function gf(e) {
    const {
        clientThreadId: t,
        variantIds: n,
        variantsInStreamInfo: a,
        turnIndex: o,
        firstVisibleTokenTimestampsRef: i
    } = e;
    if (n.length !== 2) throw new Error("ConversationTurnSideBySideFeedback requires exactly two variant IDs");
    const r = na(),
        l = xf(),
        c = In(),
        {
            resolvedTheme: m
        } = Rr(),
        [d, h] = u.useMemo(() => Qo(n.join(""))() < .5 ? [0, 1] : [1, 0], [n[0], n[1]]),
        g = d < h ? "left" : "right",
        p = g === "left" ? "right" : "left",
        b = n[d],
        f = n[h],
        v = Mt(ba(t, b)).id,
        x = Mt(ba(t, f)).id,
        M = Mt(fn(t, o, v)),
        S = Mt(fn(t, o, x)),
        y = g === "left" ? M : S,
        w = g === "left" ? S : M,
        N = a.display_treatment === "unskippable",
        E = r ? "skippable_parallel_2_in_stream:a:2.0" : "skippable_parallel_2_in_stream:a:1.5";
    u.useEffect(() => (pn.setState({
        displayingSideBySideFeedback: !0,
        unskippable: N
    }), () => {
        pn.setState({
            displayingSideBySideFeedback: !1,
            unskippable: !1
        })
    }), [N]), uu();
    const T = u.useRef({
        left_visibility_initial: null,
        left_visibility_max: null,
        right_visibility_initial: null,
        right_visibility_max: null
    });
    u.useEffect(() => Er(Nr, {
        requestCompletion: () => {
            const A = Ke(y.messages) ? .completionSampleFinishTime,
                F = Ke(w.messages) ? .completionSampleFinishTime,
                L = J.getServerThreadId(t);
            if (l) {
                const I = J.getTree(t).getParentPromptNode(v),
                    U = [M, S].map((k, W) => ({
                        messageId: k.messages[k.messages.length - 1].message.id,
                        loadFirstTokenTime: W === 0 ? i.current.left : i.current.right,
                        loadEndTime: Ke(k.messages) ? .completionSampleFinishTime
                    })),
                    C = {},
                    B = I.metadata ? .variantsInStreamInfo == null && I.message.metadata ? .paragen_variants_info != null;
                for (const k of U) C[k.messageId] = B ? {
                    load_first_token_time: e.conversationTurnMountTime,
                    load_end_time: e.conversationTurnMountTime
                } : {
                    load_first_token_time: k.loadFirstTokenTime,
                    load_end_time: k.loadEndTime
                };
                _s({
                    shouldUseNewParagenEndpoint: l,
                    params: {
                        conversation_id: L,
                        displayed_message_ids: U.map(k => k.messageId),
                        message_metadatas: C,
                        rating: "skipped",
                        selected_message_id: null,
                        source_timestamp: Date.now(),
                        ui_variant: r ? 2 : 1,
                        user_prompt_message_id: I.message.id
                    }
                })
            } else _s({
                shouldUseNewParagenEndpoint: l,
                params: {
                    feedback_version: E,
                    original_message_id: y.messages[y.messages.length - 1] ? .message.id,
                    new_message_id: w.messages[w.messages.length - 1] ? .message.id,
                    conversation_id: L,
                    completion_comparison_rating: "skip",
                    new_completion_placement: p,
                    feedback_start_time: e.conversationTurnMountTime,
                    compare_step_start_time: e.conversationTurnMountTime,
                    original_completion_load_start_time: e.conversationTurnMountTime,
                    original_completion_load_end_time: A ? ? 0,
                    new_completion_load_start_time: e.conversationTurnMountTime,
                    new_completion_load_end_time: F ? ? 0,
                    frontend_submission_time: Date.now(),
                    timezone_offset_min: new Date().getTimezoneOffset(),
                    client_contextual_info: qa(m),
                    ...T.current
                }
            })
        }
    }), [M, S, v, t, e.conversationTurnMountTime, E, p, y ? .messages, w ? .messages, m, l, r, i]);
    const _ = A => {
        const L = J.getTree(t).getLeafFromNode(A);
        J.setThreadCurrentLeafId(t, L.id);
        const R = A === b,
            I = R === (g === "left"),
            U = Ke(y.messages) ? .completionSampleFinishTime,
            C = Ke(w.messages) ? .completionSampleFinishTime;
        y.messages.length > 0 && Va(t, y.messages[y.messages.length - 1].nodeId, I ? "original" : "new"), w.messages.length > 0 && Va(t, w.messages[w.messages.length - 1].nodeId, I ? "original" : "new");
        let B;
        U == null || C == null ? B = I ? "partial_load_comparison_original" : "partial_load_comparison_new" : B = I ? "original" : "new";
        const k = J.getServerThreadId(t);
        if (l) {
            const W = [M, S].map((ee, re) => ({
                    messageId: ee.messages[ee.messages.length - 1].message.id,
                    loadFirstTokenTime: re === 0 ? i.current.left : i.current.right,
                    loadEndTime: Ke(ee.messages) ? .completionSampleFinishTime
                })),
                Z = R ? W[0].messageId : W[1].messageId,
                Y = J.getTree(t).getParentPromptNode(v),
                fe = {},
                ye = Y.metadata ? .variantsInStreamInfo == null && Y.message.metadata ? .paragen_variants_info != null;
            for (const ee of W) fe[ee.messageId] = ye ? {
                load_first_token_time: e.conversationTurnMountTime,
                load_end_time: e.conversationTurnMountTime
            } : {
                load_first_token_time: ee.loadFirstTokenTime,
                load_end_time: ee.loadEndTime
            };
            _s({
                shouldUseNewParagenEndpoint: l,
                params: {
                    conversation_id: k,
                    displayed_message_ids: W.map(ee => ee.messageId),
                    message_metadatas: fe,
                    rating: "selected",
                    selected_message_id: Z,
                    source_timestamp: Date.now(),
                    ui_variant: r ? 2 : 1,
                    user_prompt_message_id: Y.message.id
                }
            })
        } else _s({
            shouldUseNewParagenEndpoint: l,
            params: {
                feedback_version: E,
                original_message_id: y.messages[y.messages.length - 1] ? .message.id,
                new_message_id: w.messages[w.messages.length - 1] ? .message.id,
                conversation_id: k,
                completion_comparison_rating: B,
                new_completion_placement: p,
                feedback_start_time: e.conversationTurnMountTime,
                compare_step_start_time: e.conversationTurnMountTime,
                original_completion_load_start_time: e.conversationTurnMountTime,
                original_completion_load_end_time: U ? ? null,
                new_completion_load_start_time: e.conversationTurnMountTime,
                new_completion_load_end_time: C ? ? null,
                frontend_submission_time: Date.now(),
                timezone_offset_min: new Date().getTimezoneOffset(),
                client_contextual_info: qa(m),
                ...T.current
            }
        })
    };
    return s.jsx(Ai, { ...e,
        setPreferredFeedback: _,
        leftVariantId: b,
        rightVariantId: f,
        leftTurn: M,
        rightTurn: S,
        hasActiveRequest: c,
        originalTurn: y,
        visibilityStateRef: T
    })
}

function pf(e) {
    if (!e.length) return !1;
    const t = e.filter(n => n.type === Ca.Text || n.type === Ca.MultiText).filter(n => n.message.message.status !== "finished_successfully" && n.message.message.metadata ? .snorkle_status !== void 0);
    return t.length > 0 && t.every(n => {
        const a = n.message.message.content;
        return a ? .content_type === bo.Text && a.parts.join("") === ""
    })
}

function Ai({
    setPreferredFeedback: e,
    leftVariantId: t,
    rightVariantId: n,
    leftTurn: a,
    rightTurn: o,
    hasActiveRequest: i,
    originalTurn: r,
    visibilityStateRef: l,
    ...c
}) {
    const {
        defaultParagenLabel: m,
        shouldShowParagenLabels: d = !1
    } = No(), h = a && $a(a) || m, g = o && $a(o) || m, p = u.useMemo(() => a ? .messages ? ? [], [a ? .messages]), b = u.useMemo(() => o ? .messages ? ? [], [o ? .messages]), {
        avatarClassName: f,
        firstVisibleTokenTimestampsRef: v
    } = c, x = u.useMemo(() => Ds(p), [p]), M = u.useMemo(() => Ds(b), [b]), S = To(), [y, w] = u.useMemo(() => [x, M].map(W => pf(W)), [x, M]), N = ut(a ? Rs.getRequestIdFromConversationTurn(a) : "") || y, E = ut(o ? Rs.getRequestIdFromConversationTurn(o) : "") || w, T = a ? .role === Ce.User, _ = o ? .role === Ce.User, A = u.useRef(null), F = u.useRef(null), L = u.useRef(null), R = c.stubSideBySideFeedback || y, I = c.stubSideBySideFeedback || w;
    !R && v.current.left == null && (v.current.left = Date.now()), !I && v.current.right == null && (v.current.right = Date.now()), u.useEffect(() => {
        if (A.current && F.current && L.current) {
            const W = Array(11).fill(0).map(($, Y) => Y / 10),
                Z = new IntersectionObserver($ => $.forEach(Y => {
                    Y.target === F.current ? (l.current.left_visibility_initial == null && (l.current.left_visibility_initial = Y.intersectionRatio), l.current.left_visibility_max = Math.max(l.current.left_visibility_max ? ? 0, Y.intersectionRatio)) : Y.target === L.current && (l.current.right_visibility_initial == null && (l.current.right_visibility_initial = Y.intersectionRatio), l.current.right_visibility_max = Math.max(l.current.right_visibility_max ? ? 0, Y.intersectionRatio))
                }), {
                    root: A.current,
                    threshold: W
                });
            return Z.observe(F.current), Z.observe(L.current), () => Z.disconnect()
        }
    }, [l]);
    const {
        data: U
    } = Mo(void 0, !1, S), C = na(), B = s.jsx("div", {
        className: "text-pretty px-6 pb-5 pt-1 text-center text-sm text-token-text-secondary",
        children: s.jsx(O, {
            id: "TK934w",
            defaultMessage: "Which response do you prefer? Responses may take a moment to load."
        })
    }), k = Ze();
    return s.jsxs("div", {
        className: "relative flex flex-col",
        children: [s.jsxs("div", {
            className: P("sticky z-[1] text-pretty bg-token-main-surface-primary px-6 text-center text-lg", k && "top-[var(--thread-leading-height)] pt-3", !k && "top-[-1px]", C && !k ? "md:top-header-height" : k ? "" : "md:static"),
            "data-testid": "paragen-feedback-title",
            children: [s.jsx(O, {
                id: "JgCHDY",
                defaultMessage: "You’re giving feedback on a new version of ChatGPT."
            }), C ? B : null]
        }), C ? null : B, s.jsx("div", {
            className: "relative -mb-2 snap-x snap-mandatory overflow-x-auto px-3 pb-4 md:px-5 lg:px-10",
            ref: A,
            children: s.jsx("div", {
                className: P(!k && "min-w-fit"),
                children: s.jsxs("div", {
                    className: P("mx-auto flex max-w-6xl items-start", C && !k && "divide-x divide-token-border-medium dark:divide-token-border-heavy", !C && !k && "gap-4 sm:gap-6", C && k && "divide-x divide-token-border-medium dark:divide-token-border-heavy", k && !C && "gap-4 sm:gap-6"),
                    children: [s.jsxs(Ka, {
                        horizontalScrollContainerRef: A,
                        rootElementRef: F,
                        onClick: () => {
                            e(t)
                        },
                        hasActiveRequest: i,
                        isWaitingOnFirstUserVisibleToken: R,
                        children: [s.jsxs(Qa, {
                            children: [s.jsx(Sn, {
                                messages: p,
                                isUserTurn: T,
                                avatarClassName: f
                            }), s.jsx(Xa, {
                                children: d ? s.jsx("span", {
                                    className: "font-bold text-token-text-primary",
                                    children: h
                                }) : s.jsx(O, { ...Ja.responseNumber,
                                    values: {
                                        responseIndex: 1
                                    }
                                })
                            })]
                        }), C && R ? s.jsx(Ya, {}) : s.jsxs(s.Fragment, {
                            children: [U != null && !T && s.jsx(Wa, {
                                clientThreadId: c.clientThreadId,
                                messages: p,
                                isParagen: !0
                            }), s.jsx(bn, { ...c,
                                groupedMessagesToRender: x,
                                allGroupedMessages: x,
                                isEditing: !1,
                                isUserTurn: T,
                                isCompletionRequestInProgress: N,
                                hasActiveRequest: i,
                                handleEnterEdit: _t,
                                handleExitEdit: _t,
                                shouldGrowContainer: !1
                            }), s.jsx(Za, {
                                clientThreadId: c.clientThreadId,
                                conversationTurnMountTime: c.conversationTurnMountTime,
                                turn: a,
                                originalTurn: r
                            })]
                        })]
                    }), s.jsxs(Ka, {
                        horizontalScrollContainerRef: A,
                        rootElementRef: L,
                        onClick: () => {
                            e(n)
                        },
                        hasActiveRequest: i,
                        isWaitingOnFirstUserVisibleToken: I,
                        children: [s.jsxs(Qa, {
                            children: [s.jsx(Sn, {
                                messages: b,
                                isUserTurn: _,
                                avatarClassName: f
                            }), s.jsx(Xa, {
                                children: d ? s.jsx("span", {
                                    className: "font-bold text-token-text-primary",
                                    children: g
                                }) : s.jsx(O, { ...Ja.responseNumber,
                                    values: {
                                        responseIndex: 2
                                    }
                                })
                            })]
                        }), C && I ? s.jsx(Ya, {}) : s.jsxs(s.Fragment, {
                            children: [U != null && !_ && s.jsx(Wa, {
                                clientThreadId: c.clientThreadId,
                                messages: b,
                                isParagen: !0
                            }), s.jsx(bn, { ...c,
                                groupedMessagesToRender: M,
                                allGroupedMessages: M,
                                isEditing: !1,
                                isUserTurn: _,
                                isCompletionRequestInProgress: E,
                                hasActiveRequest: i,
                                handleEnterEdit: _t,
                                handleExitEdit: _t,
                                shouldGrowContainer: !1
                            }), s.jsx(Za, {
                                clientThreadId: c.clientThreadId,
                                conversationTurnMountTime: c.conversationTurnMountTime,
                                turn: o,
                                originalTurn: r
                            })]
                        })]
                    })]
                })
            })
        })]
    })
}

function Ka({
    horizontalScrollContainerRef: e,
    rootElementRef: t,
    onClick: n,
    children: a,
    hasActiveRequest: o,
    isWaitingOnFirstUserVisibleToken: i
}) {
    const r = na(),
        l = Ze(),
        {
            scrollX: c
        } = du({
            layoutEffect: !1,
            container: e,
            target: t
        }),
        m = hu(),
        d = mu(),
        h = u.useRef(null),
        g = u.useRef(null),
        p = u.useRef(null),
        [b, f] = u.useState(!1),
        [v, x] = u.useState(!1),
        [M, S] = u.useState(!1),
        [y, w] = u.useState(0);
    u.useEffect(() => {
        if (!r) return;
        const L = new IntersectionObserver(R => {
            for (const I of R) I.target === h.current ? f(I.isIntersecting) : I.target === p.current ? S(I.isIntersecting) : I.target === g.current && x(I.isIntersecting)
        }, {
            root: m ? .current,
            rootMargin: l ? `0px 0px -${y}px 0px` : void 0
        });
        return h.current && g.current && p.current && (L.observe(h.current), L.observe(g.current), L.observe(p.current)), () => {
            L.disconnect()
        }
    }, [y, r, l, m]);
    const N = !M && (v || b),
        E = fu(c, L => N ? -1 * L : 0),
        T = ja(0);
    u.useEffect(() => {
        if (!r) return;
        const L = new ResizeObserver(R => {
            ys(R.length === 1, "entryList.length === 1");
            const I = R[0];
            ys(I.contentBoxSize.length === 1, "item.contentBoxSize.length === 1"), T.set(I.contentBoxSize[0].inlineSize)
        });
        return t.current && L.observe(t.current), () => {
            L.disconnect()
        }
    }, [r, T, t]);
    const _ = ja(0);
    u.useEffect(() => {
        if (!r) return;
        const L = new ResizeObserver(R => {
            ys(R.length === 1, "entryList.length === 1");
            const I = R[0];
            ys(I.contentBoxSize.length === 1, "item.contentBoxSize.length === 1"), _.set(I.contentBoxSize[0].blockSize + 16), w(I.contentBoxSize[0].blockSize)
        });
        return d.current && L.observe(d.current), () => {
            L.disconnect()
        }
    }, [r, _, d]);
    const A = s.jsx(It, {
            className: r ? "px-5" : "mt-4 self-start",
            onClick: n,
            "data-testid": "paragen-prefer-response-button",
            children: s.jsx(O, {
                id: "U2EAH6",
                defaultMessage: "I prefer this response"
            })
        }),
        F = i;
    return s.jsxs("div", {
        "data-paragen-root": !0,
        className: P("relative flex w-full min-w-[min(450px,80vw)] snap-center flex-col gap-1 text-left", l && r && "pl-3 pr-5 sm:w-[calc(100cqw-62px)] sm:pl-3 sm:pr-5 md:px-10", !l && r && "px-10", r ? "min-h-60 py-4" : "rounded-2xl border border-token-main-surface-tertiary bg-white p-5 dark:bg-gray-700"),
        ref: t,
        children: [s.jsx("div", {
            className: P("absolute left-0 right-0 top-48 h-px", "invisible"),
            ref: h
        }), s.jsx("div", {
            className: P("absolute bottom-0 left-0 right-0 top-48", "invisible"),
            ref: g
        }), s.jsx("div", {
            className: P("absolute bottom-0 left-0 right-0 h-px", "invisible"),
            ref: p
        }), a, r ? s.jsx("div", {
            className: "flex-1"
        }) : null, r ? s.jsx("div", {
            className: "mt-4 min-h-10",
            children: F ? null : s.jsx(ae.div, {
                style: {
                    translateX: E,
                    width: T,
                    bottom: _
                },
                animate: {
                    opacity: 100
                },
                initial: {
                    opacity: 0
                },
                transition: {
                    ease: "easeOut",
                    duration: .2,
                    delay: .5
                },
                className: P({
                    fixed: N,
                    "z-20 flex w-full justify-center": !0
                }),
                children: A
            })
        }) : o ? null : A]
    })
}

function Ya() {
    return s.jsxs("div", {
        className: "flex w-full flex-col gap-4 pb-5 pt-3",
        children: [s.jsx(it, {
            className: "h-4 w-[75%]"
        }), s.jsx(it, {
            className: "h-4 w-[50%]"
        }), s.jsx(it, {
            className: "h-4 w-[80%]"
        }), s.jsx(it, {
            className: "h-4 w-[55%]"
        }), s.jsx(it, {
            className: "h-4 w-[66%]"
        }), s.jsx(it, {
            className: "h-4 w-[64%]"
        }), s.jsx(it, {
            className: "h-4 w-[48%]"
        })]
    })
}

function na() {
    const {
        layer: e
    } = Oe("3119715334");
    return e.get("should-enable-hojicha", !1)
}
const Xa = Se.div `text-sm text-token-text-secondary font-semibold`,
    Qa = Se.div `flex gap-4 items-center mb-1`,
    it = Se.div `animate-pulse rounded-[4px] bg-token-main-surface-tertiary`;

function Za({
    clientThreadId: e,
    conversationTurnMountTime: t,
    turn: n,
    originalTurn: a
}) {
    const o = Wn();
    if (!o.showParagenMetadata || !o.showDebugConversationTurns && !o.forceParagen || n == null) return null;
    let i = n === a ? "ORIGINAL" : "NEW";
    const r = n.messages[n.messages.length - 1],
        l = r ? .message ? .metadata ? .__internal;
    if (l) {
        const {
            model_id: h,
            model_definition_slug: g,
            model_definition_virtual_model_id: p,
            alternative_model_selection_rule: b,
            augmented_paragen_prompt_group_id: f,
            augmented_paragen_prompt_id: v,
            augmented_paragen_prompt: x
        } = l;
        h && (i += `
Model ID: ${h}`), g && (i += `
Model Slug: ${g}`), p && (i += `
Virtual Model ID: ${p}`), b && (i += `
Alternative Model Rule: ${b}`), f && (i += `
Prompt Group ID: ${f}`), v && (i += `
Prompt ID: ${v}`), x && (i += `
Prompt: ${x}`)
    }
    i += `
Message ID: ${r.message.id}`;
    const m = J.getTree(e).getParentPromptNode(n.variantIds[0]),
        d = m.metadata ? .variantsInStreamInfo == null && m.message.metadata ? .paragen_variants_info != null;
    return i += `
User prompt message ID: ${m.message.id}`, i += `
Is Persisted Paragen? ${d}`, i += `
Completion Sample Finish Time: ${d?`${t} (persisted)`:Ke(n.messages)?.completionSampleFinishTime}`, s.jsx("div", {
        className: "whitespace-pre-wrap text-sm text-red-500",
        children: i
    })
}
async function _s({
    shouldUseNewParagenEndpoint: e,
    params: t
}) {
    e ? await ht.submitParagenSelectionV2(t) : await ht.submitMessageComparisonFeedback(t)
}

function xf() {
    const {
        value: e
    } = Qe("3894844102");
    return e
}
const Ja = He({
        responseNumber: {
            id: "ConversationTurnTwoUpFeedback.responseNumber",
            defaultMessage: "Response {responseIndex, number}"
        }
    }),
    eo = [1, 2, 3, 4, 10, 20, 30],
    vf = .5;

function Sf({
    clientThreadId: e,
    conversationLeafId: t
}) {
    const n = Zo(Jo.isBusinessWorkspace),
        a = u.useRef(!1),
        o = Dt(e),
        i = zs(e),
        {
            isUnauthenticated: r
        } = We(),
        l = u.useMemo(() => {
            if (!o) return -1;
            const _ = Qo(o);
            return _() > vf ? -1 : eo[Math.floor(_() * eo.length)]
        }, [o]),
        c = Pr(e, t),
        m = c[c.length - 1],
        d = u.useMemo(() => Rs.getRequestIdFromConversationTurn(m), [m]),
        h = ut(d),
        [g, p] = u.useState(null),
        [b, f] = u.useState(!1),
        [v, x] = u.useState(!1),
        [M, S] = u.useState(!1),
        y = _ => {
            const A = Ke(c) ? .messages[0] ? .message.id;
            p(_), E(A, _)
        },
        w = c.filter(_ => _.role === Ce.Assistant).length,
        N = m ? .role === Ce.Assistant,
        E = u.useMemo(() => qo((_, A) => {
            o && _ && ht.submitConversationRating({
                conversation_id: o,
                message_id: _,
                rating: A,
                shown_at_assistant_turn: l
            }), oe.logEvent(ne.conversationRatingSubmitted, {
                rating: A,
                showAtAssistantTurn: l,
                conversationId: o
            }), f(!0), setTimeout(() => {
                x(!0)
            }, 1500)
        }, 2e3), [o, l]),
        T = w !== l || h || !N || !!n || i ? .kind !== dt.PrimaryAssistant || M || r;
    return u.useEffect(() => {
        !T && !a.current && (oe.logEvent(ne.conversationRatingShown, {
            showAtAssistantTurn: l,
            conversationId: o
        }), a.current = !0)
    }, [T]), M || T ? null : s.jsxs("div", {
        className: "mx-auto",
        children: [s.jsx(is, {
            children: b && !v && s.jsx(ae.div, {
                initial: {
                    opacity: 0
                },
                animate: {
                    opacity: 1
                },
                exit: {
                    opacity: 0
                },
                transition: {
                    duration: .2
                },
                children: s.jsx(to, {
                    $padded: !0,
                    children: s.jsx("span", {
                        className: "text-sm text-token-text-tertiary",
                        children: s.jsx(O, {
                            id: "rating.thanks",
                            defaultMessage: "Thanks for your feedback!"
                        })
                    })
                })
            }, "submitted")
        }), !b && s.jsx(ae.div, {
            initial: {
                opacity: 0
            },
            animate: {
                opacity: 1
            },
            transition: {
                duration: .1
            },
            children: s.jsxs(to, {
                $padded: !1,
                children: [s.jsxs("div", {
                    className: "flex items-center justify-center gap-4 px-4 py-3 text-sm text-token-text-secondary",
                    children: [s.jsx(O, {
                        id: "rating.instructions",
                        defaultMessage: "Is this conversation helpful so far?"
                    }), s.jsxs("div", {
                        className: "flex items-center gap-5",
                        children: [s.jsx(cn, {
                            $selected: g === "thumbsUp",
                            onClick: () => y("thumbsUp"),
                            children: s.jsx(ai, {
                                className: "icon-md"
                            })
                        }), s.jsx(cn, {
                            $selected: g === "thumbsDown",
                            onClick: () => y("thumbsDown"),
                            children: s.jsx(oi, {
                                className: "icon-md"
                            })
                        })]
                    })]
                }), s.jsx("div", {
                    className: "w-px flex-1 self-stretch bg-token-main-surface-tertiary"
                }), s.jsx(cn, {
                    className: "p-3",
                    $selected: !1,
                    onClick: () => S(!0),
                    children: s.jsx(Nd, {
                        className: "icon-md text-token-text-secondary hover:text-token-text-primary"
                    })
                })]
            })
        }, "rating")]
    })
}
const cn = Se.button `
  ${e=>e.$selected?"text-token-text-primary":"text-token-text-secondary"}
  hover:text-token-text-primary
`,
    to = Se.div `inline-flex rounded-xl border border-gray-100 dark:border-gray-700
${e=>e.$padded&&"py-3 px-4"}
`,
    bf = ns(() => as(() =>
        import ("./oo6z5nmlqv9shej7.js"), __vite__mapDeps([24, 1, 2, 3, 6, 7, 25, 15])));

function yf({
    clientThreadId: e,
    conversationLeafId: t,
    canShowInlineMessageFeedback: n,
    messageForRating: a,
    allGroupedMessages: o,
    currentModelId: i
}) {
    let r = null;
    const l = Ir(e, t),
        c = Dt(e),
        m = Vn(h => h.voiceFeedbackThread),
        d = c === m;
    return l ? null : (d && c ? (At.feedbackShown.success(), r = s.jsx("div", {
        className: "text-center",
        children: s.jsx(gu, {
            serverThreadId: c
        })
    })) : a.rating && n ? r = s.jsx(bf, {
        clientThreadId: e,
        conversationMessage: a,
        allGroupedMessages: o,
        currentModelId: i
    }) : r = s.jsx("div", {
        className: "text-center",
        children: s.jsx(Sf, {
            clientThreadId: e,
            conversationLeafId: t
        })
    }), s.jsx("div", {
        className: "mt-3 w-full empty:hidden",
        children: r
    }))
}
const so = 128;

function wf(e) {
    const {
        turnIndex: t,
        conversationLeafId: n,
        isFinalTurn: a,
        clientThreadId: o,
        onChangeItemInView: i,
        onChangeRating: r,
        currentModelId: l,
        avatarClassName: c,
        showAvatar: m = !0,
        scrollToMessageId: d
    } = e, h = ze(), g = Gn(), p = !!g && Fr(g), b = Pn(), f = Zo(Jo.isBusinessWorkspace), v = En(), {
        value: x
    } = Qe("2848981774"), M = J.getServerThreadId(o), S = Mt(fn(o, t, n)), y = pu(S, t, o, n), {
        messages: w,
        variantIds: N,
        variantsInStreamInfo: E
    } = S, T = Ds(w), _ = xu();
    let A = w[w.length - 1];
    for (const H of T) {
        const xe = vu(H);
        if (xe.some(qe => _.has(qe.message.id))) {
            A = xe[xe.length - 1];
            break
        }
    }
    const F = w.slice(0, w.indexOf(A) + 1),
        L = Wo(),
        [R, I] = u.useState(!1),
        [U, C] = u.useState(!1),
        B = N.findIndex(H => F.some(xe => xe.nodeId === H)),
        k = S.role === Ce.User,
        W = ss(),
        Z = Ge(o),
        $ = os(S.gizmoId ? ? Z) ? .data,
        Y = Su(),
        fe = $ && Y.includes($.gizmo.id),
        ye = ei(l),
        ee = bu(l),
        re = Ze(),
        ie = zs(o, $ ? .gizmo.id),
        we = uo(o) === ho.STREAMING,
        ke = !1,
        {
            value: ge
        } = Bn("2291672486"),
        Ae = F.some(H => H.message.content.content_type === bo.MultimodalText),
        {
            layer: Te
        } = Oe("1547743984"),
        Fe = M && L && Te.get("show_share_button_inline", !1),
        {
            isUnauthenticated: ue
        } = We(),
        [z, D] = u.useState(!1),
        [te, X] = u.useState(!1),
        Q = S.messages.map(H => H.message.id),
        V = u.useRef(null),
        G = w[w.length - 1],
        K = G.rating,
        Me = (d ? .length ? ? 0) > 2 && d !== "finalAgentTurn" && a && x && re,
        q = () => {
            F.length === 1 && (oe.logEvent(ne.editPrompt, {
                id: F[0].message.id,
                threadId: J.getServerThreadId(o)
            }), me.logEvent("chatgpt_edit_prompt"), I(!0))
        },
        de = u.useCallback(() => {
            I(!1)
        }, []),
        le = u.useCallback(H => {
            yu(o, t, v, H)
        }, [o, t, v]),
        _e = H => {
            r({
                nodeId: G.nodeId,
                messageId: G.message.id,
                rating: H
            }), oe.logEvent(H === "thumbsDown" ? ne.messageFeedbackThumbsDownClicked : ne.messageFeedbackThumbsUpClicked, {
                id: G.message.id,
                threadId: J.getServerThreadId(o),
                model: l,
                rating: H
            }), C(!0)
        },
        [Ie] = u.useState(() => Date.now()),
        gt = u.useMemo(() => Rs.getRequestIdFromConversationTurn(S), [S]),
        Vs = mo({
            clientThreadId: o,
            conversationLeafId: n
        }),
        je = ut(gt) && !Vs,
        Je = In(),
        rs = Ds(F),
        pe = u.useRef(!1);
    u.useEffect(() => {
        if (pe.current || d === void 0 || !x || !re || !V.current) {
            d === "finalAgentTurn" && a && pe.current && J.updateScrollToMessageId(o, void 0);
            return
        }(Q.includes(d) || d === "finalAgentTurn" && a) && (pe.current = !0, requestAnimationFrame(() => {
            requestAnimationFrame(() => {
                if (V.current)
                    if (d === "finalAgentTurn" && a) V.current.scrollIntoView({
                        behavior: "instant",
                        block: "end"
                    }), J.updateScrollToMessageId(o, void 0);
                    else {
                        const H = V.current.offsetHeight;
                        let xe;
                        H > so ? xe = so - H : xe = 0, V.current.style.scrollMarginTop = `calc(${xe}px + 2px + var(--thread-leading-height))`, V.current.scrollIntoView({
                            behavior: "smooth"
                        })
                    }
            })
        }))
    }, [d, V.current]);
    const {
        showDebugConversationTurns: Lt
    } = Wn(), ls = go(o), et = $o(o), tt = wu({
        clientThreadId: o,
        conversationMode: ie
    }), Bt = mt(o), pt = u.useCallback(({
        requestedModelId: H,
        systemMessage: xe,
        juice: qe,
        extraStreamParams: vs
    }) => {
        const Xs = new Qt;
        tt({
            id: G.nodeId,
            eventMetadata: {
                eventSource: "mouse"
            },
            turnTracker: Xs,
            requestedModelId: H,
            systemMessage: xe,
            juice: qe,
            extraStreamParams: vs
        })
    }, [G, tt]), xt = ke, cs = !b && !ls && !W && !k, us = Tu(), Ve = A.message.author.role === Ce.Assistant ? A.message : null;
    Mu({
        isCompletionRequestInProgress: je,
        isUserTurn: k,
        message: Ve
    });
    const ds = Lr(o, N),
        {
            isOpen: qs
        } = _u(),
        vt = ju(ie),
        Ot = !us && !vt && cs && a && E ? .num_variants_in_stream === 2 && !G.inlineComparisonRating && !ds,
        $s = Cu(S),
        st = Ot,
        zt = Ot && !$s,
        St = !k && !b && !ls && !vt && !we && !je && !qs,
        bt = St && (!f || xt || ee || p) && !vt && !ue && !W,
        Ue = !b && !((je || we) && a) && N.length > 1 && !R && !st;
    let he = !1;
    if (k && F.length === 1) {
        const {
            shouldHideContent: H
        } = Xo(F[0]);
        H && (he = !0)
    }
    const hs = k && !vt && !b && !Ae && F.length === 1 && !he && !R && !ue,
        Ht = H => {
            i(N[H]), oe.logEvent(ne.changeNode, {
                intent: "toggle_between"
            })
        };
    if (!(S.role === Ce.Root ? !1 : S.role === Ce.System || S.role === Ce.Developer || F.every(H => H.message.metadata ? .is_visually_hidden_from_conversation) ? Lt : !0) && !st) return s.jsx("div", {
        className: P(Me ? "min-h-[calc(100cqh-var(--thread-leading-height)-var(--thread-trailing-height)-var(--previous-turn-min-height))]" : "")
    });
    const ms = F.some(({
            message: H
        }) => So.getAssetPointers(H).length > 0),
        fs = !ms && a && et && !ge ? s.jsx(Kt, {
            onClick: () => {
                me.logEvent("chatgpt_regenerate_try_again_button_clicked", l, {
                    requestedModelId: l,
                    ...Xe({
                        clientThreadId: o,
                        turnIndex: t
                    })
                });
                const H = new Qt;
                tt({
                    id: Bt,
                    eventMetadata: {
                        eventSource: "mouse"
                    },
                    turnTracker: H
                }), Es()
            },
            icon: Yn,
            label: h.formatMessage({
                id: "ConversationTurn.regenerateTooltip",
                defaultMessage: "Regenerate"
            }),
            testId: "regenerate-turn-action-button"
        }) : null,
        Ut = "h-[30px] rounded-md px-1 text-token-text-secondary hover:bg-token-main-surface-secondary",
        Ks = !ms && ge ? s.jsx(mf, {
            className: Ut,
            clientThreadId: o,
            message: G,
            onModelSelect: pt,
            onDropdownChange: D,
            canRegenerateResponse: et
        }) : null,
        Ys = !k && !he && (!a || !je) ? s.jsx(Lu, {
            onClick: le
        }) : null,
        gs = !k && (!a || !je) && (G.disclaimers ? ? []).length === 0 && G.nodeId ? s.jsx(rf, {
            conversationId: o,
            message: G,
            iconClassName: "icon-md",
            className: "gap-1.5 rounded-md p-1 text-xs text-token-text-tertiary hover:text-token-text-primary"
        }) : null,
        ps = !k && G && (!a || !je) ? s.jsx(Bu, {
            message: G,
            isFinalTurn: a,
            iconClassName: "icon-md",
            className: "gap-1.5 rounded-md p-1 text-token-text-tertiary hover:text-token-text-primary"
        }) : null,
        nt = bt && !je ? s.jsxs("div", {
            className: "flex",
            children: [K !== "thumbsDown" && s.jsx(Kt, {
                onClick: () => _e("thumbsUp"),
                disabled: K === "thumbsUp",
                icon: K === "thumbsUp" ? Pd : ai,
                label: h.formatMessage({
                    id: "ConversationTurn.goodResponseTooltip",
                    defaultMessage: "Good response"
                }),
                testId: "good-response-turn-action-button"
            }, `thumbsUp:${G.nodeId}`), K !== "thumbsUp" && s.jsx(Kt, {
                onClick: () => _e("thumbsDown"),
                disabled: K === "thumbsDown",
                icon: K === "thumbsDown" ? Id : oi,
                label: h.formatMessage({
                    id: "ConversationTurn.badResponseTooltip",
                    defaultMessage: "Bad response"
                }),
                testId: "bad-response-turn-action-button"
            }, `thumbsDown:${G.nodeId}`)]
        }) : null,
        xs = Fe && s.jsx(Kt, {
            onClick: () => {
                Is.openSharingModal(M)
            },
            label: h.formatMessage({
                id: "ConversationTurn.shareButtonTooltip",
                defaultMessage: "Share conversation"
            }),
            className: "sm:hidden",
            icon: Dd
        }),
        at = !ge && s.jsx(Zm, {
            className: Ut,
            clientThreadId: o,
            message: G,
            onModelSelect: pt,
            onDropdownChange: D
        });

    function Wt(H) {
        return re ? H : s.jsx($n, {
            clientThreadId: o,
            isStaticSharedThread: b,
            withVerticalPadding: !0,
            withHorizontalPadding: !st,
            children: H
        })
    }

    function yt(H) {
        return re ? H : s.jsx(Zt, {
            children: H
        })
    }
    return s.jsxs(s.Fragment, {
        children: [y && s.jsx(ku, {
            dateString: y
        }), s.jsxs("article", {
            className: P("w-full scroll-mb-[var(--thread-trailing-height,150px)] text-token-text-primary focus-visible:outline-2 focus-visible:outline-offset-[-4px]", Me ? "min-h-[calc(100cqh-var(--thread-leading-height)-var(--thread-trailing-height)-var(--previous-turn-min-height))]" : "", d === "finalAgentTurn" && x && re ? "opacity-0" : ""),
            ref: V,
            dir: "auto",
            "data-testid": `conversation-turn-${t}`,
            "data-scroll-anchor": a,
            onMouseEnter: () => X(!0),
            onMouseLeave: () => X(!1),
            children: [s.jsx(Au, {
                role: S.role
            }), Wt(s.jsx(s.Fragment, {
                children: st ? s.jsx(ff, {
                    isFeedbackEnabled: bt,
                    variantIds: N,
                    variantsInStreamInfo: E,
                    conversationTurnMountTime: Ie,
                    stubSideBySideFeedback: zt,
                    ...e
                }) : yt(s.jsxs(s.Fragment, {
                    children: [!k && m && s.jsx(Mf, {
                        children: s.jsx(Sn, {
                            messages: F,
                            isUserTurn: k,
                            avatarClassName: c,
                            gizmo: $
                        })
                    }), s.jsx("div", {
                        className: P("group/conversation-turn relative flex w-full min-w-0 flex-col", !k && Ru),
                        children: s.jsx("div", {
                            className: "flex-col gap-1 md:gap-3",
                            children: s.jsxs(s.Fragment, {
                                children: [!k && !b && s.jsx(Eu, {
                                    messages: F,
                                    clientThreadId: o,
                                    gizmoId: $ ? .gizmo.id
                                }), s.jsx(bn, {
                                    groupedMessagesToRender: rs,
                                    allGroupedMessages: T,
                                    ...e,
                                    isEditing: R,
                                    isUserTurn: k,
                                    isCompletionRequestInProgress: je,
                                    isFeedbackEnabled: bt,
                                    isFinalTurn: a,
                                    hasActiveRequest: Je,
                                    showEditButton: hs,
                                    handleEnterEdit: q,
                                    handleExitEdit: de
                                }), fe && s.jsx("div", {
                                    className: "mb-4",
                                    children: s.jsx(Nu, {
                                        messages: F
                                    })
                                }), ye && s.jsx("div", {
                                    className: "mb-4",
                                    children: s.jsx(Pu, {
                                        messages: F
                                    })
                                }), (St || Ue) && s.jsxs(s.Fragment, {
                                    children: [s.jsx("div", {
                                        className: P("mb-2 flex gap-3 empty:hidden", k ? "mr-1 flex-row-reverse" : "-ml-2"),
                                        children: s.jsx(Iu, {
                                            alwaysShow: a,
                                            showInline: a || Ue,
                                            isHovered: te || z,
                                            pagination: Ue && s.jsx(Du, {
                                                showInline: a || Ue,
                                                currentPage: B,
                                                onChangeIndex: Ht,
                                                length: N.length,
                                                className: P("self-center", N.length > 1 ? "visible" : "!invisible")
                                            }),
                                            actions: St && s.jsxs(s.Fragment, {
                                                children: [gs, Ys, fs, nt, ps, at, xs, Ks]
                                            })
                                        })
                                    }), St && !je ? s.jsx("div", {
                                        className: "pr-2 lg:pr-0",
                                        children: s.jsx(Fu, {
                                            message: G,
                                            isFinalTurn: a
                                        })
                                    }) : null, a && !je && s.jsx(yf, {
                                        canShowInlineMessageFeedback: U,
                                        clientThreadId: o,
                                        conversationLeafId: n,
                                        messageForRating: G,
                                        allGroupedMessages: T,
                                        currentModelId: l
                                    })]
                                })]
                            })
                        })
                    })]
                }))
            }))]
        })]
    })
}
const Tf = Dr.memo(wf),
    Mf = Se.div `flex-shrink-0 flex flex-col relative items-end`;

function _f({
    onChangeItemInView: e,
    onRequestMoreCompletions: t,
    onChangeRating: n,
    onRequestCompletion: a,
    clientThreadId: o,
    conversationLeafId: i,
    hideHeader: r
}) {
    const l = be(),
        c = Ln(),
        m = Ou(),
        [d] = zu(),
        h = Hu(),
        [g] = Uu(),
        p = zs(o),
        b = Os(),
        f = Gu(o),
        v = Br(o),
        x = l.store.useContentAreaDimensions(Nt.Header, B => B ? .height ? B.height : void 0),
        M = l.store.useIsHeaderContentAreaPopulated(),
        S = yo(o),
        {
            isArchived: y
        } = S,
        w = Wu(f.id),
        N = p ? .kind === dt.GizmoMagicCreate ? "bg-token-main-surface-primary text-token-text-primary" : w,
        E = wo(o, i),
        T = Vu(),
        [_, A] = u.useState(0),
        [F, L] = u.useState(!1);
    u.useEffect(() => {
        c && (_ === 0 ? A(E) : !F && E > _ && (L(!0), me.logEvent("chatgpt_continue_conversation_first_message_sent"), oe.logEvent(ne.continueConversationFirstMessageSent)))
    }, [E, _, F, c]), c && (me.logEvent("chatgpt_continue_conversation_page_loaded"), oe.logEvent(ne.continueConversationPageLoaded));
    const R = u.useCallback(() => {
            m({
                behavior: "smooth"
            })
        }, [m]),
        I = qu(o),
        U = T && !y,
        C = (B, k, W) => [...new Array(k - B).keys()].map(Z => {
            const $ = Z + B;
            return s.jsx(Tf, {
                isFinalTurn: W($),
                turnIndex: $,
                clientThreadId: o,
                conversationLeafId: i,
                onChangeItemInView: e,
                onChangeRating: n,
                onRequestMoreCompletions: t,
                onRequestCompletion: a,
                currentModelId: f.id,
                avatarClassName: N,
                scrollToBottom: R
            }, $)
        });
    return s.jsxs("div", {
        onCopy: I,
        className: P("flex flex-col text-sm", U && "pb-[120px]", x || U ? null : "md:pb-9"),
        style: {
            paddingBottom: U ? void 0 : x
        },
        children: [!r && b ? .data && s.jsx(wi, {
            clientThreadId: o
        }), c && s.jsxs(s.Fragment, {
            children: [s.jsx(Zt, {
                children: s.jsx("p", {
                    className: "text-xs text-gray-500",
                    children: s.jsx(O, {
                        id: "threadLayout.sharedConversationCopyDisclaimer",
                        defaultMessage: "This is a copy of a conversation between ChatGPT & Anonymous."
                    })
                })
            }), E - _ === 0 && s.jsx("div", {
                className: "text-center text-xs font-semibold text-token-text-primary",
                children: s.jsx("button", {
                    onClick: () => {
                        Is.openModal($u.ReportConversation), me.logEvent("chatgpt_conversation_share_report_content_clicked", null, {
                            location: "Static Shared Thread Page"
                        }), oe.logEvent(ne.sharedConversationReportContentClicked, {
                            location: "Dynamic Shared Thread Page"
                        })
                    },
                    children: s.jsx(O, {
                        id: "thread.reportSharedConversation",
                        defaultMessage: "Report content"
                    })
                })
            }), C(0, _, B => B === _ - 1), s.jsx(Zt, {
                children: s.jsxs("p", {
                    className: "flex items-center text-xs text-gray-500",
                    children: [s.jsx(Fd, {
                        className: "icon-xs mr-2"
                    }), s.jsx(O, {
                        id: "threadLayout.sharedConversationPrivateDisclaimer",
                        defaultMessage: "Messages beyond this point are only visible to you"
                    })]
                })
            }), C(_, E, B => B === E - 1)]
        }), !c && C(0, E, B => B === E - 1), v && d && !g && s.jsx(no, {
            className: P("translate-y-[10px] md:translate-y-[30px]"),
            onClick: () => {
                me.logEvent("chatgpt_thread_scroll_to_top"), h({
                    behavior: "smooth"
                })
            },
            children: s.jsx(Ld, {
                className: "icon-md text-token-text-primary"
            })
        }), !d && s.jsx(no, {
            className: P(x ? null : "bottom-5", U ? M ? "translate-y-[-50px]" : "translate-y-[-10px]" : ""),
            style: {
                bottom: T ? "calc(var(--composer-bar_footer-current-height) + var(--composer-bar_current-height))" : x
            },
            onClick: () => {
                me.logEvent("chatgpt_thread_scroll_to_bottom"), m({
                    behavior: "smooth"
                })
            },
            children: s.jsx(Bd, {
                className: "icon-md text-token-text-primary"
            })
        })]
    })
}
const no = Se.button `cursor-pointer absolute z-10 rounded-full bg-clip-padding border text-token-text-secondary border-token-border-light right-1/2 translate-x-1/2 bg-token-main-surface-primary w-8 h-8 flex items-center justify-center`,
    jf = 60,
    Cf = ({
        children: e,
        scrollViewClassName: t,
        scrollAnchorTopOffset: n = 0
    }) => {
        const a = u.useRef(null);
        return s.jsx("div", {
            className: "h-full",
            ref: a,
            children: s.jsx(Or, {
                children: s.jsx(Kd, {
                    className: "h-full",
                    followButtonClassName: "hidden",
                    initialScrollBehavior: "auto",
                    scrollViewClassName: t,
                    scroller: () => kf(a, n) ? 0 : 1 / 0,
                    children: e
                })
            })
        })
    },
    kf = (e, t) => {
        const n = Af(e.current);
        if (n == null) return !1;
        const a = n > t,
            o = n < t - jf;
        return !a && !o
    };

function Af(e) {
    if (!e) return null;
    const t = e.querySelector('[data-scroll-anchor="true"]');
    if (!t) return null;
    const n = t.getBoundingClientRect().top,
        a = e.getBoundingClientRect().top;
    return n - a
}
const Rf = ns(() => as(() =>
        import ("./b565qz6knniq0qla.js"), __vite__mapDeps([26, 1, 2, 3, 6, 7, 27, 28, 29, 30, 31])).then(e => e.OpenDebugSidebarButton)),
    Ef = ns(() => as(() =>
        import ("./n4doychnm4y0og7a.js"), __vite__mapDeps([32, 1, 2, 3, 6, 7, 33, 15]))),
    ao = He({
        doNotShareSensitive: {
            id: "thread.modal.onboarding.title",
            defaultMessage: "Do not share sensitive materials with this application"
        },
        somethingWentWrong: {
            id: "thread.modal.unrecoverableError.title",
            defaultMessage: "Something went wrong"
        },
        tryAgainLater: {
            id: "thread.modal.unrecoverableError.description",
            defaultMessage: "We're sorry, but something went wrong. Please try again later."
        },
        resetThread: {
            id: "thread.modal.unrecoverableError.resetThread",
            defaultMessage: "Reset thread"
        },
        sharedConversationReportConversation: {
            id: "thread.sharedConversation.report",
            defaultMessage: "Report conversation"
        },
        latencyButton: {
            id: "thread.latencyButton",
            defaultMessage: "Latency"
        },
        archivedConversationDescription: {
            id: "thread.archivedConversationDescription",
            defaultMessage: "This conversation is archived. To continue, please unarchive it first."
        },
        unarchiveButton: {
            id: "thread.unarchiveButton",
            defaultMessage: "Unarchive"
        }
    });

function Nf({
    clientThreadId: e
}) {
    const t = fo(),
        n = Dt(e),
        a = async () => {
            n && (await ht.patchConversation(n, {
                is_archived: !1
            }), t.invalidateQueries({
                queryKey: ["conversation", e]
            }), Dn.setState(o => {
                const i = o.threads[n];
                i != null && (i.initialThreadData.isArchived = !1)
            }), hd(t))
        };
    return s.jsxs("div", {
        className: "my-6 flex flex-col items-center justify-center gap-4",
        children: [s.jsx("div", {
            className: "px-3 text-center text-sm text-token-text-secondary",
            children: s.jsx(O, { ...ao.archivedConversationDescription
            })
        }), s.jsx("div", {
            children: s.jsx(It, {
                disabled: !n,
                onClick: a,
                icon: Od,
                children: s.jsx(O, { ...ao.unarchiveButton
                })
            })
        })]
    })
}
const Kf = function({
        clientThreadId: e,
        onCompletionFinished: t,
        onCreate: n,
        preRequestCompletion: a,
        hideHeader: o,
        hideMessages: i,
        hideFooter: r,
        hideToolsOverlay: l,
        messagesVerticalAlign: c = "top",
        prependThreadChildren: m,
        renderEmptyState: d,
        prefetchSearch: h
    }) {
        const g = co(),
            p = Oo(e),
            b = Fn(e),
            f = mt(e),
            x = yo(e).isArchived;
        u.useEffect(() => {
            b || (js(e) ? mn.addTiming("chatgpt.web.chatPage.renderNewConversation") : mn.addTiming("chatgpt.web.chatPage.renderExistingConversation"))
        }, [e, b]);
        const M = zr(e, f),
            S = wo(e, f),
            {
                setTargetedContent: y
            } = Uo(),
            w = g ? .includes(Hr),
            N = Ku(),
            E = S >= 2;
        zo(E);
        const T = js(e) && !E && sn(p),
            _ = js(e) && !M && (sn(p) || p ? .kind === dt.GizmoTest),
            F = Ho().id,
            L = Ur(e),
            R = L ? ? F,
            I = !!L,
            U = ei(R),
            B = Bo()[R],
            k = Yu(e, p),
            W = Lo();
        Xu(S, e, f, T), u.useEffect(() => {
            Go()
        }, []), u.useEffect(() => {
            W || y(void 0)
        }, [e, y, W, f]);
        const {
            caModal: Z,
            onRequestCompletion: $,
            onChangeItemInView: Y,
            onChangeRating: fe,
            onRequestMoreCompletions: ye
        } = Qu({
            clientThreadId: e,
            currentModelId: R,
            defaultModelId: F,
            onCompletionFinished: t,
            onThreadCreated: n,
            preRequestCompletion: a
        }), {
            isUnauthenticated: ee,
            isLoading: re
        } = We(), ie = Zu({
            clientThreadId: e,
            currentLeafId: f,
            handleRequestCompletion: $,
            prefetchSearchPromise: h
        });
        Ju({
            clientThreadId: e,
            currentModelId: R
        });
        const Pe = de => s.jsx(Cf, {
            scrollAnchorTopOffset: o ? 0 : dd,
            children: c === "bottom" ? s.jsxs("div", {
                className: "flex h-full flex-col",
                children: [s.jsx("div", {
                    className: "flex-1"
                }), de]
            }) : de
        });
        u.useEffect(() => {
            document.title = k ? ? "ChatGPT"
        }, [k]);
        const we = Ge(e),
            ke = ss(),
            ge = Gr(),
            Ae = _ && !ge && !d && !we && !U && !ke,
            Te = Ae && !re && ee,
            Fe = Ae && !re && !ee,
            ue = Cm(Te),
            z = Am(Fe),
            D = Te && ue || Fe && z,
            te = Ln(),
            X = ed(),
            {
                reset: Q,
                streamingContext: V,
                StreamingProvider: G
            } = td();
        u.useEffect(() => {
            X && (V.setOnResetContext = () => {
                Q()
            })
        }, [X, Q, V]);
        const K = u.useRef(null),
            Me = u.useRef(null),
            q = u.useMemo(() => ({
                threadContentScrollContainerElementRef: K,
                footerRootContainerElementRef: Me
            }), []);
        return s.jsx(sd, {
            clientThreadId: e,
            currentLeafId: f,
            children: s.jsxs(G, {
                value: V,
                children: [w && s.jsx(Ef, {}), s.jsx(nd, {
                    children: k != null && s.jsx("title", {
                        children: k
                    })
                }), s.jsx(Wr.Provider, {
                    value: $,
                    children: s.jsxs(ad, {
                        children: [s.jsxs(od, {
                            clientThreadId: e,
                            currentModelConfig: B,
                            className: "composer-parent flex h-full flex-col focus-visible:outline-0",
                            children: [!i && s.jsx(id, {
                                value: q,
                                children: s.jsx(Pf, {
                                    ref: K,
                                    children: !b && !ie ? _ ? d ? ? s.jsx(Km, {
                                        clientThreadId: e,
                                        currentModelId: R,
                                        isModelLoaded: I,
                                        onRequestCompletion: $,
                                        enableV2Homepage: D,
                                        v2HomepageDisclaimer: D && s.jsx(ka, {
                                            clientThreadId: e
                                        })
                                    }) : E ? Pe(s.jsxs(s.Fragment, {
                                        children: [m, s.jsx(_f, {
                                            onChangeItemInView: Y,
                                            onRequestMoreCompletions: ye,
                                            onChangeRating: fe,
                                            onRequestCompletion: $,
                                            clientThreadId: e,
                                            conversationLeafId: f,
                                            hideHeader: o
                                        }, e)]
                                    })) : null : null
                                })
                            }), s.jsx(If, {
                                ref: Me,
                                children: x ? s.jsx(Nf, {
                                    clientThreadId: e
                                }) : s.jsxs("div", {
                                    children: [!D && s.jsx(Mm, {
                                        clientThreadId: e,
                                        isNewThread: T,
                                        showPromptStarters: T || !M,
                                        currentModelId: R,
                                        onRequestCompletion: $
                                    }), !r && s.jsx("div", {
                                        className: "relative w-full px-2 py-2 text-center text-xs text-token-text-secondary empty:hidden md:px-[60px]",
                                        children: sn(p) && !D && s.jsx("div", {
                                            className: "min-h-4",
                                            children: s.jsx(ka, {
                                                clientThreadId: e
                                            })
                                        })
                                    })]
                                })
                            })]
                        }), !l && s.jsxs("div", {
                            className: "group absolute bottom-2 end-2 z-20 flex flex-col gap-1 md:flex lg:bottom-3 lg:end-3",
                            children: [N ? s.jsxs(s.Fragment, {
                                children: [s.jsx(Rf, {}), !1]
                            }) : null, s.jsx(rd, {})]
                        }), Z, s.jsx(ld, {
                            clientThreadId: e,
                            isStaticSharedThread: !1,
                            isDynamicSharedThread: te
                        }), s.jsx(cd, {}), s.jsx(ud, {
                            conversationId: e,
                            currentModelId: R,
                            isActiveWindow: !ge
                        })]
                    })
                })]
            })
        })
    },
    Pf = Se.div `grow flex-1 overflow-hidden`,
    If = Se.div `md:pt-0 dark:border-white/20 md:border-transparent md:dark:border-transparent w-full`;
export {
    Tf as C, Km as E, Rm as S, Kf as T, Cf as W, Mm as a, Gm as b, Vf as c
};
//# sourceMappingURL=f23evx1hkgbz32wj.js.map