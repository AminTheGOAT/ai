import {
    fX as s,
    fV as i,
    fy as n,
    m as r,
    fJ as m,
    fW as p
} from "./hbhpmx2ipkndwudc.js";
import {
    C as c
} from "./bl44ud6ish9i5yq6.js";
import "./mgr0w69u3c317psp.js";
import "./ab2oz9enzsoo3wow.js";
import "./dc04xqeim5g7thtb.js";
import "./nb6f1twu9li01ii9.js";
import "./m7u5z7sua6e1c9ci.js";
import "./m0s651bq7jimn9ko.js";
import "./ky07c7gm4e4zomhb.js";
import "./f23evx1hkgbz32wj.js";
import "./bv1tgraszqspgaxz.js";
import "./t7u8ciwlz2voun1n.js";
import "./hxvlxwkzr288aynn.js";
import "./n5mnsu7wpta2bimq.js";
import "./le5v2hqvx6xa2eig.js";
import "./h1burzjdko4ksky5.js";
import "./nqxrsem62j81khrd.js";
import "./ex1buqdicemvrfma.js";
const O = () => (p(), {
        prefetchSearch: null
    }),
    y = ({
        currentUrl: e,
        nextUrl: o
    }) => {
        const t = e.searchParams,
            a = o.searchParams;
        return t.get("hints") !== a.get("hints") || t.get("q") !== a.get("q")
    };

function D() {
    const e = s(),
        {
            conversationId: o
        } = i(),
        {
            prefetchSearch: t
        } = n();
    return r.jsxs(r.Fragment, {
        children: [r.jsx(c, { ...e,
            urlThreadId: o,
            prefetchSearch: t ? ? void 0
        }), r.jsx(m, {})]
    })
}
export {
    O as clientLoader, D as
    default, y as shouldRevalidate
};
//# sourceMappingURL=dw2r3xi0qm9fz68p.js.map