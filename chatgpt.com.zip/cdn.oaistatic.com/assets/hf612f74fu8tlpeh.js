import {
    r,
    m as t,
    fw as o
} from "./hbhpmx2ipkndwudc.js";
import {
    c as s
} from "./j0gezfz3nz0b5qbm.js";
import "./mgr0w69u3c317psp.js";
r.startTransition(() => {
    s.hydrateRoot(document, t.jsx(r.StrictMode, {
        children: t.jsx(o, {})
    }))
});
//# sourceMappingURL=hf612f74fu8tlpeh.js.map