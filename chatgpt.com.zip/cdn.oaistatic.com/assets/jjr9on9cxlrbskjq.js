async function n() {
    return null
}

function t() {
    return null
}
export {
    n as clientLoader, t as
    default
};
//# sourceMappingURL=jjr9on9cxlrbskjq.js.map