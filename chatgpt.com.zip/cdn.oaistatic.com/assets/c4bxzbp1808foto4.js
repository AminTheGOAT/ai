function c(a, [t, n]) {
    return Math.min(n, Math.max(t, a))
}
export {
    c
};
//# sourceMappingURL=c4bxzbp1808foto4.js.map