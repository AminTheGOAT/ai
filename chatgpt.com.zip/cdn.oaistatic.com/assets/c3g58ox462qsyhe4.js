const __vite__mapDeps = (i, m = __vite__mapDeps, d = (m.f || (m.f = ["assets/o573p3wcq0pmt3oe.js", "assets/hbhpmx2ipkndwudc.js", "assets/mgr0w69u3c317psp.js", "assets/root-ncdra6h0.css", "assets/ab2oz9enzsoo3wow.js", "assets/conversation-small-h7jqffb1.css", "assets/he19u9otijy9a4gn.js", "assets/egypasm8c9wj8lxk.js", "assets/2rmjepolt52gynnz.js", "assets/m0s651bq7jimn9ko.js", "assets/g4fz1gdjxl7wb2jm.js", "assets/le5v2hqvx6xa2eig.js", "assets/dg7eqoph1i4a4w4u.js", "assets/eomgak7isz9y8t2v.js", "assets/h4q3kerkerwi7v84.js", "assets/bv1tgraszqspgaxz.js", "assets/i4dtdajj06wlzjkc.js", "assets/fzrn137102spawew.js", "assets/ecsmtmpgv59no4oe.js", "assets/m7u5z7sua6e1c9ci.js", "assets/k2shmbmg5zt8zip0.js", "assets/jwkl1jaez91v02q9.js", "assets/m3eot9818m9ymdsx.js", "assets/gbwmreggpvokaaol.js", "assets/textdoc-sandpack-code-preview-mk0lbw6o.css", "assets/gd59jw0ra9mx55sx.js"]))) => i.map(i => d[i]);
import {
    m as x,
    bF as Ia,
    bG as Ba,
    aY as Ha,
    F as be,
    G as vt,
    bC as Va,
    aR as de,
    bD as Fa,
    df as ja,
    aD as tt,
    c as Wa,
    em as V,
    aH as Mo,
    aI as Ao,
    r as C,
    aX as Ne,
    aJ as me,
    n as ci,
    cd as za,
    b as Bn,
    gJ as qa,
    ba as Ge,
    ay as _a,
    az as $a,
    o as Hn,
    C as Ua,
    H as Ga,
    e2 as Ka,
    i1 as Ya,
    ci as Xa,
    cj as Ja,
    ck as Qa,
    y as er,
    a9 as Za,
    R as To,
    w as th,
    i2 as ir,
    t as Eo,
    al as eh,
    l as ih,
    aA as nh,
    aB as sh,
    eo as rh,
    $ as oh
} from "./hbhpmx2ipkndwudc.js";
import {
    bK as lh,
    bL as ah,
    iE as Ie,
    nw as hh,
    nr as Vn,
    aO as Do,
    dD as ch,
    dE as uh,
    nx as fh,
    iF as Pt,
    ny as dh,
    fL as kt,
    nu as mh,
    nz as Me,
    t as gh,
    nA as ph,
    nB as yh,
    nC as ft,
    nD as xh,
    mX as bh,
    jK as wh,
    nE as Oo,
    ay as Ji,
    iH as Ro,
    iI as Ae,
    fG as vh,
    mS as Ch,
    iD as Po,
    nF as Lo,
    bs as Qi,
    cW as Sh,
    ak as Rs,
    nG as kh,
    nH as No,
    nI as Io,
    b6 as Mh,
    bg as Ah,
    b7 as Th,
    bf as Eh,
    jn as Dh,
    i4 as Oh,
    bi as Rh,
    nJ as Ph,
    nK as Bo,
    nL as Lh,
    nM as Nh,
    i as Ih,
    nN as Bh,
    nO as Hh,
    nP as Vh,
    fN as Ze,
    nQ as Fh,
    nR as jh,
    fC as Wh,
    nS as zh,
    eZ as qh,
    nT as _h,
    iC as $h,
    nU as Uh,
    nV as Gh,
    nW as Kh,
    nX as Yh,
    nY as Xh,
    nZ as Jh,
    n_ as Qh,
    g as nr,
    n$ as Zh,
    o0 as tc,
    o1 as ec,
    o2 as sr,
    mr as ic,
    o3 as Ei,
    o4 as rr
} from "./ab2oz9enzsoo3wow.js";
import {
    m as U
} from "./m0s651bq7jimn9ko.js";
import {
    d as nc,
    l as sc,
    H as rc,
    g as Ho,
    Z as oc,
    O as Vo,
    N as lc,
    b as Te,
    A as ac,
    a as hc,
    c as cc,
    C as Ke,
    D as uc
} from "./g4fz1gdjxl7wb2jm.js";
import {
    c0 as fc,
    a$ as dc,
    c1 as mc,
    c2 as gc,
    c3 as pc,
    a3 as yc,
    E as xc,
    c4 as bc,
    bA as wc,
    c5 as vc,
    b6 as Cc,
    c6 as Sc,
    c7 as kc,
    c8 as Mc,
    ac as un,
    ab as Ac,
    aq as Tc,
    ag as Ec,
    bz as Dc,
    c9 as Oc,
    ca as Rc
} from "./mgr0w69u3c317psp.js";
import "./h4q3kerkerwi7v84.js";
import {
    E as Pc,
    T as Lc
} from "./bv1tgraszqspgaxz.js";
import {
    i as Nc
} from "./i4dtdajj06wlzjkc.js";
import {
    L as Ic
} from "./m7u5z7sua6e1c9ci.js";
import {
    a as Bc
} from "./dg7eqoph1i4a4w4u.js";
import {
    u as Hc
} from "./k2shmbmg5zt8zip0.js";
import {
    u as Vc
} from "./jwkl1jaez91v02q9.js";
var Fn = (n => (n.Close = "close", n.Loaded = "loaded", n.Streaming = "streaming", n.Download = "download", n))(Fn || {});
const fn = "https://persistent.oaistatic.com/canvas/nux-videos/",
    Fc = `${fn}canvas_writing.mp4`,
    jc = `${fn}canvas_coding.mp4`,
    Wc = `${fn}canvas_writing_hero.jpg`,
    zc = `${fn}canvas_coding_hero.jpg`,
    qc = ({
        onClose: n,
        title: t,
        description: e,
        asset: i,
        size: s
    }) => {
        const r = vt(),
            o = i === 0;
        return x.jsxs("div", {
            className: "flex flex-col items-center focus:outline-none",
            children: [x.jsx("div", {
                className: "relative flex w-full items-center justify-center overflow-hidden border-b border-token-border-light bg-token-main-surface-secondary text-token-text-secondary",
                style: {
                    height: s === 1 ? 252 : 218
                },
                children: x.jsx("video", {
                    muted: !0,
                    loop: !0,
                    autoPlay: !0,
                    playsInline: !0,
                    className: "h-full max-w-none",
                    poster: o ? Wc : zc,
                    src: o ? Fc : jc
                })
            }), x.jsxs("div", {
                className: "flex flex-col items-center gap-8 px-10 py-8",
                children: [x.jsxs("div", {
                    className: "flex flex-col gap-2",
                    children: [x.jsx(Va, {
                        className: "text-center text-xl font-semibold leading-6",
                        children: x.jsx(de, { ...t
                        })
                    }), x.jsx(Fa, {
                        className: "text-center text-sm text-token-text-secondary",
                        children: x.jsx(de, { ...e
                        })
                    })]
                }), x.jsx(ja.Button, {
                    onClick: n,
                    title: r.formatMessage(jn.button),
                    color: "primary"
                })]
            })]
        })
    },
    _c = ({
        textdocType: n
    }) => {
        const {
            markAsViewed: t
        } = lh(ah.hasDismissedCanvasContextualOnboarding);
        return x.jsx(Ia, {
            open: !0,
            defaultOpen: !0,
            modal: !1,
            children: x.jsx(Ba, {
                container: Ha() ? .document.body,
                children: x.jsx(U.div, {
                    initial: {
                        opacity: .75,
                        scale: .9
                    },
                    animate: {
                        opacity: 1,
                        scale: 1
                    },
                    transition: {
                        type: "spring",
                        bounce: .2,
                        duration: .56
                    },
                    className: "popover fixed bottom-4 right-4 z-50 max-w-sm overflow-hidden rounded-2xl border border-token-border-light bg-token-main-surface-primary shadow-xl",
                    children: x.jsx(qc, {
                        onClose: t,
                        asset: Ie(n) ? 1 : 0,
                        size: 0,
                        title: jn.contextualModalTitle,
                        description: jn.contextualModalDescription
                    })
                })
            })
        })
    },
    jn = be({
        blockingModalTitle: {
            id: "euF+gX",
            defaultMessage: "Create and edit on an interactive canvas"
        },
        blockingModalDescription: {
            id: "yN6g+K",
            defaultMessage: "Collaborate with ChatGPT to write and code in a dedicated space."
        },
        contextualModalTitle: {
            id: "nrR4as",
            defaultMessage: "Draft and refine on the spot"
        },
        contextualModalDescription: {
            id: "OQRMEL",
            defaultMessage: "Make it shorter. Add a dad joke. Translate to Spanish. ChatGPT can do it all right on canvas."
        },
        button: {
            id: "7bNl4/",
            defaultMessage: "Got it"
        }
    });

function $c(n, t, e) {
    const i = new Map;
    return n.forEach((s, r) => {
        const o = hh(s, t, e);
        o && i.set(r, o)
    }), i
}

function Uc(n, t) {
    const e = Yc(n);
    if (e.length === 0) return t;
    let i = t;
    return e.forEach(s => {
        i = Gc(s, i)
    }), i
}

function Gc(n, t) {
    return $c(t, {
        start: n.fromA,
        end: n.toA
    }, Kc(n))
}

function Kc(n) {
    const {
        fromA: t,
        toA: e,
        fromB: i,
        toB: s
    } = n;
    return s - i - (e - t)
}

function Yc(n) {
    const t = [],
        e = (i, s, r, o) => {
            t.push({
                fromA: i,
                toA: s,
                fromB: r,
                toB: o
            })
        };
    return n.changes.iterChangedRanges(e, !0), t
}

function Xc(n, t) {
    const e = Array.from(n.keys()),
        i = Array.from(t.keys());
    if (e.length !== i.length) return !1;
    e.sort(), i.sort();
    for (let s = 0; s < e.length; s++)
        if (e[s] !== i[s]) return !1;
    for (const s of e) {
        const r = n.get(s),
            o = t.get(s);
        if (!r || !o || r.start !== o.start || r.end !== o.end) return !1
    }
    return !0
}

function Jc(n, t) {
    return {
        "bg-yellow-100 dark:bg-yellow-400": !0,
        "bg-opacity-40 bg-yellow-400 dark:bg-yellow-400 dark:bg-opacity-50": n && !t,
        "bg-opacity-60 bg-yellow-400 dark:bg-yellow-500 dark:bg-opacity-70": t,
        "bg-yellow-100 dark:bg-yellow-400 dark:bg-opacity-30": !n && !t
    }
}
const Qc = {
    "!bg-transparent": !0
};

function Zc({
    isHovered: n,
    isFocused: t,
    isCode: e,
    diffStatus: i
}) {
    return tt(e ? nc : sc, "cursor-text group is-comment transition-colors", { ...i === Vn.REMOVED ? Qc : Jc(n, t)
    }, "group-[.is-comment]:bg-opacity-40")
}

function tu(n, t) {
    return n.map(e => {
        const i = t.get(e.id);
        return i ? { ...e,
            at: i
        } : null
    }).filter(Do)
}
var nt = (n => (n.ASK = "ask", n.CREATE_TEXTDOC = "create_textdoc", n.COMMENT = "comment", n.EDIT = "edit", n))(nt || {}),
    Wn = (n => (n.SELECTION = "selection", n.BLOCK = "block", n))(Wn || {});

function Ig(n) {
    return n ? .type === "selection"
}
const eu = Wa(() => ({
        commentingOn: null,
        hoveredCommentId: null,
        focusedCommentId: null,
        visibleBlockCommentLauncher_DEBUG_ONLY: null,
        hoveredBlockCommentLauncherPos: null
    })),
    {
        setState: Ht,
        getInitialState: iu
    } = eu,
    ge = {
        reset: () => Ht(iu()),
        startCommentingOn: n => Ht(t => ({ ...t,
            commentingOn: n
        })),
        cancelCommentingOn: () => Ht(n => ({ ...n,
            commentingOn: null
        })),
        focusComment: n => Ht(t => ({ ...t,
            focusedCommentId: n
        })),
        blurComment: () => Ht(n => ({ ...n,
            focusedCommentId: null
        })),
        mouseEnterComment: n => Ht(t => ({ ...t,
            hoveredCommentId: n
        })),
        mouseLeaveComment: () => Ht(n => ({ ...n,
            hoveredCommentId: null
        })),
        mouseEnterBlock: n => Ht(t => ({ ...t,
            hoveredBlockCommentLauncherPos: n
        })),
        mouseLeaveBlock: () => Ht(n => ({ ...n,
            hoveredBlockCommentLauncherPos: null
        })),
        setVisibleBlockComment_DEBUG_ONLY: n => Ht(t => ({ ...t,
            visibleBlockCommentLauncher_DEBUG_ONLY: n
        }))
    };
class N {
    lineAt(t) {
        if (t < 0 || t > this.length) throw new RangeError(`Invalid position ${t} in document of length ${this.length}`);
        return this.lineInner(t, !1, 1, 0)
    }
    line(t) {
        if (t < 1 || t > this.lines) throw new RangeError(`Invalid line number ${t} in ${this.lines}-line document`);
        return this.lineInner(t, !0, 1, 0)
    }
    replace(t, e, i) {
        [t, e] = Be(this, t, e);
        let s = [];
        return this.decompose(0, t, s, 2), i.length && i.decompose(0, i.length, s, 3), this.decompose(e, this.length, s, 1), Ft.from(s, this.length - (e - t) + i.length)
    }
    append(t) {
        return this.replace(this.length, this.length, t)
    }
    slice(t, e = this.length) {
        [t, e] = Be(this, t, e);
        let i = [];
        return this.decompose(t, e, i, 0), Ft.from(i, e - t)
    }
    eq(t) {
        if (t == this) return !0;
        if (t.length != this.length || t.lines != this.lines) return !1;
        let e = this.scanIdentical(t, 1),
            i = this.length - this.scanIdentical(t, -1),
            s = new si(this),
            r = new si(t);
        for (let o = e, l = e;;) {
            if (s.next(o), r.next(o), o = 0, s.lineBreak != r.lineBreak || s.done != r.done || s.value != r.value) return !1;
            if (l += s.value.length, s.done || l >= i) return !0
        }
    }
    iter(t = 1) {
        return new si(this, t)
    }
    iterRange(t, e = this.length) {
        return new Fo(this, t, e)
    }
    iterLines(t, e) {
        let i;
        if (t == null) i = this.iter();
        else {
            e == null && (e = this.lines + 1);
            let s = this.line(t).from;
            i = this.iterRange(s, Math.max(s, e == this.lines + 1 ? this.length : e <= 1 ? 0 : this.line(e - 1).to))
        }
        return new jo(i)
    }
    toString() {
        return this.sliceString(0)
    }
    toJSON() {
        let t = [];
        return this.flatten(t), t
    }
    constructor() {}
    static of (t) {
        if (t.length == 0) throw new RangeError("A document must have at least one line");
        return t.length == 1 && !t[0] ? N.empty : t.length <= 32 ? new X(t) : Ft.from(X.split(t, []))
    }
}
class X extends N {
    constructor(t, e = nu(t)) {
        super(), this.text = t, this.length = e
    }
    get lines() {
        return this.text.length
    }
    get children() {
        return null
    }
    lineInner(t, e, i, s) {
        for (let r = 0;; r++) {
            let o = this.text[r],
                l = s + o.length;
            if ((e ? i : l) >= t) return new su(s, l, i, o);
            s = l + 1, i++
        }
    }
    decompose(t, e, i, s) {
        let r = t <= 0 && e >= this.length ? this : new X(or(this.text, t, e), Math.min(e, this.length) - Math.max(0, t));
        if (s & 1) {
            let o = i.pop(),
                l = zi(r.text, o.text.slice(), 0, r.length);
            if (l.length <= 32) i.push(new X(l, o.length + r.length));
            else {
                let a = l.length >> 1;
                i.push(new X(l.slice(0, a)), new X(l.slice(a)))
            }
        } else i.push(r)
    }
    replace(t, e, i) {
        if (!(i instanceof X)) return super.replace(t, e, i);
        [t, e] = Be(this, t, e);
        let s = zi(this.text, zi(i.text, or(this.text, 0, t)), e),
            r = this.length + i.length - (e - t);
        return s.length <= 32 ? new X(s, r) : Ft.from(X.split(s, []), r)
    }
    sliceString(t, e = this.length, i = `
`) {
        [t, e] = Be(this, t, e);
        let s = "";
        for (let r = 0, o = 0; r <= e && o < this.text.length; o++) {
            let l = this.text[o],
                a = r + l.length;
            r > t && o && (s += i), t < a && e > r && (s += l.slice(Math.max(0, t - r), e - r)), r = a + 1
        }
        return s
    }
    flatten(t) {
        for (let e of this.text) t.push(e)
    }
    scanIdentical() {
        return 0
    }
    static split(t, e) {
        let i = [],
            s = -1;
        for (let r of t) i.push(r), s += r.length + 1, i.length == 32 && (e.push(new X(i, s)), i = [], s = -1);
        return s > -1 && e.push(new X(i, s)), e
    }
}
class Ft extends N {
    constructor(t, e) {
        super(), this.children = t, this.length = e, this.lines = 0;
        for (let i of t) this.lines += i.lines
    }
    lineInner(t, e, i, s) {
        for (let r = 0;; r++) {
            let o = this.children[r],
                l = s + o.length,
                a = i + o.lines - 1;
            if ((e ? a : l) >= t) return o.lineInner(t, e, i, s);
            s = l + 1, i = a + 1
        }
    }
    decompose(t, e, i, s) {
        for (let r = 0, o = 0; o <= e && r < this.children.length; r++) {
            let l = this.children[r],
                a = o + l.length;
            if (t <= a && e >= o) {
                let c = s & ((o <= t ? 1 : 0) | (a >= e ? 2 : 0));
                o >= t && a <= e && !c ? i.push(l) : l.decompose(t - o, e - o, i, c)
            }
            o = a + 1
        }
    }
    replace(t, e, i) {
        if ([t, e] = Be(this, t, e), i.lines < this.lines)
            for (let s = 0, r = 0; s < this.children.length; s++) {
                let o = this.children[s],
                    l = r + o.length;
                if (t >= r && e <= l) {
                    let a = o.replace(t - r, e - r, i),
                        c = this.lines - o.lines + a.lines;
                    if (a.lines < c >> 4 && a.lines > c >> 6) {
                        let h = this.children.slice();
                        return h[s] = a, new Ft(h, this.length - (e - t) + i.length)
                    }
                    return super.replace(r, l, a)
                }
                r = l + 1
            }
        return super.replace(t, e, i)
    }
    sliceString(t, e = this.length, i = `
`) {
        [t, e] = Be(this, t, e);
        let s = "";
        for (let r = 0, o = 0; r < this.children.length && o <= e; r++) {
            let l = this.children[r],
                a = o + l.length;
            o > t && r && (s += i), t < a && e > o && (s += l.sliceString(t - o, e - o, i)), o = a + 1
        }
        return s
    }
    flatten(t) {
        for (let e of this.children) e.flatten(t)
    }
    scanIdentical(t, e) {
        if (!(t instanceof Ft)) return 0;
        let i = 0,
            [s, r, o, l] = e > 0 ? [0, 0, this.children.length, t.children.length] : [this.children.length - 1, t.children.length - 1, -1, -1];
        for (;; s += e, r += e) {
            if (s == o || r == l) return i;
            let a = this.children[s],
                c = t.children[r];
            if (a != c) return i + a.scanIdentical(c, e);
            i += a.length + 1
        }
    }
    static from(t, e = t.reduce((i, s) => i + s.length + 1, -1)) {
        let i = 0;
        for (let d of t) i += d.lines;
        if (i < 32) {
            let d = [];
            for (let m of t) m.flatten(d);
            return new X(d, e)
        }
        let s = Math.max(32, i >> 5),
            r = s << 1,
            o = s >> 1,
            l = [],
            a = 0,
            c = -1,
            h = [];

        function u(d) {
            let m;
            if (d.lines > r && d instanceof Ft)
                for (let g of d.children) u(g);
            else d.lines > o && (a > o || !a) ? (f(), l.push(d)) : d instanceof X && a && (m = h[h.length - 1]) instanceof X && d.lines + m.lines <= 32 ? (a += d.lines, c += d.length + 1, h[h.length - 1] = new X(m.text.concat(d.text), m.length + 1 + d.length)) : (a + d.lines > s && f(), a += d.lines, c += d.length + 1, h.push(d))
        }

        function f() {
            a != 0 && (l.push(h.length == 1 ? h[0] : Ft.from(h, c)), c = -1, a = h.length = 0)
        }
        for (let d of t) u(d);
        return f(), l.length == 1 ? l[0] : new Ft(l, e)
    }
}
N.empty = new X([""], 0);

function nu(n) {
    let t = -1;
    for (let e of n) t += e.length + 1;
    return t
}

function zi(n, t, e = 0, i = 1e9) {
    for (let s = 0, r = 0, o = !0; r < n.length && s <= i; r++) {
        let l = n[r],
            a = s + l.length;
        a >= e && (a > i && (l = l.slice(0, i - s)), s < e && (l = l.slice(e - s)), o ? (t[t.length - 1] += l, o = !1) : t.push(l)), s = a + 1
    }
    return t
}

function or(n, t, e) {
    return zi(n, [""], t, e)
}
class si {
    constructor(t, e = 1) {
        this.dir = e, this.done = !1, this.lineBreak = !1, this.value = "", this.nodes = [t], this.offsets = [e > 0 ? 1 : (t instanceof X ? t.text.length : t.children.length) << 1]
    }
    nextInner(t, e) {
        for (this.done = this.lineBreak = !1;;) {
            let i = this.nodes.length - 1,
                s = this.nodes[i],
                r = this.offsets[i],
                o = r >> 1,
                l = s instanceof X ? s.text.length : s.children.length;
            if (o == (e > 0 ? l : 0)) {
                if (i == 0) return this.done = !0, this.value = "", this;
                e > 0 && this.offsets[i - 1]++, this.nodes.pop(), this.offsets.pop()
            } else if ((r & 1) == (e > 0 ? 0 : 1)) {
                if (this.offsets[i] += e, t == 0) return this.lineBreak = !0, this.value = `
`, this;
                t--
            } else if (s instanceof X) {
                let a = s.text[o + (e < 0 ? -1 : 0)];
                if (this.offsets[i] += e, a.length > Math.max(0, t)) return this.value = t == 0 ? a : e > 0 ? a.slice(t) : a.slice(0, a.length - t), this;
                t -= a.length
            } else {
                let a = s.children[o + (e < 0 ? -1 : 0)];
                t > a.length ? (t -= a.length, this.offsets[i] += e) : (e < 0 && this.offsets[i]--, this.nodes.push(a), this.offsets.push(e > 0 ? 1 : (a instanceof X ? a.text.length : a.children.length) << 1))
            }
        }
    }
    next(t = 0) {
        return t < 0 && (this.nextInner(-t, -this.dir), t = this.value.length), this.nextInner(t, this.dir)
    }
}
class Fo {
    constructor(t, e, i) {
        this.value = "", this.done = !1, this.cursor = new si(t, e > i ? -1 : 1), this.pos = e > i ? t.length : 0, this.from = Math.min(e, i), this.to = Math.max(e, i)
    }
    nextInner(t, e) {
        if (e < 0 ? this.pos <= this.from : this.pos >= this.to) return this.value = "", this.done = !0, this;
        t += Math.max(0, e < 0 ? this.pos - this.to : this.from - this.pos);
        let i = e < 0 ? this.pos - this.from : this.to - this.pos;
        t > i && (t = i), i -= t;
        let {
            value: s
        } = this.cursor.next(t);
        return this.pos += (s.length + t) * e, this.value = s.length <= i ? s : e < 0 ? s.slice(s.length - i) : s.slice(0, i), this.done = !this.value, this
    }
    next(t = 0) {
        return t < 0 ? t = Math.max(t, this.from - this.pos) : t > 0 && (t = Math.min(t, this.to - this.pos)), this.nextInner(t, this.cursor.dir)
    }
    get lineBreak() {
        return this.cursor.lineBreak && this.value != ""
    }
}
class jo {
    constructor(t) {
        this.inner = t, this.afterBreak = !0, this.value = "", this.done = !1
    }
    next(t = 0) {
        let {
            done: e,
            lineBreak: i,
            value: s
        } = this.inner.next(t);
        return e && this.afterBreak ? (this.value = "", this.afterBreak = !1) : e ? (this.done = !0, this.value = "") : i ? this.afterBreak ? this.value = "" : (this.afterBreak = !0, this.next()) : (this.value = s, this.afterBreak = !1), this
    }
    get lineBreak() {
        return !1
    }
}
typeof Symbol < "u" && (N.prototype[Symbol.iterator] = function() {
    return this.iter()
}, si.prototype[Symbol.iterator] = Fo.prototype[Symbol.iterator] = jo.prototype[Symbol.iterator] = function() {
    return this
});
class su {
    constructor(t, e, i, s) {
        this.from = t, this.to = e, this.number = i, this.text = s
    }
    get length() {
        return this.to - this.from
    }
}

function Be(n, t, e) {
    return t = Math.max(0, Math.min(n.length, t)), [t, Math.max(t, Math.min(n.length, e))]
}
let De = "lc,34,7n,7,7b,19,,,,2,,2,,,20,b,1c,l,g,,2t,7,2,6,2,2,,4,z,,u,r,2j,b,1m,9,9,,o,4,,9,,3,,5,17,3,3b,f,,w,1j,,,,4,8,4,,3,7,a,2,t,,1m,,,,2,4,8,,9,,a,2,q,,2,2,1l,,4,2,4,2,2,3,3,,u,2,3,,b,2,1l,,4,5,,2,4,,k,2,m,6,,,1m,,,2,,4,8,,7,3,a,2,u,,1n,,,,c,,9,,14,,3,,1l,3,5,3,,4,7,2,b,2,t,,1m,,2,,2,,3,,5,2,7,2,b,2,s,2,1l,2,,,2,4,8,,9,,a,2,t,,20,,4,,2,3,,,8,,29,,2,7,c,8,2q,,2,9,b,6,22,2,r,,,,,,1j,e,,5,,2,5,b,,10,9,,2u,4,,6,,2,2,2,p,2,4,3,g,4,d,,2,2,6,,f,,jj,3,qa,3,t,3,t,2,u,2,1s,2,,7,8,,2,b,9,,19,3,3b,2,y,,3a,3,4,2,9,,6,3,63,2,2,,1m,,,7,,,,,2,8,6,a,2,,1c,h,1r,4,1c,7,,,5,,14,9,c,2,w,4,2,2,,3,1k,,,2,3,,,3,1m,8,2,2,48,3,,d,,7,4,,6,,3,2,5i,1m,,5,ek,,5f,x,2da,3,3x,,2o,w,fe,6,2x,2,n9w,4,,a,w,2,28,2,7k,,3,,4,,p,2,5,,47,2,q,i,d,,12,8,p,b,1a,3,1c,,2,4,2,2,13,,1v,6,2,2,2,2,c,,8,,1b,,1f,,,3,2,2,5,2,,,16,2,8,,6m,,2,,4,,fn4,,kh,g,g,g,a6,2,gt,,6a,,45,5,1ae,3,,2,5,4,14,3,4,,4l,2,fx,4,ar,2,49,b,4w,,1i,f,1k,3,1d,4,2,2,1x,3,10,5,,8,1q,,c,2,1g,9,a,4,2,,2n,3,2,,,2,6,,4g,,3,8,l,2,1l,2,,,,,m,,e,7,3,5,5f,8,2,3,,,n,,29,,2,6,,,2,,,2,,2,6j,,2,4,6,2,,2,r,2,2d,8,2,,,2,2y,,,,2,6,,,2t,3,2,4,,5,77,9,,2,6t,,a,2,,,4,,40,4,2,2,4,,w,a,14,6,2,4,8,,9,6,2,3,1a,d,,2,ba,7,,6,,,2a,m,2,7,,2,,2,3e,6,3,,,2,,7,,,20,2,3,,,,9n,2,f0b,5,1n,7,t4,,1r,4,29,,f5k,2,43q,,,3,4,5,8,8,2,7,u,4,44,3,1iz,1j,4,1e,8,,e,,m,5,,f,11s,7,,h,2,7,,2,,5,79,7,c5,4,15s,7,31,7,240,5,gx7k,2o,3k,6o".split(",").map(n => n ? parseInt(n, 36) : 1);
for (let n = 1; n < De.length; n++) De[n] += De[n - 1];

function ru(n) {
    for (let t = 1; t < De.length; t += 2)
        if (De[t] > n) return De[t - 1] <= n;
    return !1
}

function lr(n) {
    return n >= 127462 && n <= 127487
}
const ar = 8205;

function Wt(n, t, e = !0, i = !0) {
    return (e ? Wo : ou)(n, t, i)
}

function Wo(n, t, e) {
    if (t == n.length) return t;
    t && zo(n.charCodeAt(t)) && qo(n.charCodeAt(t - 1)) && t--;
    let i = ri(n, t);
    for (t += zn(i); t < n.length;) {
        let s = ri(n, t);
        if (i == ar || s == ar || e && ru(s)) t += zn(s), i = s;
        else if (lr(s)) {
            let r = 0,
                o = t - 2;
            for (; o >= 0 && lr(ri(n, o));) r++, o -= 2;
            if (r % 2 == 0) break;
            t += 2
        } else break
    }
    return t
}

function ou(n, t, e) {
    for (; t > 0;) {
        let i = Wo(n, t - 2, e);
        if (i < t) return i;
        t--
    }
    return 0
}

function zo(n) {
    return n >= 56320 && n < 57344
}

function qo(n) {
    return n >= 55296 && n < 56320
}

function ri(n, t) {
    let e = n.charCodeAt(t);
    if (!qo(e) || t + 1 == n.length) return e;
    let i = n.charCodeAt(t + 1);
    return zo(i) ? (e - 55296 << 10) + (i - 56320) + 65536 : e
}

function Bg(n) {
    return n <= 65535 ? String.fromCharCode(n) : (n -= 65536, String.fromCharCode((n >> 10) + 55296, (n & 1023) + 56320))
}

function zn(n) {
    return n < 65536 ? 1 : 2
}
const qn = /\r\n?|\n/;
var wt = function(n) {
    return n[n.Simple = 0] = "Simple", n[n.TrackDel = 1] = "TrackDel", n[n.TrackBefore = 2] = "TrackBefore", n[n.TrackAfter = 3] = "TrackAfter", n
}(wt || (wt = {}));
class Gt {
    constructor(t) {
        this.sections = t
    }
    get length() {
        let t = 0;
        for (let e = 0; e < this.sections.length; e += 2) t += this.sections[e];
        return t
    }
    get newLength() {
        let t = 0;
        for (let e = 0; e < this.sections.length; e += 2) {
            let i = this.sections[e + 1];
            t += i < 0 ? this.sections[e] : i
        }
        return t
    }
    get empty() {
        return this.sections.length == 0 || this.sections.length == 2 && this.sections[1] < 0
    }
    iterGaps(t) {
        for (let e = 0, i = 0, s = 0; e < this.sections.length;) {
            let r = this.sections[e++],
                o = this.sections[e++];
            o < 0 ? (t(i, s, r), s += r) : s += o, i += r
        }
    }
    iterChangedRanges(t, e = !1) {
        _n(this, t, e)
    }
    get invertedDesc() {
        let t = [];
        for (let e = 0; e < this.sections.length;) {
            let i = this.sections[e++],
                s = this.sections[e++];
            s < 0 ? t.push(i, s) : t.push(s, i)
        }
        return new Gt(t)
    }
    composeDesc(t) {
        return this.empty ? t : t.empty ? this : _o(this, t)
    }
    mapDesc(t, e = !1) {
        return t.empty ? this : $n(this, t, e)
    }
    mapPos(t, e = -1, i = wt.Simple) {
        let s = 0,
            r = 0;
        for (let o = 0; o < this.sections.length;) {
            let l = this.sections[o++],
                a = this.sections[o++],
                c = s + l;
            if (a < 0) {
                if (c > t) return r + (t - s);
                r += l
            } else {
                if (i != wt.Simple && c >= t && (i == wt.TrackDel && s < t && c > t || i == wt.TrackBefore && s < t || i == wt.TrackAfter && c > t)) return null;
                if (c > t || c == t && e < 0 && !l) return t == s || e < 0 ? r : r + a;
                r += a
            }
            s = c
        }
        if (t > s) throw new RangeError(`Position ${t} is out of range for changeset of length ${s}`);
        return r
    }
    touchesRange(t, e = t) {
        for (let i = 0, s = 0; i < this.sections.length && s <= e;) {
            let r = this.sections[i++],
                o = this.sections[i++],
                l = s + r;
            if (o >= 0 && s <= e && l >= t) return s < t && l > e ? "cover" : !0;
            s = l
        }
        return !1
    }
    toString() {
        let t = "";
        for (let e = 0; e < this.sections.length;) {
            let i = this.sections[e++],
                s = this.sections[e++];
            t += (t ? " " : "") + i + (s >= 0 ? ":" + s : "")
        }
        return t
    }
    toJSON() {
        return this.sections
    }
    static fromJSON(t) {
        if (!Array.isArray(t) || t.length % 2 || t.some(e => typeof e != "number")) throw new RangeError("Invalid JSON representation of ChangeDesc");
        return new Gt(t)
    }
    static create(t) {
        return new Gt(t)
    }
}
class it extends Gt {
    constructor(t, e) {
        super(t), this.inserted = e
    }
    apply(t) {
        if (this.length != t.length) throw new RangeError("Applying change set to a document with the wrong length");
        return _n(this, (e, i, s, r, o) => t = t.replace(s, s + (i - e), o), !1), t
    }
    mapDesc(t, e = !1) {
        return $n(this, t, e, !0)
    }
    invert(t) {
        let e = this.sections.slice(),
            i = [];
        for (let s = 0, r = 0; s < e.length; s += 2) {
            let o = e[s],
                l = e[s + 1];
            if (l >= 0) {
                e[s] = l, e[s + 1] = o;
                let a = s >> 1;
                for (; i.length < a;) i.push(N.empty);
                i.push(o ? t.slice(r, r + o) : N.empty)
            }
            r += o
        }
        return new it(e, i)
    }
    compose(t) {
        return this.empty ? t : t.empty ? this : _o(this, t, !0)
    }
    map(t, e = !1) {
        return t.empty ? this : $n(this, t, e, !0)
    }
    iterChanges(t, e = !1) {
        _n(this, t, e)
    }
    get desc() {
        return Gt.create(this.sections)
    }
    filter(t) {
        let e = [],
            i = [],
            s = [],
            r = new ui(this);
        t: for (let o = 0, l = 0;;) {
            let a = o == t.length ? 1e9 : t[o++];
            for (; l < a || l == a && r.len == 0;) {
                if (r.done) break t;
                let h = Math.min(r.len, a - l);
                at(s, h, -1);
                let u = r.ins == -1 ? -1 : r.off == 0 ? r.ins : 0;
                at(e, h, u), u > 0 && ee(i, e, r.text), r.forward(h), l += h
            }
            let c = t[o++];
            for (; l < c;) {
                if (r.done) break t;
                let h = Math.min(r.len, c - l);
                at(e, h, -1), at(s, h, r.ins == -1 ? -1 : r.off == 0 ? r.ins : 0), r.forward(h), l += h
            }
        }
        return {
            changes: new it(e, i),
            filtered: Gt.create(s)
        }
    }
    toJSON() {
        let t = [];
        for (let e = 0; e < this.sections.length; e += 2) {
            let i = this.sections[e],
                s = this.sections[e + 1];
            s < 0 ? t.push(i) : s == 0 ? t.push([i]) : t.push([i].concat(this.inserted[e >> 1].toJSON()))
        }
        return t
    }
    static of (t, e, i) {
        let s = [],
            r = [],
            o = 0,
            l = null;

        function a(h = !1) {
            if (!h && !s.length) return;
            o < e && at(s, e - o, -1);
            let u = new it(s, r);
            l = l ? l.compose(u.map(l)) : u, s = [], r = [], o = 0
        }

        function c(h) {
            if (Array.isArray(h))
                for (let u of h) c(u);
            else if (h instanceof it) {
                if (h.length != e) throw new RangeError(`Mismatched change set length (got ${h.length}, expected ${e})`);
                a(), l = l ? l.compose(h.map(l)) : h
            } else {
                let {
                    from: u,
                    to: f = u,
                    insert: d
                } = h;
                if (u > f || u < 0 || f > e) throw new RangeError(`Invalid change range ${u} to ${f} (in doc of length ${e})`);
                let m = d ? typeof d == "string" ? N.of(d.split(i || qn)) : d : N.empty,
                    g = m.length;
                if (u == f && g == 0) return;
                u < o && a(), u > o && at(s, u - o, -1), at(s, f - u, g), ee(r, s, m), o = f
            }
        }
        return c(t), a(!l), l
    }
    static empty(t) {
        return new it(t ? [t, -1] : [], [])
    }
    static fromJSON(t) {
        if (!Array.isArray(t)) throw new RangeError("Invalid JSON representation of ChangeSet");
        let e = [],
            i = [];
        for (let s = 0; s < t.length; s++) {
            let r = t[s];
            if (typeof r == "number") e.push(r, -1);
            else {
                if (!Array.isArray(r) || typeof r[0] != "number" || r.some((o, l) => l && typeof o != "string")) throw new RangeError("Invalid JSON representation of ChangeSet");
                if (r.length == 1) e.push(r[0], 0);
                else {
                    for (; i.length < s;) i.push(N.empty);
                    i[s] = N.of(r.slice(1)), e.push(r[0], i[s].length)
                }
            }
        }
        return new it(e, i)
    }
    static createSet(t, e) {
        return new it(t, e)
    }
}

function at(n, t, e, i = !1) {
    if (t == 0 && e <= 0) return;
    let s = n.length - 2;
    s >= 0 && e <= 0 && e == n[s + 1] ? n[s] += t : t == 0 && n[s] == 0 ? n[s + 1] += e : i ? (n[s] += t, n[s + 1] += e) : n.push(t, e)
}

function ee(n, t, e) {
    if (e.length == 0) return;
    let i = t.length - 2 >> 1;
    if (i < n.length) n[n.length - 1] = n[n.length - 1].append(e);
    else {
        for (; n.length < i;) n.push(N.empty);
        n.push(e)
    }
}

function _n(n, t, e) {
    let i = n.inserted;
    for (let s = 0, r = 0, o = 0; o < n.sections.length;) {
        let l = n.sections[o++],
            a = n.sections[o++];
        if (a < 0) s += l, r += l;
        else {
            let c = s,
                h = r,
                u = N.empty;
            for (; c += l, h += a, a && i && (u = u.append(i[o - 2 >> 1])), !(e || o == n.sections.length || n.sections[o + 1] < 0);) l = n.sections[o++], a = n.sections[o++];
            t(s, c, r, h, u), s = c, r = h
        }
    }
}

function $n(n, t, e, i = !1) {
    let s = [],
        r = i ? [] : null,
        o = new ui(n),
        l = new ui(t);
    for (let a = -1;;)
        if (o.ins == -1 && l.ins == -1) {
            let c = Math.min(o.len, l.len);
            at(s, c, -1), o.forward(c), l.forward(c)
        } else if (l.ins >= 0 && (o.ins < 0 || a == o.i || o.off == 0 && (l.len < o.len || l.len == o.len && !e))) {
        let c = l.len;
        for (at(s, l.ins, -1); c;) {
            let h = Math.min(o.len, c);
            o.ins >= 0 && a < o.i && o.len <= h && (at(s, 0, o.ins), r && ee(r, s, o.text), a = o.i), o.forward(h), c -= h
        }
        l.next()
    } else if (o.ins >= 0) {
        let c = 0,
            h = o.len;
        for (; h;)
            if (l.ins == -1) {
                let u = Math.min(h, l.len);
                c += u, h -= u, l.forward(u)
            } else if (l.ins == 0 && l.len < h) h -= l.len, l.next();
        else break;
        at(s, c, a < o.i ? o.ins : 0), r && a < o.i && ee(r, s, o.text), a = o.i, o.forward(o.len - h)
    } else {
        if (o.done && l.done) return r ? it.createSet(s, r) : Gt.create(s);
        throw new Error("Mismatched change set lengths")
    }
}

function _o(n, t, e = !1) {
    let i = [],
        s = e ? [] : null,
        r = new ui(n),
        o = new ui(t);
    for (let l = !1;;) {
        if (r.done && o.done) return s ? it.createSet(i, s) : Gt.create(i);
        if (r.ins == 0) at(i, r.len, 0, l), r.next();
        else if (o.len == 0 && !o.done) at(i, 0, o.ins, l), s && ee(s, i, o.text), o.next();
        else {
            if (r.done || o.done) throw new Error("Mismatched change set lengths"); {
                let a = Math.min(r.len2, o.len),
                    c = i.length;
                if (r.ins == -1) {
                    let h = o.ins == -1 ? -1 : o.off ? 0 : o.ins;
                    at(i, a, h, l), s && h && ee(s, i, o.text)
                } else o.ins == -1 ? (at(i, r.off ? 0 : r.len, a, l), s && ee(s, i, r.textBit(a))) : (at(i, r.off ? 0 : r.len, o.off ? 0 : o.ins, l), s && !o.off && ee(s, i, o.text));
                l = (r.ins > a || o.ins >= 0 && o.len > a) && (l || i.length > c), r.forward2(a), o.forward(a)
            }
        }
    }
}
class ui {
    constructor(t) {
        this.set = t, this.i = 0, this.next()
    }
    next() {
        let {
            sections: t
        } = this.set;
        this.i < t.length ? (this.len = t[this.i++], this.ins = t[this.i++]) : (this.len = 0, this.ins = -2), this.off = 0
    }
    get done() {
        return this.ins == -2
    }
    get len2() {
        return this.ins < 0 ? this.len : this.ins
    }
    get text() {
        let {
            inserted: t
        } = this.set, e = this.i - 2 >> 1;
        return e >= t.length ? N.empty : t[e]
    }
    textBit(t) {
        let {
            inserted: e
        } = this.set, i = this.i - 2 >> 1;
        return i >= e.length && !t ? N.empty : e[i].slice(this.off, t == null ? void 0 : this.off + t)
    }
    forward(t) {
        t == this.len ? this.next() : (this.len -= t, this.off += t)
    }
    forward2(t) {
        this.ins == -1 ? this.forward(t) : t == this.ins ? this.next() : (this.ins -= t, this.off += t)
    }
}
class ue {
    constructor(t, e, i) {
        this.from = t, this.to = e, this.flags = i
    }
    get anchor() {
        return this.flags & 32 ? this.to : this.from
    }
    get head() {
        return this.flags & 32 ? this.from : this.to
    }
    get empty() {
        return this.from == this.to
    }
    get assoc() {
        return this.flags & 8 ? -1 : this.flags & 16 ? 1 : 0
    }
    get bidiLevel() {
        let t = this.flags & 7;
        return t == 7 ? null : t
    }
    get goalColumn() {
        let t = this.flags >> 6;
        return t == 16777215 ? void 0 : t
    }
    map(t, e = -1) {
        let i, s;
        return this.empty ? i = s = t.mapPos(this.from, e) : (i = t.mapPos(this.from, 1), s = t.mapPos(this.to, -1)), i == this.from && s == this.to ? this : new ue(i, s, this.flags)
    }
    extend(t, e = t) {
        if (t <= this.anchor && e >= this.anchor) return A.range(t, e);
        let i = Math.abs(t - this.anchor) > Math.abs(e - this.anchor) ? t : e;
        return A.range(this.anchor, i)
    }
    eq(t, e = !1) {
        return this.anchor == t.anchor && this.head == t.head && (!e || !this.empty || this.assoc == t.assoc)
    }
    toJSON() {
        return {
            anchor: this.anchor,
            head: this.head
        }
    }
    static fromJSON(t) {
        if (!t || typeof t.anchor != "number" || typeof t.head != "number") throw new RangeError("Invalid JSON representation for SelectionRange");
        return A.range(t.anchor, t.head)
    }
    static create(t, e, i) {
        return new ue(t, e, i)
    }
}
class A {
    constructor(t, e) {
        this.ranges = t, this.mainIndex = e
    }
    map(t, e = -1) {
        return t.empty ? this : A.create(this.ranges.map(i => i.map(t, e)), this.mainIndex)
    }
    eq(t, e = !1) {
        if (this.ranges.length != t.ranges.length || this.mainIndex != t.mainIndex) return !1;
        for (let i = 0; i < this.ranges.length; i++)
            if (!this.ranges[i].eq(t.ranges[i], e)) return !1;
        return !0
    }
    get main() {
        return this.ranges[this.mainIndex]
    }
    asSingle() {
        return this.ranges.length == 1 ? this : new A([this.main], 0)
    }
    addRange(t, e = !0) {
        return A.create([t].concat(this.ranges), e ? 0 : this.mainIndex + 1)
    }
    replaceRange(t, e = this.mainIndex) {
        let i = this.ranges.slice();
        return i[e] = t, A.create(i, this.mainIndex)
    }
    toJSON() {
        return {
            ranges: this.ranges.map(t => t.toJSON()),
            main: this.mainIndex
        }
    }
    static fromJSON(t) {
        if (!t || !Array.isArray(t.ranges) || typeof t.main != "number" || t.main >= t.ranges.length) throw new RangeError("Invalid JSON representation for EditorSelection");
        return new A(t.ranges.map(e => ue.fromJSON(e)), t.main)
    }
    static single(t, e = t) {
        return new A([A.range(t, e)], 0)
    }
    static create(t, e = 0) {
        if (t.length == 0) throw new RangeError("A selection needs at least one range");
        for (let i = 0, s = 0; s < t.length; s++) {
            let r = t[s];
            if (r.empty ? r.from <= i : r.from < i) return A.normalized(t.slice(), e);
            i = r.to
        }
        return new A(t, e)
    }
    static cursor(t, e = 0, i, s) {
        return ue.create(t, t, (e == 0 ? 0 : e < 0 ? 8 : 16) | (i == null ? 7 : Math.min(6, i)) | (s ? ? 16777215) << 6)
    }
    static range(t, e, i, s) {
        let r = (i ? ? 16777215) << 6 | (s == null ? 7 : Math.min(6, s));
        return e < t ? ue.create(e, t, 48 | r) : ue.create(t, e, (e > t ? 8 : 0) | r)
    }
    static normalized(t, e = 0) {
        let i = t[e];
        t.sort((s, r) => s.from - r.from), e = t.indexOf(i);
        for (let s = 1; s < t.length; s++) {
            let r = t[s],
                o = t[s - 1];
            if (r.empty ? r.from <= o.to : r.from < o.to) {
                let l = o.from,
                    a = Math.max(r.to, o.to);
                s <= e && e--, t.splice(--s, 2, r.anchor > r.head ? A.range(a, l) : A.range(l, a))
            }
        }
        return new A(t, e)
    }
}

function $o(n, t) {
    for (let e of n.ranges)
        if (e.to > t) throw new RangeError("Selection points outside of document")
}
let Ps = 0;
class E {
    constructor(t, e, i, s, r) {
        this.combine = t, this.compareInput = e, this.compare = i, this.isStatic = s, this.id = Ps++, this.default = t([]), this.extensions = typeof r == "function" ? r(this) : r
    }
    get reader() {
        return this
    }
    static define(t = {}) {
        return new E(t.combine || (e => e), t.compareInput || ((e, i) => e === i), t.compare || (t.combine ? (e, i) => e === i : Ls), !!t.static, t.enables)
    } of (t) {
        return new qi([], this, 0, t)
    }
    compute(t, e) {
        if (this.isStatic) throw new Error("Can't compute a static facet");
        return new qi(t, this, 1, e)
    }
    computeN(t, e) {
        if (this.isStatic) throw new Error("Can't compute a static facet");
        return new qi(t, this, 2, e)
    }
    from(t, e) {
        return e || (e = i => i), this.compute([t], i => e(i.field(t)))
    }
}

function Ls(n, t) {
    return n == t || n.length == t.length && n.every((e, i) => e === t[i])
}
class qi {
    constructor(t, e, i, s) {
        this.dependencies = t, this.facet = e, this.type = i, this.value = s, this.id = Ps++
    }
    dynamicSlot(t) {
        var e;
        let i = this.value,
            s = this.facet.compareInput,
            r = this.id,
            o = t[r] >> 1,
            l = this.type == 2,
            a = !1,
            c = !1,
            h = [];
        for (let u of this.dependencies) u == "doc" ? a = !0 : u == "selection" ? c = !0 : ((e = t[u.id]) !== null && e !== void 0 ? e : 1) & 1 || h.push(t[u.id]);
        return {
            create(u) {
                return u.values[o] = i(u), 1
            },
            update(u, f) {
                if (a && f.docChanged || c && (f.docChanged || f.selection) || Un(u, h)) {
                    let d = i(u);
                    if (l ? !hr(d, u.values[o], s) : !s(d, u.values[o])) return u.values[o] = d, 1
                }
                return 0
            },
            reconfigure: (u, f) => {
                let d, m = f.config.address[r];
                if (m != null) {
                    let g = tn(f, m);
                    if (this.dependencies.every(p => p instanceof E ? f.facet(p) === u.facet(p) : p instanceof Tt ? f.field(p, !1) == u.field(p, !1) : !0) || (l ? hr(d = i(u), g, s) : s(d = i(u), g))) return u.values[o] = g, 0
                } else d = i(u);
                return u.values[o] = d, 1
            }
        }
    }
}

function hr(n, t, e) {
    if (n.length != t.length) return !1;
    for (let i = 0; i < n.length; i++)
        if (!e(n[i], t[i])) return !1;
    return !0
}

function Un(n, t) {
    let e = !1;
    for (let i of t) oi(n, i) & 1 && (e = !0);
    return e
}

function lu(n, t, e) {
    let i = e.map(a => n[a.id]),
        s = e.map(a => a.type),
        r = i.filter(a => !(a & 1)),
        o = n[t.id] >> 1;

    function l(a) {
        let c = [];
        for (let h = 0; h < i.length; h++) {
            let u = tn(a, i[h]);
            if (s[h] == 2)
                for (let f of u) c.push(f);
            else c.push(u)
        }
        return t.combine(c)
    }
    return {
        create(a) {
            for (let c of i) oi(a, c);
            return a.values[o] = l(a), 1
        },
        update(a, c) {
            if (!Un(a, r)) return 0;
            let h = l(a);
            return t.compare(h, a.values[o]) ? 0 : (a.values[o] = h, 1)
        },
        reconfigure(a, c) {
            let h = Un(a, i),
                u = c.config.facets[t.id],
                f = c.facet(t);
            if (u && !h && Ls(e, u)) return a.values[o] = f, 0;
            let d = l(a);
            return t.compare(d, f) ? (a.values[o] = f, 0) : (a.values[o] = d, 1)
        }
    }
}
const cr = E.define({
    static: !0
});
class Tt {
    constructor(t, e, i, s, r) {
        this.id = t, this.createF = e, this.updateF = i, this.compareF = s, this.spec = r, this.provides = void 0
    }
    static define(t) {
        let e = new Tt(Ps++, t.create, t.update, t.compare || ((i, s) => i === s), t);
        return t.provide && (e.provides = t.provide(e)), e
    }
    create(t) {
        let e = t.facet(cr).find(i => i.field == this);
        return (e ? .create || this.createF)(t)
    }
    slot(t) {
        let e = t[this.id] >> 1;
        return {
            create: i => (i.values[e] = this.create(i), 1),
            update: (i, s) => {
                let r = i.values[e],
                    o = this.updateF(r, s);
                return this.compareF(r, o) ? 0 : (i.values[e] = o, 1)
            },
            reconfigure: (i, s) => s.config.address[this.id] != null ? (i.values[e] = s.field(this), 0) : (i.values[e] = this.create(i), 1)
        }
    }
    init(t) {
        return [this, cr.of({
            field: this,
            create: t
        })]
    }
    get extension() {
        return this
    }
}
const ce = {
    lowest: 4,
    low: 3,
    default: 2,
    high: 1,
    highest: 0
};

function Ye(n) {
    return t => new Uo(t, n)
}
const Ns = {
    highest: Ye(ce.highest),
    high: Ye(ce.high),
    default: Ye(ce.default),
    low: Ye(ce.low),
    lowest: Ye(ce.lowest)
};
class Uo {
    constructor(t, e) {
        this.inner = t, this.prec = e
    }
}
class dn { of (t) {
        return new Gn(this, t)
    }
    reconfigure(t) {
        return dn.reconfigure.of({
            compartment: this,
            extension: t
        })
    }
    get(t) {
        return t.config.compartments.get(this)
    }
}
class Gn {
    constructor(t, e) {
        this.compartment = t, this.inner = e
    }
}
class Zi {
    constructor(t, e, i, s, r, o) {
        for (this.base = t, this.compartments = e, this.dynamicSlots = i, this.address = s, this.staticValues = r, this.facets = o, this.statusTemplate = []; this.statusTemplate.length < i.length;) this.statusTemplate.push(0)
    }
    staticFacet(t) {
        let e = this.address[t.id];
        return e == null ? t.default : this.staticValues[e >> 1]
    }
    static resolve(t, e, i) {
        let s = [],
            r = Object.create(null),
            o = new Map;
        for (let f of au(t, e, o)) f instanceof Tt ? s.push(f) : (r[f.facet.id] || (r[f.facet.id] = [])).push(f);
        let l = Object.create(null),
            a = [],
            c = [];
        for (let f of s) l[f.id] = c.length << 1, c.push(d => f.slot(d));
        let h = i ? .config.facets;
        for (let f in r) {
            let d = r[f],
                m = d[0].facet,
                g = h && h[f] || [];
            if (d.every(p => p.type == 0))
                if (l[m.id] = a.length << 1 | 1, Ls(g, d)) a.push(i.facet(m));
                else {
                    let p = m.combine(d.map(y => y.value));
                    a.push(i && m.compare(p, i.facet(m)) ? i.facet(m) : p)
                }
            else {
                for (let p of d) p.type == 0 ? (l[p.id] = a.length << 1 | 1, a.push(p.value)) : (l[p.id] = c.length << 1, c.push(y => p.dynamicSlot(y)));
                l[m.id] = c.length << 1, c.push(p => lu(p, m, d))
            }
        }
        let u = c.map(f => f(l));
        return new Zi(t, o, u, l, a, r)
    }
}

function au(n, t, e) {
    let i = [
            [],
            [],
            [],
            [],
            []
        ],
        s = new Map;

    function r(o, l) {
        let a = s.get(o);
        if (a != null) {
            if (a <= l) return;
            let c = i[a].indexOf(o);
            c > -1 && i[a].splice(c, 1), o instanceof Gn && e.delete(o.compartment)
        }
        if (s.set(o, l), Array.isArray(o))
            for (let c of o) r(c, l);
        else if (o instanceof Gn) {
            if (e.has(o.compartment)) throw new RangeError("Duplicate use of compartment in extensions");
            let c = t.get(o.compartment) || o.inner;
            e.set(o.compartment, c), r(c, l)
        } else if (o instanceof Uo) r(o.inner, o.prec);
        else if (o instanceof Tt) i[l].push(o), o.provides && r(o.provides, l);
        else if (o instanceof qi) i[l].push(o), o.facet.extensions && r(o.facet.extensions, ce.default);
        else {
            let c = o.extension;
            if (!c) throw new Error(`Unrecognized extension value in extension set (${o}). This sometimes happens because multiple instances of @codemirror/state are loaded, breaking instanceof checks.`);
            r(c, l)
        }
    }
    return r(n, ce.default), i.reduce((o, l) => o.concat(l))
}

function oi(n, t) {
    if (t & 1) return 2;
    let e = t >> 1,
        i = n.status[e];
    if (i == 4) throw new Error("Cyclic dependency between fields and/or facets");
    if (i & 2) return i;
    n.status[e] = 4;
    let s = n.computeSlot(n, n.config.dynamicSlots[e]);
    return n.status[e] = 2 | s
}

function tn(n, t) {
    return t & 1 ? n.config.staticValues[t >> 1] : n.values[t >> 1]
}
const Go = E.define(),
    Kn = E.define({
        combine: n => n.some(t => t),
        static: !0
    }),
    Ko = E.define({
        combine: n => n.length ? n[0] : void 0,
        static: !0
    }),
    Yo = E.define(),
    Xo = E.define(),
    Jo = E.define(),
    Qo = E.define({
        combine: n => n.length ? n[0] : !1
    });
class ze {
    constructor(t, e) {
        this.type = t, this.value = e
    }
    static define() {
        return new hu
    }
}
class hu { of (t) {
        return new ze(this, t)
    }
}
class cu {
    constructor(t) {
        this.map = t
    } of (t) {
        return new G(this, t)
    }
}
class G {
    constructor(t, e) {
        this.type = t, this.value = e
    }
    map(t) {
        let e = this.type.map(this.value, t);
        return e === void 0 ? void 0 : e == this.value ? this : new G(this.type, e)
    }
    is(t) {
        return this.type == t
    }
    static define(t = {}) {
        return new cu(t.map || (e => e))
    }
    static mapEffects(t, e) {
        if (!t.length) return t;
        let i = [];
        for (let s of t) {
            let r = s.map(e);
            r && i.push(r)
        }
        return i
    }
}
G.reconfigure = G.define();
G.appendConfig = G.define();
class ct {
    constructor(t, e, i, s, r, o) {
        this.startState = t, this.changes = e, this.selection = i, this.effects = s, this.annotations = r, this.scrollIntoView = o, this._doc = null, this._state = null, i && $o(i, e.newLength), r.some(l => l.type == ct.time) || (this.annotations = r.concat(ct.time.of(Date.now())))
    }
    static create(t, e, i, s, r, o) {
        return new ct(t, e, i, s, r, o)
    }
    get newDoc() {
        return this._doc || (this._doc = this.changes.apply(this.startState.doc))
    }
    get newSelection() {
        return this.selection || this.startState.selection.map(this.changes)
    }
    get state() {
        return this._state || this.startState.applyTransaction(this), this._state
    }
    annotation(t) {
        for (let e of this.annotations)
            if (e.type == t) return e.value
    }
    get docChanged() {
        return !this.changes.empty
    }
    get reconfigured() {
        return this.startState.config != this.state.config
    }
    isUserEvent(t) {
        let e = this.annotation(ct.userEvent);
        return !!(e && (e == t || e.length > t.length && e.slice(0, t.length) == t && e[t.length] == "."))
    }
}
ct.time = ze.define();
ct.userEvent = ze.define();
ct.addToHistory = ze.define();
ct.remote = ze.define();

function uu(n, t) {
    let e = [];
    for (let i = 0, s = 0;;) {
        let r, o;
        if (i < n.length && (s == t.length || t[s] >= n[i])) r = n[i++], o = n[i++];
        else if (s < t.length) r = t[s++], o = t[s++];
        else return e;
        !e.length || e[e.length - 1] < r ? e.push(r, o) : e[e.length - 1] < o && (e[e.length - 1] = o)
    }
}

function Zo(n, t, e) {
    var i;
    let s, r, o;
    return e ? (s = t.changes, r = it.empty(t.changes.length), o = n.changes.compose(t.changes)) : (s = t.changes.map(n.changes), r = n.changes.mapDesc(t.changes, !0), o = n.changes.compose(s)), {
        changes: o,
        selection: t.selection ? t.selection.map(r) : (i = n.selection) === null || i === void 0 ? void 0 : i.map(s),
        effects: G.mapEffects(n.effects, s).concat(G.mapEffects(t.effects, r)),
        annotations: n.annotations.length ? n.annotations.concat(t.annotations) : t.annotations,
        scrollIntoView: n.scrollIntoView || t.scrollIntoView
    }
}

function Yn(n, t, e) {
    let i = t.selection,
        s = Oe(t.annotations);
    return t.userEvent && (s = s.concat(ct.userEvent.of(t.userEvent))), {
        changes: t.changes instanceof it ? t.changes : it.of(t.changes || [], e, n.facet(Ko)),
        selection: i && (i instanceof A ? i : A.single(i.anchor, i.head)),
        effects: Oe(t.effects),
        annotations: s,
        scrollIntoView: !!t.scrollIntoView
    }
}

function tl(n, t, e) {
    let i = Yn(n, t.length ? t[0] : {}, n.doc.length);
    t.length && t[0].filter === !1 && (e = !1);
    for (let r = 1; r < t.length; r++) {
        t[r].filter === !1 && (e = !1);
        let o = !!t[r].sequential;
        i = Zo(i, Yn(n, t[r], o ? i.changes.newLength : n.doc.length), o)
    }
    let s = ct.create(n, i.changes, i.selection, i.effects, i.annotations, i.scrollIntoView);
    return du(e ? fu(s) : s)
}

function fu(n) {
    let t = n.startState,
        e = !0;
    for (let s of t.facet(Yo)) {
        let r = s(n);
        if (r === !1) {
            e = !1;
            break
        }
        Array.isArray(r) && (e = e === !0 ? r : uu(e, r))
    }
    if (e !== !0) {
        let s, r;
        if (e === !1) r = n.changes.invertedDesc, s = it.empty(t.doc.length);
        else {
            let o = n.changes.filter(e);
            s = o.changes, r = o.filtered.mapDesc(o.changes).invertedDesc
        }
        n = ct.create(t, s, n.selection && n.selection.map(r), G.mapEffects(n.effects, r), n.annotations, n.scrollIntoView)
    }
    let i = t.facet(Xo);
    for (let s = i.length - 1; s >= 0; s--) {
        let r = i[s](n);
        r instanceof ct ? n = r : Array.isArray(r) && r.length == 1 && r[0] instanceof ct ? n = r[0] : n = tl(t, Oe(r), !1)
    }
    return n
}

function du(n) {
    let t = n.startState,
        e = t.facet(Jo),
        i = n;
    for (let s = e.length - 1; s >= 0; s--) {
        let r = e[s](n);
        r && Object.keys(r).length && (i = Zo(i, Yn(t, r, n.changes.newLength), !0))
    }
    return i == n ? n : ct.create(t, n.changes, n.selection, i.effects, i.annotations, i.scrollIntoView)
}
const mu = [];

function Oe(n) {
    return n == null ? mu : Array.isArray(n) ? n : [n]
}
var $t = function(n) {
    return n[n.Word = 0] = "Word", n[n.Space = 1] = "Space", n[n.Other = 2] = "Other", n
}($t || ($t = {}));
const gu = /[\u00df\u0587\u0590-\u05f4\u0600-\u06ff\u3040-\u309f\u30a0-\u30ff\u3400-\u4db5\u4e00-\u9fcc\uac00-\ud7af]/;
let Xn;
try {
    Xn = new RegExp("[\\p{Alphabetic}\\p{Number}_]", "u")
} catch {}

function pu(n) {
    if (Xn) return Xn.test(n);
    for (let t = 0; t < n.length; t++) {
        let e = n[t];
        if (/\w/.test(e) || e > "" && (e.toUpperCase() != e.toLowerCase() || gu.test(e))) return !0
    }
    return !1
}

function yu(n) {
    return t => {
        if (!/\S/.test(t)) return $t.Space;
        if (pu(t)) return $t.Word;
        for (let e = 0; e < n.length; e++)
            if (t.indexOf(n[e]) > -1) return $t.Word;
        return $t.Other
    }
}
class q {
    constructor(t, e, i, s, r, o) {
        this.config = t, this.doc = e, this.selection = i, this.values = s, this.status = t.statusTemplate.slice(), this.computeSlot = r, o && (o._state = this);
        for (let l = 0; l < this.config.dynamicSlots.length; l++) oi(this, l << 1);
        this.computeSlot = null
    }
    field(t, e = !0) {
        let i = this.config.address[t.id];
        if (i == null) {
            if (e) throw new RangeError("Field is not present in this state");
            return
        }
        return oi(this, i), tn(this, i)
    }
    update(...t) {
        return tl(this, t, !0)
    }
    applyTransaction(t) {
        let e = this.config,
            {
                base: i,
                compartments: s
            } = e;
        for (let l of t.effects) l.is(dn.reconfigure) ? (e && (s = new Map, e.compartments.forEach((a, c) => s.set(c, a)), e = null), s.set(l.value.compartment, l.value.extension)) : l.is(G.reconfigure) ? (e = null, i = l.value) : l.is(G.appendConfig) && (e = null, i = Oe(i).concat(l.value));
        let r;
        e ? r = t.startState.values.slice() : (e = Zi.resolve(i, s, this), r = new q(e, this.doc, this.selection, e.dynamicSlots.map(() => null), (a, c) => c.reconfigure(a, this), null).values);
        let o = t.startState.facet(Kn) ? t.newSelection : t.newSelection.asSingle();
        new q(e, t.newDoc, o, r, (l, a) => a.update(l, t), t)
    }
    replaceSelection(t) {
        return typeof t == "string" && (t = this.toText(t)), this.changeByRange(e => ({
            changes: {
                from: e.from,
                to: e.to,
                insert: t
            },
            range: A.cursor(e.from + t.length)
        }))
    }
    changeByRange(t) {
        let e = this.selection,
            i = t(e.ranges[0]),
            s = this.changes(i.changes),
            r = [i.range],
            o = Oe(i.effects);
        for (let l = 1; l < e.ranges.length; l++) {
            let a = t(e.ranges[l]),
                c = this.changes(a.changes),
                h = c.map(s);
            for (let f = 0; f < l; f++) r[f] = r[f].map(h);
            let u = s.mapDesc(c, !0);
            r.push(a.range.map(u)), s = s.compose(h), o = G.mapEffects(o, h).concat(G.mapEffects(Oe(a.effects), u))
        }
        return {
            changes: s,
            selection: A.create(r, e.mainIndex),
            effects: o
        }
    }
    changes(t = []) {
        return t instanceof it ? t : it.of(t, this.doc.length, this.facet(q.lineSeparator))
    }
    toText(t) {
        return N.of(t.split(this.facet(q.lineSeparator) || qn))
    }
    sliceDoc(t = 0, e = this.doc.length) {
        return this.doc.sliceString(t, e, this.lineBreak)
    }
    facet(t) {
        let e = this.config.address[t.id];
        return e == null ? t.default : (oi(this, e), tn(this, e))
    }
    toJSON(t) {
        let e = {
            doc: this.sliceDoc(),
            selection: this.selection.toJSON()
        };
        if (t)
            for (let i in t) {
                let s = t[i];
                s instanceof Tt && this.config.address[s.id] != null && (e[i] = s.spec.toJSON(this.field(t[i]), this))
            }
        return e
    }
    static fromJSON(t, e = {}, i) {
        if (!t || typeof t.doc != "string") throw new RangeError("Invalid JSON representation for EditorState");
        let s = [];
        if (i) {
            for (let r in i)
                if (Object.prototype.hasOwnProperty.call(t, r)) {
                    let o = i[r],
                        l = t[r];
                    s.push(o.init(a => o.spec.fromJSON(l, a)))
                }
        }
        return q.create({
            doc: t.doc,
            selection: A.fromJSON(t.selection),
            extensions: e.extensions ? s.concat([e.extensions]) : s
        })
    }
    static create(t = {}) {
        let e = Zi.resolve(t.extensions || [], new Map),
            i = t.doc instanceof N ? t.doc : N.of((t.doc || "").split(e.staticFacet(q.lineSeparator) || qn)),
            s = t.selection ? t.selection instanceof A ? t.selection : A.single(t.selection.anchor, t.selection.head) : A.single(0);
        return $o(s, i.length), e.staticFacet(Kn) || (s = s.asSingle()), new q(e, i, s, e.dynamicSlots.map(() => null), (r, o) => o.create(r), null)
    }
    get tabSize() {
        return this.facet(q.tabSize)
    }
    get lineBreak() {
        return this.facet(q.lineSeparator) || `
`
    }
    get readOnly() {
        return this.facet(Qo)
    }
    phrase(t, ...e) {
        for (let i of this.facet(q.phrases))
            if (Object.prototype.hasOwnProperty.call(i, t)) {
                t = i[t];
                break
            }
        return e.length && (t = t.replace(/\$(\$|\d*)/g, (i, s) => {
            if (s == "$") return "$";
            let r = +(s || 1);
            return !r || r > e.length ? i : e[r - 1]
        })), t
    }
    languageDataAt(t, e, i = -1) {
        let s = [];
        for (let r of this.facet(Go))
            for (let o of r(this, e, i)) Object.prototype.hasOwnProperty.call(o, t) && s.push(o[t]);
        return s
    }
    charCategorizer(t) {
        return yu(this.languageDataAt("wordChars", t).join(""))
    }
    wordAt(t) {
        let {
            text: e,
            from: i,
            length: s
        } = this.doc.lineAt(t), r = this.charCategorizer(t), o = t - i, l = t - i;
        for (; o > 0;) {
            let a = Wt(e, o, !1);
            if (r(e.slice(a, o)) != $t.Word) break;
            o = a
        }
        for (; l < s;) {
            let a = Wt(e, l);
            if (r(e.slice(l, a)) != $t.Word) break;
            l = a
        }
        return o == l ? null : A.range(o + i, l + i)
    }
}
q.allowMultipleSelections = Kn;
q.tabSize = E.define({
    combine: n => n.length ? n[0] : 4
});
q.lineSeparator = Ko;
q.readOnly = Qo;
q.phrases = E.define({
    compare(n, t) {
        let e = Object.keys(n),
            i = Object.keys(t);
        return e.length == i.length && e.every(s => n[s] == t[s])
    }
});
q.languageData = Go;
q.changeFilter = Yo;
q.transactionFilter = Xo;
q.transactionExtender = Jo;
dn.reconfigure = G.define();

function Is(n, t, e = {}) {
    let i = {};
    for (let s of n)
        for (let r of Object.keys(s)) {
            let o = s[r],
                l = i[r];
            if (l === void 0) i[r] = o;
            else if (!(l === o || o === void 0))
                if (Object.hasOwnProperty.call(e, r)) i[r] = e[r](l, o);
                else throw new Error("Config merge conflict for field " + r)
        }
    for (let s in t) i[s] === void 0 && (i[s] = t[s]);
    return i
}
class He {
    eq(t) {
        return this == t
    }
    range(t, e = t) {
        return fi.create(t, e, this)
    }
}
He.prototype.startSide = He.prototype.endSide = 0;
He.prototype.point = !1;
He.prototype.mapMode = wt.TrackDel;
class fi {
    constructor(t, e, i) {
        this.from = t, this.to = e, this.value = i
    }
    static create(t, e, i) {
        return new fi(t, e, i)
    }
}

function Jn(n, t) {
    return n.from - t.from || n.value.startSide - t.value.startSide
}
class Bs {
    constructor(t, e, i, s) {
        this.from = t, this.to = e, this.value = i, this.maxPoint = s
    }
    get length() {
        return this.to[this.to.length - 1]
    }
    findIndex(t, e, i, s = 0) {
        let r = i ? this.to : this.from;
        for (let o = s, l = r.length;;) {
            if (o == l) return o;
            let a = o + l >> 1,
                c = r[a] - t || (i ? this.value[a].endSide : this.value[a].startSide) - e;
            if (a == o) return c >= 0 ? o : l;
            c >= 0 ? l = a : o = a + 1
        }
    }
    between(t, e, i, s) {
        for (let r = this.findIndex(e, -1e9, !0), o = this.findIndex(i, 1e9, !1, r); r < o; r++)
            if (s(this.from[r] + t, this.to[r] + t, this.value[r]) === !1) return !1
    }
    map(t, e) {
        let i = [],
            s = [],
            r = [],
            o = -1,
            l = -1;
        for (let a = 0; a < this.value.length; a++) {
            let c = this.value[a],
                h = this.from[a] + t,
                u = this.to[a] + t,
                f, d;
            if (h == u) {
                let m = e.mapPos(h, c.startSide, c.mapMode);
                if (m == null || (f = d = m, c.startSide != c.endSide && (d = e.mapPos(h, c.endSide), d < f))) continue
            } else if (f = e.mapPos(h, c.startSide), d = e.mapPos(u, c.endSide), f > d || f == d && c.startSide > 0 && c.endSide <= 0) continue;
            (d - f || c.endSide - c.startSide) < 0 || (o < 0 && (o = f), c.point && (l = Math.max(l, d - f)), i.push(c), s.push(f - o), r.push(d - o))
        }
        return {
            mapped: i.length ? new Bs(s, r, i, l) : null,
            pos: o
        }
    }
}
class L {
    constructor(t, e, i, s) {
        this.chunkPos = t, this.chunk = e, this.nextLayer = i, this.maxPoint = s
    }
    static create(t, e, i, s) {
        return new L(t, e, i, s)
    }
    get length() {
        let t = this.chunk.length - 1;
        return t < 0 ? 0 : Math.max(this.chunkEnd(t), this.nextLayer.length)
    }
    get size() {
        if (this.isEmpty) return 0;
        let t = this.nextLayer.size;
        for (let e of this.chunk) t += e.value.length;
        return t
    }
    chunkEnd(t) {
        return this.chunkPos[t] + this.chunk[t].length
    }
    update(t) {
        let {
            add: e = [],
            sort: i = !1,
            filterFrom: s = 0,
            filterTo: r = this.length
        } = t, o = t.filter;
        if (e.length == 0 && !o) return this;
        if (i && (e = e.slice().sort(Jn)), this.isEmpty) return e.length ? L.of(e) : this;
        let l = new el(this, null, -1).goto(0),
            a = 0,
            c = [],
            h = new di;
        for (; l.value || a < e.length;)
            if (a < e.length && (l.from - e[a].from || l.startSide - e[a].value.startSide) >= 0) {
                let u = e[a++];
                h.addInner(u.from, u.to, u.value) || c.push(u)
            } else l.rangeIndex == 1 && l.chunkIndex < this.chunk.length && (a == e.length || this.chunkEnd(l.chunkIndex) < e[a].from) && (!o || s > this.chunkEnd(l.chunkIndex) || r < this.chunkPos[l.chunkIndex]) && h.addChunk(this.chunkPos[l.chunkIndex], this.chunk[l.chunkIndex]) ? l.nextChunk() : ((!o || s > l.to || r < l.from || o(l.from, l.to, l.value)) && (h.addInner(l.from, l.to, l.value) || c.push(fi.create(l.from, l.to, l.value))), l.next());
        return h.finishInner(this.nextLayer.isEmpty && !c.length ? L.empty : this.nextLayer.update({
            add: c,
            filter: o,
            filterFrom: s,
            filterTo: r
        }))
    }
    map(t) {
        if (t.empty || this.isEmpty) return this;
        let e = [],
            i = [],
            s = -1;
        for (let o = 0; o < this.chunk.length; o++) {
            let l = this.chunkPos[o],
                a = this.chunk[o],
                c = t.touchesRange(l, l + a.length);
            if (c === !1) s = Math.max(s, a.maxPoint), e.push(a), i.push(t.mapPos(l));
            else if (c === !0) {
                let {
                    mapped: h,
                    pos: u
                } = a.map(l, t);
                h && (s = Math.max(s, h.maxPoint), e.push(h), i.push(u))
            }
        }
        let r = this.nextLayer.map(t);
        return e.length == 0 ? r : new L(i, e, r || L.empty, s)
    }
    between(t, e, i) {
        if (!this.isEmpty) {
            for (let s = 0; s < this.chunk.length; s++) {
                let r = this.chunkPos[s],
                    o = this.chunk[s];
                if (e >= r && t <= r + o.length && o.between(r, t - r, e - r, i) === !1) return
            }
            this.nextLayer.between(t, e, i)
        }
    }
    iter(t = 0) {
        return mi.from([this]).goto(t)
    }
    get isEmpty() {
        return this.nextLayer == this
    }
    static iter(t, e = 0) {
        return mi.from(t).goto(e)
    }
    static compare(t, e, i, s, r = -1) {
        let o = t.filter(u => u.maxPoint > 0 || !u.isEmpty && u.maxPoint >= r),
            l = e.filter(u => u.maxPoint > 0 || !u.isEmpty && u.maxPoint >= r),
            a = ur(o, l, i),
            c = new Xe(o, a, r),
            h = new Xe(l, a, r);
        i.iterGaps((u, f, d) => fr(c, u, h, f, d, s)), i.empty && i.length == 0 && fr(c, 0, h, 0, 0, s)
    }
    static eq(t, e, i = 0, s) {
        s == null && (s = 999999999);
        let r = t.filter(h => !h.isEmpty && e.indexOf(h) < 0),
            o = e.filter(h => !h.isEmpty && t.indexOf(h) < 0);
        if (r.length != o.length) return !1;
        if (!r.length) return !0;
        let l = ur(r, o),
            a = new Xe(r, l, 0).goto(i),
            c = new Xe(o, l, 0).goto(i);
        for (;;) {
            if (a.to != c.to || !Qn(a.active, c.active) || a.point && (!c.point || !a.point.eq(c.point))) return !1;
            if (a.to > s) return !0;
            a.next(), c.next()
        }
    }
    static spans(t, e, i, s, r = -1) {
        let o = new Xe(t, null, r).goto(e),
            l = e,
            a = o.openStart;
        for (;;) {
            let c = Math.min(o.to, i);
            if (o.point) {
                let h = o.activeForPoint(o.to),
                    u = o.pointFrom < e ? h.length + 1 : o.point.startSide < 0 ? h.length : Math.min(h.length, a);
                s.point(l, c, o.point, h, u, o.pointRank), a = Math.min(o.openEnd(c), h.length)
            } else c > l && (s.span(l, c, o.active, a), a = o.openEnd(c));
            if (o.to > i) return a + (o.point && o.to > i ? 1 : 0);
            l = o.to, o.next()
        }
    }
    static of (t, e = !1) {
        let i = new di;
        for (let s of t instanceof fi ? [t] : e ? xu(t) : t) i.add(s.from, s.to, s.value);
        return i.finish()
    }
    static join(t) {
        if (!t.length) return L.empty;
        let e = t[t.length - 1];
        for (let i = t.length - 2; i >= 0; i--)
            for (let s = t[i]; s != L.empty; s = s.nextLayer) e = new L(s.chunkPos, s.chunk, e, Math.max(s.maxPoint, e.maxPoint));
        return e
    }
}
L.empty = new L([], [], null, -1);

function xu(n) {
    if (n.length > 1)
        for (let t = n[0], e = 1; e < n.length; e++) {
            let i = n[e];
            if (Jn(t, i) > 0) return n.slice().sort(Jn);
            t = i
        }
    return n
}
L.empty.nextLayer = L.empty;
class di {
    finishChunk(t) {
        this.chunks.push(new Bs(this.from, this.to, this.value, this.maxPoint)), this.chunkPos.push(this.chunkStart), this.chunkStart = -1, this.setMaxPoint = Math.max(this.setMaxPoint, this.maxPoint), this.maxPoint = -1, t && (this.from = [], this.to = [], this.value = [])
    }
    constructor() {
        this.chunks = [], this.chunkPos = [], this.chunkStart = -1, this.last = null, this.lastFrom = -1e9, this.lastTo = -1e9, this.from = [], this.to = [], this.value = [], this.maxPoint = -1, this.setMaxPoint = -1, this.nextLayer = null
    }
    add(t, e, i) {
        this.addInner(t, e, i) || (this.nextLayer || (this.nextLayer = new di)).add(t, e, i)
    }
    addInner(t, e, i) {
        let s = t - this.lastTo || i.startSide - this.last.endSide;
        if (s <= 0 && (t - this.lastFrom || i.startSide - this.last.startSide) < 0) throw new Error("Ranges must be added sorted by `from` position and `startSide`");
        return s < 0 ? !1 : (this.from.length == 250 && this.finishChunk(!0), this.chunkStart < 0 && (this.chunkStart = t), this.from.push(t - this.chunkStart), this.to.push(e - this.chunkStart), this.last = i, this.lastFrom = t, this.lastTo = e, this.value.push(i), i.point && (this.maxPoint = Math.max(this.maxPoint, e - t)), !0)
    }
    addChunk(t, e) {
        if ((t - this.lastTo || e.value[0].startSide - this.last.endSide) < 0) return !1;
        this.from.length && this.finishChunk(!0), this.setMaxPoint = Math.max(this.setMaxPoint, e.maxPoint), this.chunks.push(e), this.chunkPos.push(t);
        let i = e.value.length - 1;
        return this.last = e.value[i], this.lastFrom = e.from[i] + t, this.lastTo = e.to[i] + t, !0
    }
    finish() {
        return this.finishInner(L.empty)
    }
    finishInner(t) {
        if (this.from.length && this.finishChunk(!1), this.chunks.length == 0) return t;
        let e = L.create(this.chunkPos, this.chunks, this.nextLayer ? this.nextLayer.finishInner(t) : t, this.setMaxPoint);
        return this.from = null, e
    }
}

function ur(n, t, e) {
    let i = new Map;
    for (let r of n)
        for (let o = 0; o < r.chunk.length; o++) r.chunk[o].maxPoint <= 0 && i.set(r.chunk[o], r.chunkPos[o]);
    let s = new Set;
    for (let r of t)
        for (let o = 0; o < r.chunk.length; o++) {
            let l = i.get(r.chunk[o]);
            l != null && (e ? e.mapPos(l) : l) == r.chunkPos[o] && !e ? .touchesRange(l, l + r.chunk[o].length) && s.add(r.chunk[o])
        }
    return s
}
class el {
    constructor(t, e, i, s = 0) {
        this.layer = t, this.skip = e, this.minPoint = i, this.rank = s
    }
    get startSide() {
        return this.value ? this.value.startSide : 0
    }
    get endSide() {
        return this.value ? this.value.endSide : 0
    }
    goto(t, e = -1e9) {
        return this.chunkIndex = this.rangeIndex = 0, this.gotoInner(t, e, !1), this
    }
    gotoInner(t, e, i) {
        for (; this.chunkIndex < this.layer.chunk.length;) {
            let s = this.layer.chunk[this.chunkIndex];
            if (!(this.skip && this.skip.has(s) || this.layer.chunkEnd(this.chunkIndex) < t || s.maxPoint < this.minPoint)) break;
            this.chunkIndex++, i = !1
        }
        if (this.chunkIndex < this.layer.chunk.length) {
            let s = this.layer.chunk[this.chunkIndex].findIndex(t - this.layer.chunkPos[this.chunkIndex], e, !0);
            (!i || this.rangeIndex < s) && this.setRangeIndex(s)
        }
        this.next()
    }
    forward(t, e) {
        (this.to - t || this.endSide - e) < 0 && this.gotoInner(t, e, !0)
    }
    next() {
        for (;;)
            if (this.chunkIndex == this.layer.chunk.length) {
                this.from = this.to = 1e9, this.value = null;
                break
            } else {
                let t = this.layer.chunkPos[this.chunkIndex],
                    e = this.layer.chunk[this.chunkIndex],
                    i = t + e.from[this.rangeIndex];
                if (this.from = i, this.to = t + e.to[this.rangeIndex], this.value = e.value[this.rangeIndex], this.setRangeIndex(this.rangeIndex + 1), this.minPoint < 0 || this.value.point && this.to - this.from >= this.minPoint) break
            }
    }
    setRangeIndex(t) {
        if (t == this.layer.chunk[this.chunkIndex].value.length) {
            if (this.chunkIndex++, this.skip)
                for (; this.chunkIndex < this.layer.chunk.length && this.skip.has(this.layer.chunk[this.chunkIndex]);) this.chunkIndex++;
            this.rangeIndex = 0
        } else this.rangeIndex = t
    }
    nextChunk() {
        this.chunkIndex++, this.rangeIndex = 0, this.next()
    }
    compare(t) {
        return this.from - t.from || this.startSide - t.startSide || this.rank - t.rank || this.to - t.to || this.endSide - t.endSide
    }
}
class mi {
    constructor(t) {
        this.heap = t
    }
    static from(t, e = null, i = -1) {
        let s = [];
        for (let r = 0; r < t.length; r++)
            for (let o = t[r]; !o.isEmpty; o = o.nextLayer) o.maxPoint >= i && s.push(new el(o, e, i, r));
        return s.length == 1 ? s[0] : new mi(s)
    }
    get startSide() {
        return this.value ? this.value.startSide : 0
    }
    goto(t, e = -1e9) {
        for (let i of this.heap) i.goto(t, e);
        for (let i = this.heap.length >> 1; i >= 0; i--) kn(this.heap, i);
        return this.next(), this
    }
    forward(t, e) {
        for (let i of this.heap) i.forward(t, e);
        for (let i = this.heap.length >> 1; i >= 0; i--) kn(this.heap, i);
        (this.to - t || this.value.endSide - e) < 0 && this.next()
    }
    next() {
        if (this.heap.length == 0) this.from = this.to = 1e9, this.value = null, this.rank = -1;
        else {
            let t = this.heap[0];
            this.from = t.from, this.to = t.to, this.value = t.value, this.rank = t.rank, t.value && t.next(), kn(this.heap, 0)
        }
    }
}

function kn(n, t) {
    for (let e = n[t];;) {
        let i = (t << 1) + 1;
        if (i >= n.length) break;
        let s = n[i];
        if (i + 1 < n.length && s.compare(n[i + 1]) >= 0 && (s = n[i + 1], i++), e.compare(s) < 0) break;
        n[i] = e, n[t] = s, t = i
    }
}
class Xe {
    constructor(t, e, i) {
        this.minPoint = i, this.active = [], this.activeTo = [], this.activeRank = [], this.minActive = -1, this.point = null, this.pointFrom = 0, this.pointRank = 0, this.to = -1e9, this.endSide = 0, this.openStart = -1, this.cursor = mi.from(t, e, i)
    }
    goto(t, e = -1e9) {
        return this.cursor.goto(t, e), this.active.length = this.activeTo.length = this.activeRank.length = 0, this.minActive = -1, this.to = t, this.endSide = e, this.openStart = -1, this.next(), this
    }
    forward(t, e) {
        for (; this.minActive > -1 && (this.activeTo[this.minActive] - t || this.active[this.minActive].endSide - e) < 0;) this.removeActive(this.minActive);
        this.cursor.forward(t, e)
    }
    removeActive(t) {
        Di(this.active, t), Di(this.activeTo, t), Di(this.activeRank, t), this.minActive = dr(this.active, this.activeTo)
    }
    addActive(t) {
        let e = 0,
            {
                value: i,
                to: s,
                rank: r
            } = this.cursor;
        for (; e < this.activeRank.length && (r - this.activeRank[e] || s - this.activeTo[e]) > 0;) e++;
        Oi(this.active, e, i), Oi(this.activeTo, e, s), Oi(this.activeRank, e, r), t && Oi(t, e, this.cursor.from), this.minActive = dr(this.active, this.activeTo)
    }
    next() {
        let t = this.to,
            e = this.point;
        this.point = null;
        let i = this.openStart < 0 ? [] : null;
        for (;;) {
            let s = this.minActive;
            if (s > -1 && (this.activeTo[s] - this.cursor.from || this.active[s].endSide - this.cursor.startSide) < 0) {
                if (this.activeTo[s] > t) {
                    this.to = this.activeTo[s], this.endSide = this.active[s].endSide;
                    break
                }
                this.removeActive(s), i && Di(i, s)
            } else if (this.cursor.value)
                if (this.cursor.from > t) {
                    this.to = this.cursor.from, this.endSide = this.cursor.startSide;
                    break
                } else {
                    let r = this.cursor.value;
                    if (!r.point) this.addActive(i), this.cursor.next();
                    else if (e && this.cursor.to == this.to && this.cursor.from < this.cursor.to) this.cursor.next();
                    else {
                        this.point = r, this.pointFrom = this.cursor.from, this.pointRank = this.cursor.rank, this.to = this.cursor.to, this.endSide = r.endSide, this.cursor.next(), this.forward(this.to, this.endSide);
                        break
                    }
                }
            else {
                this.to = this.endSide = 1e9;
                break
            }
        }
        if (i) {
            this.openStart = 0;
            for (let s = i.length - 1; s >= 0 && i[s] < t; s--) this.openStart++
        }
    }
    activeForPoint(t) {
        if (!this.active.length) return this.active;
        let e = [];
        for (let i = this.active.length - 1; i >= 0 && !(this.activeRank[i] < this.pointRank); i--)(this.activeTo[i] > t || this.activeTo[i] == t && this.active[i].endSide >= this.point.endSide) && e.push(this.active[i]);
        return e.reverse()
    }
    openEnd(t) {
        let e = 0;
        for (let i = this.activeTo.length - 1; i >= 0 && this.activeTo[i] > t; i--) e++;
        return e
    }
}

function fr(n, t, e, i, s, r) {
    n.goto(t), e.goto(i);
    let o = i + s,
        l = i,
        a = i - t;
    for (;;) {
        let c = n.to + a - e.to || n.endSide - e.endSide,
            h = c < 0 ? n.to + a : e.to,
            u = Math.min(h, o);
        if (n.point || e.point ? n.point && e.point && (n.point == e.point || n.point.eq(e.point)) && Qn(n.activeForPoint(n.to), e.activeForPoint(e.to)) || r.comparePoint(l, u, n.point, e.point) : u > l && !Qn(n.active, e.active) && r.compareRange(l, u, n.active, e.active), h > o) break;
        l = h, c <= 0 && n.next(), c >= 0 && e.next()
    }
}

function Qn(n, t) {
    if (n.length != t.length) return !1;
    for (let e = 0; e < n.length; e++)
        if (n[e] != t[e] && !n[e].eq(t[e])) return !1;
    return !0
}

function Di(n, t) {
    for (let e = t, i = n.length - 1; e < i; e++) n[e] = n[e + 1];
    n.pop()
}

function Oi(n, t, e) {
    for (let i = n.length - 1; i >= t; i--) n[i + 1] = n[i];
    n[t] = e
}

function dr(n, t) {
    let e = -1,
        i = 1e9;
    for (let s = 0; s < t.length; s++)(t[s] - i || n[s].endSide - n[e].endSide) < 0 && (e = s, i = t[s]);
    return e
}

function bu(n, t, e = n.length) {
    let i = 0;
    for (let s = 0; s < e;) n.charCodeAt(s) == 9 ? (i += t - i % t, s++) : (i++, s = Wt(n, s));
    return i
}

function wu(n, t, e, i) {
    for (let s = 0, r = 0;;) {
        if (r >= t) return s;
        if (s == n.length) break;
        r += n.charCodeAt(s) == 9 ? e - r % e : 1, s = Wt(n, s)
    }
    return i === !0 ? -1 : n.length
}
const Zn = "ͼ",
    mr = typeof Symbol > "u" ? "__" + Zn : Symbol.for(Zn),
    ts = typeof Symbol > "u" ? "__styleSet" + Math.floor(Math.random() * 1e8) : Symbol("styleSet"),
    gr = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : {};
class Ve {
    constructor(t, e) {
        this.rules = [];
        let {
            finish: i
        } = e || {};

        function s(o) {
            return /^@/.test(o) ? [o] : o.split(/,\s*/)
        }

        function r(o, l, a, c) {
            let h = [],
                u = /^@(\w+)\b/.exec(o[0]),
                f = u && u[1] == "keyframes";
            if (u && l == null) return a.push(o[0] + ";");
            for (let d in l) {
                let m = l[d];
                if (/&/.test(d)) r(d.split(/,\s*/).map(g => o.map(p => g.replace(/&/, p))).reduce((g, p) => g.concat(p)), m, a);
                else if (m && typeof m == "object") {
                    if (!u) throw new RangeError("The value of a property (" + d + ") should be a primitive value.");
                    r(s(d), m, h, f)
                } else m != null && h.push(d.replace(/_.*/, "").replace(/[A-Z]/g, g => "-" + g.toLowerCase()) + ": " + m + ";")
            }(h.length || f) && a.push((i && !u && !c ? o.map(i) : o).join(", ") + " {" + h.join(" ") + "}")
        }
        for (let o in t) r(s(o), t[o], this.rules)
    }
    getRules() {
        return this.rules.join(`
`)
    }
    static newName() {
        let t = gr[mr] || 1;
        return gr[mr] = t + 1, Zn + t.toString(36)
    }
    static mount(t, e, i) {
        let s = t[ts],
            r = i && i.nonce;
        s ? r && s.setNonce(r) : s = new vu(t, r), s.mount(Array.isArray(e) ? e : [e], t)
    }
}
let pr = new Map;
class vu {
    constructor(t, e) {
        let i = t.ownerDocument || t,
            s = i.defaultView;
        if (!t.head && t.adoptedStyleSheets && s.CSSStyleSheet) {
            let r = pr.get(i);
            if (r) return t[ts] = r;
            this.sheet = new s.CSSStyleSheet, pr.set(i, this)
        } else this.styleTag = i.createElement("style"), e && this.styleTag.setAttribute("nonce", e);
        this.modules = [], t[ts] = this
    }
    mount(t, e) {
        let i = this.sheet,
            s = 0,
            r = 0;
        for (let o = 0; o < t.length; o++) {
            let l = t[o],
                a = this.modules.indexOf(l);
            if (a < r && a > -1 && (this.modules.splice(a, 1), r--, a = -1), a == -1) {
                if (this.modules.splice(r++, 0, l), i)
                    for (let c = 0; c < l.rules.length; c++) i.insertRule(l.rules[c], s++)
            } else {
                for (; r < a;) s += this.modules[r++].rules.length;
                s += l.rules.length, r++
            }
        }
        if (i) e.adoptedStyleSheets.indexOf(this.sheet) < 0 && (e.adoptedStyleSheets = [this.sheet, ...e.adoptedStyleSheets]);
        else {
            let o = "";
            for (let a = 0; a < this.modules.length; a++) o += this.modules[a].getRules() + `
`;
            this.styleTag.textContent = o;
            let l = e.head || e;
            this.styleTag.parentNode != l && l.insertBefore(this.styleTag, l.firstChild)
        }
    }
    setNonce(t) {
        this.styleTag && this.styleTag.getAttribute("nonce") != t && this.styleTag.setAttribute("nonce", t)
    }
}

function gi(n) {
    let t;
    return n.nodeType == 11 ? t = n.getSelection ? n : n.ownerDocument : t = n, t.getSelection()
}

function es(n, t) {
    return t ? n == t || n.contains(t.nodeType != 1 ? t.parentNode : t) : !1
}

function Cu(n) {
    let t = n.activeElement;
    for (; t && t.shadowRoot;) t = t.shadowRoot.activeElement;
    return t
}

function _i(n, t) {
    if (!t.anchorNode) return !1;
    try {
        return es(n, t.anchorNode)
    } catch {
        return !1
    }
}

function Fe(n) {
    return n.nodeType == 3 ? ye(n, 0, n.nodeValue.length).getClientRects() : n.nodeType == 1 ? n.getClientRects() : []
}

function li(n, t, e, i) {
    return e ? yr(n, t, e, i, -1) || yr(n, t, e, i, 1) : !1
}

function pe(n) {
    for (var t = 0;; t++)
        if (n = n.previousSibling, !n) return t
}

function en(n) {
    return n.nodeType == 1 && /^(DIV|P|LI|UL|OL|BLOCKQUOTE|DD|DT|H\d|SECTION|PRE)$/.test(n.nodeName)
}

function yr(n, t, e, i, s) {
    for (;;) {
        if (n == e && t == i) return !0;
        if (t == (s < 0 ? 0 : Yt(n))) {
            if (n.nodeName == "DIV") return !1;
            let r = n.parentNode;
            if (!r || r.nodeType != 1) return !1;
            t = pe(n) + (s < 0 ? 0 : 1), n = r
        } else if (n.nodeType == 1) {
            if (n = n.childNodes[t + (s < 0 ? -1 : 0)], n.nodeType == 1 && n.contentEditable == "false") return !1;
            t = s < 0 ? Yt(n) : 0
        } else return !1
    }
}

function Yt(n) {
    return n.nodeType == 3 ? n.nodeValue.length : n.childNodes.length
}

function mn(n, t) {
    let e = t ? n.left : n.right;
    return {
        left: e,
        right: e,
        top: n.top,
        bottom: n.bottom
    }
}

function Su(n) {
    let t = n.visualViewport;
    return t ? {
        left: 0,
        right: t.width,
        top: 0,
        bottom: t.height
    } : {
        left: 0,
        right: n.innerWidth,
        top: 0,
        bottom: n.innerHeight
    }
}

function il(n, t) {
    let e = t.width / n.offsetWidth,
        i = t.height / n.offsetHeight;
    return (e > .995 && e < 1.005 || !isFinite(e) || Math.abs(t.width - n.offsetWidth) < 1) && (e = 1), (i > .995 && i < 1.005 || !isFinite(i) || Math.abs(t.height - n.offsetHeight) < 1) && (i = 1), {
        scaleX: e,
        scaleY: i
    }
}

function ku(n, t, e, i, s, r, o, l) {
    let a = n.ownerDocument,
        c = a.defaultView || window;
    for (let h = n, u = !1; h && !u;)
        if (h.nodeType == 1) {
            let f, d = h == a.body,
                m = 1,
                g = 1;
            if (d) f = Su(c);
            else {
                if (/^(fixed|sticky)$/.test(getComputedStyle(h).position) && (u = !0), h.scrollHeight <= h.clientHeight && h.scrollWidth <= h.clientWidth) {
                    h = h.assignedSlot || h.parentNode;
                    continue
                }
                let b = h.getBoundingClientRect();
                ({
                    scaleX: m,
                    scaleY: g
                } = il(h, b)), f = {
                    left: b.left,
                    right: b.left + h.clientWidth * m,
                    top: b.top,
                    bottom: b.top + h.clientHeight * g
                }
            }
            let p = 0,
                y = 0;
            if (s == "nearest") t.top < f.top ? (y = -(f.top - t.top + o), e > 0 && t.bottom > f.bottom + y && (y = t.bottom - f.bottom + y + o)) : t.bottom > f.bottom && (y = t.bottom - f.bottom + o, e < 0 && t.top - y < f.top && (y = -(f.top + y - t.top + o)));
            else {
                let b = t.bottom - t.top,
                    v = f.bottom - f.top;
                y = (s == "center" && b <= v ? t.top + b / 2 - v / 2 : s == "start" || s == "center" && e < 0 ? t.top - o : t.bottom - v + o) - f.top
            }
            if (i == "nearest" ? t.left < f.left ? (p = -(f.left - t.left + r), e > 0 && t.right > f.right + p && (p = t.right - f.right + p + r)) : t.right > f.right && (p = t.right - f.right + r, e < 0 && t.left < f.left + p && (p = -(f.left + p - t.left + r))) : p = (i == "center" ? t.left + (t.right - t.left) / 2 - (f.right - f.left) / 2 : i == "start" == l ? t.left - r : t.right - (f.right - f.left) + r) - f.left, p || y)
                if (d) c.scrollBy(p, y);
                else {
                    let b = 0,
                        v = 0;
                    if (y) {
                        let w = h.scrollTop;
                        h.scrollTop += y / g, v = (h.scrollTop - w) * g
                    }
                    if (p) {
                        let w = h.scrollLeft;
                        h.scrollLeft += p / m, b = (h.scrollLeft - w) * m
                    }
                    t = {
                        left: t.left - b,
                        top: t.top - v,
                        right: t.right - b,
                        bottom: t.bottom - v
                    }, b && Math.abs(b - p) < 1 && (i = "nearest"), v && Math.abs(v - y) < 1 && (s = "nearest")
                }
            if (d) break;
            h = h.assignedSlot || h.parentNode
        } else if (h.nodeType == 11) h = h.host;
    else break
}

function Mu(n) {
    let t = n.ownerDocument,
        e, i;
    for (let s = n.parentNode; s && !(s == t.body || e && i);)
        if (s.nodeType == 1) !i && s.scrollHeight > s.clientHeight && (i = s), !e && s.scrollWidth > s.clientWidth && (e = s), s = s.assignedSlot || s.parentNode;
        else if (s.nodeType == 11) s = s.host;
    else break;
    return {
        x: e,
        y: i
    }
}
class Au {
    constructor() {
        this.anchorNode = null, this.anchorOffset = 0, this.focusNode = null, this.focusOffset = 0
    }
    eq(t) {
        return this.anchorNode == t.anchorNode && this.anchorOffset == t.anchorOffset && this.focusNode == t.focusNode && this.focusOffset == t.focusOffset
    }
    setRange(t) {
        let {
            anchorNode: e,
            focusNode: i
        } = t;
        this.set(e, Math.min(t.anchorOffset, e ? Yt(e) : 0), i, Math.min(t.focusOffset, i ? Yt(i) : 0))
    }
    set(t, e, i, s) {
        this.anchorNode = t, this.anchorOffset = e, this.focusNode = i, this.focusOffset = s
    }
}
let Se = null;

function nl(n) {
    if (n.setActive) return n.setActive();
    if (Se) return n.focus(Se);
    let t = [];
    for (let e = n; e && (t.push(e, e.scrollTop, e.scrollLeft), e != e.ownerDocument); e = e.parentNode);
    if (n.focus(Se == null ? {
            get preventScroll() {
                return Se = {
                    preventScroll: !0
                }, !0
            }
        } : void 0), !Se) {
        Se = !1;
        for (let e = 0; e < t.length;) {
            let i = t[e++],
                s = t[e++],
                r = t[e++];
            i.scrollTop != s && (i.scrollTop = s), i.scrollLeft != r && (i.scrollLeft = r)
        }
    }
}
let xr;

function ye(n, t, e = t) {
    let i = xr || (xr = document.createRange());
    return i.setEnd(n, e), i.setStart(n, t), i
}

function Re(n, t, e, i) {
    let s = {
        key: t,
        code: t,
        keyCode: e,
        which: e,
        cancelable: !0
    };
    i && ({
        altKey: s.altKey,
        ctrlKey: s.ctrlKey,
        shiftKey: s.shiftKey,
        metaKey: s.metaKey
    } = i);
    let r = new KeyboardEvent("keydown", s);
    r.synthetic = !0, n.dispatchEvent(r);
    let o = new KeyboardEvent("keyup", s);
    return o.synthetic = !0, n.dispatchEvent(o), r.defaultPrevented || o.defaultPrevented
}

function Tu(n) {
    for (; n;) {
        if (n && (n.nodeType == 9 || n.nodeType == 11 && n.host)) return n;
        n = n.assignedSlot || n.parentNode
    }
    return null
}

function sl(n) {
    for (; n.attributes.length;) n.removeAttributeNode(n.attributes[0])
}

function Eu(n, t) {
    let e = t.focusNode,
        i = t.focusOffset;
    if (!e || t.anchorNode != e || t.anchorOffset != i) return !1;
    for (i = Math.min(i, Yt(e));;)
        if (i) {
            if (e.nodeType != 1) return !1;
            let s = e.childNodes[i - 1];
            s.contentEditable == "false" ? i-- : (e = s, i = Yt(e))
        } else {
            if (e == n) return !0;
            i = pe(e), e = e.parentNode
        }
}

function rl(n) {
    return n.scrollTop > Math.max(1, n.scrollHeight - n.clientHeight - 4)
}

function ol(n, t) {
    for (let e = n, i = t;;) {
        if (e.nodeType == 3 && i > 0) return {
            node: e,
            offset: i
        };
        if (e.nodeType == 1 && i > 0) {
            if (e.contentEditable == "false") return null;
            e = e.childNodes[i - 1], i = Yt(e)
        } else if (e.parentNode && !en(e)) i = pe(e), e = e.parentNode;
        else return null
    }
}

function ll(n, t) {
    for (let e = n, i = t;;) {
        if (e.nodeType == 3 && i < e.nodeValue.length) return {
            node: e,
            offset: i
        };
        if (e.nodeType == 1 && i < e.childNodes.length) {
            if (e.contentEditable == "false") return null;
            e = e.childNodes[i], i = 0
        } else if (e.parentNode && !en(e)) i = pe(e) + 1, e = e.parentNode;
        else return null
    }
}
class ht {
    constructor(t, e, i = !0) {
        this.node = t, this.offset = e, this.precise = i
    }
    static before(t, e) {
        return new ht(t.parentNode, pe(t), e)
    }
    static after(t, e) {
        return new ht(t.parentNode, pe(t) + 1, e)
    }
}
const Hs = [];
class j {
    constructor() {
        this.parent = null, this.dom = null, this.flags = 2
    }
    get overrideDOMText() {
        return null
    }
    get posAtStart() {
        return this.parent ? this.parent.posBefore(this) : 0
    }
    get posAtEnd() {
        return this.posAtStart + this.length
    }
    posBefore(t) {
        let e = this.posAtStart;
        for (let i of this.children) {
            if (i == t) return e;
            e += i.length + i.breakAfter
        }
        throw new RangeError("Invalid child in posBefore")
    }
    posAfter(t) {
        return this.posBefore(t) + t.length
    }
    sync(t, e) {
        if (this.flags & 2) {
            let i = this.dom,
                s = null,
                r;
            for (let o of this.children) {
                if (o.flags & 7) {
                    if (!o.dom && (r = s ? s.nextSibling : i.firstChild)) {
                        let l = j.get(r);
                        (!l || !l.parent && l.canReuseDOM(o)) && o.reuseDOM(r)
                    }
                    o.sync(t, e), o.flags &= -8
                }
                if (r = s ? s.nextSibling : i.firstChild, e && !e.written && e.node == i && r != o.dom && (e.written = !0), o.dom.parentNode == i)
                    for (; r && r != o.dom;) r = br(r);
                else i.insertBefore(o.dom, r);
                s = o.dom
            }
            for (r = s ? s.nextSibling : i.firstChild, r && e && e.node == i && (e.written = !0); r;) r = br(r)
        } else if (this.flags & 1)
            for (let i of this.children) i.flags & 7 && (i.sync(t, e), i.flags &= -8)
    }
    reuseDOM(t) {}
    localPosFromDOM(t, e) {
        let i;
        if (t == this.dom) i = this.dom.childNodes[e];
        else {
            let s = Yt(t) == 0 ? 0 : e == 0 ? -1 : 1;
            for (;;) {
                let r = t.parentNode;
                if (r == this.dom) break;
                s == 0 && r.firstChild != r.lastChild && (t == r.firstChild ? s = -1 : s = 1), t = r
            }
            s < 0 ? i = t : i = t.nextSibling
        }
        if (i == this.dom.firstChild) return 0;
        for (; i && !j.get(i);) i = i.nextSibling;
        if (!i) return this.length;
        for (let s = 0, r = 0;; s++) {
            let o = this.children[s];
            if (o.dom == i) return r;
            r += o.length + o.breakAfter
        }
    }
    domBoundsAround(t, e, i = 0) {
        let s = -1,
            r = -1,
            o = -1,
            l = -1;
        for (let a = 0, c = i, h = i; a < this.children.length; a++) {
            let u = this.children[a],
                f = c + u.length;
            if (c < t && f > e) return u.domBoundsAround(t, e, c);
            if (f >= t && s == -1 && (s = a, r = c), c > e && u.dom.parentNode == this.dom) {
                o = a, l = h;
                break
            }
            h = f, c = f + u.breakAfter
        }
        return {
            from: r,
            to: l < 0 ? i + this.length : l,
            startDOM: (s ? this.children[s - 1].dom.nextSibling : null) || this.dom.firstChild,
            endDOM: o < this.children.length && o >= 0 ? this.children[o].dom : null
        }
    }
    markDirty(t = !1) {
        this.flags |= 2, this.markParentsDirty(t)
    }
    markParentsDirty(t) {
        for (let e = this.parent; e; e = e.parent) {
            if (t && (e.flags |= 2), e.flags & 1) return;
            e.flags |= 1, t = !1
        }
    }
    setParent(t) {
        this.parent != t && (this.parent = t, this.flags & 7 && this.markParentsDirty(!0))
    }
    setDOM(t) {
        this.dom != t && (this.dom && (this.dom.cmView = null), this.dom = t, t.cmView = this)
    }
    get rootView() {
        for (let t = this;;) {
            let e = t.parent;
            if (!e) return t;
            t = e
        }
    }
    replaceChildren(t, e, i = Hs) {
        this.markDirty();
        for (let s = t; s < e; s++) {
            let r = this.children[s];
            r.parent == this && i.indexOf(r) < 0 && r.destroy()
        }
        this.children.splice(t, e - t, ...i);
        for (let s = 0; s < i.length; s++) i[s].setParent(this)
    }
    ignoreMutation(t) {
        return !1
    }
    ignoreEvent(t) {
        return !1
    }
    childCursor(t = this.length) {
        return new al(this.children, t, this.children.length)
    }
    childPos(t, e = 1) {
        return this.childCursor().findPos(t, e)
    }
    toString() {
        let t = this.constructor.name.replace("View", "");
        return t + (this.children.length ? "(" + this.children.join() + ")" : this.length ? "[" + (t == "Text" ? this.text : this.length) + "]" : "") + (this.breakAfter ? "#" : "")
    }
    static get(t) {
        return t.cmView
    }
    get isEditable() {
        return !0
    }
    get isWidget() {
        return !1
    }
    get isHidden() {
        return !1
    }
    merge(t, e, i, s, r, o) {
        return !1
    }
    become(t) {
        return !1
    }
    canReuseDOM(t) {
        return t.constructor == this.constructor && !((this.flags | t.flags) & 8)
    }
    getSide() {
        return 0
    }
    destroy() {
        for (let t of this.children) t.parent == this && t.destroy();
        this.parent = null
    }
}
j.prototype.breakAfter = 0;

function br(n) {
    let t = n.nextSibling;
    return n.parentNode.removeChild(n), t
}
class al {
    constructor(t, e, i) {
        this.children = t, this.pos = e, this.i = i, this.off = 0
    }
    findPos(t, e = 1) {
        for (;;) {
            if (t > this.pos || t == this.pos && (e > 0 || this.i == 0 || this.children[this.i - 1].breakAfter)) return this.off = t - this.pos, this;
            let i = this.children[--this.i];
            this.pos -= i.length + i.breakAfter
        }
    }
}

function hl(n, t, e, i, s, r, o, l, a) {
    let {
        children: c
    } = n, h = c.length ? c[t] : null, u = r.length ? r[r.length - 1] : null, f = u ? u.breakAfter : o;
    if (!(t == i && h && !o && !f && r.length < 2 && h.merge(e, s, r.length ? u : null, e == 0, l, a))) {
        if (i < c.length) {
            let d = c[i];
            d && (s < d.length || d.breakAfter && u ? .breakAfter) ? (t == i && (d = d.split(s), s = 0), !f && u && d.merge(0, s, u, !0, 0, a) ? r[r.length - 1] = d : ((s || d.children.length && !d.children[0].length) && d.merge(0, s, null, !1, 0, a), r.push(d))) : d ? .breakAfter && (u ? u.breakAfter = 1 : o = 1), i++
        }
        for (h && (h.breakAfter = o, e > 0 && (!o && r.length && h.merge(e, h.length, r[0], !1, l, 0) ? h.breakAfter = r.shift().breakAfter : (e < h.length || h.children.length && h.children[h.children.length - 1].length == 0) && h.merge(e, h.length, null, !1, l, 0), t++)); t < i && r.length;)
            if (c[i - 1].become(r[r.length - 1])) i--, r.pop(), a = r.length ? 0 : l;
            else if (c[t].become(r[0])) t++, r.shift(), l = r.length ? 0 : a;
        else break;
        !r.length && t && i < c.length && !c[t - 1].breakAfter && c[i].merge(0, 0, c[t - 1], !1, l, a) && t--, (t < i || r.length) && n.replaceChildren(t, i, r)
    }
}

function cl(n, t, e, i, s, r) {
    let o = n.childCursor(),
        {
            i: l,
            off: a
        } = o.findPos(e, 1),
        {
            i: c,
            off: h
        } = o.findPos(t, -1),
        u = t - e;
    for (let f of i) u += f.length;
    n.length += u, hl(n, c, h, l, a, i, 0, s, r)
}
let yt = typeof navigator < "u" ? navigator : {
        userAgent: "",
        vendor: "",
        platform: ""
    },
    is = typeof document < "u" ? document : {
        documentElement: {
            style: {}
        }
    };
const ns = /Edge\/(\d+)/.exec(yt.userAgent),
    ul = /MSIE \d/.test(yt.userAgent),
    ss = /Trident\/(?:[7-9]|\d{2,})\..*rv:(\d+)/.exec(yt.userAgent),
    gn = !!(ul || ss || ns),
    wr = !gn && /gecko\/(\d+)/i.test(yt.userAgent),
    Mn = !gn && /Chrome\/(\d+)/.exec(yt.userAgent),
    vr = "webkitFontSmoothing" in is.documentElement.style,
    fl = !gn && /Apple Computer/.test(yt.vendor),
    Cr = fl && (/Mobile\/\w+/.test(yt.userAgent) || yt.maxTouchPoints > 2);
var k = {
    mac: Cr || /Mac/.test(yt.platform),
    windows: /Win/.test(yt.platform),
    linux: /Linux|X11/.test(yt.platform),
    ie: gn,
    ie_version: ul ? is.documentMode || 6 : ss ? +ss[1] : ns ? +ns[1] : 0,
    gecko: wr,
    gecko_version: wr ? +(/Firefox\/(\d+)/.exec(yt.userAgent) || [0, 0])[1] : 0,
    chrome: !!Mn,
    chrome_version: Mn ? +Mn[1] : 0,
    ios: Cr,
    android: /Android\b/.test(yt.userAgent),
    webkit: vr,
    safari: fl,
    webkit_version: vr ? +(/\bAppleWebKit\/(\d+)/.exec(yt.userAgent) || [0, 0])[1] : 0,
    tabSize: is.documentElement.style.tabSize != null ? "tab-size" : "-moz-tab-size"
};
const Du = 256;
class Lt extends j {
    constructor(t) {
        super(), this.text = t
    }
    get length() {
        return this.text.length
    }
    createDOM(t) {
        this.setDOM(t || document.createTextNode(this.text))
    }
    sync(t, e) {
        this.dom || this.createDOM(), this.dom.nodeValue != this.text && (e && e.node == this.dom && (e.written = !0), this.dom.nodeValue = this.text)
    }
    reuseDOM(t) {
        t.nodeType == 3 && this.createDOM(t)
    }
    merge(t, e, i) {
        return this.flags & 8 || i && (!(i instanceof Lt) || this.length - (e - t) + i.length > Du || i.flags & 8) ? !1 : (this.text = this.text.slice(0, t) + (i ? i.text : "") + this.text.slice(e), this.markDirty(), !0)
    }
    split(t) {
        let e = new Lt(this.text.slice(t));
        return this.text = this.text.slice(0, t), this.markDirty(), e.flags |= this.flags & 8, e
    }
    localPosFromDOM(t, e) {
        return t == this.dom ? e : e ? this.text.length : 0
    }
    domAtPos(t) {
        return new ht(this.dom, t)
    }
    domBoundsAround(t, e, i) {
        return {
            from: i,
            to: i + this.length,
            startDOM: this.dom,
            endDOM: this.dom.nextSibling
        }
    }
    coordsAt(t, e) {
        return Ou(this.dom, t, e)
    }
}
class Xt extends j {
    constructor(t, e = [], i = 0) {
        super(), this.mark = t, this.children = e, this.length = i;
        for (let s of e) s.setParent(this)
    }
    setAttrs(t) {
        if (sl(t), this.mark.class && (t.className = this.mark.class), this.mark.attrs)
            for (let e in this.mark.attrs) t.setAttribute(e, this.mark.attrs[e]);
        return t
    }
    canReuseDOM(t) {
        return super.canReuseDOM(t) && !((this.flags | t.flags) & 8)
    }
    reuseDOM(t) {
        t.nodeName == this.mark.tagName.toUpperCase() && (this.setDOM(t), this.flags |= 6)
    }
    sync(t, e) {
        this.dom ? this.flags & 4 && this.setAttrs(this.dom) : this.setDOM(this.setAttrs(document.createElement(this.mark.tagName))), super.sync(t, e)
    }
    merge(t, e, i, s, r, o) {
        return i && (!(i instanceof Xt && i.mark.eq(this.mark)) || t && r <= 0 || e < this.length && o <= 0) ? !1 : (cl(this, t, e, i ? i.children.slice() : [], r - 1, o - 1), this.markDirty(), !0)
    }
    split(t) {
        let e = [],
            i = 0,
            s = -1,
            r = 0;
        for (let l of this.children) {
            let a = i + l.length;
            a > t && e.push(i < t ? l.split(t - i) : l), s < 0 && i >= t && (s = r), i = a, r++
        }
        let o = this.length - t;
        return this.length = t, s > -1 && (this.children.length = s, this.markDirty()), new Xt(this.mark, e, o)
    }
    domAtPos(t) {
        return dl(this, t)
    }
    coordsAt(t, e) {
        return gl(this, t, e)
    }
}

function Ou(n, t, e) {
    let i = n.nodeValue.length;
    t > i && (t = i);
    let s = t,
        r = t,
        o = 0;
    t == 0 && e < 0 || t == i && e >= 0 ? k.chrome || k.gecko || (t ? (s--, o = 1) : r < i && (r++, o = -1)) : e < 0 ? s-- : r < i && r++;
    let l = ye(n, s, r).getClientRects();
    if (!l.length) return null;
    let a = l[(o ? o < 0 : e >= 0) ? 0 : l.length - 1];
    return k.safari && !o && a.width == 0 && (a = Array.prototype.find.call(l, c => c.width) || a), o ? mn(a, o < 0) : a || null
}
class fe extends j {
    static create(t, e, i) {
        return new fe(t, e, i)
    }
    constructor(t, e, i) {
        super(), this.widget = t, this.length = e, this.side = i, this.prevWidget = null
    }
    split(t) {
        let e = fe.create(this.widget, this.length - t, this.side);
        return this.length -= t, e
    }
    sync(t) {
        (!this.dom || !this.widget.updateDOM(this.dom, t)) && (this.dom && this.prevWidget && this.prevWidget.destroy(this.dom), this.prevWidget = null, this.setDOM(this.widget.toDOM(t)), this.widget.editable || (this.dom.contentEditable = "false"))
    }
    getSide() {
        return this.side
    }
    merge(t, e, i, s, r, o) {
        return i && (!(i instanceof fe) || !this.widget.compare(i.widget) || t > 0 && r <= 0 || e < this.length && o <= 0) ? !1 : (this.length = t + (i ? i.length : 0) + (this.length - e), !0)
    }
    become(t) {
        return t instanceof fe && t.side == this.side && this.widget.constructor == t.widget.constructor ? (this.widget.compare(t.widget) || this.markDirty(!0), this.dom && !this.prevWidget && (this.prevWidget = this.widget), this.widget = t.widget, this.length = t.length, !0) : !1
    }
    ignoreMutation() {
        return !0
    }
    ignoreEvent(t) {
        return this.widget.ignoreEvent(t)
    }
    get overrideDOMText() {
        if (this.length == 0) return N.empty;
        let t = this;
        for (; t.parent;) t = t.parent;
        let {
            view: e
        } = t, i = e && e.state.doc, s = this.posAtStart;
        return i ? i.slice(s, s + this.length) : N.empty
    }
    domAtPos(t) {
        return (this.length ? t == 0 : this.side > 0) ? ht.before(this.dom) : ht.after(this.dom, t == this.length)
    }
    domBoundsAround() {
        return null
    }
    coordsAt(t, e) {
        let i = this.widget.coordsAt(this.dom, t, e);
        if (i) return i;
        let s = this.dom.getClientRects(),
            r = null;
        if (!s.length) return null;
        let o = this.side ? this.side < 0 : t > 0;
        for (let l = o ? s.length - 1 : 0; r = s[l], !(t > 0 ? l == 0 : l == s.length - 1 || r.top < r.bottom); l += o ? -1 : 1);
        return mn(r, !o)
    }
    get isEditable() {
        return !1
    }
    get isWidget() {
        return !0
    }
    get isHidden() {
        return this.widget.isHidden
    }
    destroy() {
        super.destroy(), this.dom && this.widget.destroy(this.dom)
    }
}
class je extends j {
    constructor(t) {
        super(), this.side = t
    }
    get length() {
        return 0
    }
    merge() {
        return !1
    }
    become(t) {
        return t instanceof je && t.side == this.side
    }
    split() {
        return new je(this.side)
    }
    sync() {
        if (!this.dom) {
            let t = document.createElement("img");
            t.className = "cm-widgetBuffer", t.setAttribute("aria-hidden", "true"), this.setDOM(t)
        }
    }
    getSide() {
        return this.side
    }
    domAtPos(t) {
        return this.side > 0 ? ht.before(this.dom) : ht.after(this.dom)
    }
    localPosFromDOM() {
        return 0
    }
    domBoundsAround() {
        return null
    }
    coordsAt(t) {
        return this.dom.getBoundingClientRect()
    }
    get overrideDOMText() {
        return N.empty
    }
    get isHidden() {
        return !0
    }
}
Lt.prototype.children = fe.prototype.children = je.prototype.children = Hs;

function dl(n, t) {
    let e = n.dom,
        {
            children: i
        } = n,
        s = 0;
    for (let r = 0; s < i.length; s++) {
        let o = i[s],
            l = r + o.length;
        if (!(l == r && o.getSide() <= 0)) {
            if (t > r && t < l && o.dom.parentNode == e) return o.domAtPos(t - r);
            if (t <= r) break;
            r = l
        }
    }
    for (let r = s; r > 0; r--) {
        let o = i[r - 1];
        if (o.dom.parentNode == e) return o.domAtPos(o.length)
    }
    for (let r = s; r < i.length; r++) {
        let o = i[r];
        if (o.dom.parentNode == e) return o.domAtPos(0)
    }
    return new ht(e, 0)
}

function ml(n, t, e) {
    let i, {
        children: s
    } = n;
    e > 0 && t instanceof Xt && s.length && (i = s[s.length - 1]) instanceof Xt && i.mark.eq(t.mark) ? ml(i, t.children[0], e - 1) : (s.push(t), t.setParent(n)), n.length += t.length
}

function gl(n, t, e) {
    let i = null,
        s = -1,
        r = null,
        o = -1;

    function l(c, h) {
        for (let u = 0, f = 0; u < c.children.length && f <= h; u++) {
            let d = c.children[u],
                m = f + d.length;
            m >= h && (d.children.length ? l(d, h - f) : (!r || r.isHidden && e > 0) && (m > h || f == m && d.getSide() > 0) ? (r = d, o = h - f) : (f < h || f == m && d.getSide() < 0 && !d.isHidden) && (i = d, s = h - f)), f = m
        }
    }
    l(n, t);
    let a = (e < 0 ? i : r) || i || r;
    return a ? a.coordsAt(Math.max(0, a == i ? s : o), e) : Ru(n)
}

function Ru(n) {
    let t = n.dom.lastChild;
    if (!t) return n.dom.getBoundingClientRect();
    let e = Fe(t);
    return e[e.length - 1] || null
}

function rs(n, t) {
    for (let e in n) e == "class" && t.class ? t.class += " " + n.class : e == "style" && t.style ? t.style += ";" + n.style : t[e] = n[e];
    return t
}
const Sr = Object.create(null);

function nn(n, t, e) {
    if (n == t) return !0;
    n || (n = Sr), t || (t = Sr);
    let i = Object.keys(n),
        s = Object.keys(t);
    if (i.length - (e && i.indexOf(e) > -1 ? 1 : 0) != s.length - (e && s.indexOf(e) > -1 ? 1 : 0)) return !1;
    for (let r of i)
        if (r != e && (s.indexOf(r) == -1 || n[r] !== t[r])) return !1;
    return !0
}

function os(n, t, e) {
    let i = !1;
    if (t)
        for (let s in t) e && s in e || (i = !0, s == "style" ? n.style.cssText = "" : n.removeAttribute(s));
    if (e)
        for (let s in e) t && t[s] == e[s] || (i = !0, s == "style" ? n.style.cssText = e[s] : n.setAttribute(s, e[s]));
    return i
}

function Pu(n) {
    let t = Object.create(null);
    for (let e = 0; e < n.attributes.length; e++) {
        let i = n.attributes[e];
        t[i.name] = i.value
    }
    return t
}
class J extends j {
    constructor() {
        super(...arguments), this.children = [], this.length = 0, this.prevAttrs = void 0, this.attrs = null, this.breakAfter = 0
    }
    merge(t, e, i, s, r, o) {
        if (i) {
            if (!(i instanceof J)) return !1;
            this.dom || i.transferDOM(this)
        }
        return s && this.setDeco(i ? i.attrs : null), cl(this, t, e, i ? i.children.slice() : [], r, o), !0
    }
    split(t) {
        let e = new J;
        if (e.breakAfter = this.breakAfter, this.length == 0) return e;
        let {
            i,
            off: s
        } = this.childPos(t);
        s && (e.append(this.children[i].split(s), 0), this.children[i].merge(s, this.children[i].length, null, !1, 0, 0), i++);
        for (let r = i; r < this.children.length; r++) e.append(this.children[r], 0);
        for (; i > 0 && this.children[i - 1].length == 0;) this.children[--i].destroy();
        return this.children.length = i, this.markDirty(), this.length = t, e
    }
    transferDOM(t) {
        this.dom && (this.markDirty(), t.setDOM(this.dom), t.prevAttrs = this.prevAttrs === void 0 ? this.attrs : this.prevAttrs, this.prevAttrs = void 0, this.dom = null)
    }
    setDeco(t) {
        nn(this.attrs, t) || (this.dom && (this.prevAttrs = this.attrs, this.markDirty()), this.attrs = t)
    }
    append(t, e) {
        ml(this, t, e)
    }
    addLineDeco(t) {
        let e = t.spec.attributes,
            i = t.spec.class;
        e && (this.attrs = rs(e, this.attrs || {})), i && (this.attrs = rs({
            class: i
        }, this.attrs || {}))
    }
    domAtPos(t) {
        return dl(this, t)
    }
    reuseDOM(t) {
        t.nodeName == "DIV" && (this.setDOM(t), this.flags |= 6)
    }
    sync(t, e) {
        var i;
        this.dom ? this.flags & 4 && (sl(this.dom), this.dom.className = "cm-line", this.prevAttrs = this.attrs ? null : void 0) : (this.setDOM(document.createElement("div")), this.dom.className = "cm-line", this.prevAttrs = this.attrs ? null : void 0), this.prevAttrs !== void 0 && (os(this.dom, this.prevAttrs, this.attrs), this.dom.classList.add("cm-line"), this.prevAttrs = void 0), super.sync(t, e);
        let s = this.dom.lastChild;
        for (; s && j.get(s) instanceof Xt;) s = s.lastChild;
        if (!s || !this.length || s.nodeName != "BR" && ((i = j.get(s)) === null || i === void 0 ? void 0 : i.isEditable) == !1 && (!k.ios || !this.children.some(r => r instanceof Lt))) {
            let r = document.createElement("BR");
            r.cmIgnore = !0, this.dom.appendChild(r)
        }
    }
    measureTextSize() {
        if (this.children.length == 0 || this.length > 20) return null;
        let t = 0,
            e;
        for (let i of this.children) {
            if (!(i instanceof Lt) || /[^ -~]/.test(i.text)) return null;
            let s = Fe(i.dom);
            if (s.length != 1) return null;
            t += s[0].width, e = s[0].height
        }
        return t ? {
            lineHeight: this.dom.getBoundingClientRect().height,
            charWidth: t / this.length,
            textHeight: e
        } : null
    }
    coordsAt(t, e) {
        let i = gl(this, t, e);
        if (!this.children.length && i && this.parent) {
            let {
                heightOracle: s
            } = this.parent.view.viewState, r = i.bottom - i.top;
            if (Math.abs(r - s.lineHeight) < 2 && s.textHeight < r) {
                let o = (r - s.textHeight) / 2;
                return {
                    top: i.top + o,
                    bottom: i.bottom - o,
                    left: i.left,
                    right: i.left
                }
            }
        }
        return i
    }
    become(t) {
        return t instanceof J && this.children.length == 0 && t.children.length == 0 && nn(this.attrs, t.attrs) && this.breakAfter == t.breakAfter
    }
    covers() {
        return !0
    }
    static find(t, e) {
        for (let i = 0, s = 0; i < t.children.length; i++) {
            let r = t.children[i],
                o = s + r.length;
            if (o >= e) {
                if (r instanceof J) return r;
                if (o > e) break
            }
            s = o + r.breakAfter
        }
        return null
    }
}
class Kt extends j {
    constructor(t, e, i) {
        super(), this.widget = t, this.length = e, this.deco = i, this.breakAfter = 0, this.prevWidget = null
    }
    merge(t, e, i, s, r, o) {
        return i && (!(i instanceof Kt) || !this.widget.compare(i.widget) || t > 0 && r <= 0 || e < this.length && o <= 0) ? !1 : (this.length = t + (i ? i.length : 0) + (this.length - e), !0)
    }
    domAtPos(t) {
        return t == 0 ? ht.before(this.dom) : ht.after(this.dom, t == this.length)
    }
    split(t) {
        let e = this.length - t;
        this.length = t;
        let i = new Kt(this.widget, e, this.deco);
        return i.breakAfter = this.breakAfter, i
    }
    get children() {
        return Hs
    }
    sync(t) {
        (!this.dom || !this.widget.updateDOM(this.dom, t)) && (this.dom && this.prevWidget && this.prevWidget.destroy(this.dom), this.prevWidget = null, this.setDOM(this.widget.toDOM(t)), this.widget.editable || (this.dom.contentEditable = "false"))
    }
    get overrideDOMText() {
        return this.parent ? this.parent.view.state.doc.slice(this.posAtStart, this.posAtEnd) : N.empty
    }
    domBoundsAround() {
        return null
    }
    become(t) {
        return t instanceof Kt && t.widget.constructor == this.widget.constructor ? (t.widget.compare(this.widget) || this.markDirty(!0), this.dom && !this.prevWidget && (this.prevWidget = this.widget), this.widget = t.widget, this.length = t.length, this.deco = t.deco, this.breakAfter = t.breakAfter, !0) : !1
    }
    ignoreMutation() {
        return !0
    }
    ignoreEvent(t) {
        return this.widget.ignoreEvent(t)
    }
    get isEditable() {
        return !1
    }
    get isWidget() {
        return !0
    }
    coordsAt(t, e) {
        return this.widget.coordsAt(this.dom, t, e)
    }
    destroy() {
        super.destroy(), this.dom && this.widget.destroy(this.dom)
    }
    covers(t) {
        let {
            startSide: e,
            endSide: i
        } = this.deco;
        return e == i ? !1 : t < 0 ? e < 0 : i > 0
    }
}
class qe {
    eq(t) {
        return !1
    }
    updateDOM(t, e) {
        return !1
    }
    compare(t) {
        return this == t || this.constructor == t.constructor && this.eq(t)
    }
    get estimatedHeight() {
        return -1
    }
    get lineBreaks() {
        return 0
    }
    ignoreEvent(t) {
        return !0
    }
    coordsAt(t, e, i) {
        return null
    }
    get isHidden() {
        return !1
    }
    get editable() {
        return !1
    }
    destroy(t) {}
}
var dt = function(n) {
    return n[n.Text = 0] = "Text", n[n.WidgetBefore = 1] = "WidgetBefore", n[n.WidgetAfter = 2] = "WidgetAfter", n[n.WidgetRange = 3] = "WidgetRange", n
}(dt || (dt = {}));
class B extends He {
    constructor(t, e, i, s) {
        super(), this.startSide = t, this.endSide = e, this.widget = i, this.spec = s
    }
    get heightRelevant() {
        return !1
    }
    static mark(t) {
        return new Si(t)
    }
    static widget(t) {
        let e = Math.max(-1e4, Math.min(1e4, t.side || 0)),
            i = !!t.block;
        return e += i && !t.inlineOrder ? e > 0 ? 3e8 : -4e8 : e > 0 ? 1e8 : -1e8, new se(t, e, e, i, t.widget || null, !1)
    }
    static replace(t) {
        let e = !!t.block,
            i, s;
        if (t.isBlockGap) i = -5e8, s = 4e8;
        else {
            let {
                start: r,
                end: o
            } = pl(t, e);
            i = (r ? e ? -3e8 : -1 : 5e8) - 1, s = (o ? e ? 2e8 : 1 : -6e8) + 1
        }
        return new se(t, i, s, e, t.widget || null, !0)
    }
    static line(t) {
        return new ki(t)
    }
    static set(t, e = !1) {
        return L.of(t, e)
    }
    hasHeight() {
        return this.widget ? this.widget.estimatedHeight > -1 : !1
    }
}
B.none = L.empty;
class Si extends B {
    constructor(t) {
        let {
            start: e,
            end: i
        } = pl(t);
        super(e ? -1 : 5e8, i ? 1 : -6e8, null, t), this.tagName = t.tagName || "span", this.class = t.class || "", this.attrs = t.attributes || null
    }
    eq(t) {
        var e, i;
        return this == t || t instanceof Si && this.tagName == t.tagName && (this.class || ((e = this.attrs) === null || e === void 0 ? void 0 : e.class)) == (t.class || ((i = t.attrs) === null || i === void 0 ? void 0 : i.class)) && nn(this.attrs, t.attrs, "class")
    }
    range(t, e = t) {
        if (t >= e) throw new RangeError("Mark decorations may not be empty");
        return super.range(t, e)
    }
}
Si.prototype.point = !1;
class ki extends B {
    constructor(t) {
        super(-2e8, -2e8, null, t)
    }
    eq(t) {
        return t instanceof ki && this.spec.class == t.spec.class && nn(this.spec.attributes, t.spec.attributes)
    }
    range(t, e = t) {
        if (e != t) throw new RangeError("Line decoration ranges must be zero-length");
        return super.range(t, e)
    }
}
ki.prototype.mapMode = wt.TrackBefore;
ki.prototype.point = !0;
class se extends B {
    constructor(t, e, i, s, r, o) {
        super(e, i, r, t), this.block = s, this.isReplace = o, this.mapMode = s ? e <= 0 ? wt.TrackBefore : wt.TrackAfter : wt.TrackDel
    }
    get type() {
        return this.startSide != this.endSide ? dt.WidgetRange : this.startSide <= 0 ? dt.WidgetBefore : dt.WidgetAfter
    }
    get heightRelevant() {
        return this.block || !!this.widget && (this.widget.estimatedHeight >= 5 || this.widget.lineBreaks > 0)
    }
    eq(t) {
        return t instanceof se && Lu(this.widget, t.widget) && this.block == t.block && this.startSide == t.startSide && this.endSide == t.endSide
    }
    range(t, e = t) {
        if (this.isReplace && (t > e || t == e && this.startSide > 0 && this.endSide <= 0)) throw new RangeError("Invalid range for replacement decoration");
        if (!this.isReplace && e != t) throw new RangeError("Widget decorations can only have zero-length ranges");
        return super.range(t, e)
    }
}
se.prototype.point = !0;

function pl(n, t = !1) {
    let {
        inclusiveStart: e,
        inclusiveEnd: i
    } = n;
    return e == null && (e = n.inclusive), i == null && (i = n.inclusive), {
        start: e ? ? t,
        end: i ? ? t
    }
}

function Lu(n, t) {
    return n == t || !!(n && t && n.compare(t))
}

function ls(n, t, e, i = 0) {
    let s = e.length - 1;
    s >= 0 && e[s] + i >= n ? e[s] = Math.max(e[s], t) : e.push(n, t)
}
class ai {
    constructor(t, e, i, s) {
        this.doc = t, this.pos = e, this.end = i, this.disallowBlockEffectsFor = s, this.content = [], this.curLine = null, this.breakAtStart = 0, this.pendingBuffer = 0, this.bufferMarks = [], this.atCursorPos = !0, this.openStart = -1, this.openEnd = -1, this.text = "", this.textOff = 0, this.cursor = t.iter(), this.skip = e
    }
    posCovered() {
        if (this.content.length == 0) return !this.breakAtStart && this.doc.lineAt(this.pos).from != this.pos;
        let t = this.content[this.content.length - 1];
        return !(t.breakAfter || t instanceof Kt && t.deco.endSide < 0)
    }
    getLine() {
        return this.curLine || (this.content.push(this.curLine = new J), this.atCursorPos = !0), this.curLine
    }
    flushBuffer(t = this.bufferMarks) {
        this.pendingBuffer && (this.curLine.append(Ri(new je(-1), t), t.length), this.pendingBuffer = 0)
    }
    addBlockWidget(t) {
        this.flushBuffer(), this.curLine = null, this.content.push(t)
    }
    finish(t) {
        this.pendingBuffer && t <= this.bufferMarks.length ? this.flushBuffer() : this.pendingBuffer = 0, !this.posCovered() && !(t && this.content.length && this.content[this.content.length - 1] instanceof Kt) && this.getLine()
    }
    buildText(t, e, i) {
        for (; t > 0;) {
            if (this.textOff == this.text.length) {
                let {
                    value: r,
                    lineBreak: o,
                    done: l
                } = this.cursor.next(this.skip);
                if (this.skip = 0, l) throw new Error("Ran out of text content when drawing inline views");
                if (o) {
                    this.posCovered() || this.getLine(), this.content.length ? this.content[this.content.length - 1].breakAfter = 1 : this.breakAtStart = 1, this.flushBuffer(), this.curLine = null, this.atCursorPos = !0, t--;
                    continue
                } else this.text = r, this.textOff = 0
            }
            let s = Math.min(this.text.length - this.textOff, t, 512);
            this.flushBuffer(e.slice(e.length - i)), this.getLine().append(Ri(new Lt(this.text.slice(this.textOff, this.textOff + s)), e), i), this.atCursorPos = !0, this.textOff += s, t -= s, i = 0
        }
    }
    span(t, e, i, s) {
        this.buildText(e - t, i, s), this.pos = e, this.openStart < 0 && (this.openStart = s)
    }
    point(t, e, i, s, r, o) {
        if (this.disallowBlockEffectsFor[o] && i instanceof se) {
            if (i.block) throw new RangeError("Block decorations may not be specified via plugins");
            if (e > this.doc.lineAt(this.pos).to) throw new RangeError("Decorations that replace line breaks may not be specified via plugins")
        }
        let l = e - t;
        if (i instanceof se)
            if (i.block) i.startSide > 0 && !this.posCovered() && this.getLine(), this.addBlockWidget(new Kt(i.widget || We.block, l, i));
            else {
                let a = fe.create(i.widget || We.inline, l, l ? 0 : i.startSide),
                    c = this.atCursorPos && !a.isEditable && r <= s.length && (t < e || i.startSide > 0),
                    h = !a.isEditable && (t < e || r > s.length || i.startSide <= 0),
                    u = this.getLine();
                this.pendingBuffer == 2 && !c && !a.isEditable && (this.pendingBuffer = 0), this.flushBuffer(s), c && (u.append(Ri(new je(1), s), r), r = s.length + Math.max(0, r - s.length)), u.append(Ri(a, s), r), this.atCursorPos = h, this.pendingBuffer = h ? t < e || r > s.length ? 1 : 2 : 0, this.pendingBuffer && (this.bufferMarks = s.slice())
            }
        else this.doc.lineAt(this.pos).from == this.pos && this.getLine().addLineDeco(i);
        l && (this.textOff + l <= this.text.length ? this.textOff += l : (this.skip += l - (this.text.length - this.textOff), this.text = "", this.textOff = 0), this.pos = e), this.openStart < 0 && (this.openStart = r)
    }
    static build(t, e, i, s, r) {
        let o = new ai(t, e, i, r);
        return o.openEnd = L.spans(s, e, i, o), o.openStart < 0 && (o.openStart = o.openEnd), o.finish(o.openEnd), o
    }
}

function Ri(n, t) {
    for (let e of t) n = new Xt(e, [n], n.length);
    return n
}
class We extends qe {
    constructor(t) {
        super(), this.tag = t
    }
    eq(t) {
        return t.tag == this.tag
    }
    toDOM() {
        return document.createElement(this.tag)
    }
    updateDOM(t) {
        return t.nodeName.toLowerCase() == this.tag
    }
    get isHidden() {
        return !0
    }
}
We.inline = new We("span");
We.block = new We("div");
var Q = function(n) {
    return n[n.LTR = 0] = "LTR", n[n.RTL = 1] = "RTL", n
}(Q || (Q = {}));
const xe = Q.LTR,
    Vs = Q.RTL;

function yl(n) {
    let t = [];
    for (let e = 0; e < n.length; e++) t.push(1 << +n[e]);
    return t
}
const Nu = yl("88888888888888888888888888888888888666888888787833333333337888888000000000000000000000000008888880000000000000000000000000088888888888888888888888888888888888887866668888088888663380888308888800000000000000000000000800000000000000000000000000000008"),
    Iu = yl("4444448826627288999999999992222222222222222222222222222222222222222222222229999999999999999999994444444444644222822222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222999999949999999229989999223333333333"),
    as = Object.create(null),
    Vt = [];
for (let n of ["()", "[]", "{}"]) {
    let t = n.charCodeAt(0),
        e = n.charCodeAt(1);
    as[t] = e, as[e] = -t
}

function xl(n) {
    return n <= 247 ? Nu[n] : 1424 <= n && n <= 1524 ? 2 : 1536 <= n && n <= 1785 ? Iu[n - 1536] : 1774 <= n && n <= 2220 ? 4 : 8192 <= n && n <= 8204 ? 256 : 64336 <= n && n <= 65023 ? 4 : 1
}
const Bu = /[\u0590-\u05f4\u0600-\u06ff\u0700-\u08ac\ufb50-\ufdff]/;
class ie {
    get dir() {
        return this.level % 2 ? Vs : xe
    }
    constructor(t, e, i) {
        this.from = t, this.to = e, this.level = i
    }
    side(t, e) {
        return this.dir == e == t ? this.to : this.from
    }
    forward(t, e) {
        return t == (this.dir == e)
    }
    static find(t, e, i, s) {
        let r = -1;
        for (let o = 0; o < t.length; o++) {
            let l = t[o];
            if (l.from <= e && l.to >= e) {
                if (l.level == i) return o;
                (r < 0 || (s != 0 ? s < 0 ? l.from < e : l.to > e : t[r].level > l.level)) && (r = o)
            }
        }
        if (r < 0) throw new RangeError("Index out of range");
        return r
    }
}

function bl(n, t) {
    if (n.length != t.length) return !1;
    for (let e = 0; e < n.length; e++) {
        let i = n[e],
            s = t[e];
        if (i.from != s.from || i.to != s.to || i.direction != s.direction || !bl(i.inner, s.inner)) return !1
    }
    return !0
}
const F = [];

function Hu(n, t, e, i, s) {
    for (let r = 0; r <= i.length; r++) {
        let o = r ? i[r - 1].to : t,
            l = r < i.length ? i[r].from : e,
            a = r ? 256 : s;
        for (let c = o, h = a, u = a; c < l; c++) {
            let f = xl(n.charCodeAt(c));
            f == 512 ? f = h : f == 8 && u == 4 && (f = 16), F[c] = f == 4 ? 2 : f, f & 7 && (u = f), h = f
        }
        for (let c = o, h = a, u = a; c < l; c++) {
            let f = F[c];
            if (f == 128) c < l - 1 && h == F[c + 1] && h & 24 ? f = F[c] = h : F[c] = 256;
            else if (f == 64) {
                let d = c + 1;
                for (; d < l && F[d] == 64;) d++;
                let m = c && h == 8 || d < e && F[d] == 8 ? u == 1 ? 1 : 8 : 256;
                for (let g = c; g < d; g++) F[g] = m;
                c = d - 1
            } else f == 8 && u == 1 && (F[c] = 1);
            h = f, f & 7 && (u = f)
        }
    }
}

function Vu(n, t, e, i, s) {
    let r = s == 1 ? 2 : 1;
    for (let o = 0, l = 0, a = 0; o <= i.length; o++) {
        let c = o ? i[o - 1].to : t,
            h = o < i.length ? i[o].from : e;
        for (let u = c, f, d, m; u < h; u++)
            if (d = as[f = n.charCodeAt(u)])
                if (d < 0) {
                    for (let g = l - 3; g >= 0; g -= 3)
                        if (Vt[g + 1] == -d) {
                            let p = Vt[g + 2],
                                y = p & 2 ? s : p & 4 ? p & 1 ? r : s : 0;
                            y && (F[u] = F[Vt[g]] = y), l = g;
                            break
                        }
                } else {
                    if (Vt.length == 189) break;
                    Vt[l++] = u, Vt[l++] = f, Vt[l++] = a
                }
        else if ((m = F[u]) == 2 || m == 1) {
            let g = m == s;
            a = g ? 0 : 1;
            for (let p = l - 3; p >= 0; p -= 3) {
                let y = Vt[p + 2];
                if (y & 2) break;
                if (g) Vt[p + 2] |= 2;
                else {
                    if (y & 4) break;
                    Vt[p + 2] |= 4
                }
            }
        }
    }
}

function Fu(n, t, e, i) {
    for (let s = 0, r = i; s <= e.length; s++) {
        let o = s ? e[s - 1].to : n,
            l = s < e.length ? e[s].from : t;
        for (let a = o; a < l;) {
            let c = F[a];
            if (c == 256) {
                let h = a + 1;
                for (;;)
                    if (h == l) {
                        if (s == e.length) break;
                        h = e[s++].to, l = s < e.length ? e[s].from : t
                    } else if (F[h] == 256) h++;
                else break;
                let u = r == 1,
                    f = (h < t ? F[h] : i) == 1,
                    d = u == f ? u ? 1 : 2 : i;
                for (let m = h, g = s, p = g ? e[g - 1].to : n; m > a;) m == p && (m = e[--g].from, p = g ? e[g - 1].to : n), F[--m] = d;
                a = h
            } else r = c, a++
        }
    }
}

function hs(n, t, e, i, s, r, o) {
    let l = i % 2 ? 2 : 1;
    if (i % 2 == s % 2)
        for (let a = t, c = 0; a < e;) {
            let h = !0,
                u = !1;
            if (c == r.length || a < r[c].from) {
                let g = F[a];
                g != l && (h = !1, u = g == 16)
            }
            let f = !h && l == 1 ? [] : null,
                d = h ? i : i + 1,
                m = a;
            t: for (;;)
                if (c < r.length && m == r[c].from) {
                    if (u) break t;
                    let g = r[c];
                    if (!h)
                        for (let p = g.to, y = c + 1;;) {
                            if (p == e) break t;
                            if (y < r.length && r[y].from == p) p = r[y++].to;
                            else {
                                if (F[p] == l) break t;
                                break
                            }
                        }
                    if (c++, f) f.push(g);
                    else {
                        g.from > a && o.push(new ie(a, g.from, d));
                        let p = g.direction == xe != !(d % 2);
                        cs(n, p ? i + 1 : i, s, g.inner, g.from, g.to, o), a = g.to
                    }
                    m = g.to
                } else {
                    if (m == e || (h ? F[m] != l : F[m] == l)) break;
                    m++
                }
            f ? hs(n, a, m, i + 1, s, f, o) : a < m && o.push(new ie(a, m, d)), a = m
        } else
            for (let a = e, c = r.length; a > t;) {
                let h = !0,
                    u = !1;
                if (!c || a > r[c - 1].to) {
                    let g = F[a - 1];
                    g != l && (h = !1, u = g == 16)
                }
                let f = !h && l == 1 ? [] : null,
                    d = h ? i : i + 1,
                    m = a;
                t: for (;;)
                    if (c && m == r[c - 1].to) {
                        if (u) break t;
                        let g = r[--c];
                        if (!h)
                            for (let p = g.from, y = c;;) {
                                if (p == t) break t;
                                if (y && r[y - 1].to == p) p = r[--y].from;
                                else {
                                    if (F[p - 1] == l) break t;
                                    break
                                }
                            }
                        if (f) f.push(g);
                        else {
                            g.to < a && o.push(new ie(g.to, a, d));
                            let p = g.direction == xe != !(d % 2);
                            cs(n, p ? i + 1 : i, s, g.inner, g.from, g.to, o), a = g.from
                        }
                        m = g.from
                    } else {
                        if (m == t || (h ? F[m - 1] != l : F[m - 1] == l)) break;
                        m--
                    }
                f ? hs(n, m, a, i + 1, s, f, o) : m < a && o.push(new ie(m, a, d)), a = m
            }
}

function cs(n, t, e, i, s, r, o) {
    let l = t % 2 ? 2 : 1;
    Hu(n, s, r, i, l), Vu(n, s, r, i, l), Fu(s, r, i, l), hs(n, s, r, t, e, i, o)
}

function ju(n, t, e) {
    if (!n) return [new ie(0, 0, t == Vs ? 1 : 0)];
    if (t == xe && !e.length && !Bu.test(n)) return wl(n.length);
    if (e.length)
        for (; n.length > F.length;) F[F.length] = 256;
    let i = [],
        s = t == xe ? 0 : 1;
    return cs(n, s, s, e, 0, n.length, i), i
}

function wl(n) {
    return [new ie(0, n, 0)]
}
let vl = "";

function Wu(n, t, e, i, s) {
    var r;
    let o = i.head - n.from,
        l = ie.find(t, o, (r = i.bidiLevel) !== null && r !== void 0 ? r : -1, i.assoc),
        a = t[l],
        c = a.side(s, e);
    if (o == c) {
        let f = l += s ? 1 : -1;
        if (f < 0 || f >= t.length) return null;
        a = t[l = f], o = a.side(!s, e), c = a.side(s, e)
    }
    let h = Wt(n.text, o, a.forward(s, e));
    (h < a.from || h > a.to) && (h = c), vl = n.text.slice(Math.min(o, h), Math.max(o, h));
    let u = l == (s ? t.length - 1 : 0) ? null : t[l + (s ? 1 : -1)];
    return u && h == c && u.level + (s ? 0 : 1) < a.level ? A.cursor(u.side(!s, e) + n.from, u.forward(s, e) ? 1 : -1, u.level) : A.cursor(h + n.from, a.forward(s, e) ? -1 : 1, a.level)
}

function zu(n, t, e) {
    for (let i = t; i < e; i++) {
        let s = xl(n.charCodeAt(i));
        if (s == 1) return xe;
        if (s == 2 || s == 4) return Vs
    }
    return xe
}
const Cl = E.define(),
    Sl = E.define(),
    kl = E.define(),
    Ml = E.define(),
    us = E.define(),
    Al = E.define(),
    Tl = E.define(),
    El = E.define({
        combine: n => n.some(t => t)
    }),
    Dl = E.define({
        combine: n => n.some(t => t)
    }),
    Ol = E.define();
class Pe {
    constructor(t, e = "nearest", i = "nearest", s = 5, r = 5, o = !1) {
        this.range = t, this.y = e, this.x = i, this.yMargin = s, this.xMargin = r, this.isSnapshot = o
    }
    map(t) {
        return t.empty ? this : new Pe(this.range.map(t), this.y, this.x, this.yMargin, this.xMargin, this.isSnapshot)
    }
    clip(t) {
        return this.range.to <= t.doc.length ? this : new Pe(A.cursor(t.doc.length), this.y, this.x, this.yMargin, this.xMargin, this.isSnapshot)
    }
}
const Pi = G.define({
        map: (n, t) => n.map(t)
    }),
    Rl = G.define();

function Ut(n, t, e) {
    let i = n.facet(Ml);
    i.length ? i[0](t) : window.onerror ? window.onerror(String(t), e, void 0, void 0, t) : e ? console.error(e + ":", t) : console.error(t)
}
const Zt = E.define({
    combine: n => n.length ? n[0] : !0
});
let qu = 0;
const ti = E.define();
class Nt {
    constructor(t, e, i, s, r) {
        this.id = t, this.create = e, this.domEventHandlers = i, this.domEventObservers = s, this.extension = r(this)
    }
    static define(t, e) {
        const {
            eventHandlers: i,
            eventObservers: s,
            provide: r,
            decorations: o
        } = e || {};
        return new Nt(qu++, t, i, s, l => {
            let a = [ti.of(l)];
            return o && a.push(pi.of(c => {
                let h = c.plugin(l);
                return h ? o(h) : B.none
            })), r && a.push(r(l)), a
        })
    }
    static fromClass(t, e) {
        return Nt.define(i => new t(i), e)
    }
}
class An {
    constructor(t) {
        this.spec = t, this.mustUpdate = null, this.value = null
    }
    update(t) {
        if (this.value) {
            if (this.mustUpdate) {
                let e = this.mustUpdate;
                if (this.mustUpdate = null, this.value.update) try {
                    this.value.update(e)
                } catch (i) {
                    if (Ut(e.state, i, "CodeMirror plugin crashed"), this.value.destroy) try {
                        this.value.destroy()
                    } catch {}
                    this.deactivate()
                }
            }
        } else if (this.spec) try {
            this.value = this.spec.create(t)
        } catch (e) {
            Ut(t.state, e, "CodeMirror plugin crashed"), this.deactivate()
        }
        return this
    }
    destroy(t) {
        var e;
        if (!((e = this.value) === null || e === void 0) && e.destroy) try {
            this.value.destroy()
        } catch (i) {
            Ut(t.state, i, "CodeMirror plugin crashed")
        }
    }
    deactivate() {
        this.spec = this.value = null
    }
}
const Pl = E.define(),
    Fs = E.define(),
    pi = E.define(),
    Ll = E.define(),
    js = E.define(),
    Nl = E.define();

function kr(n, t) {
    let e = n.state.facet(Nl);
    if (!e.length) return e;
    let i = e.map(r => r instanceof Function ? r(n) : r),
        s = [];
    return L.spans(i, t.from, t.to, {
        point() {},
        span(r, o, l, a) {
            let c = r - t.from,
                h = o - t.from,
                u = s;
            for (let f = l.length - 1; f >= 0; f--, a--) {
                let d = l[f].spec.bidiIsolate,
                    m;
                if (d == null && (d = zu(t.text, c, h)), a > 0 && u.length && (m = u[u.length - 1]).to == c && m.direction == d) m.to = h, u = m.inner;
                else {
                    let g = {
                        from: c,
                        to: h,
                        direction: d,
                        inner: []
                    };
                    u.push(g), u = g.inner
                }
            }
        }
    }), s
}
const Il = E.define();

function Bl(n) {
    let t = 0,
        e = 0,
        i = 0,
        s = 0;
    for (let r of n.state.facet(Il)) {
        let o = r(n);
        o && (o.left != null && (t = Math.max(t, o.left)), o.right != null && (e = Math.max(e, o.right)), o.top != null && (i = Math.max(i, o.top)), o.bottom != null && (s = Math.max(s, o.bottom)))
    }
    return {
        left: t,
        right: e,
        top: i,
        bottom: s
    }
}
const ei = E.define();
class Mt {
    constructor(t, e, i, s) {
        this.fromA = t, this.toA = e, this.fromB = i, this.toB = s
    }
    join(t) {
        return new Mt(Math.min(this.fromA, t.fromA), Math.max(this.toA, t.toA), Math.min(this.fromB, t.fromB), Math.max(this.toB, t.toB))
    }
    addToSet(t) {
        let e = t.length,
            i = this;
        for (; e > 0; e--) {
            let s = t[e - 1];
            if (!(s.fromA > i.toA)) {
                if (s.toA < i.fromA) break;
                i = i.join(s), t.splice(e - 1, 1)
            }
        }
        return t.splice(e, 0, i), t
    }
    static extendWithRanges(t, e) {
        if (e.length == 0) return t;
        let i = [];
        for (let s = 0, r = 0, o = 0, l = 0;; s++) {
            let a = s == t.length ? null : t[s],
                c = o - l,
                h = a ? a.fromB : 1e9;
            for (; r < e.length && e[r] < h;) {
                let u = e[r],
                    f = e[r + 1],
                    d = Math.max(l, u),
                    m = Math.min(h, f);
                if (d <= m && new Mt(d + c, m + c, d, m).addToSet(i), f > h) break;
                r += 2
            }
            if (!a) return i;
            new Mt(a.fromA, a.toA, a.fromB, a.toB).addToSet(i), o = a.toA, l = a.toB
        }
    }
}
class sn {
    constructor(t, e, i) {
        this.view = t, this.state = e, this.transactions = i, this.flags = 0, this.startState = t.state, this.changes = it.empty(this.startState.doc.length);
        for (let r of i) this.changes = this.changes.compose(r.changes);
        let s = [];
        this.changes.iterChangedRanges((r, o, l, a) => s.push(new Mt(r, o, l, a))), this.changedRanges = s
    }
    static create(t, e, i) {
        return new sn(t, e, i)
    }
    get viewportChanged() {
        return (this.flags & 4) > 0
    }
    get heightChanged() {
        return (this.flags & 2) > 0
    }
    get geometryChanged() {
        return this.docChanged || (this.flags & 10) > 0
    }
    get focusChanged() {
        return (this.flags & 1) > 0
    }
    get docChanged() {
        return !this.changes.empty
    }
    get selectionSet() {
        return this.transactions.some(t => t.selection)
    }
    get empty() {
        return this.flags == 0 && this.transactions.length == 0
    }
}
class Mr extends j {
    get length() {
        return this.view.state.doc.length
    }
    constructor(t) {
        super(), this.view = t, this.decorations = [], this.dynamicDecorationMap = [!1], this.domChanged = null, this.hasComposition = null, this.markedForComposition = new Set, this.editContextFormatting = B.none, this.lastCompositionAfterCursor = !1, this.minWidth = 0, this.minWidthFrom = 0, this.minWidthTo = 0, this.impreciseAnchor = null, this.impreciseHead = null, this.forceSelection = !1, this.lastUpdate = Date.now(), this.setDOM(t.contentDOM), this.children = [new J], this.children[0].setParent(this), this.updateDeco(), this.updateInner([new Mt(0, 0, 0, t.state.doc.length)], 0, null)
    }
    update(t) {
        var e;
        let i = t.changedRanges;
        this.minWidth > 0 && i.length && (i.every(({
            fromA: c,
            toA: h
        }) => h < this.minWidthFrom || c > this.minWidthTo) ? (this.minWidthFrom = t.changes.mapPos(this.minWidthFrom, 1), this.minWidthTo = t.changes.mapPos(this.minWidthTo, 1)) : this.minWidth = this.minWidthFrom = this.minWidthTo = 0), this.updateEditContextFormatting(t);
        let s = -1;
        this.view.inputState.composing >= 0 && !this.view.observer.editContext && (!((e = this.domChanged) === null || e === void 0) && e.newSel ? s = this.domChanged.newSel.head : !Xu(t.changes, this.hasComposition) && !t.selectionSet && (s = t.state.selection.main.head));
        let r = s > -1 ? $u(this.view, t.changes, s) : null;
        if (this.domChanged = null, this.hasComposition) {
            this.markedForComposition.clear();
            let {
                from: c,
                to: h
            } = this.hasComposition;
            i = new Mt(c, h, t.changes.mapPos(c, -1), t.changes.mapPos(h, 1)).addToSet(i.slice())
        }
        this.hasComposition = r ? {
            from: r.range.fromB,
            to: r.range.toB
        } : null, (k.ie || k.chrome) && !r && t && t.state.doc.lines != t.startState.doc.lines && (this.forceSelection = !0);
        let o = this.decorations,
            l = this.updateDeco(),
            a = Ku(o, l, t.changes);
        return i = Mt.extendWithRanges(i, a), !(this.flags & 7) && i.length == 0 ? !1 : (this.updateInner(i, t.startState.doc.length, r), t.transactions.length && (this.lastUpdate = Date.now()), !0)
    }
    updateInner(t, e, i) {
        this.view.viewState.mustMeasureContent = !0, this.updateChildren(t, e, i);
        let {
            observer: s
        } = this.view;
        s.ignore(() => {
            this.dom.style.height = this.view.viewState.contentHeight / this.view.scaleY + "px", this.dom.style.flexBasis = this.minWidth ? this.minWidth + "px" : "";
            let o = k.chrome || k.ios ? {
                node: s.selectionRange.focusNode,
                written: !1
            } : void 0;
            this.sync(this.view, o), this.flags &= -8, o && (o.written || s.selectionRange.focusNode != o.node) && (this.forceSelection = !0), this.dom.style.height = ""
        }), this.markedForComposition.forEach(o => o.flags &= -9);
        let r = [];
        if (this.view.viewport.from || this.view.viewport.to < this.view.state.doc.length)
            for (let o of this.children) o instanceof Kt && o.widget instanceof Ar && r.push(o.dom);
        s.updateGaps(r)
    }
    updateChildren(t, e, i) {
        let s = i ? i.range.addToSet(t.slice()) : t,
            r = this.childCursor(e);
        for (let o = s.length - 1;; o--) {
            let l = o >= 0 ? s[o] : null;
            if (!l) break;
            let {
                fromA: a,
                toA: c,
                fromB: h,
                toB: u
            } = l, f, d, m, g;
            if (i && i.range.fromB < u && i.range.toB > h) {
                let w = ai.build(this.view.state.doc, h, i.range.fromB, this.decorations, this.dynamicDecorationMap),
                    S = ai.build(this.view.state.doc, i.range.toB, u, this.decorations, this.dynamicDecorationMap);
                d = w.breakAtStart, m = w.openStart, g = S.openEnd;
                let M = this.compositionView(i);
                S.breakAtStart ? M.breakAfter = 1 : S.content.length && M.merge(M.length, M.length, S.content[0], !1, S.openStart, 0) && (M.breakAfter = S.content[0].breakAfter, S.content.shift()), w.content.length && M.merge(0, 0, w.content[w.content.length - 1], !0, 0, w.openEnd) && w.content.pop(), f = w.content.concat(M).concat(S.content)
            } else({
                content: f,
                breakAtStart: d,
                openStart: m,
                openEnd: g
            } = ai.build(this.view.state.doc, h, u, this.decorations, this.dynamicDecorationMap));
            let {
                i: p,
                off: y
            } = r.findPos(c, 1), {
                i: b,
                off: v
            } = r.findPos(a, -1);
            hl(this, b, v, p, y, f, d, m, g)
        }
        i && this.fixCompositionDOM(i)
    }
    updateEditContextFormatting(t) {
        this.editContextFormatting = this.editContextFormatting.map(t.changes);
        for (let e of t.transactions)
            for (let i of e.effects) i.is(Rl) && (this.editContextFormatting = i.value)
    }
    compositionView(t) {
        let e = new Lt(t.text.nodeValue);
        e.flags |= 8;
        for (let {
                deco: s
            } of t.marks) e = new Xt(s, [e], e.length);
        let i = new J;
        return i.append(e, 0), i
    }
    fixCompositionDOM(t) {
        let e = (r, o) => {
                o.flags |= 8 | (o.children.some(a => a.flags & 7) ? 1 : 0), this.markedForComposition.add(o);
                let l = j.get(r);
                l && l != o && (l.dom = null), o.setDOM(r)
            },
            i = this.childPos(t.range.fromB, 1),
            s = this.children[i.i];
        e(t.line, s);
        for (let r = t.marks.length - 1; r >= -1; r--) i = s.childPos(i.off, 1), s = s.children[i.i], e(r >= 0 ? t.marks[r].node : t.text, s)
    }
    updateSelection(t = !1, e = !1) {
        (t || !this.view.observer.selectionRange.focusNode) && this.view.observer.readSelectionRange();
        let i = this.view.root.activeElement,
            s = i == this.dom,
            r = !s && _i(this.dom, this.view.observer.selectionRange) && !(i && this.dom.contains(i));
        if (!(s || e || r)) return;
        let o = this.forceSelection;
        this.forceSelection = !1;
        let l = this.view.state.selection.main,
            a = this.moveToLine(this.domAtPos(l.anchor)),
            c = l.empty ? a : this.moveToLine(this.domAtPos(l.head));
        if (k.gecko && l.empty && !this.hasComposition && _u(a)) {
            let u = document.createTextNode("");
            this.view.observer.ignore(() => a.node.insertBefore(u, a.node.childNodes[a.offset] || null)), a = c = new ht(u, 0), o = !0
        }
        let h = this.view.observer.selectionRange;
        (o || !h.focusNode || (!li(a.node, a.offset, h.anchorNode, h.anchorOffset) || !li(c.node, c.offset, h.focusNode, h.focusOffset)) && !this.suppressWidgetCursorChange(h, l)) && (this.view.observer.ignore(() => {
            k.android && k.chrome && this.dom.contains(h.focusNode) && Yu(h.focusNode, this.dom) && (this.dom.blur(), this.dom.focus({
                preventScroll: !0
            }));
            let u = gi(this.view.root);
            if (u)
                if (l.empty) {
                    if (k.gecko) {
                        let f = Uu(a.node, a.offset);
                        if (f && f != 3) {
                            let d = (f == 1 ? ol : ll)(a.node, a.offset);
                            d && (a = new ht(d.node, d.offset))
                        }
                    }
                    u.collapse(a.node, a.offset), l.bidiLevel != null && u.caretBidiLevel !== void 0 && (u.caretBidiLevel = l.bidiLevel)
                } else if (u.extend) {
                u.collapse(a.node, a.offset);
                try {
                    u.extend(c.node, c.offset)
                } catch {}
            } else {
                let f = document.createRange();
                l.anchor > l.head && ([a, c] = [c, a]), f.setEnd(c.node, c.offset), f.setStart(a.node, a.offset), u.removeAllRanges(), u.addRange(f)
            }
            r && this.view.root.activeElement == this.dom && (this.dom.blur(), i && i.focus())
        }), this.view.observer.setSelectionRange(a, c)), this.impreciseAnchor = a.precise ? null : new ht(h.anchorNode, h.anchorOffset), this.impreciseHead = c.precise ? null : new ht(h.focusNode, h.focusOffset)
    }
    suppressWidgetCursorChange(t, e) {
        return this.hasComposition && e.empty && li(t.focusNode, t.focusOffset, t.anchorNode, t.anchorOffset) && this.posFromDOM(t.focusNode, t.focusOffset) == e.head
    }
    enforceCursorAssoc() {
        if (this.hasComposition) return;
        let {
            view: t
        } = this, e = t.state.selection.main, i = gi(t.root), {
            anchorNode: s,
            anchorOffset: r
        } = t.observer.selectionRange;
        if (!i || !e.empty || !e.assoc || !i.modify) return;
        let o = J.find(this, e.head);
        if (!o) return;
        let l = o.posAtStart;
        if (e.head == l || e.head == l + o.length) return;
        let a = this.coordsAt(e.head, -1),
            c = this.coordsAt(e.head, 1);
        if (!a || !c || a.bottom > c.top) return;
        let h = this.domAtPos(e.head + e.assoc);
        i.collapse(h.node, h.offset), i.modify("move", e.assoc < 0 ? "forward" : "backward", "lineboundary"), t.observer.readSelectionRange();
        let u = t.observer.selectionRange;
        t.docView.posFromDOM(u.anchorNode, u.anchorOffset) != e.from && i.collapse(s, r)
    }
    moveToLine(t) {
        let e = this.dom,
            i;
        if (t.node != e) return t;
        for (let s = t.offset; !i && s < e.childNodes.length; s++) {
            let r = j.get(e.childNodes[s]);
            r instanceof J && (i = r.domAtPos(0))
        }
        for (let s = t.offset - 1; !i && s >= 0; s--) {
            let r = j.get(e.childNodes[s]);
            r instanceof J && (i = r.domAtPos(r.length))
        }
        return i ? new ht(i.node, i.offset, !0) : t
    }
    nearest(t) {
        for (let e = t; e;) {
            let i = j.get(e);
            if (i && i.rootView == this) return i;
            e = e.parentNode
        }
        return null
    }
    posFromDOM(t, e) {
        let i = this.nearest(t);
        if (!i) throw new RangeError("Trying to find position for a DOM position outside of the document");
        return i.localPosFromDOM(t, e) + i.posAtStart
    }
    domAtPos(t) {
        let {
            i: e,
            off: i
        } = this.childCursor().findPos(t, -1);
        for (; e < this.children.length - 1;) {
            let s = this.children[e];
            if (i < s.length || s instanceof J) break;
            e++, i = 0
        }
        return this.children[e].domAtPos(i)
    }
    coordsAt(t, e) {
        let i = null,
            s = 0;
        for (let r = this.length, o = this.children.length - 1; o >= 0; o--) {
            let l = this.children[o],
                a = r - l.breakAfter,
                c = a - l.length;
            if (a < t) break;
            if (c <= t && (c < t || l.covers(-1)) && (a > t || l.covers(1)) && (!i || l instanceof J && !(i instanceof J && e >= 0))) i = l, s = c;
            else if (i && c == t && a == t && l instanceof Kt && Math.abs(e) < 2) {
                if (l.deco.startSide < 0) break;
                o && (i = null)
            }
            r = c
        }
        return i ? i.coordsAt(t - s, e) : null
    }
    coordsForChar(t) {
        let {
            i: e,
            off: i
        } = this.childPos(t, 1), s = this.children[e];
        if (!(s instanceof J)) return null;
        for (; s.children.length;) {
            let {
                i: l,
                off: a
            } = s.childPos(i, 1);
            for (;; l++) {
                if (l == s.children.length) return null;
                if ((s = s.children[l]).length) break
            }
            i = a
        }
        if (!(s instanceof Lt)) return null;
        let r = Wt(s.text, i);
        if (r == i) return null;
        let o = ye(s.dom, i, r).getClientRects();
        for (let l = 0; l < o.length; l++) {
            let a = o[l];
            if (l == o.length - 1 || a.top < a.bottom && a.left < a.right) return a
        }
        return null
    }
    measureVisibleLineHeights(t) {
        let e = [],
            {
                from: i,
                to: s
            } = t,
            r = this.view.contentDOM.clientWidth,
            o = r > Math.max(this.view.scrollDOM.clientWidth, this.minWidth) + 1,
            l = -1,
            a = this.view.textDirection == Q.LTR;
        for (let c = 0, h = 0; h < this.children.length; h++) {
            let u = this.children[h],
                f = c + u.length;
            if (f > s) break;
            if (c >= i) {
                let d = u.dom.getBoundingClientRect();
                if (e.push(d.height), o) {
                    let m = u.dom.lastChild,
                        g = m ? Fe(m) : [];
                    if (g.length) {
                        let p = g[g.length - 1],
                            y = a ? p.right - d.left : d.right - p.left;
                        y > l && (l = y, this.minWidth = r, this.minWidthFrom = c, this.minWidthTo = f)
                    }
                }
            }
            c = f + u.breakAfter
        }
        return e
    }
    textDirectionAt(t) {
        let {
            i: e
        } = this.childPos(t, 1);
        return getComputedStyle(this.children[e].dom).direction == "rtl" ? Q.RTL : Q.LTR
    }
    measureTextSize() {
        for (let r of this.children)
            if (r instanceof J) {
                let o = r.measureTextSize();
                if (o) return o
            }
        let t = document.createElement("div"),
            e, i, s;
        return t.className = "cm-line", t.style.width = "99999px", t.style.position = "absolute", t.textContent = "abc def ghi jkl mno pqr stu", this.view.observer.ignore(() => {
            this.dom.appendChild(t);
            let r = Fe(t.firstChild)[0];
            e = t.getBoundingClientRect().height, i = r ? r.width / 27 : 7, s = r ? r.height : e, t.remove()
        }), {
            lineHeight: e,
            charWidth: i,
            textHeight: s
        }
    }
    childCursor(t = this.length) {
        let e = this.children.length;
        return e && (t -= this.children[--e].length), new al(this.children, t, e)
    }
    computeBlockGapDeco() {
        let t = [],
            e = this.view.viewState;
        for (let i = 0, s = 0;; s++) {
            let r = s == e.viewports.length ? null : e.viewports[s],
                o = r ? r.from - 1 : this.length;
            if (o > i) {
                let l = (e.lineBlockAt(o).bottom - e.lineBlockAt(i).top) / this.view.scaleY;
                t.push(B.replace({
                    widget: new Ar(l),
                    block: !0,
                    inclusive: !0,
                    isBlockGap: !0
                }).range(i, o))
            }
            if (!r) break;
            i = r.to + 1
        }
        return B.set(t)
    }
    updateDeco() {
        let t = 1,
            e = this.view.state.facet(pi).map(r => (this.dynamicDecorationMap[t++] = typeof r == "function") ? r(this.view) : r),
            i = !1,
            s = this.view.state.facet(Ll).map((r, o) => {
                let l = typeof r == "function";
                return l && (i = !0), l ? r(this.view) : r
            });
        for (s.length && (this.dynamicDecorationMap[t++] = i, e.push(L.join(s))), this.decorations = [this.editContextFormatting, ...e, this.computeBlockGapDeco(), this.view.viewState.lineGapDeco]; t < this.decorations.length;) this.dynamicDecorationMap[t++] = !1;
        return this.decorations
    }
    scrollIntoView(t) {
        if (t.isSnapshot) {
            let c = this.view.viewState.lineBlockAt(t.range.head);
            this.view.scrollDOM.scrollTop = c.top - t.yMargin, this.view.scrollDOM.scrollLeft = t.xMargin;
            return
        }
        for (let c of this.view.state.facet(Ol)) try {
            if (c(this.view, t.range, t)) return !0
        } catch (h) {
            Ut(this.view.state, h, "scroll handler")
        }
        let {
            range: e
        } = t, i = this.coordsAt(e.head, e.empty ? e.assoc : e.head > e.anchor ? -1 : 1), s;
        if (!i) return;
        !e.empty && (s = this.coordsAt(e.anchor, e.anchor > e.head ? -1 : 1)) && (i = {
            left: Math.min(i.left, s.left),
            top: Math.min(i.top, s.top),
            right: Math.max(i.right, s.right),
            bottom: Math.max(i.bottom, s.bottom)
        });
        let r = Bl(this.view),
            o = {
                left: i.left - r.left,
                top: i.top - r.top,
                right: i.right + r.right,
                bottom: i.bottom + r.bottom
            },
            {
                offsetWidth: l,
                offsetHeight: a
            } = this.view.scrollDOM;
        ku(this.view.scrollDOM, o, e.head < e.anchor ? -1 : 1, t.x, t.y, Math.max(Math.min(t.xMargin, l), -l), Math.max(Math.min(t.yMargin, a), -a), this.view.textDirection == Q.LTR)
    }
}

function _u(n) {
    return n.node.nodeType == 1 && n.node.firstChild && (n.offset == 0 || n.node.childNodes[n.offset - 1].contentEditable == "false") && (n.offset == n.node.childNodes.length || n.node.childNodes[n.offset].contentEditable == "false")
}
class Ar extends qe {
    constructor(t) {
        super(), this.height = t
    }
    toDOM() {
        let t = document.createElement("div");
        return t.className = "cm-gap", this.updateDOM(t), t
    }
    eq(t) {
        return t.height == this.height
    }
    updateDOM(t) {
        return t.style.height = this.height + "px", !0
    }
    get editable() {
        return !0
    }
    get estimatedHeight() {
        return this.height
    }
    ignoreEvent() {
        return !1
    }
}

function Hl(n, t) {
    let e = n.observer.selectionRange;
    if (!e.focusNode) return null;
    let i = ol(e.focusNode, e.focusOffset),
        s = ll(e.focusNode, e.focusOffset),
        r = i || s;
    if (s && i && s.node != i.node) {
        let l = j.get(s.node);
        if (!l || l instanceof Lt && l.text != s.node.nodeValue) r = s;
        else if (n.docView.lastCompositionAfterCursor) {
            let a = j.get(i.node);
            !a || a instanceof Lt && a.text != i.node.nodeValue || (r = s)
        }
    }
    if (n.docView.lastCompositionAfterCursor = r != i, !r) return null;
    let o = t - r.offset;
    return {
        from: o,
        to: o + r.node.nodeValue.length,
        node: r.node
    }
}

function $u(n, t, e) {
    let i = Hl(n, e);
    if (!i) return null;
    let {
        node: s,
        from: r,
        to: o
    } = i, l = s.nodeValue;
    if (/[\n\r]/.test(l) || n.state.doc.sliceString(i.from, i.to) != l) return null;
    let a = t.invertedDesc,
        c = new Mt(a.mapPos(r), a.mapPos(o), r, o),
        h = [];
    for (let u = s.parentNode;; u = u.parentNode) {
        let f = j.get(u);
        if (f instanceof Xt) h.push({
            node: u,
            deco: f.mark
        });
        else {
            if (f instanceof J || u.nodeName == "DIV" && u.parentNode == n.contentDOM) return {
                range: c,
                text: s,
                marks: h,
                line: u
            };
            if (u != n.contentDOM) h.push({
                node: u,
                deco: new Si({
                    inclusive: !0,
                    attributes: Pu(u),
                    tagName: u.tagName.toLowerCase()
                })
            });
            else return null
        }
    }
}

function Uu(n, t) {
    return n.nodeType != 1 ? 0 : (t && n.childNodes[t - 1].contentEditable == "false" ? 1 : 0) | (t < n.childNodes.length && n.childNodes[t].contentEditable == "false" ? 2 : 0)
}
let Gu = class {
    constructor() {
        this.changes = []
    }
    compareRange(t, e) {
        ls(t, e, this.changes)
    }
    comparePoint(t, e) {
        ls(t, e, this.changes)
    }
};

function Ku(n, t, e) {
    let i = new Gu;
    return L.compare(n, t, e, i), i.changes
}

function Yu(n, t) {
    for (let e = n; e && e != t; e = e.assignedSlot || e.parentNode)
        if (e.nodeType == 1 && e.contentEditable == "false") return !0;
    return !1
}

function Xu(n, t) {
    let e = !1;
    return t && n.iterChangedRanges((i, s) => {
        i < t.to && s > t.from && (e = !0)
    }), e
}

function Ju(n, t, e = 1) {
    let i = n.charCategorizer(t),
        s = n.doc.lineAt(t),
        r = t - s.from;
    if (s.length == 0) return A.cursor(t);
    r == 0 ? e = 1 : r == s.length && (e = -1);
    let o = r,
        l = r;
    e < 0 ? o = Wt(s.text, r, !1) : l = Wt(s.text, r);
    let a = i(s.text.slice(o, l));
    for (; o > 0;) {
        let c = Wt(s.text, o, !1);
        if (i(s.text.slice(c, o)) != a) break;
        o = c
    }
    for (; l < s.length;) {
        let c = Wt(s.text, l);
        if (i(s.text.slice(l, c)) != a) break;
        l = c
    }
    return A.range(o + s.from, l + s.from)
}

function Qu(n, t) {
    return t.left > n ? t.left - n : Math.max(0, n - t.right)
}

function Zu(n, t) {
    return t.top > n ? t.top - n : Math.max(0, n - t.bottom)
}

function Tn(n, t) {
    return n.top < t.bottom - 1 && n.bottom > t.top + 1
}

function Tr(n, t) {
    return t < n.top ? {
        top: t,
        left: n.left,
        right: n.right,
        bottom: n.bottom
    } : n
}

function Er(n, t) {
    return t > n.bottom ? {
        top: n.top,
        left: n.left,
        right: n.right,
        bottom: t
    } : n
}

function fs(n, t, e) {
    let i, s, r, o, l = !1,
        a, c, h, u;
    for (let m = n.firstChild; m; m = m.nextSibling) {
        let g = Fe(m);
        for (let p = 0; p < g.length; p++) {
            let y = g[p];
            s && Tn(s, y) && (y = Tr(Er(y, s.bottom), s.top));
            let b = Qu(t, y),
                v = Zu(e, y);
            if (b == 0 && v == 0) return m.nodeType == 3 ? Dr(m, t, e) : fs(m, t, e);
            if (!i || o > v || o == v && r > b) {
                i = m, s = y, r = b, o = v;
                let w = v ? e < y.top ? -1 : 1 : b ? t < y.left ? -1 : 1 : 0;
                l = !w || (w > 0 ? p < g.length - 1 : p > 0)
            }
            b == 0 ? e > y.bottom && (!h || h.bottom < y.bottom) ? (a = m, h = y) : e < y.top && (!u || u.top > y.top) && (c = m, u = y) : h && Tn(h, y) ? h = Er(h, y.bottom) : u && Tn(u, y) && (u = Tr(u, y.top))
        }
    }
    if (h && h.bottom >= e ? (i = a, s = h) : u && u.top <= e && (i = c, s = u), !i) return {
        node: n,
        offset: 0
    };
    let f = Math.max(s.left, Math.min(s.right, t));
    if (i.nodeType == 3) return Dr(i, f, e);
    if (l && i.contentEditable != "false") return fs(i, f, e);
    let d = Array.prototype.indexOf.call(n.childNodes, i) + (t >= (s.left + s.right) / 2 ? 1 : 0);
    return {
        node: n,
        offset: d
    }
}

function Dr(n, t, e) {
    let i = n.nodeValue.length,
        s = -1,
        r = 1e9,
        o = 0;
    for (let l = 0; l < i; l++) {
        let a = ye(n, l, l + 1).getClientRects();
        for (let c = 0; c < a.length; c++) {
            let h = a[c];
            if (h.top == h.bottom) continue;
            o || (o = t - h.left);
            let u = (h.top > e ? h.top - e : e - h.bottom) - 1;
            if (h.left - 1 <= t && h.right + 1 >= t && u < r) {
                let f = t >= (h.left + h.right) / 2,
                    d = f;
                if ((k.chrome || k.gecko) && ye(n, l).getBoundingClientRect().left == h.right && (d = !f), u <= 0) return {
                    node: n,
                    offset: l + (d ? 1 : 0)
                };
                s = l + (d ? 1 : 0), r = u
            }
        }
    }
    return {
        node: n,
        offset: s > -1 ? s : o > 0 ? n.nodeValue.length : 0
    }
}

function Vl(n, t, e, i = -1) {
    var s, r;
    let o = n.contentDOM.getBoundingClientRect(),
        l = o.top + n.viewState.paddingTop,
        a, {
            docHeight: c
        } = n.viewState,
        {
            x: h,
            y: u
        } = t,
        f = u - l;
    if (f < 0) return 0;
    if (f > c) return n.state.doc.length;
    for (let w = n.viewState.heightOracle.textHeight / 2, S = !1; a = n.elementAtHeight(f), a.type != dt.Text;)
        for (; f = i > 0 ? a.bottom + w : a.top - w, !(f >= 0 && f <= c);) {
            if (S) return e ? null : 0;
            S = !0, i = -i
        }
    u = l + f;
    let d = a.from;
    if (d < n.viewport.from) return n.viewport.from == 0 ? 0 : e ? null : Or(n, o, a, h, u);
    if (d > n.viewport.to) return n.viewport.to == n.state.doc.length ? n.state.doc.length : e ? null : Or(n, o, a, h, u);
    let m = n.dom.ownerDocument,
        g = n.root.elementFromPoint ? n.root : m,
        p = g.elementFromPoint(h, u);
    p && !n.contentDOM.contains(p) && (p = null), p || (h = Math.max(o.left + 1, Math.min(o.right - 1, h)), p = g.elementFromPoint(h, u), p && !n.contentDOM.contains(p) && (p = null));
    let y, b = -1;
    if (p && ((s = n.docView.nearest(p)) === null || s === void 0 ? void 0 : s.isEditable) != !1) {
        if (m.caretPositionFromPoint) {
            let w = m.caretPositionFromPoint(h, u);
            w && ({
                offsetNode: y,
                offset: b
            } = w)
        } else if (m.caretRangeFromPoint) {
            let w = m.caretRangeFromPoint(h, u);
            w && ({
                startContainer: y,
                startOffset: b
            } = w, (!n.contentDOM.contains(y) || k.safari && tf(y, b, h) || k.chrome && ef(y, b, h)) && (y = void 0))
        }
    }
    if (!y || !n.docView.dom.contains(y)) {
        let w = J.find(n.docView, d);
        if (!w) return f > a.top + a.height / 2 ? a.to : a.from;
        ({
            node: y,
            offset: b
        } = fs(w.dom, h, u))
    }
    let v = n.docView.nearest(y);
    if (!v) return null;
    if (v.isWidget && ((r = v.dom) === null || r === void 0 ? void 0 : r.nodeType) == 1) {
        let w = v.dom.getBoundingClientRect();
        return t.y < w.top || t.y <= w.bottom && t.x <= (w.left + w.right) / 2 ? v.posAtStart : v.posAtEnd
    } else return v.localPosFromDOM(y, b) + v.posAtStart
}

function Or(n, t, e, i, s) {
    let r = Math.round((i - t.left) * n.defaultCharacterWidth);
    if (n.lineWrapping && e.height > n.defaultLineHeight * 1.5) {
        let l = n.viewState.heightOracle.textHeight,
            a = Math.floor((s - e.top - (n.defaultLineHeight - l) * .5) / l);
        r += a * n.viewState.heightOracle.lineLength
    }
    let o = n.state.sliceDoc(e.from, e.to);
    return e.from + wu(o, r, n.state.tabSize)
}

function tf(n, t, e) {
    let i;
    if (n.nodeType != 3 || t != (i = n.nodeValue.length)) return !1;
    for (let s = n.nextSibling; s; s = s.nextSibling)
        if (s.nodeType != 1 || s.nodeName != "BR") return !1;
    return ye(n, i - 1, i).getBoundingClientRect().left > e
}

function ef(n, t, e) {
    if (t != 0) return !1;
    for (let s = n;;) {
        let r = s.parentNode;
        if (!r || r.nodeType != 1 || r.firstChild != s) return !1;
        if (r.classList.contains("cm-line")) break;
        s = r
    }
    let i = n.nodeType == 1 ? n.getBoundingClientRect() : ye(n, 0, Math.max(n.nodeValue.length, 1)).getBoundingClientRect();
    return e - i.left > 5
}

function ds(n, t) {
    let e = n.lineBlockAt(t);
    if (Array.isArray(e.type)) {
        for (let i of e.type)
            if (i.to > t || i.to == t && (i.to == e.to || i.type == dt.Text)) return i
    }
    return e
}

function nf(n, t, e, i) {
    let s = ds(n, t.head),
        r = !i || s.type != dt.Text || !(n.lineWrapping || s.widgetLineBreaks) ? null : n.coordsAtPos(t.assoc < 0 && t.head > s.from ? t.head - 1 : t.head);
    if (r) {
        let o = n.dom.getBoundingClientRect(),
            l = n.textDirectionAt(s.from),
            a = n.posAtCoords({
                x: e == (l == Q.LTR) ? o.right - 1 : o.left + 1,
                y: (r.top + r.bottom) / 2
            });
        if (a != null) return A.cursor(a, e ? -1 : 1)
    }
    return A.cursor(e ? s.to : s.from, e ? -1 : 1)
}

function Rr(n, t, e, i) {
    let s = n.state.doc.lineAt(t.head),
        r = n.bidiSpans(s),
        o = n.textDirectionAt(s.from);
    for (let l = t, a = null;;) {
        let c = Wu(s, r, o, l, e),
            h = vl;
        if (!c) {
            if (s.number == (e ? n.state.doc.lines : 1)) return l;
            h = `
`, s = n.state.doc.line(s.number + (e ? 1 : -1)), r = n.bidiSpans(s), c = n.visualLineSide(s, !e)
        }
        if (a) {
            if (!a(h)) return l
        } else {
            if (!i) return c;
            a = i(h)
        }
        l = c
    }
}

function sf(n, t, e) {
    let i = n.state.charCategorizer(t),
        s = i(e);
    return r => {
        let o = i(r);
        return s == $t.Space && (s = o), s == o
    }
}

function rf(n, t, e, i) {
    let s = t.head,
        r = e ? 1 : -1;
    if (s == (e ? n.state.doc.length : 0)) return A.cursor(s, t.assoc);
    let o = t.goalColumn,
        l, a = n.contentDOM.getBoundingClientRect(),
        c = n.coordsAtPos(s, t.assoc || -1),
        h = n.documentTop;
    if (c) o == null && (o = c.left - a.left), l = r < 0 ? c.top : c.bottom;
    else {
        let d = n.viewState.lineBlockAt(s);
        o == null && (o = Math.min(a.right - a.left, n.defaultCharacterWidth * (s - d.from))), l = (r < 0 ? d.top : d.bottom) + h
    }
    let u = a.left + o,
        f = i ? ? n.viewState.heightOracle.textHeight >> 1;
    for (let d = 0;; d += 10) {
        let m = l + (f + d) * r,
            g = Vl(n, {
                x: u,
                y: m
            }, !1, r);
        if (m < a.top || m > a.bottom || (r < 0 ? g < s : g > s)) {
            let p = n.docView.coordsForChar(g),
                y = !p || m < p.top ? -1 : 1;
            return A.cursor(g, y, void 0, o)
        }
    }
}

function $i(n, t, e) {
    for (;;) {
        let i = 0;
        for (let s of n) s.between(t - 1, t + 1, (r, o, l) => {
            if (t > r && t < o) {
                let a = i || e || (t - r < o - t ? -1 : 1);
                t = a < 0 ? r : o, i = a
            }
        });
        if (!i) return t
    }
}

function En(n, t, e) {
    let i = $i(n.state.facet(js).map(s => s(n)), e.from, t.head > e.from ? -1 : 1);
    return i == e.from ? e : A.cursor(i, i < e.from ? 1 : -1)
}
class of {
    setSelectionOrigin(t) {
        this.lastSelectionOrigin = t, this.lastSelectionTime = Date.now()
    }
    constructor(t) {
        this.view = t, this.lastKeyCode = 0, this.lastKeyTime = 0, this.lastTouchTime = 0, this.lastFocusTime = 0, this.lastScrollTop = 0, this.lastScrollLeft = 0, this.pendingIOSKey = void 0, this.tabFocusMode = -1, this.lastSelectionOrigin = null, this.lastSelectionTime = 0, this.lastContextMenu = 0, this.scrollHandlers = [], this.handlers = Object.create(null), this.composing = -1, this.compositionFirstChange = null, this.compositionEndedAt = 0, this.compositionPendingKey = !1, this.compositionPendingChange = !1, this.mouseSelection = null, this.draggedContent = null, this.handleEvent = this.handleEvent.bind(this), this.notifiedFocused = t.hasFocus, k.safari && t.contentDOM.addEventListener("input", () => null), k.gecko && Cf(t.contentDOM.ownerDocument)
    }
    handleEvent(t) {
        !mf(this.view, t) || this.ignoreDuringComposition(t) || t.type == "keydown" && this.keydown(t) || this.runHandlers(t.type, t)
    }
    runHandlers(t, e) {
        let i = this.handlers[t];
        if (i) {
            for (let s of i.observers) s(this.view, e);
            for (let s of i.handlers) {
                if (e.defaultPrevented) break;
                if (s(this.view, e)) {
                    e.preventDefault();
                    break
                }
            }
        }
    }
    ensureHandlers(t) {
        let e = lf(t),
            i = this.handlers,
            s = this.view.contentDOM;
        for (let r in e)
            if (r != "scroll") {
                let o = !e[r].handlers.length,
                    l = i[r];
                l && o != !l.handlers.length && (s.removeEventListener(r, this.handleEvent), l = null), l || s.addEventListener(r, this.handleEvent, {
                    passive: o
                })
            }
        for (let r in i) r != "scroll" && !e[r] && s.removeEventListener(r, this.handleEvent);
        this.handlers = e
    }
    keydown(t) {
        if (this.lastKeyCode = t.keyCode, this.lastKeyTime = Date.now(), t.keyCode == 9 && this.tabFocusMode > -1 && (!this.tabFocusMode || Date.now() <= this.tabFocusMode)) return !0;
        if (this.tabFocusMode > 0 && t.keyCode != 27 && jl.indexOf(t.keyCode) < 0 && (this.tabFocusMode = -1), k.android && k.chrome && !t.synthetic && (t.keyCode == 13 || t.keyCode == 8)) return this.view.observer.delayAndroidKey(t.key, t.keyCode), !0;
        let e;
        return k.ios && !t.synthetic && !t.altKey && !t.metaKey && ((e = Fl.find(i => i.keyCode == t.keyCode)) && !t.ctrlKey || af.indexOf(t.key) > -1 && t.ctrlKey && !t.shiftKey) ? (this.pendingIOSKey = e || t, setTimeout(() => this.flushIOSKey(), 250), !0) : (t.keyCode != 229 && this.view.observer.forceFlush(), !1)
    }
    flushIOSKey(t) {
        let e = this.pendingIOSKey;
        return !e || e.key == "Enter" && t && t.from < t.to && /^\S+$/.test(t.insert.toString()) ? !1 : (this.pendingIOSKey = void 0, Re(this.view.contentDOM, e.key, e.keyCode, e instanceof KeyboardEvent ? e : void 0))
    }
    ignoreDuringComposition(t) {
        return /^key/.test(t.type) ? this.composing > 0 ? !0 : k.safari && !k.ios && this.compositionPendingKey && Date.now() - this.compositionEndedAt < 100 ? (this.compositionPendingKey = !1, !0) : !1 : !1
    }
    startMouseSelection(t) {
        this.mouseSelection && this.mouseSelection.destroy(), this.mouseSelection = t
    }
    update(t) {
        this.view.observer.update(t), this.mouseSelection && this.mouseSelection.update(t), this.draggedContent && t.docChanged && (this.draggedContent = this.draggedContent.map(t.changes)), t.transactions.length && (this.lastKeyCode = this.lastSelectionTime = 0)
    }
    destroy() {
        this.mouseSelection && this.mouseSelection.destroy()
    }
}

function Pr(n, t) {
    return (e, i) => {
        try {
            return t.call(n, i, e)
        } catch (s) {
            Ut(e.state, s)
        }
    }
}

function lf(n) {
    let t = Object.create(null);

    function e(i) {
        return t[i] || (t[i] = {
            observers: [],
            handlers: []
        })
    }
    for (let i of n) {
        let s = i.spec;
        if (s && s.domEventHandlers)
            for (let r in s.domEventHandlers) {
                let o = s.domEventHandlers[r];
                o && e(r).handlers.push(Pr(i.value, o))
            }
        if (s && s.domEventObservers)
            for (let r in s.domEventObservers) {
                let o = s.domEventObservers[r];
                o && e(r).observers.push(Pr(i.value, o))
            }
    }
    for (let i in It) e(i).handlers.push(It[i]);
    for (let i in At) e(i).observers.push(At[i]);
    return t
}
const Fl = [{
        key: "Backspace",
        keyCode: 8,
        inputType: "deleteContentBackward"
    }, {
        key: "Enter",
        keyCode: 13,
        inputType: "insertParagraph"
    }, {
        key: "Enter",
        keyCode: 13,
        inputType: "insertLineBreak"
    }, {
        key: "Delete",
        keyCode: 46,
        inputType: "deleteContentForward"
    }],
    af = "dthko",
    jl = [16, 17, 18, 20, 91, 92, 224, 225],
    Li = 6;

function Ni(n) {
    return Math.max(0, n) * .7 + 8
}

function hf(n, t) {
    return Math.max(Math.abs(n.clientX - t.clientX), Math.abs(n.clientY - t.clientY))
}
class cf {
    constructor(t, e, i, s) {
        this.view = t, this.startEvent = e, this.style = i, this.mustSelect = s, this.scrollSpeed = {
            x: 0,
            y: 0
        }, this.scrolling = -1, this.lastEvent = e, this.scrollParents = Mu(t.contentDOM), this.atoms = t.state.facet(js).map(o => o(t));
        let r = t.contentDOM.ownerDocument;
        r.addEventListener("mousemove", this.move = this.move.bind(this)), r.addEventListener("mouseup", this.up = this.up.bind(this)), this.extend = e.shiftKey, this.multiple = t.state.facet(q.allowMultipleSelections) && uf(t, e), this.dragging = df(t, e) && _l(e) == 1 ? null : !1
    }
    start(t) {
        this.dragging === !1 && this.select(t)
    }
    move(t) {
        if (t.buttons == 0) return this.destroy();
        if (this.dragging || this.dragging == null && hf(this.startEvent, t) < 10) return;
        this.select(this.lastEvent = t);
        let e = 0,
            i = 0,
            s = 0,
            r = 0,
            o = this.view.win.innerWidth,
            l = this.view.win.innerHeight;
        this.scrollParents.x && ({
            left: s,
            right: o
        } = this.scrollParents.x.getBoundingClientRect()), this.scrollParents.y && ({
            top: r,
            bottom: l
        } = this.scrollParents.y.getBoundingClientRect());
        let a = Bl(this.view);
        t.clientX - a.left <= s + Li ? e = -Ni(s - t.clientX) : t.clientX + a.right >= o - Li && (e = Ni(t.clientX - o)), t.clientY - a.top <= r + Li ? i = -Ni(r - t.clientY) : t.clientY + a.bottom >= l - Li && (i = Ni(t.clientY - l)), this.setScrollSpeed(e, i)
    }
    up(t) {
        this.dragging == null && this.select(this.lastEvent), this.dragging || t.preventDefault(), this.destroy()
    }
    destroy() {
        this.setScrollSpeed(0, 0);
        let t = this.view.contentDOM.ownerDocument;
        t.removeEventListener("mousemove", this.move), t.removeEventListener("mouseup", this.up), this.view.inputState.mouseSelection = this.view.inputState.draggedContent = null
    }
    setScrollSpeed(t, e) {
        this.scrollSpeed = {
            x: t,
            y: e
        }, t || e ? this.scrolling < 0 && (this.scrolling = setInterval(() => this.scroll(), 50)) : this.scrolling > -1 && (clearInterval(this.scrolling), this.scrolling = -1)
    }
    scroll() {
        let {
            x: t,
            y: e
        } = this.scrollSpeed;
        t && this.scrollParents.x && (this.scrollParents.x.scrollLeft += t, t = 0), e && this.scrollParents.y && (this.scrollParents.y.scrollTop += e, e = 0), (t || e) && this.view.win.scrollBy(t, e), this.dragging === !1 && this.select(this.lastEvent)
    }
    skipAtoms(t) {
        let e = null;
        for (let i = 0; i < t.ranges.length; i++) {
            let s = t.ranges[i],
                r = null;
            if (s.empty) {
                let o = $i(this.atoms, s.from, 0);
                o != s.from && (r = A.cursor(o, -1))
            } else {
                let o = $i(this.atoms, s.from, -1),
                    l = $i(this.atoms, s.to, 1);
                (o != s.from || l != s.to) && (r = A.range(s.from == s.anchor ? o : l, s.from == s.head ? o : l))
            }
            r && (e || (e = t.ranges.slice()), e[i] = r)
        }
        return e ? A.create(e, t.mainIndex) : t
    }
    select(t) {
        let {
            view: e
        } = this, i = this.skipAtoms(this.style.get(t, this.extend, this.multiple));
        (this.mustSelect || !i.eq(e.state.selection, this.dragging === !1)) && this.view.dispatch({
            selection: i,
            userEvent: "select.pointer"
        }), this.mustSelect = !1
    }
    update(t) {
        t.transactions.some(e => e.isUserEvent("input.type")) ? this.destroy() : this.style.update(t) && setTimeout(() => this.select(this.lastEvent), 20)
    }
}

function uf(n, t) {
    let e = n.state.facet(Cl);
    return e.length ? e[0](t) : k.mac ? t.metaKey : t.ctrlKey
}

function ff(n, t) {
    let e = n.state.facet(Sl);
    return e.length ? e[0](t) : k.mac ? !t.altKey : !t.ctrlKey
}

function df(n, t) {
    let {
        main: e
    } = n.state.selection;
    if (e.empty) return !1;
    let i = gi(n.root);
    if (!i || i.rangeCount == 0) return !0;
    let s = i.getRangeAt(0).getClientRects();
    for (let r = 0; r < s.length; r++) {
        let o = s[r];
        if (o.left <= t.clientX && o.right >= t.clientX && o.top <= t.clientY && o.bottom >= t.clientY) return !0
    }
    return !1
}

function mf(n, t) {
    if (!t.bubbles) return !0;
    if (t.defaultPrevented) return !1;
    for (let e = t.target, i; e != n.contentDOM; e = e.parentNode)
        if (!e || e.nodeType == 11 || (i = j.get(e)) && i.ignoreEvent(t)) return !1;
    return !0
}
const It = Object.create(null),
    At = Object.create(null),
    Wl = k.ie && k.ie_version < 15 || k.ios && k.webkit_version < 604;

function gf(n) {
    let t = n.dom.parentNode;
    if (!t) return;
    let e = t.appendChild(document.createElement("textarea"));
    e.style.cssText = "position: fixed; left: -10000px; top: 10px", e.focus(), setTimeout(() => {
        n.focus(), e.remove(), zl(n, e.value)
    }, 50)
}

function zl(n, t) {
    let {
        state: e
    } = n, i, s = 1, r = e.toText(t), o = r.lines == e.selection.ranges.length;
    if (ms != null && e.selection.ranges.every(a => a.empty) && ms == r.toString()) {
        let a = -1;
        i = e.changeByRange(c => {
            let h = e.doc.lineAt(c.from);
            if (h.from == a) return {
                range: c
            };
            a = h.from;
            let u = e.toText((o ? r.line(s++).text : t) + e.lineBreak);
            return {
                changes: {
                    from: h.from,
                    insert: u
                },
                range: A.cursor(c.from + u.length)
            }
        })
    } else o ? i = e.changeByRange(a => {
        let c = r.line(s++);
        return {
            changes: {
                from: a.from,
                to: a.to,
                insert: c.text
            },
            range: A.cursor(a.from + c.length)
        }
    }) : i = e.replaceSelection(r);
    n.dispatch(i, {
        userEvent: "input.paste",
        scrollIntoView: !0
    })
}
At.scroll = n => {
    n.inputState.lastScrollTop = n.scrollDOM.scrollTop, n.inputState.lastScrollLeft = n.scrollDOM.scrollLeft
};
It.keydown = (n, t) => (n.inputState.setSelectionOrigin("select"), t.keyCode == 27 && n.inputState.tabFocusMode != 0 && (n.inputState.tabFocusMode = Date.now() + 2e3), !1);
At.touchstart = (n, t) => {
    n.inputState.lastTouchTime = Date.now(), n.inputState.setSelectionOrigin("select.pointer")
};
At.touchmove = n => {
    n.inputState.setSelectionOrigin("select.pointer")
};
It.mousedown = (n, t) => {
    if (n.observer.flush(), n.inputState.lastTouchTime > Date.now() - 2e3) return !1;
    let e = null;
    for (let i of n.state.facet(kl))
        if (e = i(n, t), e) break;
    if (!e && t.button == 0 && (e = xf(n, t)), e) {
        let i = !n.hasFocus;
        n.inputState.startMouseSelection(new cf(n, t, e, i)), i && n.observer.ignore(() => {
            nl(n.contentDOM);
            let r = n.root.activeElement;
            r && !r.contains(n.contentDOM) && r.blur()
        });
        let s = n.inputState.mouseSelection;
        if (s) return s.start(t), s.dragging === !1
    }
    return !1
};

function Lr(n, t, e, i) {
    if (i == 1) return A.cursor(t, e);
    if (i == 2) return Ju(n.state, t, e); {
        let s = J.find(n.docView, t),
            r = n.state.doc.lineAt(s ? s.posAtEnd : t),
            o = s ? s.posAtStart : r.from,
            l = s ? s.posAtEnd : r.to;
        return l < n.state.doc.length && l == r.to && l++, A.range(o, l)
    }
}
let ql = (n, t) => n >= t.top && n <= t.bottom,
    Nr = (n, t, e) => ql(t, e) && n >= e.left && n <= e.right;

function pf(n, t, e, i) {
    let s = J.find(n.docView, t);
    if (!s) return 1;
    let r = t - s.posAtStart;
    if (r == 0) return 1;
    if (r == s.length) return -1;
    let o = s.coordsAt(r, -1);
    if (o && Nr(e, i, o)) return -1;
    let l = s.coordsAt(r, 1);
    return l && Nr(e, i, l) ? 1 : o && ql(i, o) ? -1 : 1
}

function Ir(n, t) {
    let e = n.posAtCoords({
        x: t.clientX,
        y: t.clientY
    }, !1);
    return {
        pos: e,
        bias: pf(n, e, t.clientX, t.clientY)
    }
}
const yf = k.ie && k.ie_version <= 11;
let Br = null,
    Hr = 0,
    Vr = 0;

function _l(n) {
    if (!yf) return n.detail;
    let t = Br,
        e = Vr;
    return Br = n, Vr = Date.now(), Hr = !t || e > Date.now() - 400 && Math.abs(t.clientX - n.clientX) < 2 && Math.abs(t.clientY - n.clientY) < 2 ? (Hr + 1) % 3 : 1
}

function xf(n, t) {
    let e = Ir(n, t),
        i = _l(t),
        s = n.state.selection;
    return {
        update(r) {
            r.docChanged && (e.pos = r.changes.mapPos(e.pos), s = s.map(r.changes))
        },
        get(r, o, l) {
            let a = Ir(n, r),
                c, h = Lr(n, a.pos, a.bias, i);
            if (e.pos != a.pos && !o) {
                let u = Lr(n, e.pos, e.bias, i),
                    f = Math.min(u.from, h.from),
                    d = Math.max(u.to, h.to);
                h = f < h.from ? A.range(f, d) : A.range(d, f)
            }
            return o ? s.replaceRange(s.main.extend(h.from, h.to)) : l && i == 1 && s.ranges.length > 1 && (c = bf(s, a.pos)) ? c : l ? s.addRange(h) : A.create([h])
        }
    }
}

function bf(n, t) {
    for (let e = 0; e < n.ranges.length; e++) {
        let {
            from: i,
            to: s
        } = n.ranges[e];
        if (i <= t && s >= t) return A.create(n.ranges.slice(0, e).concat(n.ranges.slice(e + 1)), n.mainIndex == e ? 0 : n.mainIndex - (n.mainIndex > e ? 1 : 0))
    }
    return null
}
It.dragstart = (n, t) => {
    let {
        selection: {
            main: e
        }
    } = n.state;
    if (t.target.draggable) {
        let s = n.docView.nearest(t.target);
        if (s && s.isWidget) {
            let r = s.posAtStart,
                o = r + s.length;
            (r >= e.to || o <= e.from) && (e = A.range(r, o))
        }
    }
    let {
        inputState: i
    } = n;
    return i.mouseSelection && (i.mouseSelection.dragging = !0), i.draggedContent = e, t.dataTransfer && (t.dataTransfer.setData("Text", n.state.sliceDoc(e.from, e.to)), t.dataTransfer.effectAllowed = "copyMove"), !1
};
It.dragend = n => (n.inputState.draggedContent = null, !1);

function Fr(n, t, e, i) {
    if (!e) return;
    let s = n.posAtCoords({
            x: t.clientX,
            y: t.clientY
        }, !1),
        {
            draggedContent: r
        } = n.inputState,
        o = i && r && ff(n, t) ? {
            from: r.from,
            to: r.to
        } : null,
        l = {
            from: s,
            insert: e
        },
        a = n.state.changes(o ? [o, l] : l);
    n.focus(), n.dispatch({
        changes: a,
        selection: {
            anchor: a.mapPos(s, -1),
            head: a.mapPos(s, 1)
        },
        userEvent: o ? "move.drop" : "input.drop"
    }), n.inputState.draggedContent = null
}
It.drop = (n, t) => {
    if (!t.dataTransfer) return !1;
    if (n.state.readOnly) return !0;
    let e = t.dataTransfer.files;
    if (e && e.length) {
        let i = Array(e.length),
            s = 0,
            r = () => {
                ++s == e.length && Fr(n, t, i.filter(o => o != null).join(n.state.lineBreak), !1)
            };
        for (let o = 0; o < e.length; o++) {
            let l = new FileReader;
            l.onerror = r, l.onload = () => {
                /[\x00-\x08\x0e-\x1f]{2}/.test(l.result) || (i[o] = l.result), r()
            }, l.readAsText(e[o])
        }
        return !0
    } else {
        let i = t.dataTransfer.getData("Text");
        if (i) return Fr(n, t, i, !0), !0
    }
    return !1
};
It.paste = (n, t) => {
    if (n.state.readOnly) return !0;
    n.observer.flush();
    let e = Wl ? null : t.clipboardData;
    return e ? (zl(n, e.getData("text/plain") || e.getData("text/uri-list")), !0) : (gf(n), !1)
};

function wf(n, t) {
    let e = n.dom.parentNode;
    if (!e) return;
    let i = e.appendChild(document.createElement("textarea"));
    i.style.cssText = "position: fixed; left: -10000px; top: 10px", i.value = t, i.focus(), i.selectionEnd = t.length, i.selectionStart = 0, setTimeout(() => {
        i.remove(), n.focus()
    }, 50)
}

function vf(n) {
    let t = [],
        e = [],
        i = !1;
    for (let s of n.selection.ranges) s.empty || (t.push(n.sliceDoc(s.from, s.to)), e.push(s));
    if (!t.length) {
        let s = -1;
        for (let {
                from: r
            } of n.selection.ranges) {
            let o = n.doc.lineAt(r);
            o.number > s && (t.push(o.text), e.push({
                from: o.from,
                to: Math.min(n.doc.length, o.to + 1)
            })), s = o.number
        }
        i = !0
    }
    return {
        text: t.join(n.lineBreak),
        ranges: e,
        linewise: i
    }
}
let ms = null;
It.copy = It.cut = (n, t) => {
    let {
        text: e,
        ranges: i,
        linewise: s
    } = vf(n.state);
    if (!e && !s) return !1;
    ms = s ? e : null, t.type == "cut" && !n.state.readOnly && n.dispatch({
        changes: i,
        scrollIntoView: !0,
        userEvent: "delete.cut"
    });
    let r = Wl ? null : t.clipboardData;
    return r ? (r.clearData(), r.setData("text/plain", e), !0) : (wf(n, e), !1)
};
const $l = ze.define();

function Ul(n, t) {
    let e = [];
    for (let i of n.facet(Tl)) {
        let s = i(n, t);
        s && e.push(s)
    }
    return e ? n.update({
        effects: e,
        annotations: $l.of(!0)
    }) : null
}

function Gl(n) {
    setTimeout(() => {
        let t = n.hasFocus;
        if (t != n.inputState.notifiedFocused) {
            let e = Ul(n.state, t);
            e ? n.dispatch(e) : n.update([])
        }
    }, 10)
}
At.focus = n => {
    n.inputState.lastFocusTime = Date.now(), !n.scrollDOM.scrollTop && (n.inputState.lastScrollTop || n.inputState.lastScrollLeft) && (n.scrollDOM.scrollTop = n.inputState.lastScrollTop, n.scrollDOM.scrollLeft = n.inputState.lastScrollLeft), Gl(n)
};
At.blur = n => {
    n.observer.clearSelectionRange(), Gl(n)
};
At.compositionstart = At.compositionupdate = n => {
    n.observer.editContext || (n.inputState.compositionFirstChange == null && (n.inputState.compositionFirstChange = !0), n.inputState.composing < 0 && (n.inputState.composing = 0))
};
At.compositionend = n => {
    n.observer.editContext || (n.inputState.composing = -1, n.inputState.compositionEndedAt = Date.now(), n.inputState.compositionPendingKey = !0, n.inputState.compositionPendingChange = n.observer.pendingRecords().length > 0, n.inputState.compositionFirstChange = null, k.chrome && k.android ? n.observer.flushSoon() : n.inputState.compositionPendingChange ? Promise.resolve().then(() => n.observer.flush()) : setTimeout(() => {
        n.inputState.composing < 0 && n.docView.hasComposition && n.update([])
    }, 50))
};
At.contextmenu = n => {
    n.inputState.lastContextMenu = Date.now()
};
It.beforeinput = (n, t) => {
    var e;
    let i;
    if (k.chrome && k.android && (i = Fl.find(s => s.inputType == t.inputType)) && (n.observer.delayAndroidKey(i.key, i.keyCode), i.key == "Backspace" || i.key == "Delete")) {
        let s = ((e = window.visualViewport) === null || e === void 0 ? void 0 : e.height) || 0;
        setTimeout(() => {
            var r;
            (((r = window.visualViewport) === null || r === void 0 ? void 0 : r.height) || 0) > s + 10 && n.hasFocus && (n.contentDOM.blur(), n.focus())
        }, 100)
    }
    return k.ios && t.inputType == "deleteContentForward" && n.observer.flushSoon(), k.safari && t.inputType == "insertText" && n.inputState.composing >= 0 && setTimeout(() => At.compositionend(n, t), 20), !1
};
const jr = new Set;

function Cf(n) {
    jr.has(n) || (jr.add(n), n.addEventListener("copy", () => {}), n.addEventListener("cut", () => {}))
}
const Wr = ["pre-wrap", "normal", "pre-line", "break-spaces"];
class Sf {
    constructor(t) {
        this.lineWrapping = t, this.doc = N.empty, this.heightSamples = {}, this.lineHeight = 14, this.charWidth = 7, this.textHeight = 14, this.lineLength = 30, this.heightChanged = !1
    }
    heightForGap(t, e) {
        let i = this.doc.lineAt(e).number - this.doc.lineAt(t).number + 1;
        return this.lineWrapping && (i += Math.max(0, Math.ceil((e - t - i * this.lineLength * .5) / this.lineLength))), this.lineHeight * i
    }
    heightForLine(t) {
        return this.lineWrapping ? (1 + Math.max(0, Math.ceil((t - this.lineLength) / (this.lineLength - 5)))) * this.lineHeight : this.lineHeight
    }
    setDoc(t) {
        return this.doc = t, this
    }
    mustRefreshForWrapping(t) {
        return Wr.indexOf(t) > -1 != this.lineWrapping
    }
    mustRefreshForHeights(t) {
        let e = !1;
        for (let i = 0; i < t.length; i++) {
            let s = t[i];
            s < 0 ? i++ : this.heightSamples[Math.floor(s * 10)] || (e = !0, this.heightSamples[Math.floor(s * 10)] = !0)
        }
        return e
    }
    refresh(t, e, i, s, r, o) {
        let l = Wr.indexOf(t) > -1,
            a = Math.round(e) != Math.round(this.lineHeight) || this.lineWrapping != l;
        if (this.lineWrapping = l, this.lineHeight = e, this.charWidth = i, this.textHeight = s, this.lineLength = r, a) {
            this.heightSamples = {};
            for (let c = 0; c < o.length; c++) {
                let h = o[c];
                h < 0 ? c++ : this.heightSamples[Math.floor(h * 10)] = !0
            }
        }
        return a
    }
}
class kf {
    constructor(t, e) {
        this.from = t, this.heights = e, this.index = 0
    }
    get more() {
        return this.index < this.heights.length
    }
}
class jt {
    constructor(t, e, i, s, r) {
        this.from = t, this.length = e, this.top = i, this.height = s, this._content = r
    }
    get type() {
        return typeof this._content == "number" ? dt.Text : Array.isArray(this._content) ? this._content : this._content.type
    }
    get to() {
        return this.from + this.length
    }
    get bottom() {
        return this.top + this.height
    }
    get widget() {
        return this._content instanceof se ? this._content.widget : null
    }
    get widgetLineBreaks() {
        return typeof this._content == "number" ? this._content : 0
    }
    join(t) {
        let e = (Array.isArray(this._content) ? this._content : [this]).concat(Array.isArray(t._content) ? t._content : [t]);
        return new jt(this.from, this.length + t.length, this.top, this.height + t.height, e)
    }
}
var z = function(n) {
    return n[n.ByPos = 0] = "ByPos", n[n.ByHeight = 1] = "ByHeight", n[n.ByPosNoHeight = 2] = "ByPosNoHeight", n
}(z || (z = {}));
const Ui = .001;
class mt {
    constructor(t, e, i = 2) {
        this.length = t, this.height = e, this.flags = i
    }
    get outdated() {
        return (this.flags & 2) > 0
    }
    set outdated(t) {
        this.flags = (t ? 2 : 0) | this.flags & -3
    }
    setHeight(t, e) {
        this.height != e && (Math.abs(this.height - e) > Ui && (t.heightChanged = !0), this.height = e)
    }
    replace(t, e, i) {
        return mt.of(i)
    }
    decomposeLeft(t, e) {
        e.push(this)
    }
    decomposeRight(t, e) {
        e.push(this)
    }
    applyChanges(t, e, i, s) {
        let r = this,
            o = i.doc;
        for (let l = s.length - 1; l >= 0; l--) {
            let {
                fromA: a,
                toA: c,
                fromB: h,
                toB: u
            } = s[l], f = r.lineAt(a, z.ByPosNoHeight, i.setDoc(e), 0, 0), d = f.to >= c ? f : r.lineAt(c, z.ByPosNoHeight, i, 0, 0);
            for (u += d.to - c, c = d.to; l > 0 && f.from <= s[l - 1].toA;) a = s[l - 1].fromA, h = s[l - 1].fromB, l--, a < f.from && (f = r.lineAt(a, z.ByPosNoHeight, i, 0, 0));
            h += f.from - a, a = f.from;
            let m = Ws.build(i.setDoc(o), t, h, u);
            r = r.replace(a, c, m)
        }
        return r.updateHeight(i, 0)
    }
    static empty() {
        return new bt(0, 0)
    }
    static of (t) {
        if (t.length == 1) return t[0];
        let e = 0,
            i = t.length,
            s = 0,
            r = 0;
        for (;;)
            if (e == i)
                if (s > r * 2) {
                    let l = t[e - 1];
                    l.break ? t.splice(--e, 1, l.left, null, l.right) : t.splice(--e, 1, l.left, l.right), i += 1 + l.break, s -= l.size
                } else if (r > s * 2) {
            let l = t[i];
            l.break ? t.splice(i, 1, l.left, null, l.right) : t.splice(i, 1, l.left, l.right), i += 2 + l.break, r -= l.size
        } else break;
        else if (s < r) {
            let l = t[e++];
            l && (s += l.size)
        } else {
            let l = t[--i];
            l && (r += l.size)
        }
        let o = 0;
        return t[e - 1] == null ? (o = 1, e--) : t[e] == null && (o = 1, i++), new Mf(mt.of(t.slice(0, e)), o, mt.of(t.slice(i)))
    }
}
mt.prototype.size = 1;
class Kl extends mt {
    constructor(t, e, i) {
        super(t, e), this.deco = i
    }
    blockAt(t, e, i, s) {
        return new jt(s, this.length, i, this.height, this.deco || 0)
    }
    lineAt(t, e, i, s, r) {
        return this.blockAt(0, i, s, r)
    }
    forEachLine(t, e, i, s, r, o) {
        t <= r + this.length && e >= r && o(this.blockAt(0, i, s, r))
    }
    updateHeight(t, e = 0, i = !1, s) {
        return s && s.from <= e && s.more && this.setHeight(t, s.heights[s.index++]), this.outdated = !1, this
    }
    toString() {
        return `block(${this.length})`
    }
}
class bt extends Kl {
    constructor(t, e) {
        super(t, e, null), this.collapsed = 0, this.widgetHeight = 0, this.breaks = 0
    }
    blockAt(t, e, i, s) {
        return new jt(s, this.length, i, this.height, this.breaks)
    }
    replace(t, e, i) {
        let s = i[0];
        return i.length == 1 && (s instanceof bt || s instanceof st && s.flags & 4) && Math.abs(this.length - s.length) < 10 ? (s instanceof st ? s = new bt(s.length, this.height) : s.height = this.height, this.outdated || (s.outdated = !1), s) : mt.of(i)
    }
    updateHeight(t, e = 0, i = !1, s) {
        return s && s.from <= e && s.more ? this.setHeight(t, s.heights[s.index++]) : (i || this.outdated) && this.setHeight(t, Math.max(this.widgetHeight, t.heightForLine(this.length - this.collapsed)) + this.breaks * t.lineHeight), this.outdated = !1, this
    }
    toString() {
        return `line(${this.length}${this.collapsed?-this.collapsed:""}${this.widgetHeight?":"+this.widgetHeight:""})`
    }
}
class st extends mt {
    constructor(t) {
        super(t, 0)
    }
    heightMetrics(t, e) {
        let i = t.doc.lineAt(e).number,
            s = t.doc.lineAt(e + this.length).number,
            r = s - i + 1,
            o, l = 0;
        if (t.lineWrapping) {
            let a = Math.min(this.height, t.lineHeight * r);
            o = a / r, this.length > r + 1 && (l = (this.height - a) / (this.length - r - 1))
        } else o = this.height / r;
        return {
            firstLine: i,
            lastLine: s,
            perLine: o,
            perChar: l
        }
    }
    blockAt(t, e, i, s) {
        let {
            firstLine: r,
            lastLine: o,
            perLine: l,
            perChar: a
        } = this.heightMetrics(e, s);
        if (e.lineWrapping) {
            let c = s + (t < e.lineHeight ? 0 : Math.round(Math.max(0, Math.min(1, (t - i) / this.height)) * this.length)),
                h = e.doc.lineAt(c),
                u = l + h.length * a,
                f = Math.max(i, t - u / 2);
            return new jt(h.from, h.length, f, u, 0)
        } else {
            let c = Math.max(0, Math.min(o - r, Math.floor((t - i) / l))),
                {
                    from: h,
                    length: u
                } = e.doc.line(r + c);
            return new jt(h, u, i + l * c, l, 0)
        }
    }
    lineAt(t, e, i, s, r) {
        if (e == z.ByHeight) return this.blockAt(t, i, s, r);
        if (e == z.ByPosNoHeight) {
            let {
                from: d,
                to: m
            } = i.doc.lineAt(t);
            return new jt(d, m - d, 0, 0, 0)
        }
        let {
            firstLine: o,
            perLine: l,
            perChar: a
        } = this.heightMetrics(i, r), c = i.doc.lineAt(t), h = l + c.length * a, u = c.number - o, f = s + l * u + a * (c.from - r - u);
        return new jt(c.from, c.length, Math.max(s, Math.min(f, s + this.height - h)), h, 0)
    }
    forEachLine(t, e, i, s, r, o) {
        t = Math.max(t, r), e = Math.min(e, r + this.length);
        let {
            firstLine: l,
            perLine: a,
            perChar: c
        } = this.heightMetrics(i, r);
        for (let h = t, u = s; h <= e;) {
            let f = i.doc.lineAt(h);
            if (h == t) {
                let m = f.number - l;
                u += a * m + c * (t - r - m)
            }
            let d = a + c * f.length;
            o(new jt(f.from, f.length, u, d, 0)), u += d, h = f.to + 1
        }
    }
    replace(t, e, i) {
        let s = this.length - e;
        if (s > 0) {
            let r = i[i.length - 1];
            r instanceof st ? i[i.length - 1] = new st(r.length + s) : i.push(null, new st(s - 1))
        }
        if (t > 0) {
            let r = i[0];
            r instanceof st ? i[0] = new st(t + r.length) : i.unshift(new st(t - 1), null)
        }
        return mt.of(i)
    }
    decomposeLeft(t, e) {
        e.push(new st(t - 1), null)
    }
    decomposeRight(t, e) {
        e.push(null, new st(this.length - t - 1))
    }
    updateHeight(t, e = 0, i = !1, s) {
        let r = e + this.length;
        if (s && s.from <= e + this.length && s.more) {
            let o = [],
                l = Math.max(e, s.from),
                a = -1;
            for (s.from > e && o.push(new st(s.from - e - 1).updateHeight(t, e)); l <= r && s.more;) {
                let h = t.doc.lineAt(l).length;
                o.length && o.push(null);
                let u = s.heights[s.index++];
                a == -1 ? a = u : Math.abs(u - a) >= Ui && (a = -2);
                let f = new bt(h, u);
                f.outdated = !1, o.push(f), l += h + 1
            }
            l <= r && o.push(null, new st(r - l).updateHeight(t, l));
            let c = mt.of(o);
            return (a < 0 || Math.abs(c.height - this.height) >= Ui || Math.abs(a - this.heightMetrics(t, e).perLine) >= Ui) && (t.heightChanged = !0), c
        } else(i || this.outdated) && (this.setHeight(t, t.heightForGap(e, e + this.length)), this.outdated = !1);
        return this
    }
    toString() {
        return `gap(${this.length})`
    }
}
class Mf extends mt {
    constructor(t, e, i) {
        super(t.length + e + i.length, t.height + i.height, e | (t.outdated || i.outdated ? 2 : 0)), this.left = t, this.right = i, this.size = t.size + i.size
    }
    get break() {
        return this.flags & 1
    }
    blockAt(t, e, i, s) {
        let r = i + this.left.height;
        return t < r ? this.left.blockAt(t, e, i, s) : this.right.blockAt(t, e, r, s + this.left.length + this.break)
    }
    lineAt(t, e, i, s, r) {
        let o = s + this.left.height,
            l = r + this.left.length + this.break,
            a = e == z.ByHeight ? t < o : t < l,
            c = a ? this.left.lineAt(t, e, i, s, r) : this.right.lineAt(t, e, i, o, l);
        if (this.break || (a ? c.to < l : c.from > l)) return c;
        let h = e == z.ByPosNoHeight ? z.ByPosNoHeight : z.ByPos;
        return a ? c.join(this.right.lineAt(l, h, i, o, l)) : this.left.lineAt(l, h, i, s, r).join(c)
    }
    forEachLine(t, e, i, s, r, o) {
        let l = s + this.left.height,
            a = r + this.left.length + this.break;
        if (this.break) t < a && this.left.forEachLine(t, e, i, s, r, o), e >= a && this.right.forEachLine(t, e, i, l, a, o);
        else {
            let c = this.lineAt(a, z.ByPos, i, s, r);
            t < c.from && this.left.forEachLine(t, c.from - 1, i, s, r, o), c.to >= t && c.from <= e && o(c), e > c.to && this.right.forEachLine(c.to + 1, e, i, l, a, o)
        }
    }
    replace(t, e, i) {
        let s = this.left.length + this.break;
        if (e < s) return this.balanced(this.left.replace(t, e, i), this.right);
        if (t > this.left.length) return this.balanced(this.left, this.right.replace(t - s, e - s, i));
        let r = [];
        t > 0 && this.decomposeLeft(t, r);
        let o = r.length;
        for (let l of i) r.push(l);
        if (t > 0 && zr(r, o - 1), e < this.length) {
            let l = r.length;
            this.decomposeRight(e, r), zr(r, l)
        }
        return mt.of(r)
    }
    decomposeLeft(t, e) {
        let i = this.left.length;
        if (t <= i) return this.left.decomposeLeft(t, e);
        e.push(this.left), this.break && (i++, t >= i && e.push(null)), t > i && this.right.decomposeLeft(t - i, e)
    }
    decomposeRight(t, e) {
        let i = this.left.length,
            s = i + this.break;
        if (t >= s) return this.right.decomposeRight(t - s, e);
        t < i && this.left.decomposeRight(t, e), this.break && t < s && e.push(null), e.push(this.right)
    }
    balanced(t, e) {
        return t.size > 2 * e.size || e.size > 2 * t.size ? mt.of(this.break ? [t, null, e] : [t, e]) : (this.left = t, this.right = e, this.height = t.height + e.height, this.outdated = t.outdated || e.outdated, this.size = t.size + e.size, this.length = t.length + this.break+e.length, this)
    }
    updateHeight(t, e = 0, i = !1, s) {
        let {
            left: r,
            right: o
        } = this, l = e + r.length + this.break, a = null;
        return s && s.from <= e + r.length && s.more ? a = r = r.updateHeight(t, e, i, s) : r.updateHeight(t, e, i), s && s.from <= l + o.length && s.more ? a = o = o.updateHeight(t, l, i, s) : o.updateHeight(t, l, i), a ? this.balanced(r, o) : (this.height = this.left.height + this.right.height, this.outdated = !1, this)
    }
    toString() {
        return this.left + (this.break ? " " : "-") + this.right
    }
}

function zr(n, t) {
    let e, i;
    n[t] == null && (e = n[t - 1]) instanceof st && (i = n[t + 1]) instanceof st && n.splice(t - 1, 3, new st(e.length + 1 + i.length))
}
const Af = 5;
class Ws {
    constructor(t, e) {
        this.pos = t, this.oracle = e, this.nodes = [], this.lineStart = -1, this.lineEnd = -1, this.covering = null, this.writtenTo = t
    }
    get isCovered() {
        return this.covering && this.nodes[this.nodes.length - 1] == this.covering
    }
    span(t, e) {
        if (this.lineStart > -1) {
            let i = Math.min(e, this.lineEnd),
                s = this.nodes[this.nodes.length - 1];
            s instanceof bt ? s.length += i - this.pos : (i > this.pos || !this.isCovered) && this.nodes.push(new bt(i - this.pos, -1)), this.writtenTo = i, e > i && (this.nodes.push(null), this.writtenTo++, this.lineStart = -1)
        }
        this.pos = e
    }
    point(t, e, i) {
        if (t < e || i.heightRelevant) {
            let s = i.widget ? i.widget.estimatedHeight : 0,
                r = i.widget ? i.widget.lineBreaks : 0;
            s < 0 && (s = this.oracle.lineHeight);
            let o = e - t;
            i.block ? this.addBlock(new Kl(o, s, i)) : (o || r || s >= Af) && this.addLineDeco(s, r, o)
        } else e > t && this.span(t, e);
        this.lineEnd > -1 && this.lineEnd < this.pos && (this.lineEnd = this.oracle.doc.lineAt(this.pos).to)
    }
    enterLine() {
        if (this.lineStart > -1) return;
        let {
            from: t,
            to: e
        } = this.oracle.doc.lineAt(this.pos);
        this.lineStart = t, this.lineEnd = e, this.writtenTo < t && ((this.writtenTo < t - 1 || this.nodes[this.nodes.length - 1] == null) && this.nodes.push(this.blankContent(this.writtenTo, t - 1)), this.nodes.push(null)), this.pos > t && this.nodes.push(new bt(this.pos - t, -1)), this.writtenTo = this.pos
    }
    blankContent(t, e) {
        let i = new st(e - t);
        return this.oracle.doc.lineAt(t).to == e && (i.flags |= 4), i
    }
    ensureLine() {
        this.enterLine();
        let t = this.nodes.length ? this.nodes[this.nodes.length - 1] : null;
        if (t instanceof bt) return t;
        let e = new bt(0, -1);
        return this.nodes.push(e), e
    }
    addBlock(t) {
        this.enterLine();
        let e = t.deco;
        e && e.startSide > 0 && !this.isCovered && this.ensureLine(), this.nodes.push(t), this.writtenTo = this.pos = this.pos + t.length, e && e.endSide > 0 && (this.covering = t)
    }
    addLineDeco(t, e, i) {
        let s = this.ensureLine();
        s.length += i, s.collapsed += i, s.widgetHeight = Math.max(s.widgetHeight, t), s.breaks += e, this.writtenTo = this.pos = this.pos + i
    }
    finish(t) {
        let e = this.nodes.length == 0 ? null : this.nodes[this.nodes.length - 1];
        this.lineStart > -1 && !(e instanceof bt) && !this.isCovered ? this.nodes.push(new bt(0, -1)) : (this.writtenTo < this.pos || e == null) && this.nodes.push(this.blankContent(this.writtenTo, this.pos));
        let i = t;
        for (let s of this.nodes) s instanceof bt && s.updateHeight(this.oracle, i), i += s ? s.length : 1;
        return this.nodes
    }
    static build(t, e, i, s) {
        let r = new Ws(i, t);
        return L.spans(e, i, s, r, 0), r.finish(i)
    }
}

function Tf(n, t, e) {
    let i = new Ef;
    return L.compare(n, t, e, i, 0), i.changes
}
class Ef {
    constructor() {
        this.changes = []
    }
    compareRange() {}
    comparePoint(t, e, i, s) {
        (t < e || i && i.heightRelevant || s && s.heightRelevant) && ls(t, e, this.changes, 5)
    }
}

function Df(n, t) {
    let e = n.getBoundingClientRect(),
        i = n.ownerDocument,
        s = i.defaultView || window,
        r = Math.max(0, e.left),
        o = Math.min(s.innerWidth, e.right),
        l = Math.max(0, e.top),
        a = Math.min(s.innerHeight, e.bottom);
    for (let c = n.parentNode; c && c != i.body;)
        if (c.nodeType == 1) {
            let h = c,
                u = window.getComputedStyle(h);
            if ((h.scrollHeight > h.clientHeight || h.scrollWidth > h.clientWidth) && u.overflow != "visible") {
                let f = h.getBoundingClientRect();
                r = Math.max(r, f.left), o = Math.min(o, f.right), l = Math.max(l, f.top), a = c == n.parentNode ? f.bottom : Math.min(a, f.bottom)
            }
            c = u.position == "absolute" || u.position == "fixed" ? h.offsetParent : h.parentNode
        } else if (c.nodeType == 11) c = c.host;
    else break;
    return {
        left: r - e.left,
        right: Math.max(r, o) - e.left,
        top: l - (e.top + t),
        bottom: Math.max(l, a) - (e.top + t)
    }
}

function Of(n, t) {
    let e = n.getBoundingClientRect();
    return {
        left: 0,
        right: e.right - e.left,
        top: t,
        bottom: e.bottom - (e.top + t)
    }
}
class Dn {
    constructor(t, e, i) {
        this.from = t, this.to = e, this.size = i
    }
    static same(t, e) {
        if (t.length != e.length) return !1;
        for (let i = 0; i < t.length; i++) {
            let s = t[i],
                r = e[i];
            if (s.from != r.from || s.to != r.to || s.size != r.size) return !1
        }
        return !0
    }
    draw(t, e) {
        return B.replace({
            widget: new Rf(this.size * (e ? t.scaleY : t.scaleX), e)
        }).range(this.from, this.to)
    }
}
class Rf extends qe {
    constructor(t, e) {
        super(), this.size = t, this.vertical = e
    }
    eq(t) {
        return t.size == this.size && t.vertical == this.vertical
    }
    toDOM() {
        let t = document.createElement("div");
        return this.vertical ? t.style.height = this.size + "px" : (t.style.width = this.size + "px", t.style.height = "2px", t.style.display = "inline-block"), t
    }
    get estimatedHeight() {
        return this.vertical ? this.size : -1
    }
}
class qr {
    constructor(t) {
        this.state = t, this.pixelViewport = {
            left: 0,
            right: window.innerWidth,
            top: 0,
            bottom: 0
        }, this.inView = !0, this.paddingTop = 0, this.paddingBottom = 0, this.contentDOMWidth = 0, this.contentDOMHeight = 0, this.editorHeight = 0, this.editorWidth = 0, this.scrollTop = 0, this.scrolledToBottom = !1, this.scaleX = 1, this.scaleY = 1, this.scrollAnchorPos = 0, this.scrollAnchorHeight = -1, this.scaler = _r, this.scrollTarget = null, this.printing = !1, this.mustMeasureContent = !0, this.defaultTextDirection = Q.LTR, this.visibleRanges = [], this.mustEnforceCursorAssoc = !1;
        let e = t.facet(Fs).some(i => typeof i != "function" && i.class == "cm-lineWrapping");
        this.heightOracle = new Sf(e), this.stateDeco = t.facet(pi).filter(i => typeof i != "function"), this.heightMap = mt.empty().applyChanges(this.stateDeco, N.empty, this.heightOracle.setDoc(t.doc), [new Mt(0, 0, 0, t.doc.length)]);
        for (let i = 0; i < 2 && (this.viewport = this.getViewport(0, null), !!this.updateForViewport()); i++);
        this.updateViewportLines(), this.lineGaps = this.ensureLineGaps([]), this.lineGapDeco = B.set(this.lineGaps.map(i => i.draw(this, !1))), this.computeVisibleRanges()
    }
    updateForViewport() {
        let t = [this.viewport],
            {
                main: e
            } = this.state.selection;
        for (let i = 0; i <= 1; i++) {
            let s = i ? e.head : e.anchor;
            if (!t.some(({
                    from: r,
                    to: o
                }) => s >= r && s <= o)) {
                let {
                    from: r,
                    to: o
                } = this.lineBlockAt(s);
                t.push(new Ii(r, o))
            }
        }
        return this.viewports = t.sort((i, s) => i.from - s.from), this.updateScaler()
    }
    updateScaler() {
        let t = this.scaler;
        return this.scaler = this.heightMap.height <= 7e6 ? _r : new zs(this.heightOracle, this.heightMap, this.viewports), t.eq(this.scaler) ? 0 : 2
    }
    updateViewportLines() {
        this.viewportLines = [], this.heightMap.forEachLine(this.viewport.from, this.viewport.to, this.heightOracle.setDoc(this.state.doc), 0, 0, t => {
            this.viewportLines.push(ii(t, this.scaler))
        })
    }
    update(t, e = null) {
        this.state = t.state;
        let i = this.stateDeco;
        this.stateDeco = this.state.facet(pi).filter(h => typeof h != "function");
        let s = t.changedRanges,
            r = Mt.extendWithRanges(s, Tf(i, this.stateDeco, t ? t.changes : it.empty(this.state.doc.length))),
            o = this.heightMap.height,
            l = this.scrolledToBottom ? null : this.scrollAnchorAt(this.scrollTop);
        this.heightMap = this.heightMap.applyChanges(this.stateDeco, t.startState.doc, this.heightOracle.setDoc(this.state.doc), r), this.heightMap.height != o && (t.flags |= 2), l ? (this.scrollAnchorPos = t.changes.mapPos(l.from, -1), this.scrollAnchorHeight = l.top) : (this.scrollAnchorPos = -1, this.scrollAnchorHeight = this.heightMap.height);
        let a = r.length ? this.mapViewport(this.viewport, t.changes) : this.viewport;
        (e && (e.range.head < a.from || e.range.head > a.to) || !this.viewportIsAppropriate(a)) && (a = this.getViewport(0, e));
        let c = a.from != this.viewport.from || a.to != this.viewport.to;
        this.viewport = a, t.flags |= this.updateForViewport(), (c || !t.changes.empty || t.flags & 2) && this.updateViewportLines(), (this.lineGaps.length || this.viewport.to - this.viewport.from > 4e3) && this.updateLineGaps(this.ensureLineGaps(this.mapLineGaps(this.lineGaps, t.changes))), t.flags |= this.computeVisibleRanges(), e && (this.scrollTarget = e), !this.mustEnforceCursorAssoc && t.selectionSet && t.view.lineWrapping && t.state.selection.main.empty && t.state.selection.main.assoc && !t.state.facet(Dl) && (this.mustEnforceCursorAssoc = !0)
    }
    measure(t) {
        let e = t.contentDOM,
            i = window.getComputedStyle(e),
            s = this.heightOracle,
            r = i.whiteSpace;
        this.defaultTextDirection = i.direction == "rtl" ? Q.RTL : Q.LTR;
        let o = this.heightOracle.mustRefreshForWrapping(r),
            l = e.getBoundingClientRect(),
            a = o || this.mustMeasureContent || this.contentDOMHeight != l.height;
        this.contentDOMHeight = l.height, this.mustMeasureContent = !1;
        let c = 0,
            h = 0;
        if (l.width && l.height) {
            let {
                scaleX: w,
                scaleY: S
            } = il(e, l);
            (w > .005 && Math.abs(this.scaleX - w) > .005 || S > .005 && Math.abs(this.scaleY - S) > .005) && (this.scaleX = w, this.scaleY = S, c |= 8, o = a = !0)
        }
        let u = (parseInt(i.paddingTop) || 0) * this.scaleY,
            f = (parseInt(i.paddingBottom) || 0) * this.scaleY;
        (this.paddingTop != u || this.paddingBottom != f) && (this.paddingTop = u, this.paddingBottom = f, c |= 10), this.editorWidth != t.scrollDOM.clientWidth && (s.lineWrapping && (a = !0), this.editorWidth = t.scrollDOM.clientWidth, c |= 8);
        let d = t.scrollDOM.scrollTop * this.scaleY;
        this.scrollTop != d && (this.scrollAnchorHeight = -1, this.scrollTop = d), this.scrolledToBottom = rl(t.scrollDOM);
        let m = (this.printing ? Of : Df)(e, this.paddingTop),
            g = m.top - this.pixelViewport.top,
            p = m.bottom - this.pixelViewport.bottom;
        this.pixelViewport = m;
        let y = this.pixelViewport.bottom > this.pixelViewport.top && this.pixelViewport.right > this.pixelViewport.left;
        if (y != this.inView && (this.inView = y, y && (a = !0)), !this.inView && !this.scrollTarget) return 0;
        let b = l.width;
        if ((this.contentDOMWidth != b || this.editorHeight != t.scrollDOM.clientHeight) && (this.contentDOMWidth = l.width, this.editorHeight = t.scrollDOM.clientHeight, c |= 8), a) {
            let w = t.docView.measureVisibleLineHeights(this.viewport);
            if (s.mustRefreshForHeights(w) && (o = !0), o || s.lineWrapping && Math.abs(b - this.contentDOMWidth) > s.charWidth) {
                let {
                    lineHeight: S,
                    charWidth: M,
                    textHeight: D
                } = t.docView.measureTextSize();
                o = S > 0 && s.refresh(r, S, M, D, b / M, w), o && (t.docView.minWidth = 0, c |= 8)
            }
            g > 0 && p > 0 ? h = Math.max(g, p) : g < 0 && p < 0 && (h = Math.min(g, p)), s.heightChanged = !1;
            for (let S of this.viewports) {
                let M = S.from == this.viewport.from ? w : t.docView.measureVisibleLineHeights(S);
                this.heightMap = (o ? mt.empty().applyChanges(this.stateDeco, N.empty, this.heightOracle, [new Mt(0, 0, 0, t.state.doc.length)]) : this.heightMap).updateHeight(s, 0, o, new kf(S.from, M))
            }
            s.heightChanged && (c |= 2)
        }
        let v = !this.viewportIsAppropriate(this.viewport, h) || this.scrollTarget && (this.scrollTarget.range.head < this.viewport.from || this.scrollTarget.range.head > this.viewport.to);
        return v && (c & 2 && (c |= this.updateScaler()), this.viewport = this.getViewport(h, this.scrollTarget), c |= this.updateForViewport()), (c & 2 || v) && this.updateViewportLines(), (this.lineGaps.length || this.viewport.to - this.viewport.from > 4e3) && this.updateLineGaps(this.ensureLineGaps(o ? [] : this.lineGaps, t)), c |= this.computeVisibleRanges(), this.mustEnforceCursorAssoc && (this.mustEnforceCursorAssoc = !1, t.docView.enforceCursorAssoc()), c
    }
    get visibleTop() {
        return this.scaler.fromDOM(this.pixelViewport.top)
    }
    get visibleBottom() {
        return this.scaler.fromDOM(this.pixelViewport.bottom)
    }
    getViewport(t, e) {
        let i = .5 - Math.max(-.5, Math.min(.5, t / 1e3 / 2)),
            s = this.heightMap,
            r = this.heightOracle,
            {
                visibleTop: o,
                visibleBottom: l
            } = this,
            a = new Ii(s.lineAt(o - i * 1e3, z.ByHeight, r, 0, 0).from, s.lineAt(l + (1 - i) * 1e3, z.ByHeight, r, 0, 0).to);
        if (e) {
            let {
                head: c
            } = e.range;
            if (c < a.from || c > a.to) {
                let h = Math.min(this.editorHeight, this.pixelViewport.bottom - this.pixelViewport.top),
                    u = s.lineAt(c, z.ByPos, r, 0, 0),
                    f;
                e.y == "center" ? f = (u.top + u.bottom) / 2 - h / 2 : e.y == "start" || e.y == "nearest" && c < a.from ? f = u.top : f = u.bottom - h, a = new Ii(s.lineAt(f - 1e3 / 2, z.ByHeight, r, 0, 0).from, s.lineAt(f + h + 1e3 / 2, z.ByHeight, r, 0, 0).to)
            }
        }
        return a
    }
    mapViewport(t, e) {
        let i = e.mapPos(t.from, -1),
            s = e.mapPos(t.to, 1);
        return new Ii(this.heightMap.lineAt(i, z.ByPos, this.heightOracle, 0, 0).from, this.heightMap.lineAt(s, z.ByPos, this.heightOracle, 0, 0).to)
    }
    viewportIsAppropriate({
        from: t,
        to: e
    }, i = 0) {
        if (!this.inView) return !0;
        let {
            top: s
        } = this.heightMap.lineAt(t, z.ByPos, this.heightOracle, 0, 0), {
            bottom: r
        } = this.heightMap.lineAt(e, z.ByPos, this.heightOracle, 0, 0), {
            visibleTop: o,
            visibleBottom: l
        } = this;
        return (t == 0 || s <= o - Math.max(10, Math.min(-i, 250))) && (e == this.state.doc.length || r >= l + Math.max(10, Math.min(i, 250))) && s > o - 2 * 1e3 && r < l + 2 * 1e3
    }
    mapLineGaps(t, e) {
        if (!t.length || e.empty) return t;
        let i = [];
        for (let s of t) e.touchesRange(s.from, s.to) || i.push(new Dn(e.mapPos(s.from), e.mapPos(s.to), s.size));
        return i
    }
    ensureLineGaps(t, e) {
        let i = this.heightOracle.lineWrapping,
            s = i ? 1e4 : 2e3,
            r = s >> 1,
            o = s << 1;
        if (this.defaultTextDirection != Q.LTR && !i) return [];
        let l = [],
            a = (h, u, f, d) => {
                if (u - h < r) return;
                let m = this.state.selection.main,
                    g = [m.from];
                m.empty || g.push(m.to);
                for (let y of g)
                    if (y > h && y < u) {
                        a(h, y - 10, f, d), a(y + 10, u, f, d);
                        return
                    }
                let p = Lf(t, y => y.from >= f.from && y.to <= f.to && Math.abs(y.from - h) < r && Math.abs(y.to - u) < r && !g.some(b => y.from < b && y.to > b));
                if (!p) {
                    if (u < f.to && e && i && e.visibleRanges.some(y => y.from <= u && y.to >= u)) {
                        let y = e.moveToLineBoundary(A.cursor(u), !1, !0).head;
                        y > h && (u = y)
                    }
                    p = new Dn(h, u, this.gapSize(f, h, u, d))
                }
                l.push(p)
            },
            c = h => {
                if (h.length < o || h.type != dt.Text) return;
                let u = Pf(h.from, h.to, this.stateDeco);
                if (u.total < o) return;
                let f = this.scrollTarget ? this.scrollTarget.range.head : null,
                    d, m;
                if (i) {
                    let g = s / this.heightOracle.lineLength * this.heightOracle.lineHeight,
                        p, y;
                    if (f != null) {
                        let b = Hi(u, f),
                            v = ((this.visibleBottom - this.visibleTop) / 2 + g) / h.height;
                        p = b - v, y = b + v
                    } else p = (this.visibleTop - h.top - g) / h.height, y = (this.visibleBottom - h.top + g) / h.height;
                    d = Bi(u, p), m = Bi(u, y)
                } else {
                    let g = u.total * this.heightOracle.charWidth,
                        p = s * this.heightOracle.charWidth,
                        y, b;
                    if (f != null) {
                        let v = Hi(u, f),
                            w = ((this.pixelViewport.right - this.pixelViewport.left) / 2 + p) / g;
                        y = v - w, b = v + w
                    } else y = (this.pixelViewport.left - p) / g, b = (this.pixelViewport.right + p) / g;
                    d = Bi(u, y), m = Bi(u, b)
                }
                d > h.from && a(h.from, d, h, u), m < h.to && a(m, h.to, h, u)
            };
        for (let h of this.viewportLines) Array.isArray(h.type) ? h.type.forEach(c) : c(h);
        return l
    }
    gapSize(t, e, i, s) {
        let r = Hi(s, i) - Hi(s, e);
        return this.heightOracle.lineWrapping ? t.height * r : s.total * this.heightOracle.charWidth * r
    }
    updateLineGaps(t) {
        Dn.same(t, this.lineGaps) || (this.lineGaps = t, this.lineGapDeco = B.set(t.map(e => e.draw(this, this.heightOracle.lineWrapping))))
    }
    computeVisibleRanges() {
        let t = this.stateDeco;
        this.lineGaps.length && (t = t.concat(this.lineGapDeco));
        let e = [];
        L.spans(t, this.viewport.from, this.viewport.to, {
            span(s, r) {
                e.push({
                    from: s,
                    to: r
                })
            },
            point() {}
        }, 20);
        let i = e.length != this.visibleRanges.length || this.visibleRanges.some((s, r) => s.from != e[r].from || s.to != e[r].to);
        return this.visibleRanges = e, i ? 4 : 0
    }
    lineBlockAt(t) {
        return t >= this.viewport.from && t <= this.viewport.to && this.viewportLines.find(e => e.from <= t && e.to >= t) || ii(this.heightMap.lineAt(t, z.ByPos, this.heightOracle, 0, 0), this.scaler)
    }
    lineBlockAtHeight(t) {
        return t >= this.viewportLines[0].top && t <= this.viewportLines[this.viewportLines.length - 1].bottom && this.viewportLines.find(e => e.top <= t && e.bottom >= t) || ii(this.heightMap.lineAt(this.scaler.fromDOM(t), z.ByHeight, this.heightOracle, 0, 0), this.scaler)
    }
    scrollAnchorAt(t) {
        let e = this.lineBlockAtHeight(t + 8);
        return e.from >= this.viewport.from || this.viewportLines[0].top - t > 200 ? e : this.viewportLines[0]
    }
    elementAtHeight(t) {
        return ii(this.heightMap.blockAt(this.scaler.fromDOM(t), this.heightOracle, 0, 0), this.scaler)
    }
    get docHeight() {
        return this.scaler.toDOM(this.heightMap.height)
    }
    get contentHeight() {
        return this.docHeight + this.paddingTop + this.paddingBottom
    }
}
class Ii {
    constructor(t, e) {
        this.from = t, this.to = e
    }
}

function Pf(n, t, e) {
    let i = [],
        s = n,
        r = 0;
    return L.spans(e, n, t, {
        span() {},
        point(o, l) {
            o > s && (i.push({
                from: s,
                to: o
            }), r += o - s), s = l
        }
    }, 20), s < t && (i.push({
        from: s,
        to: t
    }), r += t - s), {
        total: r,
        ranges: i
    }
}

function Bi({
    total: n,
    ranges: t
}, e) {
    if (e <= 0) return t[0].from;
    if (e >= 1) return t[t.length - 1].to;
    let i = Math.floor(n * e);
    for (let s = 0;; s++) {
        let {
            from: r,
            to: o
        } = t[s], l = o - r;
        if (i <= l) return r + i;
        i -= l
    }
}

function Hi(n, t) {
    let e = 0;
    for (let {
            from: i,
            to: s
        } of n.ranges) {
        if (t <= s) {
            e += t - i;
            break
        }
        e += s - i
    }
    return e / n.total
}

function Lf(n, t) {
    for (let e of n)
        if (t(e)) return e
}
const _r = {
    toDOM(n) {
        return n
    },
    fromDOM(n) {
        return n
    },
    scale: 1,
    eq(n) {
        return n == this
    }
};
class zs {
    constructor(t, e, i) {
        let s = 0,
            r = 0,
            o = 0;
        this.viewports = i.map(({
            from: l,
            to: a
        }) => {
            let c = e.lineAt(l, z.ByPos, t, 0, 0).top,
                h = e.lineAt(a, z.ByPos, t, 0, 0).bottom;
            return s += h - c, {
                from: l,
                to: a,
                top: c,
                bottom: h,
                domTop: 0,
                domBottom: 0
            }
        }), this.scale = (7e6 - s) / (e.height - s);
        for (let l of this.viewports) l.domTop = o + (l.top - r) * this.scale, o = l.domBottom = l.domTop + (l.bottom - l.top), r = l.bottom
    }
    toDOM(t) {
        for (let e = 0, i = 0, s = 0;; e++) {
            let r = e < this.viewports.length ? this.viewports[e] : null;
            if (!r || t < r.top) return s + (t - i) * this.scale;
            if (t <= r.bottom) return r.domTop + (t - r.top);
            i = r.bottom, s = r.domBottom
        }
    }
    fromDOM(t) {
        for (let e = 0, i = 0, s = 0;; e++) {
            let r = e < this.viewports.length ? this.viewports[e] : null;
            if (!r || t < r.domTop) return i + (t - s) / this.scale;
            if (t <= r.domBottom) return r.top + (t - r.domTop);
            i = r.bottom, s = r.domBottom
        }
    }
    eq(t) {
        return t instanceof zs ? this.scale == t.scale && this.viewports.length == t.viewports.length && this.viewports.every((e, i) => e.from == t.viewports[i].from && e.to == t.viewports[i].to) : !1
    }
}

function ii(n, t) {
    if (t.scale == 1) return n;
    let e = t.toDOM(n.top),
        i = t.toDOM(n.bottom);
    return new jt(n.from, n.length, e, i - e, Array.isArray(n._content) ? n._content.map(s => ii(s, t)) : n._content)
}
const Vi = E.define({
        combine: n => n.join(" ")
    }),
    gs = E.define({
        combine: n => n.indexOf(!0) > -1
    }),
    ps = Ve.newName(),
    Yl = Ve.newName(),
    Xl = Ve.newName(),
    Jl = {
        "&light": "." + Yl,
        "&dark": "." + Xl
    };

function ys(n, t, e) {
    return new Ve(t, {
        finish(i) {
            return /&/.test(i) ? i.replace(/&\w*/, s => {
                if (s == "&") return n;
                if (!e || !e[s]) throw new RangeError(`Unsupported selector: ${s}`);
                return e[s]
            }) : n + " " + i
        }
    })
}
const Nf = ys("." + ps, {
        "&": {
            position: "relative !important",
            boxSizing: "border-box",
            "&.cm-focused": {
                outline: "1px dotted #212121"
            },
            display: "flex !important",
            flexDirection: "column"
        },
        ".cm-scroller": {
            display: "flex !important",
            alignItems: "flex-start !important",
            fontFamily: "monospace",
            lineHeight: 1.4,
            height: "100%",
            overflowX: "auto",
            position: "relative",
            zIndex: 0
        },
        ".cm-content": {
            margin: 0,
            flexGrow: 2,
            flexShrink: 0,
            display: "block",
            whiteSpace: "pre",
            wordWrap: "normal",
            boxSizing: "border-box",
            minHeight: "100%",
            padding: "4px 0",
            outline: "none",
            "&[contenteditable=true]": {
                WebkitUserModify: "read-write-plaintext-only"
            }
        },
        ".cm-lineWrapping": {
            whiteSpace_fallback: "pre-wrap",
            whiteSpace: "break-spaces",
            wordBreak: "break-word",
            overflowWrap: "anywhere",
            flexShrink: 1
        },
        "&light .cm-content": {
            caretColor: "black"
        },
        "&dark .cm-content": {
            caretColor: "white"
        },
        ".cm-line": {
            display: "block",
            padding: "0 2px 0 6px"
        },
        ".cm-layer": {
            position: "absolute",
            left: 0,
            top: 0,
            contain: "size style",
            "& > *": {
                position: "absolute"
            }
        },
        "&light .cm-selectionBackground": {
            background: "#d9d9d9"
        },
        "&dark .cm-selectionBackground": {
            background: "#222"
        },
        "&light.cm-focused > .cm-scroller > .cm-selectionLayer .cm-selectionBackground": {
            background: "#d7d4f0"
        },
        "&dark.cm-focused > .cm-scroller > .cm-selectionLayer .cm-selectionBackground": {
            background: "#233"
        },
        ".cm-cursorLayer": {
            pointerEvents: "none"
        },
        "&.cm-focused > .cm-scroller > .cm-cursorLayer": {
            animation: "steps(1) cm-blink 1.2s infinite"
        },
        "@keyframes cm-blink": {
            "0%": {},
            "50%": {
                opacity: 0
            },
            "100%": {}
        },
        "@keyframes cm-blink2": {
            "0%": {},
            "50%": {
                opacity: 0
            },
            "100%": {}
        },
        ".cm-cursor, .cm-dropCursor": {
            borderLeft: "1.2px solid black",
            marginLeft: "-0.6px",
            pointerEvents: "none"
        },
        ".cm-cursor": {
            display: "none"
        },
        "&dark .cm-cursor": {
            borderLeftColor: "#444"
        },
        ".cm-dropCursor": {
            position: "absolute"
        },
        "&.cm-focused > .cm-scroller > .cm-cursorLayer .cm-cursor": {
            display: "block"
        },
        ".cm-iso": {
            unicodeBidi: "isolate"
        },
        ".cm-announced": {
            position: "fixed",
            top: "-10000px"
        },
        "@media print": {
            ".cm-announced": {
                display: "none"
            }
        },
        "&light .cm-activeLine": {
            backgroundColor: "#cceeff44"
        },
        "&dark .cm-activeLine": {
            backgroundColor: "#99eeff33"
        },
        "&light .cm-specialChar": {
            color: "red"
        },
        "&dark .cm-specialChar": {
            color: "#f78"
        },
        ".cm-gutters": {
            flexShrink: 0,
            display: "flex",
            height: "100%",
            boxSizing: "border-box",
            insetInlineStart: 0,
            zIndex: 200
        },
        "&light .cm-gutters": {
            backgroundColor: "#f5f5f5",
            color: "#6c6c6c",
            borderRight: "1px solid #ddd"
        },
        "&dark .cm-gutters": {
            backgroundColor: "#333338",
            color: "#ccc"
        },
        ".cm-gutter": {
            display: "flex !important",
            flexDirection: "column",
            flexShrink: 0,
            boxSizing: "border-box",
            minHeight: "100%",
            overflow: "hidden"
        },
        ".cm-gutterElement": {
            boxSizing: "border-box"
        },
        ".cm-lineNumbers .cm-gutterElement": {
            padding: "0 3px 0 5px",
            minWidth: "20px",
            textAlign: "right",
            whiteSpace: "nowrap"
        },
        "&light .cm-activeLineGutter": {
            backgroundColor: "#e2f2ff"
        },
        "&dark .cm-activeLineGutter": {
            backgroundColor: "#222227"
        },
        ".cm-panels": {
            boxSizing: "border-box",
            position: "sticky",
            left: 0,
            right: 0
        },
        "&light .cm-panels": {
            backgroundColor: "#f5f5f5",
            color: "black"
        },
        "&light .cm-panels-top": {
            borderBottom: "1px solid #ddd"
        },
        "&light .cm-panels-bottom": {
            borderTop: "1px solid #ddd"
        },
        "&dark .cm-panels": {
            backgroundColor: "#333338",
            color: "white"
        },
        ".cm-tab": {
            display: "inline-block",
            overflow: "hidden",
            verticalAlign: "bottom"
        },
        ".cm-widgetBuffer": {
            verticalAlign: "text-top",
            height: "1em",
            width: 0,
            display: "inline"
        },
        ".cm-placeholder": {
            color: "#888",
            display: "inline-block",
            verticalAlign: "top"
        },
        ".cm-highlightSpace:before": {
            content: "attr(data-display)",
            position: "absolute",
            pointerEvents: "none",
            color: "#888"
        },
        ".cm-highlightTab": {
            backgroundImage: `url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="200" height="20"><path stroke="%23888" stroke-width="1" fill="none" d="M1 10H196L190 5M190 15L196 10M197 4L197 16"/></svg>')`,
            backgroundSize: "auto 100%",
            backgroundPosition: "right 90%",
            backgroundRepeat: "no-repeat"
        },
        ".cm-trailingSpace": {
            backgroundColor: "#ff332255"
        },
        ".cm-button": {
            verticalAlign: "middle",
            color: "inherit",
            fontSize: "70%",
            padding: ".2em 1em",
            borderRadius: "1px"
        },
        "&light .cm-button": {
            backgroundImage: "linear-gradient(#eff1f5, #d9d9df)",
            border: "1px solid #888",
            "&:active": {
                backgroundImage: "linear-gradient(#b4b4b4, #d0d3d6)"
            }
        },
        "&dark .cm-button": {
            backgroundImage: "linear-gradient(#393939, #111)",
            border: "1px solid #888",
            "&:active": {
                backgroundImage: "linear-gradient(#111, #333)"
            }
        },
        ".cm-textfield": {
            verticalAlign: "middle",
            color: "inherit",
            fontSize: "70%",
            border: "1px solid silver",
            padding: ".2em .5em"
        },
        "&light .cm-textfield": {
            backgroundColor: "white"
        },
        "&dark .cm-textfield": {
            border: "1px solid #555",
            backgroundColor: "inherit"
        }
    }, Jl),
    ni = "￿";
class If {
    constructor(t, e) {
        this.points = t, this.text = "", this.lineSeparator = e.facet(q.lineSeparator)
    }
    append(t) {
        this.text += t
    }
    lineBreak() {
        this.text += ni
    }
    readRange(t, e) {
        if (!t) return this;
        let i = t.parentNode;
        for (let s = t;;) {
            this.findPointBefore(i, s);
            let r = this.text.length;
            this.readNode(s);
            let o = s.nextSibling;
            if (o == e) break;
            let l = j.get(s),
                a = j.get(o);
            (l && a ? l.breakAfter : (l ? l.breakAfter : en(s)) || en(o) && (s.nodeName != "BR" || s.cmIgnore) && this.text.length > r) && this.lineBreak(), s = o
        }
        return this.findPointBefore(i, e), this
    }
    readTextNode(t) {
        let e = t.nodeValue;
        for (let i of this.points) i.node == t && (i.pos = this.text.length + Math.min(i.offset, e.length));
        for (let i = 0, s = this.lineSeparator ? null : /\r\n?|\n/g;;) {
            let r = -1,
                o = 1,
                l;
            if (this.lineSeparator ? (r = e.indexOf(this.lineSeparator, i), o = this.lineSeparator.length) : (l = s.exec(e)) && (r = l.index, o = l[0].length), this.append(e.slice(i, r < 0 ? e.length : r)), r < 0) break;
            if (this.lineBreak(), o > 1)
                for (let a of this.points) a.node == t && a.pos > this.text.length && (a.pos -= o - 1);
            i = r + o
        }
    }
    readNode(t) {
        if (t.cmIgnore) return;
        let e = j.get(t),
            i = e && e.overrideDOMText;
        if (i != null) {
            this.findPointInside(t, i.length);
            for (let s = i.iter(); !s.next().done;) s.lineBreak ? this.lineBreak() : this.append(s.value)
        } else t.nodeType == 3 ? this.readTextNode(t) : t.nodeName == "BR" ? t.nextSibling && this.lineBreak() : t.nodeType == 1 && this.readRange(t.firstChild, null)
    }
    findPointBefore(t, e) {
        for (let i of this.points) i.node == t && t.childNodes[i.offset] == e && (i.pos = this.text.length)
    }
    findPointInside(t, e) {
        for (let i of this.points)(t.nodeType == 3 ? i.node == t : t.contains(i.node)) && (i.pos = this.text.length + (Bf(t, i.node, i.offset) ? e : 0))
    }
}

function Bf(n, t, e) {
    for (;;) {
        if (!t || e < Yt(t)) return !1;
        if (t == n) return !0;
        e = pe(t) + 1, t = t.parentNode
    }
}
class $r {
    constructor(t, e) {
        this.node = t, this.offset = e, this.pos = -1
    }
}
class Hf {
    constructor(t, e, i, s) {
        this.typeOver = s, this.bounds = null, this.text = "", this.domChanged = e > -1;
        let {
            impreciseHead: r,
            impreciseAnchor: o
        } = t.docView;
        if (t.state.readOnly && e > -1) this.newSel = null;
        else if (e > -1 && (this.bounds = t.docView.domBoundsAround(e, i, 0))) {
            let l = r || o ? [] : jf(t),
                a = new If(l, t.state);
            a.readRange(this.bounds.startDOM, this.bounds.endDOM), this.text = a.text, this.newSel = Wf(l, this.bounds.from)
        } else {
            let l = t.observer.selectionRange,
                a = r && r.node == l.focusNode && r.offset == l.focusOffset || !es(t.contentDOM, l.focusNode) ? t.state.selection.main.head : t.docView.posFromDOM(l.focusNode, l.focusOffset),
                c = o && o.node == l.anchorNode && o.offset == l.anchorOffset || !es(t.contentDOM, l.anchorNode) ? t.state.selection.main.anchor : t.docView.posFromDOM(l.anchorNode, l.anchorOffset),
                h = t.viewport;
            if ((k.ios || k.chrome) && t.state.selection.main.empty && a != c && (h.from > 0 || h.to < t.state.doc.length)) {
                let u = Math.min(a, c),
                    f = Math.max(a, c),
                    d = h.from - u,
                    m = h.to - f;
                (d == 0 || d == 1 || u == 0) && (m == 0 || m == -1 || f == t.state.doc.length) && (a = 0, c = t.state.doc.length)
            }
            this.newSel = A.single(c, a)
        }
    }
}

function Ql(n, t) {
    let e, {
            newSel: i
        } = t,
        s = n.state.selection.main,
        r = n.inputState.lastKeyTime > Date.now() - 100 ? n.inputState.lastKeyCode : -1;
    if (t.bounds) {
        let {
            from: o,
            to: l
        } = t.bounds, a = s.from, c = null;
        (r === 8 || k.android && t.text.length < l - o) && (a = s.to, c = "end");
        let h = Ff(n.state.doc.sliceString(o, l, ni), t.text, a - o, c);
        h && (k.chrome && r == 13 && h.toB == h.from + 2 && t.text.slice(h.from, h.toB) == ni + ni && h.toB--, e = {
            from: o + h.from,
            to: o + h.toA,
            insert: N.of(t.text.slice(h.from, h.toB).split(ni))
        })
    } else i && (!n.hasFocus && n.state.facet(Zt) || i.main.eq(s)) && (i = null);
    if (!e && !i) return !1;
    if (!e && t.typeOver && !s.empty && i && i.main.empty ? e = {
            from: s.from,
            to: s.to,
            insert: n.state.doc.slice(s.from, s.to)
        } : e && e.from >= s.from && e.to <= s.to && (e.from != s.from || e.to != s.to) && s.to - s.from - (e.to - e.from) <= 4 ? e = {
            from: s.from,
            to: s.to,
            insert: n.state.doc.slice(s.from, e.from).append(e.insert).append(n.state.doc.slice(e.to, s.to))
        } : (k.mac || k.android) && e && e.from == e.to && e.from == s.head - 1 && /^\. ?$/.test(e.insert.toString()) && n.contentDOM.getAttribute("autocorrect") == "off" ? (i && e.insert.length == 2 && (i = A.single(i.main.anchor - 1, i.main.head - 1)), e = {
            from: s.from,
            to: s.to,
            insert: N.of([" "])
        }) : k.chrome && e && e.from == e.to && e.from == s.head && e.insert.toString() == `
 ` && n.lineWrapping && (i && (i = A.single(i.main.anchor - 1, i.main.head - 1)), e = {
            from: s.from,
            to: s.to,
            insert: N.of([" "])
        }), e) return Zl(n, e, i, r);
    if (i && !i.main.eq(s)) {
        let o = !1,
            l = "select";
        return n.inputState.lastSelectionTime > Date.now() - 50 && (n.inputState.lastSelectionOrigin == "select" && (o = !0), l = n.inputState.lastSelectionOrigin), n.dispatch({
            selection: i,
            scrollIntoView: o,
            userEvent: l
        }), !0
    } else return !1
}

function Zl(n, t, e, i = -1) {
    if (k.ios && n.inputState.flushIOSKey(t)) return !0;
    let s = n.state.selection.main;
    if (k.android && (t.to == s.to && (t.from == s.from || t.from == s.from - 1 && n.state.sliceDoc(t.from, s.from) == " ") && t.insert.length == 1 && t.insert.lines == 2 && Re(n.contentDOM, "Enter", 13) || (t.from == s.from - 1 && t.to == s.to && t.insert.length == 0 || i == 8 && t.insert.length < t.to - t.from && t.to > s.head) && Re(n.contentDOM, "Backspace", 8) || t.from == s.from && t.to == s.to + 1 && t.insert.length == 0 && Re(n.contentDOM, "Delete", 46))) return !0;
    let r = t.insert.toString();
    n.inputState.composing >= 0 && n.inputState.composing++;
    let o, l = () => o || (o = Vf(n, t, e));
    return n.state.facet(Al).some(a => a(n, t.from, t.to, r, l)) || n.dispatch(l()), !0
}

function Vf(n, t, e) {
    let i, s = n.state,
        r = s.selection.main;
    if (t.from >= r.from && t.to <= r.to && t.to - t.from >= (r.to - r.from) / 3 && (!e || e.main.empty && e.main.from == t.from + t.insert.length) && n.inputState.composing < 0) {
        let l = r.from < t.from ? s.sliceDoc(r.from, t.from) : "",
            a = r.to > t.to ? s.sliceDoc(t.to, r.to) : "";
        i = s.replaceSelection(n.state.toText(l + t.insert.sliceString(0, void 0, n.state.lineBreak) + a))
    } else {
        let l = s.changes(t),
            a = e && e.main.to <= l.newLength ? e.main : void 0;
        if (s.selection.ranges.length > 1 && n.inputState.composing >= 0 && t.to <= r.to && t.to >= r.to - 10) {
            let c = n.state.sliceDoc(t.from, t.to),
                h, u = e && Hl(n, e.main.head);
            if (u) {
                let m = t.insert.length - (t.to - t.from);
                h = {
                    from: u.from,
                    to: u.to - m
                }
            } else h = n.state.doc.lineAt(r.head);
            let f = r.to - t.to,
                d = r.to - r.from;
            i = s.changeByRange(m => {
                if (m.from == r.from && m.to == r.to) return {
                    changes: l,
                    range: a || m.map(l)
                };
                let g = m.to - f,
                    p = g - c.length;
                if (m.to - m.from != d || n.state.sliceDoc(p, g) != c || m.to >= h.from && m.from <= h.to) return {
                    range: m
                };
                let y = s.changes({
                        from: p,
                        to: g,
                        insert: t.insert
                    }),
                    b = m.to - r.to;
                return {
                    changes: y,
                    range: a ? A.range(Math.max(0, a.anchor + b), Math.max(0, a.head + b)) : m.map(y)
                }
            })
        } else i = {
            changes: l,
            selection: a && s.selection.replaceRange(a)
        }
    }
    let o = "input.type";
    return (n.composing || n.inputState.compositionPendingChange && n.inputState.compositionEndedAt > Date.now() - 50) && (n.inputState.compositionPendingChange = !1, o += ".compose", n.inputState.compositionFirstChange && (o += ".start", n.inputState.compositionFirstChange = !1)), s.update(i, {
        userEvent: o,
        scrollIntoView: !0
    })
}

function Ff(n, t, e, i) {
    let s = Math.min(n.length, t.length),
        r = 0;
    for (; r < s && n.charCodeAt(r) == t.charCodeAt(r);) r++;
    if (r == s && n.length == t.length) return null;
    let o = n.length,
        l = t.length;
    for (; o > 0 && l > 0 && n.charCodeAt(o - 1) == t.charCodeAt(l - 1);) o--, l--;
    if (i == "end") {
        let a = Math.max(0, r - Math.min(o, l));
        e -= o + a - r
    }
    if (o < r && n.length < t.length) {
        let a = e <= r && e >= o ? r - e : 0;
        r -= a, l = r + (l - o), o = r
    } else if (l < r) {
        let a = e <= r && e >= l ? r - e : 0;
        r -= a, o = r + (o - l), l = r
    }
    return {
        from: r,
        toA: o,
        toB: l
    }
}

function jf(n) {
    let t = [];
    if (n.root.activeElement != n.contentDOM) return t;
    let {
        anchorNode: e,
        anchorOffset: i,
        focusNode: s,
        focusOffset: r
    } = n.observer.selectionRange;
    return e && (t.push(new $r(e, i)), (s != e || r != i) && t.push(new $r(s, r))), t
}

function Wf(n, t) {
    if (n.length == 0) return null;
    let e = n[0].pos,
        i = n.length == 2 ? n[1].pos : e;
    return e > -1 && i > -1 ? A.single(e + t, i + t) : null
}
const zf = {
        childList: !0,
        characterData: !0,
        subtree: !0,
        attributes: !0,
        characterDataOldValue: !0
    },
    On = k.ie && k.ie_version <= 11;
class qf {
    constructor(t) {
        this.view = t, this.active = !1, this.editContext = null, this.selectionRange = new Au, this.selectionChanged = !1, this.delayedFlush = -1, this.resizeTimeout = -1, this.queue = [], this.delayedAndroidKey = null, this.flushingAndroidKey = -1, this.lastChange = 0, this.scrollTargets = [], this.intersection = null, this.resizeScroll = null, this.intersecting = !1, this.gapIntersection = null, this.gaps = [], this.printQuery = null, this.parentCheck = -1, this.dom = t.contentDOM, this.observer = new MutationObserver(e => {
            for (let i of e) this.queue.push(i);
            (k.ie && k.ie_version <= 11 || k.ios && t.composing) && e.some(i => i.type == "childList" && i.removedNodes.length || i.type == "characterData" && i.oldValue.length > i.target.nodeValue.length) ? this.flushSoon() : this.flush()
        }), window.EditContext && t.constructor.EDIT_CONTEXT !== !1 && !(k.chrome && k.chrome_version < 126) && (this.editContext = new $f(t), t.state.facet(Zt) && (t.contentDOM.editContext = this.editContext.editContext)), On && (this.onCharData = e => {
            this.queue.push({
                target: e.target,
                type: "characterData",
                oldValue: e.prevValue
            }), this.flushSoon()
        }), this.onSelectionChange = this.onSelectionChange.bind(this), this.onResize = this.onResize.bind(this), this.onPrint = this.onPrint.bind(this), this.onScroll = this.onScroll.bind(this), window.matchMedia && (this.printQuery = window.matchMedia("print")), typeof ResizeObserver == "function" && (this.resizeScroll = new ResizeObserver(() => {
            var e;
            ((e = this.view.docView) === null || e === void 0 ? void 0 : e.lastUpdate) < Date.now() - 75 && this.onResize()
        }), this.resizeScroll.observe(t.scrollDOM)), this.addWindowListeners(this.win = t.win), this.start(), typeof IntersectionObserver == "function" && (this.intersection = new IntersectionObserver(e => {
            this.parentCheck < 0 && (this.parentCheck = setTimeout(this.listenForScroll.bind(this), 1e3)), e.length > 0 && e[e.length - 1].intersectionRatio > 0 != this.intersecting && (this.intersecting = !this.intersecting, this.intersecting != this.view.inView && this.onScrollChanged(document.createEvent("Event")))
        }, {
            threshold: [0, .001]
        }), this.intersection.observe(this.dom), this.gapIntersection = new IntersectionObserver(e => {
            e.length > 0 && e[e.length - 1].intersectionRatio > 0 && this.onScrollChanged(document.createEvent("Event"))
        }, {})), this.listenForScroll(), this.readSelectionRange()
    }
    onScrollChanged(t) {
        this.view.inputState.runHandlers("scroll", t), this.intersecting && this.view.measure()
    }
    onScroll(t) {
        this.intersecting && this.flush(!1), this.editContext && this.view.requestMeasure(this.editContext.measureReq), this.onScrollChanged(t)
    }
    onResize() {
        this.resizeTimeout < 0 && (this.resizeTimeout = setTimeout(() => {
            this.resizeTimeout = -1, this.view.requestMeasure()
        }, 50))
    }
    onPrint(t) {
        t.type == "change" && !t.matches || (this.view.viewState.printing = !0, this.view.measure(), setTimeout(() => {
            this.view.viewState.printing = !1, this.view.requestMeasure()
        }, 500))
    }
    updateGaps(t) {
        if (this.gapIntersection && (t.length != this.gaps.length || this.gaps.some((e, i) => e != t[i]))) {
            this.gapIntersection.disconnect();
            for (let e of t) this.gapIntersection.observe(e);
            this.gaps = t
        }
    }
    onSelectionChange(t) {
        let e = this.selectionChanged;
        if (!this.readSelectionRange() || this.delayedAndroidKey) return;
        let {
            view: i
        } = this, s = this.selectionRange;
        if (i.state.facet(Zt) ? i.root.activeElement != this.dom : !_i(i.dom, s)) return;
        let r = s.anchorNode && i.docView.nearest(s.anchorNode);
        if (r && r.ignoreEvent(t)) {
            e || (this.selectionChanged = !1);
            return
        }(k.ie && k.ie_version <= 11 || k.android && k.chrome) && !i.state.selection.main.empty && s.focusNode && li(s.focusNode, s.focusOffset, s.anchorNode, s.anchorOffset) ? this.flushSoon() : this.flush(!1)
    }
    readSelectionRange() {
        let {
            view: t
        } = this, e = gi(t.root);
        if (!e) return !1;
        let i = k.safari && t.root.nodeType == 11 && Cu(this.dom.ownerDocument) == this.dom && _f(this.view, e) || e;
        if (!i || this.selectionRange.eq(i)) return !1;
        let s = _i(this.dom, i);
        return s && !this.selectionChanged && t.inputState.lastFocusTime > Date.now() - 200 && t.inputState.lastTouchTime < Date.now() - 300 && Eu(this.dom, i) ? (this.view.inputState.lastFocusTime = 0, t.docView.updateSelection(), !1) : (this.selectionRange.setRange(i), s && (this.selectionChanged = !0), !0)
    }
    setSelectionRange(t, e) {
        this.selectionRange.set(t.node, t.offset, e.node, e.offset), this.selectionChanged = !1
    }
    clearSelectionRange() {
        this.selectionRange.set(null, 0, null, 0)
    }
    listenForScroll() {
        this.parentCheck = -1;
        let t = 0,
            e = null;
        for (let i = this.dom; i;)
            if (i.nodeType == 1) !e && t < this.scrollTargets.length && this.scrollTargets[t] == i ? t++ : e || (e = this.scrollTargets.slice(0, t)), e && e.push(i), i = i.assignedSlot || i.parentNode;
            else if (i.nodeType == 11) i = i.host;
        else break;
        if (t < this.scrollTargets.length && !e && (e = this.scrollTargets.slice(0, t)), e) {
            for (let i of this.scrollTargets) i.removeEventListener("scroll", this.onScroll);
            for (let i of this.scrollTargets = e) i.addEventListener("scroll", this.onScroll)
        }
    }
    ignore(t) {
        if (!this.active) return t();
        try {
            return this.stop(), t()
        } finally {
            this.start(), this.clear()
        }
    }
    start() {
        this.active || (this.observer.observe(this.dom, zf), On && this.dom.addEventListener("DOMCharacterDataModified", this.onCharData), this.active = !0)
    }
    stop() {
        this.active && (this.active = !1, this.observer.disconnect(), On && this.dom.removeEventListener("DOMCharacterDataModified", this.onCharData))
    }
    clear() {
        this.processRecords(), this.queue.length = 0, this.selectionChanged = !1
    }
    delayAndroidKey(t, e) {
        var i;
        if (!this.delayedAndroidKey) {
            let s = () => {
                let r = this.delayedAndroidKey;
                r && (this.clearDelayedAndroidKey(), this.view.inputState.lastKeyCode = r.keyCode, this.view.inputState.lastKeyTime = Date.now(), !this.flush() && r.force && Re(this.dom, r.key, r.keyCode))
            };
            this.flushingAndroidKey = this.view.win.requestAnimationFrame(s)
        }(!this.delayedAndroidKey || t == "Enter") && (this.delayedAndroidKey = {
            key: t,
            keyCode: e,
            force: this.lastChange < Date.now() - 50 || !!(!((i = this.delayedAndroidKey) === null || i === void 0) && i.force)
        })
    }
    clearDelayedAndroidKey() {
        this.win.cancelAnimationFrame(this.flushingAndroidKey), this.delayedAndroidKey = null, this.flushingAndroidKey = -1
    }
    flushSoon() {
        this.delayedFlush < 0 && (this.delayedFlush = this.view.win.requestAnimationFrame(() => {
            this.delayedFlush = -1, this.flush()
        }))
    }
    forceFlush() {
        this.delayedFlush >= 0 && (this.view.win.cancelAnimationFrame(this.delayedFlush), this.delayedFlush = -1), this.flush()
    }
    pendingRecords() {
        for (let t of this.observer.takeRecords()) this.queue.push(t);
        return this.queue
    }
    processRecords() {
        let t = this.pendingRecords();
        t.length && (this.queue = []);
        let e = -1,
            i = -1,
            s = !1;
        for (let r of t) {
            let o = this.readMutation(r);
            o && (o.typeOver && (s = !0), e == -1 ? {
                from: e,
                to: i
            } = o : (e = Math.min(o.from, e), i = Math.max(o.to, i)))
        }
        return {
            from: e,
            to: i,
            typeOver: s
        }
    }
    readChange() {
        let {
            from: t,
            to: e,
            typeOver: i
        } = this.processRecords(), s = this.selectionChanged && _i(this.dom, this.selectionRange);
        if (t < 0 && !s) return null;
        t > -1 && (this.lastChange = Date.now()), this.view.inputState.lastFocusTime = 0, this.selectionChanged = !1;
        let r = new Hf(this.view, t, e, i);
        return this.view.docView.domChanged = {
            newSel: r.newSel ? r.newSel.main : null
        }, r
    }
    flush(t = !0) {
        if (this.delayedFlush >= 0 || this.delayedAndroidKey) return !1;
        t && this.readSelectionRange();
        let e = this.readChange();
        if (!e) return this.view.requestMeasure(), !1;
        let i = this.view.state,
            s = Ql(this.view, e);
        return this.view.state == i && (e.domChanged || e.newSel && !e.newSel.main.eq(this.view.state.selection.main)) && this.view.update([]), s
    }
    readMutation(t) {
        let e = this.view.docView.nearest(t.target);
        if (!e || e.ignoreMutation(t)) return null;
        if (e.markDirty(t.type == "attributes"), t.type == "attributes" && (e.flags |= 4), t.type == "childList") {
            let i = Ur(e, t.previousSibling || t.target.previousSibling, -1),
                s = Ur(e, t.nextSibling || t.target.nextSibling, 1);
            return {
                from: i ? e.posAfter(i) : e.posAtStart,
                to: s ? e.posBefore(s) : e.posAtEnd,
                typeOver: !1
            }
        } else return t.type == "characterData" ? {
            from: e.posAtStart,
            to: e.posAtEnd,
            typeOver: t.target.nodeValue == t.oldValue
        } : null
    }
    setWindow(t) {
        t != this.win && (this.removeWindowListeners(this.win), this.win = t, this.addWindowListeners(this.win))
    }
    addWindowListeners(t) {
        t.addEventListener("resize", this.onResize), this.printQuery ? this.printQuery.addEventListener("change", this.onPrint) : t.addEventListener("beforeprint", this.onPrint), t.addEventListener("scroll", this.onScroll), t.document.addEventListener("selectionchange", this.onSelectionChange)
    }
    removeWindowListeners(t) {
        t.removeEventListener("scroll", this.onScroll), t.removeEventListener("resize", this.onResize), this.printQuery ? this.printQuery.removeEventListener("change", this.onPrint) : t.removeEventListener("beforeprint", this.onPrint), t.document.removeEventListener("selectionchange", this.onSelectionChange)
    }
    update(t) {
        this.editContext && (this.editContext.update(t), t.startState.facet(Zt) != t.state.facet(Zt) && (t.view.contentDOM.editContext = t.state.facet(Zt) ? this.editContext.editContext : null))
    }
    destroy() {
        var t, e, i;
        this.stop(), (t = this.intersection) === null || t === void 0 || t.disconnect(), (e = this.gapIntersection) === null || e === void 0 || e.disconnect(), (i = this.resizeScroll) === null || i === void 0 || i.disconnect();
        for (let s of this.scrollTargets) s.removeEventListener("scroll", this.onScroll);
        this.removeWindowListeners(this.win), clearTimeout(this.parentCheck), clearTimeout(this.resizeTimeout), this.win.cancelAnimationFrame(this.delayedFlush), this.win.cancelAnimationFrame(this.flushingAndroidKey), this.editContext && (this.view.contentDOM.editContext = null, this.editContext.destroy())
    }
}

function Ur(n, t, e) {
    for (; t;) {
        let i = j.get(t);
        if (i && i.parent == n) return i;
        let s = t.parentNode;
        t = s != n.dom ? s : e > 0 ? t.nextSibling : t.previousSibling
    }
    return null
}

function Gr(n, t) {
    let e = t.startContainer,
        i = t.startOffset,
        s = t.endContainer,
        r = t.endOffset,
        o = n.docView.domAtPos(n.state.selection.main.anchor);
    return li(o.node, o.offset, s, r) && ([e, i, s, r] = [s, r, e, i]), {
        anchorNode: e,
        anchorOffset: i,
        focusNode: s,
        focusOffset: r
    }
}

function _f(n, t) {
    if (t.getComposedRanges) {
        let s = t.getComposedRanges(n.root)[0];
        if (s) return Gr(n, s)
    }
    let e = null;

    function i(s) {
        s.preventDefault(), s.stopImmediatePropagation(), e = s.getTargetRanges()[0]
    }
    return n.contentDOM.addEventListener("beforeinput", i, !0), n.dom.ownerDocument.execCommand("indent"), n.contentDOM.removeEventListener("beforeinput", i, !0), e ? Gr(n, e) : null
}
class $f {
    constructor(t) {
        this.from = 0, this.to = 0, this.pendingContextChange = null, this.handlers = Object.create(null), this.resetRange(t.state);
        let e = this.editContext = new window.EditContext({
            text: t.state.doc.sliceString(this.from, this.to),
            selectionStart: this.toContextPos(Math.max(this.from, Math.min(this.to, t.state.selection.main.anchor))),
            selectionEnd: this.toContextPos(t.state.selection.main.head)
        });
        this.handlers.textupdate = i => {
            let {
                anchor: s
            } = t.state.selection.main, r = {
                from: this.toEditorPos(i.updateRangeStart),
                to: this.toEditorPos(i.updateRangeEnd),
                insert: N.of(i.text.split(`
`))
            };
            r.from == this.from && s < this.from ? r.from = s : r.to == this.to && s > this.to && (r.to = s), !(r.from == r.to && !r.insert.length) && (this.pendingContextChange = r, Zl(t, r, A.single(this.toEditorPos(i.selectionStart), this.toEditorPos(i.selectionEnd))), this.pendingContextChange && (this.revertPending(t.state), this.setSelection(t.state)))
        }, this.handlers.characterboundsupdate = i => {
            let s = [],
                r = null;
            for (let o = this.toEditorPos(i.rangeStart), l = this.toEditorPos(i.rangeEnd); o < l; o++) {
                let a = t.coordsForChar(o);
                r = a && new DOMRect(a.left, a.top, a.right - a.left, a.bottom - a.top) || r || new DOMRect, s.push(r)
            }
            e.updateCharacterBounds(i.rangeStart, s)
        }, this.handlers.textformatupdate = i => {
            let s = [];
            for (let r of i.getTextFormats()) {
                let o = r.underlineStyle,
                    l = r.underlineThickness;
                if (o != "None" && l != "None") {
                    let a = `text-decoration: underline ${o=="Dashed"?"dashed ":o=="Squiggle"?"wavy ":""}${l=="Thin"?1:2}px`;
                    s.push(B.mark({
                        attributes: {
                            style: a
                        }
                    }).range(this.toEditorPos(r.rangeStart), this.toEditorPos(r.rangeEnd)))
                }
            }
            t.dispatch({
                effects: Rl.of(B.set(s))
            })
        }, this.handlers.compositionstart = () => {
            t.inputState.composing < 0 && (t.inputState.composing = 0, t.inputState.compositionFirstChange = !0)
        }, this.handlers.compositionend = () => {
            t.inputState.composing = -1, t.inputState.compositionFirstChange = null
        };
        for (let i in this.handlers) e.addEventListener(i, this.handlers[i]);
        this.measureReq = {
            read: i => {
                this.editContext.updateControlBounds(i.contentDOM.getBoundingClientRect());
                let s = gi(i.root);
                s && s.rangeCount && this.editContext.updateSelectionBounds(s.getRangeAt(0).getBoundingClientRect())
            }
        }
    }
    applyEdits(t) {
        let e = 0,
            i = !1,
            s = this.pendingContextChange;
        return t.changes.iterChanges((r, o, l, a, c) => {
            if (i) return;
            let h = c.length - (o - r);
            if (s && o >= s.to)
                if (s.from == r && s.to == o && s.insert.eq(c)) {
                    s = this.pendingContextChange = null, e += h, this.to += h;
                    return
                } else s = null, this.revertPending(t.state);
            if (r += e, o += e, o <= this.from) this.from += h, this.to += h;
            else if (r < this.to) {
                if (r < this.from || o > this.to || this.to - this.from + c.length > 3e4) {
                    i = !0;
                    return
                }
                this.editContext.updateText(this.toContextPos(r), this.toContextPos(o), c.toString()), this.to += h
            }
            e += h
        }), s && !i && this.revertPending(t.state), !i
    }
    update(t) {
        let e = this.pendingContextChange;
        !this.applyEdits(t) || !this.rangeIsValid(t.state) ? (this.pendingContextChange = null, this.resetRange(t.state), this.editContext.updateText(0, this.editContext.text.length, t.state.doc.sliceString(this.from, this.to)), this.setSelection(t.state)) : (t.docChanged || t.selectionSet || e) && this.setSelection(t.state), (t.geometryChanged || t.docChanged || t.selectionSet) && t.view.requestMeasure(this.measureReq)
    }
    resetRange(t) {
        let {
            head: e
        } = t.selection.main;
        this.from = Math.max(0, e - 1e4), this.to = Math.min(t.doc.length, e + 1e4)
    }
    revertPending(t) {
        let e = this.pendingContextChange;
        this.pendingContextChange = null, this.editContext.updateText(this.toContextPos(e.from), this.toContextPos(e.from + e.insert.length), t.doc.sliceString(e.from, e.to))
    }
    setSelection(t) {
        let {
            main: e
        } = t.selection, i = this.toContextPos(Math.max(this.from, Math.min(this.to, e.anchor))), s = this.toContextPos(e.head);
        (this.editContext.selectionStart != i || this.editContext.selectionEnd != s) && this.editContext.updateSelection(i, s)
    }
    rangeIsValid(t) {
        let {
            head: e
        } = t.selection.main;
        return !(this.from > 0 && e - this.from < 500 || this.to < t.doc.length && this.to - e < 500 || this.to - this.from > 1e4 * 3)
    }
    toEditorPos(t) {
        return t + this.from
    }
    toContextPos(t) {
        return t - this.from
    }
    destroy() {
        for (let t in this.handlers) this.editContext.removeEventListener(t, this.handlers[t])
    }
}
class P {
    get state() {
        return this.viewState.state
    }
    get viewport() {
        return this.viewState.viewport
    }
    get visibleRanges() {
        return this.viewState.visibleRanges
    }
    get inView() {
        return this.viewState.inView
    }
    get composing() {
        return this.inputState.composing > 0
    }
    get compositionStarted() {
        return this.inputState.composing >= 0
    }
    get root() {
        return this._root
    }
    get win() {
        return this.dom.ownerDocument.defaultView || window
    }
    constructor(t = {}) {
        this.plugins = [], this.pluginMap = new Map, this.editorAttrs = {}, this.contentAttrs = {}, this.bidiCache = [], this.destroyed = !1, this.updateState = 2, this.measureScheduled = -1, this.measureRequests = [], this.contentDOM = document.createElement("div"), this.scrollDOM = document.createElement("div"), this.scrollDOM.tabIndex = -1, this.scrollDOM.className = "cm-scroller", this.scrollDOM.appendChild(this.contentDOM), this.announceDOM = document.createElement("div"), this.announceDOM.className = "cm-announced", this.announceDOM.setAttribute("aria-live", "polite"), this.dom = document.createElement("div"), this.dom.appendChild(this.announceDOM), this.dom.appendChild(this.scrollDOM), t.parent && t.parent.appendChild(this.dom);
        let {
            dispatch: e
        } = t;
        this.dispatchTransactions = t.dispatchTransactions || e && (i => i.forEach(s => e(s, this))) || (i => this.update(i)), this.dispatch = this.dispatch.bind(this), this._root = t.root || Tu(t.parent) || document, this.viewState = new qr(t.state || q.create(t)), t.scrollTo && t.scrollTo.is(Pi) && (this.viewState.scrollTarget = t.scrollTo.value.clip(this.viewState.state)), this.plugins = this.state.facet(ti).map(i => new An(i));
        for (let i of this.plugins) i.update(this);
        this.observer = new qf(this), this.inputState = new of (this), this.inputState.ensureHandlers(this.plugins), this.docView = new Mr(this), this.mountStyles(), this.updateAttrs(), this.updateState = 0, this.requestMeasure()
    }
    dispatch(...t) {
        let e = t.length == 1 && t[0] instanceof ct ? t : t.length == 1 && Array.isArray(t[0]) ? t[0] : [this.state.update(...t)];
        this.dispatchTransactions(e, this)
    }
    update(t) {
        if (this.updateState != 0) throw new Error("Calls to EditorView.update are not allowed while an update is in progress");
        let e = !1,
            i = !1,
            s, r = this.state;
        for (let f of t) {
            if (f.startState != r) throw new RangeError("Trying to update state with a transaction that doesn't start from the previous state.");
            r = f.state
        }
        if (this.destroyed) {
            this.viewState.state = r;
            return
        }
        let o = this.hasFocus,
            l = 0,
            a = null;
        t.some(f => f.annotation($l)) ? (this.inputState.notifiedFocused = o, l = 1) : o != this.inputState.notifiedFocused && (this.inputState.notifiedFocused = o, a = Ul(r, o), a || (l = 1));
        let c = this.observer.delayedAndroidKey,
            h = null;
        if (c ? (this.observer.clearDelayedAndroidKey(), h = this.observer.readChange(), (h && !this.state.doc.eq(r.doc) || !this.state.selection.eq(r.selection)) && (h = null)) : this.observer.clear(), r.facet(q.phrases) != this.state.facet(q.phrases)) return this.setState(r);
        s = sn.create(this, r, t), s.flags |= l;
        let u = this.viewState.scrollTarget;
        try {
            this.updateState = 2;
            for (let f of t) {
                if (u && (u = u.map(f.changes)), f.scrollIntoView) {
                    let {
                        main: d
                    } = f.state.selection;
                    u = new Pe(d.empty ? d : A.cursor(d.head, d.head > d.anchor ? -1 : 1))
                }
                for (let d of f.effects) d.is(Pi) && (u = d.value.clip(this.state))
            }
            this.viewState.update(s, u), this.bidiCache = rn.update(this.bidiCache, s.changes), s.empty || (this.updatePlugins(s), this.inputState.update(s)), e = this.docView.update(s), this.state.facet(ei) != this.styleModules && this.mountStyles(), i = this.updateAttrs(), this.showAnnouncements(t), this.docView.updateSelection(e, t.some(f => f.isUserEvent("select.pointer")))
        } finally {
            this.updateState = 0
        }
        if (s.startState.facet(Vi) != s.state.facet(Vi) && (this.viewState.mustMeasureContent = !0), (e || i || u || this.viewState.mustEnforceCursorAssoc || this.viewState.mustMeasureContent) && this.requestMeasure(), e && this.docViewUpdate(), !s.empty)
            for (let f of this.state.facet(us)) try {
                f(s)
            } catch (d) {
                Ut(this.state, d, "update listener")
            }(a || h) && Promise.resolve().then(() => {
                a && this.state == a.startState && this.dispatch(a), h && !Ql(this, h) && c.force && Re(this.contentDOM, c.key, c.keyCode)
            })
    }
    setState(t) {
        if (this.updateState != 0) throw new Error("Calls to EditorView.setState are not allowed while an update is in progress");
        if (this.destroyed) {
            this.viewState.state = t;
            return
        }
        this.updateState = 2;
        let e = this.hasFocus;
        try {
            for (let i of this.plugins) i.destroy(this);
            this.viewState = new qr(t), this.plugins = t.facet(ti).map(i => new An(i)), this.pluginMap.clear();
            for (let i of this.plugins) i.update(this);
            this.docView.destroy(), this.docView = new Mr(this), this.inputState.ensureHandlers(this.plugins), this.mountStyles(), this.updateAttrs(), this.bidiCache = []
        } finally {
            this.updateState = 0
        }
        e && this.focus(), this.requestMeasure()
    }
    updatePlugins(t) {
        let e = t.startState.facet(ti),
            i = t.state.facet(ti);
        if (e != i) {
            let s = [];
            for (let r of i) {
                let o = e.indexOf(r);
                if (o < 0) s.push(new An(r));
                else {
                    let l = this.plugins[o];
                    l.mustUpdate = t, s.push(l)
                }
            }
            for (let r of this.plugins) r.mustUpdate != t && r.destroy(this);
            this.plugins = s, this.pluginMap.clear()
        } else
            for (let s of this.plugins) s.mustUpdate = t;
        for (let s = 0; s < this.plugins.length; s++) this.plugins[s].update(this);
        e != i && this.inputState.ensureHandlers(this.plugins)
    }
    docViewUpdate() {
        for (let t of this.plugins) {
            let e = t.value;
            if (e && e.docViewUpdate) try {
                e.docViewUpdate(this)
            } catch (i) {
                Ut(this.state, i, "doc view update listener")
            }
        }
    }
    measure(t = !0) {
        if (this.destroyed) return;
        if (this.measureScheduled > -1 && this.win.cancelAnimationFrame(this.measureScheduled), this.observer.delayedAndroidKey) {
            this.measureScheduled = -1, this.requestMeasure();
            return
        }
        this.measureScheduled = 0, t && this.observer.forceFlush();
        let e = null,
            i = this.scrollDOM,
            s = i.scrollTop * this.scaleY,
            {
                scrollAnchorPos: r,
                scrollAnchorHeight: o
            } = this.viewState;
        Math.abs(s - this.viewState.scrollTop) > 1 && (o = -1), this.viewState.scrollAnchorHeight = -1;
        try {
            for (let l = 0;; l++) {
                if (o < 0)
                    if (rl(i)) r = -1, o = this.viewState.heightMap.height;
                    else {
                        let d = this.viewState.scrollAnchorAt(s);
                        r = d.from, o = d.top
                    }
                this.updateState = 1;
                let a = this.viewState.measure(this);
                if (!a && !this.measureRequests.length && this.viewState.scrollTarget == null) break;
                if (l > 5) {
                    console.warn(this.measureRequests.length ? "Measure loop restarted more than 5 times" : "Viewport failed to stabilize");
                    break
                }
                let c = [];
                a & 4 || ([this.measureRequests, c] = [c, this.measureRequests]);
                let h = c.map(d => {
                        try {
                            return d.read(this)
                        } catch (m) {
                            return Ut(this.state, m), Kr
                        }
                    }),
                    u = sn.create(this, this.state, []),
                    f = !1;
                u.flags |= a, e ? e.flags |= a : e = u, this.updateState = 2, u.empty || (this.updatePlugins(u), this.inputState.update(u), this.updateAttrs(), f = this.docView.update(u), f && this.docViewUpdate());
                for (let d = 0; d < c.length; d++)
                    if (h[d] != Kr) try {
                        let m = c[d];
                        m.write && m.write(h[d], this)
                    } catch (m) {
                        Ut(this.state, m)
                    }
                if (f && this.docView.updateSelection(!0), !u.viewportChanged && this.measureRequests.length == 0) {
                    if (this.viewState.editorHeight)
                        if (this.viewState.scrollTarget) {
                            this.docView.scrollIntoView(this.viewState.scrollTarget), this.viewState.scrollTarget = null, o = -1;
                            continue
                        } else {
                            let m = (r < 0 ? this.viewState.heightMap.height : this.viewState.lineBlockAt(r).top) - o;
                            if (m > 1 || m < -1) {
                                s = s + m, i.scrollTop = s / this.scaleY, o = -1;
                                continue
                            }
                        }
                    break
                }
            }
        } finally {
            this.updateState = 0, this.measureScheduled = -1
        }
        if (e && !e.empty)
            for (let l of this.state.facet(us)) l(e)
    }
    get themeClasses() {
        return ps + " " + (this.state.facet(gs) ? Xl : Yl) + " " + this.state.facet(Vi)
    }
    updateAttrs() {
        let t = Yr(this, Pl, {
                class: "cm-editor" + (this.hasFocus ? " cm-focused " : " ") + this.themeClasses
            }),
            e = {
                spellcheck: "false",
                autocorrect: "off",
                autocapitalize: "off",
                translate: "no",
                contenteditable: this.state.facet(Zt) ? "true" : "false",
                class: "cm-content",
                style: `${k.tabSize}: ${this.state.tabSize}`,
                role: "textbox",
                "aria-multiline": "true"
            };
        this.state.readOnly && (e["aria-readonly"] = "true"), Yr(this, Fs, e);
        let i = this.observer.ignore(() => {
            let s = os(this.contentDOM, this.contentAttrs, e),
                r = os(this.dom, this.editorAttrs, t);
            return s || r
        });
        return this.editorAttrs = t, this.contentAttrs = e, i
    }
    showAnnouncements(t) {
        let e = !0;
        for (let i of t)
            for (let s of i.effects)
                if (s.is(P.announce)) {
                    e && (this.announceDOM.textContent = ""), e = !1;
                    let r = this.announceDOM.appendChild(document.createElement("div"));
                    r.textContent = s.value
                }
    }
    mountStyles() {
        this.styleModules = this.state.facet(ei);
        let t = this.state.facet(P.cspNonce);
        Ve.mount(this.root, this.styleModules.concat(Nf).reverse(), t ? {
            nonce: t
        } : void 0)
    }
    readMeasured() {
        if (this.updateState == 2) throw new Error("Reading the editor layout isn't allowed during an update");
        this.updateState == 0 && this.measureScheduled > -1 && this.measure(!1)
    }
    requestMeasure(t) {
        if (this.measureScheduled < 0 && (this.measureScheduled = this.win.requestAnimationFrame(() => this.measure())), t) {
            if (this.measureRequests.indexOf(t) > -1) return;
            if (t.key != null) {
                for (let e = 0; e < this.measureRequests.length; e++)
                    if (this.measureRequests[e].key === t.key) {
                        this.measureRequests[e] = t;
                        return
                    }
            }
            this.measureRequests.push(t)
        }
    }
    plugin(t) {
        let e = this.pluginMap.get(t);
        return (e === void 0 || e && e.spec != t) && this.pluginMap.set(t, e = this.plugins.find(i => i.spec == t) || null), e && e.update(this).value
    }
    get documentTop() {
        return this.contentDOM.getBoundingClientRect().top + this.viewState.paddingTop
    }
    get documentPadding() {
        return {
            top: this.viewState.paddingTop,
            bottom: this.viewState.paddingBottom
        }
    }
    get scaleX() {
        return this.viewState.scaleX
    }
    get scaleY() {
        return this.viewState.scaleY
    }
    elementAtHeight(t) {
        return this.readMeasured(), this.viewState.elementAtHeight(t)
    }
    lineBlockAtHeight(t) {
        return this.readMeasured(), this.viewState.lineBlockAtHeight(t)
    }
    get viewportLineBlocks() {
        return this.viewState.viewportLines
    }
    lineBlockAt(t) {
        return this.viewState.lineBlockAt(t)
    }
    get contentHeight() {
        return this.viewState.contentHeight
    }
    moveByChar(t, e, i) {
        return En(this, t, Rr(this, t, e, i))
    }
    moveByGroup(t, e) {
        return En(this, t, Rr(this, t, e, i => sf(this, t.head, i)))
    }
    visualLineSide(t, e) {
        let i = this.bidiSpans(t),
            s = this.textDirectionAt(t.from),
            r = i[e ? i.length - 1 : 0];
        return A.cursor(r.side(e, s) + t.from, r.forward(!e, s) ? 1 : -1)
    }
    moveToLineBoundary(t, e, i = !0) {
        return nf(this, t, e, i)
    }
    moveVertically(t, e, i) {
        return En(this, t, rf(this, t, e, i))
    }
    domAtPos(t) {
        return this.docView.domAtPos(t)
    }
    posAtDOM(t, e = 0) {
        return this.docView.posFromDOM(t, e)
    }
    posAtCoords(t, e = !0) {
        return this.readMeasured(), Vl(this, t, e)
    }
    coordsAtPos(t, e = 1) {
        this.readMeasured();
        let i = this.docView.coordsAt(t, e);
        if (!i || i.left == i.right) return i;
        let s = this.state.doc.lineAt(t),
            r = this.bidiSpans(s),
            o = r[ie.find(r, t - s.from, -1, e)];
        return mn(i, o.dir == Q.LTR == e > 0)
    }
    coordsForChar(t) {
        return this.readMeasured(), this.docView.coordsForChar(t)
    }
    get defaultCharacterWidth() {
        return this.viewState.heightOracle.charWidth
    }
    get defaultLineHeight() {
        return this.viewState.heightOracle.lineHeight
    }
    get textDirection() {
        return this.viewState.defaultTextDirection
    }
    textDirectionAt(t) {
        return !this.state.facet(El) || t < this.viewport.from || t > this.viewport.to ? this.textDirection : (this.readMeasured(), this.docView.textDirectionAt(t))
    }
    get lineWrapping() {
        return this.viewState.heightOracle.lineWrapping
    }
    bidiSpans(t) {
        if (t.length > Uf) return wl(t.length);
        let e = this.textDirectionAt(t.from),
            i;
        for (let r of this.bidiCache)
            if (r.from == t.from && r.dir == e && (r.fresh || bl(r.isolates, i = kr(this, t)))) return r.order;
        i || (i = kr(this, t));
        let s = ju(t.text, e, i);
        return this.bidiCache.push(new rn(t.from, t.to, e, i, !0, s)), s
    }
    get hasFocus() {
        var t;
        return (this.dom.ownerDocument.hasFocus() || k.safari && ((t = this.inputState) === null || t === void 0 ? void 0 : t.lastContextMenu) > Date.now() - 3e4) && this.root.activeElement == this.contentDOM
    }
    focus() {
        this.observer.ignore(() => {
            nl(this.contentDOM), this.docView.updateSelection()
        })
    }
    setRoot(t) {
        this._root != t && (this._root = t, this.observer.setWindow((t.nodeType == 9 ? t : t.ownerDocument).defaultView || window), this.mountStyles())
    }
    destroy() {
        this.root.activeElement == this.contentDOM && this.contentDOM.blur();
        for (let t of this.plugins) t.destroy(this);
        this.plugins = [], this.inputState.destroy(), this.docView.destroy(), this.dom.remove(), this.observer.destroy(), this.measureScheduled > -1 && this.win.cancelAnimationFrame(this.measureScheduled), this.destroyed = !0
    }
    static scrollIntoView(t, e = {}) {
        return Pi.of(new Pe(typeof t == "number" ? A.cursor(t) : t, e.y, e.x, e.yMargin, e.xMargin))
    }
    scrollSnapshot() {
        let {
            scrollTop: t,
            scrollLeft: e
        } = this.scrollDOM, i = this.viewState.scrollAnchorAt(t);
        return Pi.of(new Pe(A.cursor(i.from), "start", "start", i.top - t, e, !0))
    }
    setTabFocusMode(t) {
        t == null ? this.inputState.tabFocusMode = this.inputState.tabFocusMode < 0 ? 0 : -1 : typeof t == "boolean" ? this.inputState.tabFocusMode = t ? 0 : -1 : this.inputState.tabFocusMode != 0 && (this.inputState.tabFocusMode = Date.now() + t)
    }
    static domEventHandlers(t) {
        return Nt.define(() => ({}), {
            eventHandlers: t
        })
    }
    static domEventObservers(t) {
        return Nt.define(() => ({}), {
            eventObservers: t
        })
    }
    static theme(t, e) {
        let i = Ve.newName(),
            s = [Vi.of(i), ei.of(ys(`.${i}`, t))];
        return e && e.dark && s.push(gs.of(!0)), s
    }
    static baseTheme(t) {
        return Ns.lowest(ei.of(ys("." + ps, t, Jl)))
    }
    static findFromDOM(t) {
        var e;
        let i = t.querySelector(".cm-content"),
            s = i && j.get(i) || j.get(t);
        return ((e = s ? .rootView) === null || e === void 0 ? void 0 : e.view) || null
    }
}
P.styleModule = ei;
P.inputHandler = Al;
P.scrollHandler = Ol;
P.focusChangeEffect = Tl;
P.perLineTextDirection = El;
P.exceptionSink = Ml;
P.updateListener = us;
P.editable = Zt;
P.mouseSelectionStyle = kl;
P.dragMovesSelection = Sl;
P.clickAddsSelectionRange = Cl;
P.decorations = pi;
P.outerDecorations = Ll;
P.atomicRanges = js;
P.bidiIsolatedRanges = Nl;
P.scrollMargins = Il;
P.darkTheme = gs;
P.cspNonce = E.define({
    combine: n => n.length ? n[0] : ""
});
P.contentAttributes = Fs;
P.editorAttributes = Pl;
P.lineWrapping = P.contentAttributes.of({
    class: "cm-lineWrapping"
});
P.announce = G.define();
const Uf = 4096,
    Kr = {};
class rn {
    constructor(t, e, i, s, r, o) {
        this.from = t, this.to = e, this.dir = i, this.isolates = s, this.fresh = r, this.order = o
    }
    static update(t, e) {
        if (e.empty && !t.some(r => r.fresh)) return t;
        let i = [],
            s = t.length ? t[t.length - 1].dir : Q.LTR;
        for (let r = Math.max(0, t.length - 10); r < t.length; r++) {
            let o = t[r];
            o.dir == s && !e.touchesRange(o.from, o.to) && i.push(new rn(e.mapPos(o.from, 1), e.mapPos(o.to, -1), o.dir, o.isolates, !1, o.order))
        }
        return i
    }
}

function Yr(n, t, e) {
    for (let i = n.state.facet(t), s = i.length - 1; s >= 0; s--) {
        let r = i[s],
            o = typeof r == "function" ? r(n) : r;
        o && rs(o, e)
    }
    return e
}
const Gf = k.mac ? "mac" : k.windows ? "win" : k.linux ? "linux" : "key";

function Kf(n, t) {
    const e = n.split(/-(?!$)/);
    let i = e[e.length - 1];
    i == "Space" && (i = " ");
    let s, r, o, l;
    for (let a = 0; a < e.length - 1; ++a) {
        const c = e[a];
        if (/^(cmd|meta|m)$/i.test(c)) l = !0;
        else if (/^a(lt)?$/i.test(c)) s = !0;
        else if (/^(c|ctrl|control)$/i.test(c)) r = !0;
        else if (/^s(hift)?$/i.test(c)) o = !0;
        else if (/^mod$/i.test(c)) t == "mac" ? l = !0 : r = !0;
        else throw new Error("Unrecognized modifier name: " + c)
    }
    return s && (i = "Alt-" + i), r && (i = "Ctrl-" + i), l && (i = "Meta-" + i), o && (i = "Shift-" + i), i
}

function Fi(n, t, e) {
    return t.altKey && (n = "Alt-" + n), t.ctrlKey && (n = "Ctrl-" + n), t.metaKey && (n = "Meta-" + n), e !== !1 && t.shiftKey && (n = "Shift-" + n), n
}
const Yf = Ns.default(P.domEventHandlers({
        keydown(n, t) {
            return td(Jf(t.state), n, t, "editor")
        }
    })),
    Xf = E.define({
        enables: Yf
    }),
    Xr = new WeakMap;

function Jf(n) {
    let t = n.facet(Xf),
        e = Xr.get(t);
    return e || Xr.set(t, e = Zf(t.reduce((i, s) => i.concat(s), []))), e
}
let te = null;
const Qf = 4e3;

function Zf(n, t = Gf) {
    let e = Object.create(null),
        i = Object.create(null),
        s = (o, l) => {
            let a = i[o];
            if (a == null) i[o] = l;
            else if (a != l) throw new Error("Key binding " + o + " is used both as a regular binding and as a multi-stroke prefix")
        },
        r = (o, l, a, c, h) => {
            var u, f;
            let d = e[o] || (e[o] = Object.create(null)),
                m = l.split(/ (?!$)/).map(y => Kf(y, t));
            for (let y = 1; y < m.length; y++) {
                let b = m.slice(0, y).join(" ");
                s(b, !0), d[b] || (d[b] = {
                    preventDefault: !0,
                    stopPropagation: !1,
                    run: [v => {
                        let w = te = {
                            view: v,
                            prefix: b,
                            scope: o
                        };
                        return setTimeout(() => {
                            te == w && (te = null)
                        }, Qf), !0
                    }]
                })
            }
            let g = m.join(" ");
            s(g, !1);
            let p = d[g] || (d[g] = {
                preventDefault: !1,
                stopPropagation: !1,
                run: ((f = (u = d._any) === null || u === void 0 ? void 0 : u.run) === null || f === void 0 ? void 0 : f.slice()) || []
            });
            a && p.run.push(a), c && (p.preventDefault = !0), h && (p.stopPropagation = !0)
        };
    for (let o of n) {
        let l = o.scope ? o.scope.split(" ") : ["editor"];
        if (o.any)
            for (let c of l) {
                let h = e[c] || (e[c] = Object.create(null));
                h._any || (h._any = {
                    preventDefault: !1,
                    stopPropagation: !1,
                    run: []
                });
                let {
                    any: u
                } = o;
                for (let f in h) h[f].run.push(d => u(d, xs))
            }
        let a = o[t] || o.key;
        if (a)
            for (let c of l) r(c, a, o.run, o.preventDefault, o.stopPropagation), o.shift && r(c, "Shift-" + a, o.shift, o.preventDefault, o.stopPropagation)
    }
    return e
}
let xs = null;

function td(n, t, e, i) {
    xs = t;
    let s = ch(t),
        r = ri(s, 0),
        o = zn(r) == s.length && s != " ",
        l = "",
        a = !1,
        c = !1,
        h = !1;
    te && te.view == e && te.scope == i && (l = te.prefix + " ", jl.indexOf(t.keyCode) < 0 && (c = !0, te = null));
    let u = new Set,
        f = p => {
            if (p) {
                for (let y of p.run)
                    if (!u.has(y) && (u.add(y), y(e))) return p.stopPropagation && (h = !0), !0;
                p.preventDefault && (p.stopPropagation && (h = !0), c = !0)
            }
            return !1
        },
        d = n[i],
        m, g;
    return d && (f(d[l + Fi(s, t, !o)]) ? a = !0 : o && (t.altKey || t.metaKey || t.ctrlKey) && !(k.windows && t.ctrlKey && t.altKey) && (m = uh[t.keyCode]) && m != s ? (f(d[l + Fi(m, t, !0)]) || t.shiftKey && (g = fh[t.keyCode]) != s && g != m && f(d[l + Fi(g, t, !1)])) && (a = !0) : o && t.shiftKey && f(d[l + Fi(s, t, !0)]) && (a = !0), !a && f(d._any) && (a = !0)), c && (a = !0), a && h && t.stopPropagation(), xs = null, a
}
class Mi {
    constructor(t, e, i, s, r) {
        this.className = t, this.left = e, this.top = i, this.width = s, this.height = r
    }
    draw() {
        let t = document.createElement("div");
        return t.className = this.className, this.adjust(t), t
    }
    update(t, e) {
        return e.className != this.className ? !1 : (this.adjust(t), !0)
    }
    adjust(t) {
        t.style.left = this.left + "px", t.style.top = this.top + "px", this.width != null && (t.style.width = this.width + "px"), t.style.height = this.height + "px"
    }
    eq(t) {
        return this.left == t.left && this.top == t.top && this.width == t.width && this.height == t.height && this.className == t.className
    }
    static forRange(t, e, i) {
        if (i.empty) {
            let s = t.coordsAtPos(i.head, i.assoc || 1);
            if (!s) return [];
            let r = ta(t);
            return [new Mi(e, s.left - r.left, s.top - r.top, null, s.bottom - s.top)]
        } else return ed(t, e, i)
    }
}

function ta(n) {
    let t = n.scrollDOM.getBoundingClientRect();
    return {
        left: (n.textDirection == Q.LTR ? t.left : t.right - n.scrollDOM.clientWidth * n.scaleX) - n.scrollDOM.scrollLeft * n.scaleX,
        top: t.top - n.scrollDOM.scrollTop * n.scaleY
    }
}

function Jr(n, t, e, i) {
    let s = n.coordsAtPos(t, e * 2);
    if (!s) return i;
    let r = n.dom.getBoundingClientRect(),
        o = (s.top + s.bottom) / 2,
        l = n.posAtCoords({
            x: r.left + 1,
            y: o
        }),
        a = n.posAtCoords({
            x: r.right - 1,
            y: o
        });
    return l == null || a == null ? i : {
        from: Math.max(i.from, Math.min(l, a)),
        to: Math.min(i.to, Math.max(l, a))
    }
}

function ed(n, t, e) {
    if (e.to <= n.viewport.from || e.from >= n.viewport.to) return [];
    let i = Math.max(e.from, n.viewport.from),
        s = Math.min(e.to, n.viewport.to),
        r = n.textDirection == Q.LTR,
        o = n.contentDOM,
        l = o.getBoundingClientRect(),
        a = ta(n),
        c = o.querySelector(".cm-line"),
        h = c && window.getComputedStyle(c),
        u = l.left + (h ? parseInt(h.paddingLeft) + Math.min(0, parseInt(h.textIndent)) : 0),
        f = l.right - (h ? parseInt(h.paddingRight) : 0),
        d = ds(n, i),
        m = ds(n, s),
        g = d.type == dt.Text ? d : null,
        p = m.type == dt.Text ? m : null;
    if (g && (n.lineWrapping || d.widgetLineBreaks) && (g = Jr(n, i, 1, g)), p && (n.lineWrapping || m.widgetLineBreaks) && (p = Jr(n, s, -1, p)), g && p && g.from == p.from && g.to == p.to) return b(v(e.from, e.to, g)); {
        let S = g ? v(e.from, null, g) : w(d, !1),
            M = p ? v(null, e.to, p) : w(m, !0),
            D = [];
        return (g || d).to < (p || m).from - (g && p ? 1 : 0) || d.widgetLineBreaks > 1 && S.bottom + n.defaultLineHeight / 2 < M.top ? D.push(y(u, S.bottom, f, M.top)) : S.bottom < M.top && n.elementAtHeight((S.bottom + M.top) / 2).type == dt.Text && (S.bottom = M.top = (S.bottom + M.top) / 2), b(S).concat(D).concat(b(M))
    }

    function y(S, M, D, T) {
        return new Mi(t, S - a.left, M - a.top - .01, D - S, T - M + .01)
    }

    function b({
        top: S,
        bottom: M,
        horizontal: D
    }) {
        let T = [];
        for (let O = 0; O < D.length; O += 2) T.push(y(D[O], S, D[O + 1], M));
        return T
    }

    function v(S, M, D) {
        let T = 1e9,
            O = -1e9,
            K = [];

        function rt(Z, et, xt, R, Bt) {
            let _ = n.coordsAtPos(Z, Z == D.to ? -2 : 2),
                Y = n.coordsAtPos(xt, xt == D.from ? 2 : -2);
            !_ || !Y || (T = Math.min(_.top, Y.top, T), O = Math.max(_.bottom, Y.bottom, O), Bt == Q.LTR ? K.push(r && et ? u : _.left, r && R ? f : Y.right) : K.push(!r && R ? u : Y.left, !r && et ? f : _.right))
        }
        let ot = S ? ? D.from,
            $ = M ? ? D.to;
        for (let Z of n.visibleRanges)
            if (Z.to > ot && Z.from < $)
                for (let et = Math.max(Z.from, ot), xt = Math.min(Z.to, $);;) {
                    let R = n.state.doc.lineAt(et);
                    for (let Bt of n.bidiSpans(R)) {
                        let _ = Bt.from + R.from,
                            Y = Bt.to + R.from;
                        if (_ >= xt) break;
                        Y > et && rt(Math.max(_, et), S == null && _ <= ot, Math.min(Y, xt), M == null && Y >= $, Bt.dir)
                    }
                    if (et = R.to + 1, et >= xt) break
                }
        return K.length == 0 && rt(ot, S == null, $, M == null, n.textDirection), {
            top: T,
            bottom: O,
            horizontal: K
        }
    }

    function w(S, M) {
        let D = l.top + (M ? S.top : S.bottom);
        return {
            top: D,
            bottom: D,
            horizontal: []
        }
    }
}

function id(n, t) {
    return n.constructor == t.constructor && n.eq(t)
}
class nd {
    constructor(t, e) {
        this.view = t, this.layer = e, this.drawn = [], this.scaleX = 1, this.scaleY = 1, this.measureReq = {
            read: this.measure.bind(this),
            write: this.draw.bind(this)
        }, this.dom = t.scrollDOM.appendChild(document.createElement("div")), this.dom.classList.add("cm-layer"), e.above && this.dom.classList.add("cm-layer-above"), e.class && this.dom.classList.add(e.class), this.scale(), this.dom.setAttribute("aria-hidden", "true"), this.setOrder(t.state), t.requestMeasure(this.measureReq), e.mount && e.mount(this.dom, t)
    }
    update(t) {
        t.startState.facet(Gi) != t.state.facet(Gi) && this.setOrder(t.state), (this.layer.update(t, this.dom) || t.geometryChanged) && (this.scale(), t.view.requestMeasure(this.measureReq))
    }
    docViewUpdate(t) {
        this.layer.updateOnDocViewUpdate !== !1 && t.requestMeasure(this.measureReq)
    }
    setOrder(t) {
        let e = 0,
            i = t.facet(Gi);
        for (; e < i.length && i[e] != this.layer;) e++;
        this.dom.style.zIndex = String((this.layer.above ? 150 : -1) - e)
    }
    measure() {
        return this.layer.markers(this.view)
    }
    scale() {
        let {
            scaleX: t,
            scaleY: e
        } = this.view;
        (t != this.scaleX || e != this.scaleY) && (this.scaleX = t, this.scaleY = e, this.dom.style.transform = `scale(${1/t}, ${1/e})`)
    }
    draw(t) {
        if (t.length != this.drawn.length || t.some((e, i) => !id(e, this.drawn[i]))) {
            let e = this.dom.firstChild,
                i = 0;
            for (let s of t) s.update && e && s.constructor && this.drawn[i].constructor && s.update(e, this.drawn[i]) ? (e = e.nextSibling, i++) : this.dom.insertBefore(s.draw(), e);
            for (; e;) {
                let s = e.nextSibling;
                e.remove(), e = s
            }
            this.drawn = t
        }
    }
    destroy() {
        this.layer.destroy && this.layer.destroy(this.dom, this.view), this.dom.remove()
    }
}
const Gi = E.define();

function ea(n) {
    return [Nt.define(t => new nd(t, n)), Gi.of(n)]
}
const ia = !k.ios,
    yi = E.define({
        combine(n) {
            return Is(n, {
                cursorBlinkRate: 1200,
                drawRangeCursor: !0
            }, {
                cursorBlinkRate: (t, e) => Math.min(t, e),
                drawRangeCursor: (t, e) => t || e
            })
        }
    });

function Vg(n = {}) {
    return [yi.of(n), sd, rd, od, Dl.of(!0)]
}

function na(n) {
    return n.startState.facet(yi) != n.state.facet(yi)
}
const sd = ea({
    above: !0,
    markers(n) {
        let {
            state: t
        } = n, e = t.facet(yi), i = [];
        for (let s of t.selection.ranges) {
            let r = s == t.selection.main;
            if (s.empty ? !r || ia : e.drawRangeCursor) {
                let o = r ? "cm-cursor cm-cursor-primary" : "cm-cursor cm-cursor-secondary",
                    l = s.empty ? s : A.cursor(s.head, s.head > s.anchor ? -1 : 1);
                for (let a of Mi.forRange(n, o, l)) i.push(a)
            }
        }
        return i
    },
    update(n, t) {
        n.transactions.some(i => i.selection) && (t.style.animationName = t.style.animationName == "cm-blink" ? "cm-blink2" : "cm-blink");
        let e = na(n);
        return e && Qr(n.state, t), n.docChanged || n.selectionSet || e
    },
    mount(n, t) {
        Qr(t.state, n)
    },
    class: "cm-cursorLayer"
});

function Qr(n, t) {
    t.style.animationDuration = n.facet(yi).cursorBlinkRate + "ms"
}
const rd = ea({
        above: !1,
        markers(n) {
            return n.state.selection.ranges.map(t => t.empty ? [] : Mi.forRange(n, "cm-selectionBackground", t)).reduce((t, e) => t.concat(e))
        },
        update(n, t) {
            return n.docChanged || n.selectionSet || n.viewportChanged || na(n)
        },
        class: "cm-selectionLayer"
    }),
    bs = {
        ".cm-line": {
            "& ::selection, &::selection": {
                backgroundColor: "transparent !important"
            }
        },
        ".cm-content": {
            "& :focus": {
                caretColor: "initial !important",
                "&::selection, & ::selection": {
                    backgroundColor: "Highlight !important"
                }
            }
        }
    };
ia && (bs[".cm-line"].caretColor = bs[".cm-content"].caretColor = "transparent !important");
const od = Ns.highest(P.theme(bs));

function Zr(n, t, e, i, s) {
    t.lastIndex = 0;
    for (let r = n.iterRange(e, i), o = e, l; !r.next().done; o += r.value.length)
        if (!r.lineBreak)
            for (; l = t.exec(r.value);) s(o + l.index, l)
}

function ld(n, t) {
    let e = n.visibleRanges;
    if (e.length == 1 && e[0].from == n.viewport.from && e[0].to == n.viewport.to) return e;
    let i = [];
    for (let {
            from: s,
            to: r
        } of e) s = Math.max(n.state.doc.lineAt(s).from, s - t), r = Math.min(n.state.doc.lineAt(r).to, r + t), i.length && i[i.length - 1].to >= s ? i[i.length - 1].to = r : i.push({
        from: s,
        to: r
    });
    return i
}
class ad {
    constructor(t) {
        const {
            regexp: e,
            decoration: i,
            decorate: s,
            boundary: r,
            maxLength: o = 1e3
        } = t;
        if (!e.global) throw new RangeError("The regular expression given to MatchDecorator should have its 'g' flag set");
        if (this.regexp = e, s) this.addMatch = (l, a, c, h) => s(h, c, c + l[0].length, l, a);
        else if (typeof i == "function") this.addMatch = (l, a, c, h) => {
            let u = i(l, a, c);
            u && h(c, c + l[0].length, u)
        };
        else if (i) this.addMatch = (l, a, c, h) => h(c, c + l[0].length, i);
        else throw new RangeError("Either 'decorate' or 'decoration' should be provided to MatchDecorator");
        this.boundary = r, this.maxLength = o
    }
    createDeco(t) {
        let e = new di,
            i = e.add.bind(e);
        for (let {
                from: s,
                to: r
            } of ld(t, this.maxLength)) Zr(t.state.doc, this.regexp, s, r, (o, l) => this.addMatch(l, t, o, i));
        return e.finish()
    }
    updateDeco(t, e) {
        let i = 1e9,
            s = -1;
        return t.docChanged && t.changes.iterChanges((r, o, l, a) => {
            a > t.view.viewport.from && l < t.view.viewport.to && (i = Math.min(l, i), s = Math.max(a, s))
        }), t.viewportChanged || s - i > 1e3 ? this.createDeco(t.view) : s > -1 ? this.updateRange(t.view, e.map(t.changes), i, s) : e
    }
    updateRange(t, e, i, s) {
        for (let r of t.visibleRanges) {
            let o = Math.max(r.from, i),
                l = Math.min(r.to, s);
            if (l > o) {
                let a = t.state.doc.lineAt(o),
                    c = a.to < l ? t.state.doc.lineAt(l) : a,
                    h = Math.max(r.from, a.from),
                    u = Math.min(r.to, c.to);
                if (this.boundary) {
                    for (; o > a.from; o--)
                        if (this.boundary.test(a.text[o - 1 - a.from])) {
                            h = o;
                            break
                        }
                    for (; l < c.to; l++)
                        if (this.boundary.test(c.text[l - c.from])) {
                            u = l;
                            break
                        }
                }
                let f = [],
                    d, m = (g, p, y) => f.push(y.range(g, p));
                if (a == c)
                    for (this.regexp.lastIndex = h - a.from;
                        (d = this.regexp.exec(a.text)) && d.index < u - a.from;) this.addMatch(d, t, d.index + a.from, m);
                else Zr(t.state.doc, this.regexp, h, u, (g, p) => this.addMatch(p, t, g, m));
                e = e.update({
                    filterFrom: h,
                    filterTo: u,
                    filter: (g, p) => g < h || p > u,
                    add: f
                })
            }
        }
        return e
    }
}
const ws = /x/.unicode != null ? "gu" : "g",
    hd = new RegExp(`[\0-\b
--­؜​‎‏\u2028\u2029‭‮⁦⁧⁩\uFEFF￹-￼]`, ws),
    cd = {
        0: "null",
        7: "bell",
        8: "backspace",
        10: "newline",
        11: "vertical tab",
        13: "carriage return",
        27: "escape",
        8203: "zero width space",
        8204: "zero width non-joiner",
        8205: "zero width joiner",
        8206: "left-to-right mark",
        8207: "right-to-left mark",
        8232: "line separator",
        8237: "left-to-right override",
        8238: "right-to-left override",
        8294: "left-to-right isolate",
        8295: "right-to-left isolate",
        8297: "pop directional isolate",
        8233: "paragraph separator",
        65279: "zero width no-break space",
        65532: "object replacement"
    };
let Rn = null;

function ud() {
    var n;
    if (Rn == null && typeof document < "u" && document.body) {
        let t = document.body.style;
        Rn = ((n = t.tabSize) !== null && n !== void 0 ? n : t.MozTabSize) != null
    }
    return Rn || !1
}
const Ki = E.define({
    combine(n) {
        let t = Is(n, {
            render: null,
            specialChars: hd,
            addSpecialChars: null
        });
        return (t.replaceTabs = !ud()) && (t.specialChars = new RegExp("	|" + t.specialChars.source, ws)), t.addSpecialChars && (t.specialChars = new RegExp(t.specialChars.source + "|" + t.addSpecialChars.source, ws)), t
    }
});

function Fg(n = {}) {
    return [Ki.of(n), fd()]
}
let to = null;

function fd() {
    return to || (to = Nt.fromClass(class {
        constructor(n) {
            this.view = n, this.decorations = B.none, this.decorationCache = Object.create(null), this.decorator = this.makeDecorator(n.state.facet(Ki)), this.decorations = this.decorator.createDeco(n)
        }
        makeDecorator(n) {
            return new ad({
                regexp: n.specialChars,
                decoration: (t, e, i) => {
                    let {
                        doc: s
                    } = e.state, r = ri(t[0], 0);
                    if (r == 9) {
                        let o = s.lineAt(i),
                            l = e.state.tabSize,
                            a = bu(o.text, l, i - o.from);
                        return B.replace({
                            widget: new pd((l - a % l) * this.view.defaultCharacterWidth / this.view.scaleX)
                        })
                    }
                    return this.decorationCache[r] || (this.decorationCache[r] = B.replace({
                        widget: new gd(n, r)
                    }))
                },
                boundary: n.replaceTabs ? void 0 : /[^]/
            })
        }
        update(n) {
            let t = n.state.facet(Ki);
            n.startState.facet(Ki) != t ? (this.decorator = this.makeDecorator(t), this.decorations = this.decorator.createDeco(n.view)) : this.decorations = this.decorator.updateDeco(n, this.decorations)
        }
    }, {
        decorations: n => n.decorations
    }))
}
const dd = "•";

function md(n) {
    return n >= 32 ? dd : n == 10 ? "␤" : String.fromCharCode(9216 + n)
}
class gd extends qe {
    constructor(t, e) {
        super(), this.options = t, this.code = e
    }
    eq(t) {
        return t.code == this.code
    }
    toDOM(t) {
        let e = md(this.code),
            i = t.state.phrase("Control character") + " " + (cd[this.code] || "0x" + this.code.toString(16)),
            s = this.options.render && this.options.render(this.code, i, e);
        if (s) return s;
        let r = document.createElement("span");
        return r.textContent = e, r.title = i, r.setAttribute("aria-label", i), r.className = "cm-specialChar", r
    }
    ignoreEvent() {
        return !1
    }
}
class pd extends qe {
    constructor(t) {
        super(), this.width = t
    }
    eq(t) {
        return t.width == this.width
    }
    toDOM() {
        let t = document.createElement("span");
        return t.textContent = "	", t.className = "cm-tab", t.style.width = this.width + "px", t
    }
    ignoreEvent() {
        return !1
    }
}

function jg() {
    return xd
}
const yd = B.line({
        class: "cm-activeLine"
    }),
    xd = Nt.fromClass(class {
        constructor(n) {
            this.decorations = this.getDeco(n)
        }
        update(n) {
            (n.docChanged || n.selectionSet) && (this.decorations = this.getDeco(n.view))
        }
        getDeco(n) {
            let t = -1,
                e = [];
            for (let i of n.state.selection.ranges) {
                let s = n.lineBlockAt(i.head);
                s.from > t && (e.push(yd.range(s.from)), t = s.from)
            }
            return B.set(e)
        }
    }, {
        decorations: n => n.decorations
    });
class bd extends qe {
    constructor(t) {
        super(), this.content = t
    }
    toDOM() {
        let t = document.createElement("span");
        return t.className = "cm-placeholder", t.style.pointerEvents = "none", t.appendChild(typeof this.content == "string" ? document.createTextNode(this.content) : this.content), typeof this.content == "string" ? t.setAttribute("aria-label", "placeholder " + this.content) : t.setAttribute("aria-hidden", "true"), t
    }
    coordsAt(t) {
        let e = t.firstChild ? Fe(t.firstChild) : [];
        if (!e.length) return null;
        let i = window.getComputedStyle(t.parentNode),
            s = mn(e[0], i.direction != "rtl"),
            r = parseInt(i.lineHeight);
        return s.bottom - s.top > r * 1.5 ? {
            left: s.left,
            right: s.right,
            top: s.top,
            bottom: s.top + r
        } : s
    }
    ignoreEvent() {
        return !1
    }
}

function Wg(n) {
    return Nt.fromClass(class {
        constructor(t) {
            this.view = t, this.placeholder = n ? B.set([B.widget({
                widget: new bd(n),
                side: 1
            }).range(0)]) : B.none
        }
        get decorations() {
            return this.view.state.doc.length ? B.none : this.placeholder
        }
    }, {
        decorations: t => t.decorations
    })
}
const Je = "-10000px";
class wd {
    constructor(t, e, i, s) {
        this.facet = e, this.createTooltipView = i, this.removeTooltipView = s, this.input = t.state.facet(e), this.tooltips = this.input.filter(o => o);
        let r = null;
        this.tooltipViews = this.tooltips.map(o => r = i(o, r))
    }
    update(t, e) {
        var i;
        let s = t.state.facet(this.facet),
            r = s.filter(a => a);
        if (s === this.input) {
            for (let a of this.tooltipViews) a.update && a.update(t);
            return !1
        }
        let o = [],
            l = e ? [] : null;
        for (let a = 0; a < r.length; a++) {
            let c = r[a],
                h = -1;
            if (c) {
                for (let u = 0; u < this.tooltips.length; u++) {
                    let f = this.tooltips[u];
                    f && f.create == c.create && (h = u)
                }
                if (h < 0) o[a] = this.createTooltipView(c, a ? o[a - 1] : null), l && (l[a] = !!c.above);
                else {
                    let u = o[a] = this.tooltipViews[h];
                    l && (l[a] = e[h]), u.update && u.update(t)
                }
            }
        }
        for (let a of this.tooltipViews) o.indexOf(a) < 0 && (this.removeTooltipView(a), (i = a.destroy) === null || i === void 0 || i.call(a));
        return e && (l.forEach((a, c) => e[c] = a), e.length = l.length), this.input = s, this.tooltips = r, this.tooltipViews = o, !0
    }
}

function vd(n) {
    let {
        win: t
    } = n;
    return {
        top: 0,
        left: 0,
        bottom: t.innerHeight,
        right: t.innerWidth
    }
}
const Pn = E.define({
        combine: n => {
            var t, e, i;
            return {
                position: k.ios ? "absolute" : ((t = n.find(s => s.position)) === null || t === void 0 ? void 0 : t.position) || "fixed",
                parent: ((e = n.find(s => s.parent)) === null || e === void 0 ? void 0 : e.parent) || null,
                tooltipSpace: ((i = n.find(s => s.tooltipSpace)) === null || i === void 0 ? void 0 : i.tooltipSpace) || vd
            }
        }
    }),
    eo = new WeakMap,
    sa = Nt.fromClass(class {
        constructor(n) {
            this.view = n, this.above = [], this.inView = !0, this.madeAbsolute = !1, this.lastTransaction = 0, this.measureTimeout = -1;
            let t = n.state.facet(Pn);
            this.position = t.position, this.parent = t.parent, this.classes = n.themeClasses, this.createContainer(), this.measureReq = {
                read: this.readMeasure.bind(this),
                write: this.writeMeasure.bind(this),
                key: this
            }, this.resizeObserver = typeof ResizeObserver == "function" ? new ResizeObserver(() => this.measureSoon()) : null, this.manager = new wd(n, kd, (e, i) => this.createTooltip(e, i), e => {
                this.resizeObserver && this.resizeObserver.unobserve(e.dom), e.dom.remove()
            }), this.above = this.manager.tooltips.map(e => !!e.above), this.intersectionObserver = typeof IntersectionObserver == "function" ? new IntersectionObserver(e => {
                Date.now() > this.lastTransaction - 50 && e.length > 0 && e[e.length - 1].intersectionRatio < 1 && this.measureSoon()
            }, {
                threshold: [1]
            }) : null, this.observeIntersection(), n.win.addEventListener("resize", this.measureSoon = this.measureSoon.bind(this)), this.maybeMeasure()
        }
        createContainer() {
            this.parent ? (this.container = document.createElement("div"), this.container.style.position = "relative", this.container.className = this.view.themeClasses, this.parent.appendChild(this.container)) : this.container = this.view.dom
        }
        observeIntersection() {
            if (this.intersectionObserver) {
                this.intersectionObserver.disconnect();
                for (let n of this.manager.tooltipViews) this.intersectionObserver.observe(n.dom)
            }
        }
        measureSoon() {
            this.measureTimeout < 0 && (this.measureTimeout = setTimeout(() => {
                this.measureTimeout = -1, this.maybeMeasure()
            }, 50))
        }
        update(n) {
            n.transactions.length && (this.lastTransaction = Date.now());
            let t = this.manager.update(n, this.above);
            t && this.observeIntersection();
            let e = t || n.geometryChanged,
                i = n.state.facet(Pn);
            if (i.position != this.position && !this.madeAbsolute) {
                this.position = i.position;
                for (let s of this.manager.tooltipViews) s.dom.style.position = this.position;
                e = !0
            }
            if (i.parent != this.parent) {
                this.parent && this.container.remove(), this.parent = i.parent, this.createContainer();
                for (let s of this.manager.tooltipViews) this.container.appendChild(s.dom);
                e = !0
            } else this.parent && this.view.themeClasses != this.classes && (this.classes = this.container.className = this.view.themeClasses);
            e && this.maybeMeasure()
        }
        createTooltip(n, t) {
            let e = n.create(this.view),
                i = t ? t.dom : null;
            if (e.dom.classList.add("cm-tooltip"), n.arrow && !e.dom.querySelector(".cm-tooltip > .cm-tooltip-arrow")) {
                let s = document.createElement("div");
                s.className = "cm-tooltip-arrow", e.dom.appendChild(s)
            }
            return e.dom.style.position = this.position, e.dom.style.top = Je, e.dom.style.left = "0px", this.container.insertBefore(e.dom, i), e.mount && e.mount(this.view), this.resizeObserver && this.resizeObserver.observe(e.dom), e
        }
        destroy() {
            var n, t, e;
            this.view.win.removeEventListener("resize", this.measureSoon);
            for (let i of this.manager.tooltipViews) i.dom.remove(), (n = i.destroy) === null || n === void 0 || n.call(i);
            this.parent && this.container.remove(), (t = this.resizeObserver) === null || t === void 0 || t.disconnect(), (e = this.intersectionObserver) === null || e === void 0 || e.disconnect(), clearTimeout(this.measureTimeout)
        }
        readMeasure() {
            let n = this.view.dom.getBoundingClientRect(),
                t = 1,
                e = 1,
                i = !1;
            if (this.position == "fixed" && this.manager.tooltipViews.length) {
                let {
                    dom: s
                } = this.manager.tooltipViews[0];
                if (k.gecko) i = s.offsetParent != this.container.ownerDocument.body;
                else if (s.style.top == Je && s.style.left == "0px") {
                    let r = s.getBoundingClientRect();
                    i = Math.abs(r.top + 1e4) > 1 || Math.abs(r.left) > 1
                }
            }
            if (i || this.position == "absolute")
                if (this.parent) {
                    let s = this.parent.getBoundingClientRect();
                    s.width && s.height && (t = s.width / this.parent.offsetWidth, e = s.height / this.parent.offsetHeight)
                } else({
                    scaleX: t,
                    scaleY: e
                } = this.view.viewState);
            return {
                editor: n,
                parent: this.parent ? this.container.getBoundingClientRect() : n,
                pos: this.manager.tooltips.map((s, r) => {
                    let o = this.manager.tooltipViews[r];
                    return o.getCoords ? o.getCoords(s.pos) : this.view.coordsAtPos(s.pos)
                }),
                size: this.manager.tooltipViews.map(({
                    dom: s
                }) => s.getBoundingClientRect()),
                space: this.view.state.facet(Pn).tooltipSpace(this.view),
                scaleX: t,
                scaleY: e,
                makeAbsolute: i
            }
        }
        writeMeasure(n) {
            var t;
            if (n.makeAbsolute) {
                this.madeAbsolute = !0, this.position = "absolute";
                for (let l of this.manager.tooltipViews) l.dom.style.position = "absolute"
            }
            let {
                editor: e,
                space: i,
                scaleX: s,
                scaleY: r
            } = n, o = [];
            for (let l = 0; l < this.manager.tooltips.length; l++) {
                let a = this.manager.tooltips[l],
                    c = this.manager.tooltipViews[l],
                    {
                        dom: h
                    } = c,
                    u = n.pos[l],
                    f = n.size[l];
                if (!u || u.bottom <= Math.max(e.top, i.top) || u.top >= Math.min(e.bottom, i.bottom) || u.right < Math.max(e.left, i.left) - .1 || u.left > Math.min(e.right, i.right) + .1) {
                    h.style.top = Je;
                    continue
                }
                let d = a.arrow ? c.dom.querySelector(".cm-tooltip-arrow") : null,
                    m = d ? 7 : 0,
                    g = f.right - f.left,
                    p = (t = eo.get(c)) !== null && t !== void 0 ? t : f.bottom - f.top,
                    y = c.offset || Sd,
                    b = this.view.textDirection == Q.LTR,
                    v = f.width > i.right - i.left ? b ? i.left : i.right - f.width : b ? Math.min(u.left - (d ? 14 : 0) + y.x, i.right - g) : Math.max(i.left, u.left - g + (d ? 14 : 0) - y.x),
                    w = this.above[l];
                !a.strictSide && (w ? u.top - (f.bottom - f.top) - y.y < i.top : u.bottom + (f.bottom - f.top) + y.y > i.bottom) && w == i.bottom - u.bottom > u.top - i.top && (w = this.above[l] = !w);
                let S = (w ? u.top - i.top : i.bottom - u.bottom) - m;
                if (S < p && c.resize !== !1) {
                    if (S < this.view.defaultLineHeight) {
                        h.style.top = Je;
                        continue
                    }
                    eo.set(c, p), h.style.height = (p = S) / r + "px"
                } else h.style.height && (h.style.height = "");
                let M = w ? u.top - p - m - y.y : u.bottom + m + y.y,
                    D = v + g;
                if (c.overlap !== !0)
                    for (let T of o) T.left < D && T.right > v && T.top < M + p && T.bottom > M && (M = w ? T.top - p - 2 - m : T.bottom + m + 2);
                if (this.position == "absolute" ? (h.style.top = (M - n.parent.top) / r + "px", h.style.left = (v - n.parent.left) / s + "px") : (h.style.top = M / r + "px", h.style.left = v / s + "px"), d) {
                    let T = u.left + (b ? y.x : -y.x) - (v + 14 - 7);
                    d.style.left = T / s + "px"
                }
                c.overlap !== !0 && o.push({
                    left: v,
                    top: M,
                    right: D,
                    bottom: M + p
                }), h.classList.toggle("cm-tooltip-above", w), h.classList.toggle("cm-tooltip-below", !w), c.positioned && c.positioned(n.space)
            }
        }
        maybeMeasure() {
            if (this.manager.tooltips.length && (this.view.inView && this.view.requestMeasure(this.measureReq), this.inView != this.view.inView && (this.inView = this.view.inView, !this.inView)))
                for (let n of this.manager.tooltipViews) n.dom.style.top = Je
        }
    }, {
        eventObservers: {
            scroll() {
                this.maybeMeasure()
            }
        }
    }),
    Cd = P.baseTheme({
        ".cm-tooltip": {
            zIndex: 100,
            boxSizing: "border-box"
        },
        "&light .cm-tooltip": {
            border: "1px solid #bbb",
            backgroundColor: "#f5f5f5"
        },
        "&light .cm-tooltip-section:not(:first-child)": {
            borderTop: "1px solid #bbb"
        },
        "&dark .cm-tooltip": {
            backgroundColor: "#333338",
            color: "white"
        },
        ".cm-tooltip-arrow": {
            height: "7px",
            width: `${7*2}px`,
            position: "absolute",
            zIndex: -1,
            overflow: "hidden",
            "&:before, &:after": {
                content: "''",
                position: "absolute",
                width: 0,
                height: 0,
                borderLeft: "7px solid transparent",
                borderRight: "7px solid transparent"
            },
            ".cm-tooltip-above &": {
                bottom: "-7px",
                "&:before": {
                    borderTop: "7px solid #bbb"
                },
                "&:after": {
                    borderTop: "7px solid #f5f5f5",
                    bottom: "1px"
                }
            },
            ".cm-tooltip-below &": {
                top: "-7px",
                "&:before": {
                    borderBottom: "7px solid #bbb"
                },
                "&:after": {
                    borderBottom: "7px solid #f5f5f5",
                    top: "1px"
                }
            }
        },
        "&dark .cm-tooltip .cm-tooltip-arrow": {
            "&:before": {
                borderTopColor: "#333338",
                borderBottomColor: "#333338"
            },
            "&:after": {
                borderTopColor: "transparent",
                borderBottomColor: "transparent"
            }
        }
    }),
    Sd = {
        x: 0,
        y: 0
    },
    kd = E.define({
        enables: [sa, Cd]
    });

function zg(n, t) {
    let e = n.plugin(sa);
    if (!e) return null;
    let i = e.manager.tooltips.indexOf(t);
    return i < 0 ? null : e.manager.tooltipViews[i]
}
class re extends He {
    compare(t) {
        return this == t || this.constructor == t.constructor && this.eq(t)
    }
    eq(t) {
        return !1
    }
    destroy(t) {}
}
re.prototype.elementClass = "";
re.prototype.toDOM = void 0;
re.prototype.mapMode = wt.TrackBefore;
re.prototype.startSide = re.prototype.endSide = -1;
re.prototype.point = !0;
const Yi = E.define(),
    Md = {
        class: "",
        renderEmptyElements: !1,
        elementStyle: "",
        markers: () => L.empty,
        lineMarker: () => null,
        widgetMarker: () => null,
        lineMarkerChange: null,
        initialSpacer: null,
        updateSpacer: null,
        domEventHandlers: {}
    },
    hi = E.define();

function qg(n) {
    return [ra(), hi.of(Object.assign(Object.assign({}, Md), n))]
}
const io = E.define({
    combine: n => n.some(t => t)
});

function ra(n) {
    return [Ad]
}
const Ad = Nt.fromClass(class {
    constructor(n) {
        this.view = n, this.prevViewport = n.viewport, this.dom = document.createElement("div"), this.dom.className = "cm-gutters", this.dom.setAttribute("aria-hidden", "true"), this.dom.style.minHeight = this.view.contentHeight / this.view.scaleY + "px", this.gutters = n.state.facet(hi).map(t => new so(n, t));
        for (let t of this.gutters) this.dom.appendChild(t.dom);
        this.fixed = !n.state.facet(io), this.fixed && (this.dom.style.position = "sticky"), this.syncGutters(!1), n.scrollDOM.insertBefore(this.dom, n.contentDOM)
    }
    update(n) {
        if (this.updateGutters(n)) {
            let t = this.prevViewport,
                e = n.view.viewport,
                i = Math.min(t.to, e.to) - Math.max(t.from, e.from);
            this.syncGutters(i < (e.to - e.from) * .8)
        }
        n.geometryChanged && (this.dom.style.minHeight = this.view.contentHeight / this.view.scaleY + "px"), this.view.state.facet(io) != !this.fixed && (this.fixed = !this.fixed, this.dom.style.position = this.fixed ? "sticky" : ""), this.prevViewport = n.view.viewport
    }
    syncGutters(n) {
        let t = this.dom.nextSibling;
        n && this.dom.remove();
        let e = L.iter(this.view.state.facet(Yi), this.view.viewport.from),
            i = [],
            s = this.gutters.map(r => new Td(r, this.view.viewport, -this.view.documentPadding.top));
        for (let r of this.view.viewportLineBlocks)
            if (i.length && (i = []), Array.isArray(r.type)) {
                let o = !0;
                for (let l of r.type)
                    if (l.type == dt.Text && o) {
                        vs(e, i, l.from);
                        for (let a of s) a.line(this.view, l, i);
                        o = !1
                    } else if (l.widget)
                    for (let a of s) a.widget(this.view, l)
            } else if (r.type == dt.Text) {
            vs(e, i, r.from);
            for (let o of s) o.line(this.view, r, i)
        } else if (r.widget)
            for (let o of s) o.widget(this.view, r);
        for (let r of s) r.finish();
        n && this.view.scrollDOM.insertBefore(this.dom, t)
    }
    updateGutters(n) {
        let t = n.startState.facet(hi),
            e = n.state.facet(hi),
            i = n.docChanged || n.heightChanged || n.viewportChanged || !L.eq(n.startState.facet(Yi), n.state.facet(Yi), n.view.viewport.from, n.view.viewport.to);
        if (t == e)
            for (let s of this.gutters) s.update(n) && (i = !0);
        else {
            i = !0;
            let s = [];
            for (let r of e) {
                let o = t.indexOf(r);
                o < 0 ? s.push(new so(this.view, r)) : (this.gutters[o].update(n), s.push(this.gutters[o]))
            }
            for (let r of this.gutters) r.dom.remove(), s.indexOf(r) < 0 && r.destroy();
            for (let r of s) this.dom.appendChild(r.dom);
            this.gutters = s
        }
        return i
    }
    destroy() {
        for (let n of this.gutters) n.destroy();
        this.dom.remove()
    }
}, {
    provide: n => P.scrollMargins.of(t => {
        let e = t.plugin(n);
        return !e || e.gutters.length == 0 || !e.fixed ? null : t.textDirection == Q.LTR ? {
            left: e.dom.offsetWidth * t.scaleX
        } : {
            right: e.dom.offsetWidth * t.scaleX
        }
    })
});

function no(n) {
    return Array.isArray(n) ? n : [n]
}

function vs(n, t, e) {
    for (; n.value && n.from <= e;) n.from == e && t.push(n.value), n.next()
}
class Td {
    constructor(t, e, i) {
        this.gutter = t, this.height = i, this.i = 0, this.cursor = L.iter(t.markers, e.from)
    }
    addElement(t, e, i) {
        let {
            gutter: s
        } = this, r = (e.top - this.height) / t.scaleY, o = e.height / t.scaleY;
        if (this.i == s.elements.length) {
            let l = new oa(t, o, r, i);
            s.elements.push(l), s.dom.appendChild(l.dom)
        } else s.elements[this.i].update(t, o, r, i);
        this.height = e.bottom, this.i++
    }
    line(t, e, i) {
        let s = [];
        vs(this.cursor, s, e.from), i.length && (s = s.concat(i));
        let r = this.gutter.config.lineMarker(t, e, s);
        r && s.unshift(r);
        let o = this.gutter;
        s.length == 0 && !o.config.renderEmptyElements || this.addElement(t, e, s)
    }
    widget(t, e) {
        let i = this.gutter.config.widgetMarker(t, e.widget, e);
        i && this.addElement(t, e, [i])
    }
    finish() {
        let t = this.gutter;
        for (; t.elements.length > this.i;) {
            let e = t.elements.pop();
            t.dom.removeChild(e.dom), e.destroy()
        }
    }
}
class so {
    constructor(t, e) {
        this.view = t, this.config = e, this.elements = [], this.spacer = null, this.dom = document.createElement("div"), this.dom.className = "cm-gutter" + (this.config.class ? " " + this.config.class : "");
        for (let i in e.domEventHandlers) this.dom.addEventListener(i, s => {
            let r = s.target,
                o;
            if (r != this.dom && this.dom.contains(r)) {
                for (; r.parentNode != this.dom;) r = r.parentNode;
                let a = r.getBoundingClientRect();
                o = (a.top + a.bottom) / 2
            } else o = s.clientY;
            let l = t.lineBlockAtHeight(o - t.documentTop);
            e.domEventHandlers[i](t, l, s) && s.preventDefault()
        });
        this.markers = no(e.markers(t)), e.initialSpacer && (this.spacer = new oa(t, 0, 0, [e.initialSpacer(t)]), this.dom.appendChild(this.spacer.dom), this.spacer.dom.style.cssText += "visibility: hidden; pointer-events: none")
    }
    update(t) {
        let e = this.markers;
        if (this.markers = no(this.config.markers(t.view)), this.spacer && this.config.updateSpacer) {
            let s = this.config.updateSpacer(this.spacer.markers[0], t);
            s != this.spacer.markers[0] && this.spacer.update(t.view, 0, 0, [s])
        }
        let i = t.view.viewport;
        return !L.eq(this.markers, e, i.from, i.to) || (this.config.lineMarkerChange ? this.config.lineMarkerChange(t) : !1)
    }
    destroy() {
        for (let t of this.elements) t.destroy()
    }
}
class oa {
    constructor(t, e, i, s) {
        this.height = -1, this.above = 0, this.markers = [], this.dom = document.createElement("div"), this.dom.className = "cm-gutterElement", this.update(t, e, i, s)
    }
    update(t, e, i, s) {
        this.height != e && (this.height = e, this.dom.style.height = e + "px"), this.above != i && (this.dom.style.marginTop = (this.above = i) ? i + "px" : ""), Ed(this.markers, s) || this.setMarkers(t, s)
    }
    setMarkers(t, e) {
        let i = "cm-gutterElement",
            s = this.dom.firstChild;
        for (let r = 0, o = 0;;) {
            let l = o,
                a = r < e.length ? e[r++] : null,
                c = !1;
            if (a) {
                let h = a.elementClass;
                h && (i += " " + h);
                for (let u = o; u < this.markers.length; u++)
                    if (this.markers[u].compare(a)) {
                        l = u, c = !0;
                        break
                    }
            } else l = this.markers.length;
            for (; o < l;) {
                let h = this.markers[o++];
                if (h.toDOM) {
                    h.destroy(s);
                    let u = s.nextSibling;
                    s.remove(), s = u
                }
            }
            if (!a) break;
            a.toDOM && (c ? s = s.nextSibling : this.dom.insertBefore(a.toDOM(t), s)), c && o++
        }
        this.dom.className = i, this.markers = e
    }
    destroy() {
        this.setMarkers(null, [])
    }
}

function Ed(n, t) {
    if (n.length != t.length) return !1;
    for (let e = 0; e < n.length; e++)
        if (!n[e].compare(t[e])) return !1;
    return !0
}
const Dd = E.define(),
    Ee = E.define({
        combine(n) {
            return Is(n, {
                formatNumber: String,
                domEventHandlers: {}
            }, {
                domEventHandlers(t, e) {
                    let i = Object.assign({}, t);
                    for (let s in e) {
                        let r = i[s],
                            o = e[s];
                        i[s] = r ? (l, a, c) => r(l, a, c) || o(l, a, c) : o
                    }
                    return i
                }
            })
        }
    });
class Ln extends re {
    constructor(t) {
        super(), this.number = t
    }
    eq(t) {
        return this.number == t.number
    }
    toDOM() {
        return document.createTextNode(this.number)
    }
}

function Nn(n, t) {
    return n.state.facet(Ee).formatNumber(t, n.state)
}
const Od = hi.compute([Ee], n => ({
    class: "cm-lineNumbers",
    renderEmptyElements: !1,
    markers(t) {
        return t.state.facet(Dd)
    },
    lineMarker(t, e, i) {
        return i.some(s => s.toDOM) ? null : new Ln(Nn(t, t.state.doc.lineAt(e.from).number))
    },
    widgetMarker: () => null,
    lineMarkerChange: t => t.startState.facet(Ee) != t.state.facet(Ee),
    initialSpacer(t) {
        return new Ln(Nn(t, ro(t.state.doc.lines)))
    },
    updateSpacer(t, e) {
        let i = Nn(e.view, ro(e.view.state.doc.lines));
        return i == t.number ? t : new Ln(i)
    },
    domEventHandlers: n.facet(Ee).domEventHandlers
}));

function _g(n = {}) {
    return [Ee.of(n), ra(), Od]
}

function ro(n) {
    let t = 9;
    for (; t < n;) t = t * 10 + 9;
    return t
}
const Rd = new class extends re {
        constructor() {
            super(...arguments), this.elementClass = "cm-activeLineGutter"
        }
    },
    Pd = Yi.compute(["selection"], n => {
        let t = [],
            e = -1;
        for (let i of n.selection.ranges) {
            let s = n.doc.lineAt(i.head).from;
            s > e && (e = s, t.push(Rd.range(s)))
        }
        return L.of(t)
    });

function $g() {
    return Pd
}
const la = G.define(),
    Ld = G.define(),
    Nd = G.define(),
    Id = G.define();

function Bd(n) {
    return new Map(n.map(t => [t.id, t.at]))
}
const Cs = Tt.define({
        create() {
            return null
        },
        update(n, t) {
            for (const e of t.effects)
                if (e.is(la)) return e.value;
            return n
        }
    }),
    on = Tt.define({
        create() {
            return []
        },
        update(n, t) {
            for (const o of t.effects)
                if (o.is(Ld)) return o.value;
            const e = n,
                i = Bd(e),
                s = Uc(t, i);
            return Xc(i, s) ? e : tu(e, s)
        }
    }),
    Ss = Tt.define({
        create() {
            return null
        },
        update(n, t) {
            for (const e of t.effects)
                if (e.is(Nd)) return e.value;
            return n
        }
    }),
    ks = Tt.define({
        create() {
            return null
        },
        update(n, t) {
            for (const e of t.effects)
                if (e.is(Id)) return e.value;
            return n
        }
    });

function oo(n) {
    if (!n || n.to - n.from === 0) return B.none;
    const t = B.mark({
        class: rc.code
    });
    return B.set([t.range(n.from, n.to)])
}

function lo(n, t, e) {
    if (n.length === 0) return B.none;
    const s = [...n].sort((r, o) => r.at.start - o.at.start).map(r => {
        if (r.at.end - r.at.start === 0) return null;
        const o = r.id === t,
            l = r.id === e,
            a = Zc({
                isHovered: o,
                isFocused: l,
                isCode: !0,
                diffStatus: r.diffStatus
            });
        return B.mark({
            class: a,
            attributes: {
                "data-comment-id": r.id
            }
        }).range(r.at.start, r.at.end)
    }).filter(Do);
    return B.set(s)
}
const Hd = Tt.define({
        create(n) {
            const t = n.field(Cs, !1);
            return oo(t ? ? null)
        },
        update(n, t) {
            const e = t.state.field(Cs, !1);
            return oo(e ? ? null)
        },
        provide: n => P.decorations.from(n)
    }),
    Vd = Tt.define({
        create(n) {
            const t = n.field(on, !1),
                e = n.field(Ss, !1),
                i = n.field(ks, !1);
            return lo(t ? ? [], e ? ? null, i ? ? null)
        },
        update(n, t) {
            const e = t.state.field(on, !1),
                i = t.state.field(Ss, !1),
                s = t.state.field(ks, !1);
            return lo(e ? ? [], i ? ? null, s ? ? null)
        },
        provide: n => P.decorations.from(n)
    });

function Fd(n) {
    n.state.selection.main.empty && n.dispatch({
        effects: la.of(null)
    })
}

function aa(n) {
    let t = n.dataset.commentId;
    for (let e = 0; e < 10 && !t && n.parentElement; e++) n = n.parentElement, t = n.dataset.commentId;
    return t
}

function jd(n) {
    const t = n.target,
        e = aa(t);
    e && ge.focusComment(e)
}

function Wd(n) {
    const t = n.target,
        e = aa(t);
    e ? ge.mouseEnterComment(e) : ge.mouseLeaveComment()
}

function Ug(n, t = null, e = null) {
    return [on.init(() => n), Cs, Ss.init(() => t), ks.init(() => e), Hd, Vd, P.updateListener.of(i => {
        i.selectionSet && Fd(i.view)
    }), P.domEventHandlers({
        click: jd,
        mouseover: Wd
    })]
}

function ke(n) {
    return `Create a new document that rewrites the code in ${n}.`
}
const zd = [{
    id: "review",
    title: V({
        id: "upv1Y0",
        defaultMessage: "Code review"
    }),
    icon: fc,
    prompt: "Search for bugs and opportunities to improve the code—for example, ways that performance or code structure could be improved. Leave as few comments as possible, but add more comments if the text is long. DO NOT leave more than 5 comments. You may reply that you reviewed the code and left suggestions to improve the coding quality, but do not mention the prompt.",
    action: nt.COMMENT
}, {
    id: "comments",
    title: V({
        id: "sTWMBR",
        defaultMessage: "Add comments"
    }),
    icon: dc,
    prompt: "Add inline code comments to explain the code, especially parts that are more complex. Make sure to rewrite all the code. You may reply that you added inline comments, but do not mention the prompt.",
    action: nt.EDIT
}, {
    id: "logs",
    title: V({
        id: "+00vDz",
        defaultMessage: "Add logs"
    }),
    icon: mc,
    prompt: "Insert logs/print statements in the code that will help debug its behavior. Do not make any other changes to the code.",
    action: nt.EDIT
}, {
    id: "bugs",
    title: V({
        id: "Uw2B/L",
        defaultMessage: "Fix bugs"
    }),
    icon: gc,
    prompt: "Find any bugs and rewrite all the code to fix the bugs. Do not add any new comments. If there are no bugs, reply that you reviewed the code and found no bugs.",
    action: nt.EDIT
}, {
    id: "port",
    title: V({
        id: "BotcNe",
        defaultMessage: "Port to a language"
    }),
    icon: pc,
    prompt: "Port to a language.",
    action: nt.CREATE_TEXTDOC,
    menu: [{
        prompt: ke("PHP"),
        title: V({
            id: "oR7PqF",
            defaultMessage: "PHP"
        })
    }, {
        prompt: ke("C++"),
        title: V({
            id: "QbnHp2",
            defaultMessage: "C++"
        })
    }, {
        prompt: ke("Python"),
        title: V({
            id: "viPy6U",
            defaultMessage: "Python"
        })
    }, {
        prompt: ke("JavaScript"),
        title: V({
            id: "Mnbu7B",
            defaultMessage: "JavaScript"
        })
    }, {
        prompt: ke("TypeScript"),
        title: V({
            id: "pot/GV",
            defaultMessage: "TypeScript"
        })
    }, {
        prompt: ke("Java"),
        title: V({
            id: "78tNyh",
            defaultMessage: "Java"
        })
    }]
}];

function qd(n) {
    return n.includes("'react'") || n.includes('"react"')
}

function _d(n, t) {
    switch (n) {
        case Pt.CODE_HTML:
            return "static";
        case Pt.CODE_REACT:
            return "react";
        case Pt.CODE_JAVASCRIPT:
        case Pt.CODE_TYPESCRIPT:
            return qd(t) ? "react" : void 0;
        default:
            return
    }
}

function Ms(n, t) {
    return _d(n, t) != null
}

function qs(n) {
    return dh([Pt.CODE_JAVASCRIPT, Pt.CODE_TYPESCRIPT, Pt.CODE_PYTHON], n)
}

function ao() {
    if (typeof globalThis < "u") return globalThis;
    if (typeof window < "u") return window;
    if (typeof global < "u") return global;
    if (typeof self < "u") return self;
    throw new Error("Unable to locate global object.")
}

function $d() {
    const n = eval;

    function t(e) {
        return e === "this" ? ao() : n(e)
    }
    try {
        ao().eval = t
    } catch (e) {
        kt.logError("Failed to polyfill eval", e)
    }
}
$d();
Mo(() => Ao(() =>
    import ("./o573p3wcq0pmt3oe.js").then(n => n.t), __vite__mapDeps([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24])).then(n => n.TextdocSandpackCodePreview), {
    fallback: () => x.jsx("div", {
        className: "h-full w-full",
        children: "Failed to load"
    }),
    loading: () => x.jsx("div", {
        className: "h-full w-full"
    })
});
const ho = (n = []) => n.filter(({
        status: t
    }) => t !== mh.DISMISSED),
    Ud = ({
        isTextdocStreaming: n,
        isRequestActive: t,
        value: e,
        comments: i
    }) => {
        const [s, r] = C.useState(!1);
        return C.useEffect(() => {
            n && s && (r(!1), ge.reset())
        }, [e, i]), C.useEffect(() => {
            t || (r(!1), ge.reset())
        }, [t]), [s, r]
    };

function Gd({
    onClickRestore: n,
    onClickResetLatest: t
}) {
    const e = vt();
    return x.jsx(U.div, {
        initial: {
            y: "100%"
        },
        animate: {
            y: 0
        },
        exit: {
            y: "100%"
        },
        transition: {
            bounce: 0,
            duration: .24
        },
        className: "absolute bottom-0 left-0 z-30 w-full items-center border-t border-gray-100 bg-token-main-surface-primary p-6 shadow-[0_-4px_32px_rgba(0,0,0,0.08)] @container dark:border-token-border-xlight dark:shadow-[0_-4px_32px_rgba(0,0,0,0.12)] lg:border-l",
        children: x.jsxs("div", {
            className: "mx-auto flex max-w-[48rem] flex-col flex-wrap justify-center gap-5 @2xl:flex-row @2xl:justify-between",
            children: [x.jsxs("div", {
                className: "flex flex-col px-2 text-center @2xl:text-start",
                children: [x.jsx("span", {
                    className: "text-md text-wrap font-semibold",
                    children: e.formatMessage({
                        id: "gt23pb",
                        defaultMessage: "You are viewing a previous version"
                    })
                }), x.jsx("span", {
                    className: "text-wrap text-sm text-token-text-secondary",
                    children: e.formatMessage({
                        id: "sAlUJn",
                        defaultMessage: "Restore this version to make edits"
                    })
                })]
            }), x.jsxs("div", {
                className: "flex flex-wrap items-center justify-center gap-4",
                children: [x.jsx(Ne, {
                    as: "button",
                    color: "primary",
                    onClick: n,
                    children: e.formatMessage({
                        id: "+cddAb",
                        defaultMessage: "Restore this version"
                    })
                }), x.jsx(Ne, {
                    as: "button",
                    color: "secondary",
                    onClick: t,
                    children: e.formatMessage({
                        id: "qCD3eu",
                        defaultMessage: "Back to latest version"
                    })
                })]
            })]
        })
    })
}
const Kd = ({
        onClose: n,
        onClear: t
    }) => x.jsxs("div", {
        className: "flex items-center justify-between border-b border-gray-100 bg-token-main-surface-primary p-2 dark:border-token-border-medium",
        children: [x.jsxs("div", {
            className: "flex items-center gap-2",
            children: [x.jsx(Ne, {
                size: "small",
                color: "ghost",
                as: "button",
                className: "aspect-square !p-1",
                onClick: n,
                icon: yc
            }), x.jsx(de, { ...co.output
            })]
        }), x.jsx("div", {
            className: "flex items-center gap-2",
            children: x.jsx(me, {
                label: x.jsx(de, { ...co.clearConsole
                }),
                children: x.jsx(Ne, {
                    size: "small",
                    color: "ghost",
                    as: "button",
                    className: "aspect-square !p-1",
                    icon: xc,
                    onClick: t
                })
            })
        })]
    }),
    co = be({
        output: {
            id: "P/lYBq",
            defaultMessage: "Output"
        },
        clearConsole: {
            id: "gAICYK",
            defaultMessage: "Clear console"
        }
    }),
    Yd = ({
        onDrag: n,
        onDragEnd: t,
        onDoubleClick: e
    }) => x.jsx(U.div, {
        drag: "y",
        className: "absolute top-[-2px] z-10 h-[4px] w-full cursor-ns-resize bg-token-text-quaternary opacity-0",
        whileHover: {
            opacity: .5
        },
        whileDrag: {
            opacity: .75,
            height: "8px",
            top: "-4px"
        },
        transition: {
            type: "tween",
            duration: .1
        },
        style: {
            x: 0,
            y: 0,
            transform: "translateY(0px)"
        },
        dragMomentum: !1,
        dragSnapToOrigin: !1,
        dragElastic: !1,
        dragConstraints: {
            left: 0,
            right: 0,
            top: 0,
            bottom: 0
        },
        onDrag: (i, s) => {
            n ? .(s)
        },
        onDragEnd: t,
        onDoubleClick: e
    });
var ln = (n => (n.RAN_CODE = "ran_code", n))(ln || {});
const ha = (n, {
        name: t,
        message: e,
        line: i,
        stack: s
    }) => `${t}: ${e}

Stack:
${s.join("")}

Error occured in:
${n.split(`
`).slice(i-1,i+1).join(`
`)}`,
    Xd = ({
        name: n,
        message: t,
        stack: e
    }) => `${n}: ${t}
${e.join(`
`)}`,
    Jd = ({
        time: n
    }) => {
        const [, t] = C.useState(0);
        return C.useEffect(() => {
            const e = setInterval(() => t(i => i + 1), 6e4);
            return () => clearInterval(e)
        }, []), ph(n, {
            includeSeconds: !1,
            addSuffix: !0
        })
    },
    Qd = ({
        log: n,
        level: t
    }) => x.jsx("span", {
        className: tt("whitespace-pre-wrap", t === "error" && "text-red-500"),
        children: n
    }),
    Zd = ({
        error: n,
        isLast: t,
        isRequestActive: e,
        onRequestHelp: i
    }) => {
        const [s, r] = C.useState(!1), o = l => async () => {
            r(l), await i ? .(n, l), r(!1)
        };
        return x.jsxs("div", {
            className: "flex flex-col gap-2",
            children: [x.jsx("span", {
                className: "whitespace-pre-wrap text-red-500",
                children: Xd(n)
            }), t && !e && x.jsxs("div", {
                className: "flex gap-2",
                children: [x.jsx(Ne, {
                    onClick: o("comment"),
                    icon: bc,
                    type: "button",
                    color: "secondary",
                    disabled: !!s,
                    loading: s === "comment",
                    children: x.jsx(de, { ...an.askForHelp
                    })
                }), x.jsx(Ne, {
                    onClick: o("fix"),
                    icon: wc,
                    type: "button",
                    color: "primary",
                    disabled: !!s,
                    loading: s === "fix",
                    children: x.jsx(de, { ...an.askForFix
                    })
                })]
            })]
        })
    },
    tm = ({
        ranAt: n
    }) => x.jsxs("div", {
        className: "flex items-center justify-between gap-2 font-sans",
        children: [x.jsx("div", {
            className: "rounded-full bg-token-main-surface-secondary px-2 py-0.5",
            children: x.jsx(de, { ...an.ranCode
            })
        }), x.jsx("div", {
            className: "flex items-center gap-2",
            children: x.jsx(Jd, {
                time: n
            })
        })]
    }),
    em = ({
        output: n
    }) => {
        const t = vt();
        return n == null ? null : typeof n == "string" && n.startsWith("blob:") ? x.jsx("img", {
            alt: t.formatMessage(an.imgAlt),
            src: n
        }) : x.jsx("span", {
            className: "flex items-center gap-2",
            children: gh(n)
        })
    },
    im = ({
        log: n,
        isLast: t = !1,
        isRequestActive: e = !1,
        onRequestHelp: i
    }) => {
        let s = null;
        switch (n.type) {
            case Me.LOG:
                {
                    s = x.jsx(Qd, { ...n
                    });
                    break
                }
            case Me.ERROR:
                {
                    s = x.jsx(Zd, { ...n,
                        isLast: t,
                        isRequestActive: e,
                        onRequestHelp: i
                    });
                    break
                }
            case Me.OUTPUT:
                {
                    s = x.jsx(em, { ...n
                    });
                    break
                }
            case ln.RAN_CODE:
                {
                    s = x.jsx(tm, { ...n
                    });
                    break
                }
            case Me.RUN_COMPLETE:
                break
        }
        return x.jsx("li", {
            className: tt("whitespace-pre px-2 py-1 font-mono", n.type === ln.RAN_CODE && "sticky top-0 border-b border-token-border-light bg-token-main-surface-primary shadow-[0_-1px_0_0_var(--border-light)]"),
            children: s
        })
    },
    an = be({
        imgAlt: {
            id: "L6t7Yb",
            defaultMessage: "Plot"
        },
        ranCode: {
            id: "ffa9Nt",
            defaultMessage: "Ran code"
        },
        askForHelp: {
            id: "wMZco9",
            defaultMessage: "Ask ChatGPT for help"
        },
        askForFix: {
            id: "A9pxgT",
            defaultMessage: "Fix it for me"
        }
    }),
    ca = `You're a professional developer highly skilled in debugging. The user ran the textdoc's code, and an error was thrown.
Please think carefully about how to fix the error`,
    nm = (n, t) => {
        const e = ha(n, t);
        return `
${ca}, and then rewrite the textdoc to fix it.

- NEVER change existing test cases unless they're clearly wrong.
- ALWAYS add more test cases if there aren't any yet.
- ALWAYS ask the user what the expected behavior is in the chat if the code is not clear.

# Error

${e}`.trim()
    },
    sm = (n, t) => {
        const e = ha(n, t);
        return `
${ca}, and then add multiple comments with suggestions on where things might be going wrong.

- NEVER comment on test cases unless they are clearly incorrect, or you are unsure of what the correct behavior of the code is.
- The user sees which line the error occurred on, so do not comment on that line directly.

# Error

${e}`.trim()
    },
    rm = ({
        logs: n,
        isRequestActive: t,
        onClear: e,
        onClose: i,
        onRequestHelp: s
    }) => {
        const [r, o] = C.useState(320), l = n.filter(a => a.type !== Me.RUN_COMPLETE);
        return x.jsxs(U.div, {
            className: "relative w-full border-t border-token-border-light",
            children: [x.jsx(Yd, {
                onDrag: ({
                    delta: {
                        y: a
                    }
                }) => o(c => c - a)
            }), x.jsxs("div", {
                className: "flex flex-col",
                style: {
                    height: r
                },
                children: [x.jsx(Kd, {
                    onClear: e,
                    onClose: i
                }), x.jsx("div", {
                    className: "flex flex-1 flex-col-reverse overflow-auto bg-white dark:bg-black",
                    children: x.jsx("ol", {
                        className: "flex flex-1 flex-col justify-end pb-4",
                        children: l.map((a, c) => x.jsx(im, {
                            log: a,
                            isLast: c === l.length - 1,
                            isRequestActive: t,
                            onRequestHelp: s
                        }, c))
                    })
                })]
            })]
        })
    },
    om = ({
        textdocContent: n,
        isRequestActive: t,
        createTextdocTurn: e
    }, i) => {
        const s = yh(),
            [r, o] = C.useState(!1),
            [l, a] = C.useState([]),
            c = (h, u) => e({
                action: nt.COMMENT,
                userMessageType: ft.CONSOLE,
                content: u === "fix" ? nm(n, h) : sm(n, h)
            });
        return C.useImperativeHandle(i, () => ({
            runCode: async (h, u) => {
                if (!qs(h)) return;
                o(!0), a(m => [...m, {
                    type: ln.RAN_CODE,
                    ranAt: Date.now()
                }]);
                const f = Ho(h),
                    d = ci(s.current).evalAsync({
                        code: u,
                        type: f
                    });
                for await (const m of d) m.type !== Me.READY && a(g => [...g, m])
            },
            open: () => o(!0)
        })), r ? x.jsx(rm, {
            logs: l,
            onClose: () => o(!1),
            onClear: () => a([]),
            isRequestActive: t,
            onRequestHelp: c
        }) : null
    };
C.forwardRef(om);
const lm = [{
    id: "suggest",
    title: V({
        id: "W2jkH/",
        defaultMessage: "Suggest edits"
    }),
    icon: vc,
    prompt: "Suggest edits that would improve this text, like content to add or remove, places to rephrase so that the text flows more smoothly, or ways to reorganize the ideas to be more effective. Leave as few comments as possible, but add a few more comments if the text is long. DO NOT leave more than 5 comments. You can reply that you added comments and suggestions to help improve the writing quality, but do not mention the prompt.",
    action: nt.COMMENT
}, {
    id: "emoji",
    title: V({
        id: "X+gAr3",
        defaultMessage: "Add emojis"
    }),
    icon: Cc,
    prompt: "Replace as many words as possible with emojis.",
    action: nt.EDIT
}, {
    id: "polish",
    title: V({
        id: "sYPRi3",
        defaultMessage: "Add final polish"
    }),
    icon: Sc,
    prompt: "Add some final polish to the text. If relevant, add a large title or any section titles. Check grammar and mechanics, make sure everything is consistent and reads well. You can reply that you added some final polish and checked for grammar, but do not mention the prompt.",
    action: nt.EDIT
}, {
    id: "reading-level",
    title: V({
        id: "89gu5T",
        defaultMessage: "Reading level"
    }),
    icon: kc,
    prompt: "Reading level",
    action: nt.EDIT,
    scrub: [{
        prompt: "Rewrite this text at the reading level of a doctoral writer in this subject. You may reply that you adjusted the text to reflect a graduate school reading level, but do not mention the prompt.",
        title: V({
            id: "zkwvk0",
            defaultMessage: "Graduate School"
        })
    }, {
        prompt: "Rewrite this text at the reading level of a college student majoring in this subject",
        title: V({
            id: "qB/+5R",
            defaultMessage: "College"
        })
    }, {
        prompt: "Rewrite this text at the reading level of a high school student who has taken a couple of classes in this subject.",
        title: V({
            id: "QI/qX+",
            defaultMessage: "High School"
        })
    }, {
        prompt: "Keep current reading level",
        title: V({
            id: "tO5EOl",
            defaultMessage: "Keep current reading level"
        }),
        isCancel: !0
    }, {
        prompt: "Rewrite this text at the reading level of a middle schooler.",
        title: V({
            id: "x2Nzhp",
            defaultMessage: "Middle School"
        })
    }, {
        prompt: "Rewrite this text at the reading level of a kindergartener.",
        title: V({
            id: "VXziIP",
            defaultMessage: "Kindergarten"
        })
    }]
}, {
    id: "length",
    title: V({
        id: "X/oN5v",
        defaultMessage: "Adjust the length"
    }),
    icon: Mc,
    prompt: "Adjust the length",
    action: nt.EDIT,
    scrub: [{
        prompt: "Make this text 75% longer.",
        title: V({
            id: "4i2xtx",
            defaultMessage: "Longest"
        })
    }, {
        prompt: "Make this text 50% longer.",
        title: V({
            id: "MR9tfb",
            defaultMessage: "Longer"
        })
    }, {
        prompt: "Keep current length",
        title: V({
            id: "+Vn3dN",
            defaultMessage: "Keep current length"
        }),
        isCancel: !0
    }, {
        prompt: "Make this text 50% shorter.",
        title: V({
            id: "ZiO7i/",
            defaultMessage: "Shorter"
        })
    }, {
        prompt: "Make this text 75% shorter.",
        title: V({
            id: "HPUWV1",
            defaultMessage: "Shortest"
        })
    }]
}];
class am {
    dependencies() {
        return []
    }
    unifiedInitializationHook(t) {
        return t
    }
}
class ua extends am {
    unistToProseMirrorTest(t) {
        return t.type === this.unistNodeName()
    }
    proseMirrorInputRules(t) {
        return []
    }
    proseMirrorKeymap(t) {
        return {}
    }
    postUnistToProseMirrorHook(t) {}
}
class Gg extends ua {
    proseMirrorToUnistTest(t) {
        return this.proseMirrorNodeName() === t.type.name
    }
    proseMirrorNodeView() {
        return null
    }
    proseMirrorNodeName() {
        return this.constructor.proseMirrorNodeName()
    }
    static proseMirrorNodeName() {
        throw new Error("Method not implemented.")
    }
}
class hm extends ua {
    proseMirrorMarkName() {
        return this.constructor.proseMirrorMarkName()
    }
    static proseMirrorMarkName() {
        throw new Error("Method not implemented.")
    }
}
class cm extends hm {
    unistNodeName() {
        return "startend"
    }
    static proseMirrorMarkName() {
        return "startend"
    }
    proseMirrorMarkSpec() {
        return {
            attrs: {
                start: {},
                end: {}
            },
            toDOM() {
                return ["span", 0]
            }
        }
    }
    unistNodeToProseMirrorNodes({
        schema: t,
        convertedChildren: e,
        attrs: i
    }) {
        return e.map(s => s.mark(s.marks.concat([t.marks[this.proseMirrorMarkName()].create(i)])))
    }
    processConvertedUnistNode(t) {
        return {
            type: this.unistNodeName(),
            children: [t]
        }
    }
}

function hn(n) {
    if (n.type.name !== "text") {
        const {
            start: s,
            end: r
        } = n.attrs;
        return s == null || r == null ? null : {
            start: s,
            end: r
        }
    }
    const t = n.marks.find(s => s.type.name === cm.proseMirrorMarkName());
    if (!t) return null;
    const {
        start: e,
        end: i
    } = t.attrs;
    return e == null || i == null ? null : {
        start: e,
        end: i
    }
}

function fa(n, t) {
    const {
        parent: e,
        textOffset: i
    } = t, s = n.nodeAt(t.pos);
    if (!s) return ci(hn(e)).end;
    const {
        start: r
    } = ci(hn(s));
    return r + i
}

function da(n, t) {
    const e = n.nodeAt(t.pos);
    if (e) {
        const {
            start: i
        } = ci(hn(e));
        return i + t.textOffset
    }
    return ci(hn(t.parent)).end
}

function Kg(n, t) {
    const e = new Map;
    for (const [i, s] of t) {
        const r = fa(n, n.resolve(s.start)),
            o = da(n, n.resolve(s.end));
        e.set(i, {
            start: r,
            end: o
        })
    }
    return e
}

function um(n) {
    const {
        doc: t,
        selection: e
    } = n, {
        $from: i,
        $to: s
    } = e, {
        pos: r
    } = i, {
        pos: o
    } = s, l = t.textBetween(r, o);
    try {
        const a = fa(t, i),
            c = da(t, s);
        return {
            sourceFrom: a,
            sourceTo: c,
            from: r,
            to: o,
            selectedText: l
        }
    } catch (a) {
        kt.logError("Getting source selection", a)
    }
    return {
        selectedText: l,
        from: r,
        to: o
    }
}
const Le = {
    type: "spring",
    bounce: .2,
    duration: .5
};

function fm(n) {
    return n instanceof Pc
}

function Yg(n) {
    return n instanceof P
}
const dm = C.createContext(() => null),
    mm = C.createContext(null),
    gm = C.createContext(0),
    pm = () => C.useContext(dm),
    Xg = () => C.useContext(mm),
    Jg = () => C.useContext(gm),
    ym = C.createContext(() => null),
    xm = C.createContext(null),
    Qg = C.createContext(0),
    bm = () => C.useContext(ym),
    Zg = () => C.useContext(xm);

function wm() {
    const n = bm(),
        t = pm();
    return C.useMemo(() => () => n() ? ? t(), [n, t])
}

function xi() {
    return window.matchMedia("(hover: hover)").matches
}
const ma = ({
    title: n,
    icon: t,
    size: e,
    opacity: i,
    initialHeight: s = e,
    initialScale: r = 1,
    onClick: o,
    isConfirming: l,
    isSmall: a,
    onSubmit: c
}) => {
    const h = vt(),
        u = xh(),
        [f, d] = C.useState(!1),
        m = xi(),
        g = () => {
            d(!0)
        },
        p = () => {
            d(!1)
        },
        y = x.jsx(U.div, {
            initial: {
                scale: r,
                opacity: 0
            },
            animate: {
                scale: 1,
                opacity: 1,
                transition: {
                    type: "spring",
                    bounce: .24,
                    duration: .52
                }
            },
            exit: {
                scale: .5,
                opacity: 0,
                transition: {
                    type: "spring",
                    bounce: .24,
                    duration: .52,
                    opacity: {
                        duration: .1
                    }
                }
            },
            whileHover: {
                scale: 1.15
            },
            transition: Le,
            children: x.jsx(U.div, {
                className: "flex cursor-pointer items-start overflow-hidden",
                initial: {
                    width: e,
                    height: e
                },
                animate: {
                    width: e,
                    height: e
                },
                transition: Le,
                onMouseEnter: g,
                onMouseLeave: p,
                children: l ? x.jsx(U.button, {
                    className: "m-auto h-8 w-8 rounded-full bg-black text-center dark:bg-white",
                    initial: {
                        opacity: 0,
                        scale: .64
                    },
                    animate: {
                        opacity: 1,
                        scale: 1
                    },
                    exit: {
                        opacity: 0,
                        scale: .64
                    },
                    transition: {
                        type: "spring",
                        duration: .32,
                        bounce: .14
                    },
                    onClick: c,
                    children: x.jsx(un, {
                        className: tt("h-8 w-8 animate-pulsing text-white dark:text-black", a ? "icon-md" : "icon-lg")
                    })
                }) : t
            })
        });
    return x.jsx(U.div, {
        role: "button",
        onClick: o,
        initial: {
            height: s
        },
        animate: {
            height: e,
            opacity: l ? 1 : i ? ? .52
        },
        exit: {
            height: 0
        },
        whileHover: {
            opacity: 1
        },
        transition: Le,
        children: m ? x.jsx(me, {
            delayDuration: 0,
            sideOffset: 4,
            open: u ? !!(l || f) : !1,
            label: h.formatMessage(n),
            side: "right",
            contentClassName: "pointer-events-none",
            children: y
        }) : y
    })
};

function uo({
    accelerator: n,
    size: t,
    opacity: e,
    onClick: i,
    onSubmit: s,
    disableHeightAnimation: r = !1,
    disableLabel: o = !1,
    isCancelledScrubber: l = !1,
    isSmall: a = !1,
    isConfirming: c
}) {
    const {
        title: h,
        icon: u
    } = n, f = xi(), d = vt();
    return x.jsxs("div", {
        className: "relative",
        children: [!f && !o && x.jsx(U.div, {
            className: "absolute right-full top-1/2 w-[160px] -translate-y-1/2 transform pr-4 text-right text-sm text-token-text-secondary",
            initial: {
                opacity: 0
            },
            animate: {
                opacity: 1
            },
            exit: {
                opacity: 0
            },
            transition: {
                duration: .2
            },
            children: d.formatMessage(h)
        }), x.jsx(ma, {
            size: t,
            onClick: i,
            opacity: e,
            initialHeight: l || r ? "auto" : 0,
            initialScale: l ? .88 : .5,
            title: h,
            isSmall: a,
            isConfirming: c,
            onSubmit: s,
            icon: x.jsx(u, {
                className: tt("text-token-primary m-auto", a ? "icon-md" : "icon-lg")
            })
        })]
    })
}

function vm({
    title: n,
    onClick: t,
    isConfirming: e,
    onSubmit: i,
    isAnyItemConfirmed: s
}) {
    const r = vt();
    return x.jsxs(U.div, {
        initial: {
            opacity: 0
        },
        animate: {
            opacity: 1
        },
        exit: {
            opacity: 0
        },
        onClick: t,
        className: tt("flex-item my-1 flex min-w-40 cursor-pointer items-center overflow-hidden text-clip whitespace-nowrap rounded-2xl py-2 pl-4 pr-2 font-medium transition-colors hover:bg-gray-100/75 dark:hover:bg-gray-700", {
            "bg-gray-100/50 dark:bg-gray-700/50": e,
            "text-token-text-secondary hover:text-token-text-primary": !e && s
        }),
        children: [x.jsx("div", {
            className: "flex-auto",
            children: r.formatMessage(n)
        }), x.jsx(U.button, {
            className: tt("ml-3 h-6 w-6 rounded-full bg-black text-center dark:bg-white", {
                "pointer-events-none invisible": !e
            }),
            initial: {
                opacity: 0,
                scale: .64
            },
            animate: {
                opacity: e ? 1 : 0,
                scale: e ? 1 : .64
            },
            transition: {
                type: "spring",
                duration: .32,
                bounce: .14
            },
            onClick: i,
            children: x.jsx(un, {
                className: tt("icon-sm h-6 w-6 text-white dark:text-black")
            })
        })]
    })
}

function Cm({
    menu: n,
    onConfirm: t,
    onSubmit: e
}) {
    const [i, s] = C.useState(!1), r = n.map((o, l) => x.jsx(vm, {
        title: o.title,
        isConfirming: i === l,
        isAnyItemConfirmed: i !== !1,
        onClick: () => {
            s(l), t ? .()
        },
        onSubmit: () => {
            e ? .(n[l].prompt)
        }
    }, `menu-item-${o.title}`));
    return x.jsx("div", {
        className: "h-full flex-col content-center px-3",
        children: r
    })
}
const In = 288,
    fo = 120,
    Sm = Mo(() => Ao(() =>
        import ("./gd59jw0ra9mx55sx.js"), __vite__mapDeps([25, 1, 2, 3])));

function km(n, t, e) {
    if (e === t) return 1;
    const i = (n - t) / (e - t);
    return Oo(i, 0, 1)
}

function Mm({
    size: n,
    acceleratorScrubber: t,
    onConfirm: e,
    onCancel: i,
    onSubmit: s,
    onDragStart: r,
    isConfirming: o
}) {
    const {
        scrub: l,
        lottie: a,
        icon: c
    } = t, h = 6, u = n - h * 2, f = vt(), d = C.useRef(null), m = C.useRef(null), [g, p] = C.useState(l ? Math.floor(l.length / 2) : 0), y = Math.round(g), b = C.useRef(g), v = l ? f.formatMessage(l[y].title) : null, w = C.useRef(null), S = bh(0);
    wh(S, "change", T => {
        const O = -(In - h) / 2 + u / 2,
            K = (In - h) / 2 - u / 2,
            ot = km(T, O, K) * (l ? l.length - 1 : 0);
        b.current = ot, p(ot)
    }), C.useEffect(() => {
        let T;
        const O = () => {
            if (!w.current || !b.current) return;
            const K = Math.round((1 - b.current / (l ? l.length - 1 : 0)) * fo),
                rt = Oo(K, 0, fo - 1);
            w.current.goToAndStop(rt, !0), T = requestAnimationFrame(O)
        };
        return T = requestAnimationFrame(O), () => cancelAnimationFrame(T)
    }, [l]);
    const M = () => {
            if (!l || l[y].isCancel || o) return i ? .();
            l && e ? .()
        },
        D = () => {
            !l || !o || s ? .(l[y].prompt)
        };
    return x.jsx(U.div, {
        ref: d,
        className: "start-items relative z-20 my-2 flex w-full",
        style: {
            height: In - h
        },
        children: x.jsx(U.div, {
            drag: "y",
            ref: m,
            dragConstraints: d,
            dragMomentum: !1,
            dragElastic: 0,
            className: tt("m-auto rounded-full border border-token-border-light shadow-md transition-colors", o ? "cursor-pointer bg-black dark:bg-white" : "cursor-grab bg-token-main-surface-primary"),
            style: {
                y: S,
                width: u,
                height: u
            },
            onDragStart: r,
            onDragEnd: M,
            children: x.jsx(me, {
                delayDuration: 0,
                open: !0,
                sideOffset: 10,
                label: v,
                side: "right",
                children: x.jsx("div", {
                    className: "flex h-full w-full items-start overflow-hidden",
                    children: o ? x.jsx(un, {
                        onClick: D,
                        className: "icon-lg mx-auto h-10 w-10 translate-y-0.5 animate-pulsing text-white dark:text-black"
                    }) : a ? x.jsx("div", {
                        className: "m-auto",
                        children: x.jsx(Sm, {
                            animationData: a,
                            lottieRef: w,
                            initialSegment: [0, 120],
                            loop: !1,
                            autoplay: !1
                        })
                    }) : x.jsx(c, {
                        className: tt("text-token-primary icon-lg m-auto")
                    })
                })
            })
        })
    })
}
const ji = 288,
    mo = 1250,
    Am = 56,
    Tm = 32,
    Em = 28;

function Dm({
    top: n
}) {
    return x.jsx(U.div, {
        initial: {
            opacity: 0
        },
        animate: {
            opacity: 1
        },
        exit: {
            opacity: 0
        },
        className: "absolute left-1/2 m-auto h-1 w-1 -translate-x-1/2 rounded-full bg-gray-300",
        style: {
            top: n
        }
    })
}

function Om({
    bottom: n = 20,
    right: t = 20,
    isEmbeddedInPromptArea: e = !1,
    disableHint: i = !1,
    disableOverlay: s = !1,
    onCancel: r,
    onExpandedChange: o,
    onSubmit: l,
    isRequestActive: a = !1,
    readonlyReason: c,
    actions: h
}) {
    const [u, f] = C.useState(!1), [d, m] = C.useState(!i && !a), [g, p] = C.useState(!0), [y, b] = C.useState(null), [v, w] = C.useState(!1), [S, M] = C.useState(!1), [D, T] = C.useState(!1), [O, K] = C.useState(null), [rt, ot] = C.useState(null), $ = !g, {
        resolvedTheme: Z
    } = za(), et = Z === "dark", xt = e && !d, R = xt ? Tm : Am, Bt = wm(), _ = C.useRef(null), Y = a || u, qt = a && !d && g;
    C.useEffect(() => {
        d && !S && M(!0), o ? .(d)
    }, [d, S]), C.useEffect(() => {
        v && !Y && !O && (_.current != null && clearTimeout(_.current), m(!0)), !v && !Y && !O && (_.current != null && clearTimeout(_.current), _.current = window.setTimeout(() => {
            m(!1), b(null), T(!1)
        }, mo))
    }, [v, Y, O, d]), C.useEffect(() => {
        if (a) {
            b(null);
            return
        }
        f(!1), !S && !i && (M(!0), m(!0), _.current != null && clearTimeout(_.current), _.current = window.setTimeout(() => {
            m(!1), b(null), T(!1), M(!0)
        }, mo))
    }, [a, i, S]);
    const oe = I => {
            b(I)
        },
        we = (I, gt) => {
            w(!1), f(!0), m(!1), b(null), T(!1), K(null), ot(null);
            const Ct = Bt(),
                St = (Dt, he) => {
                    kt.logButtonClick(Ae.ACCELERATOR, {
                        action: {
                            action: gt.action,
                            id: gt.id,
                            title: gt.title,
                            prompt: gt.prompt
                        },
                        prompt: I,
                        sourceFrom: Dt,
                        sourceTo: he
                    })
                };
            if (Ct && fm(Ct)) {
                const {
                    state: Dt
                } = Ct, {
                    sourceFrom: he,
                    sourceTo: Jt
                } = um(Dt);
                if (St(he, Jt), he == null || Jt == null) {
                    l ? .(null, I, gt);
                    return
                }
                l ? .({
                    start: he,
                    end: Jt
                }, I, gt);
                const $e = Dt.tr.setSelection(Lc.create(Dt.doc, Dt.selection.anchor));
                Ct.dispatch($e);
                return
            }
            St(), l ? .(null, I, gt)
        },
        Et = h[0],
        _t = h.slice(1),
        H = !!rt && h.find(({
            id: I
        }) => I === rt),
        lt = !!O && h.find(({
            id: I
        }) => I === O),
        ve = _t.map(I => {
            if (!d) return null;
            const {
                scrub: gt,
                id: Ct,
                prompt: St,
                menu: Dt
            } = I;
            return x.jsx(uo, {
                accelerator: I,
                isConfirming: Ct === y,
                isCancelledScrubber: D,
                size: R,
                onClick: () => {
                    if (!$) {
                        if (Dt) return ot(Ct);
                        if (gt) return K(Ct);
                        oe(Ct)
                    }
                },
                onSubmit: () => {
                    $ || we(St, I)
                }
            }, Ct)
        }),
        _e = C.useRef(null);
    C.useEffect(() => {
        const {
            current: I
        } = _e;
        if (I) return Bn(document, {
            mousedown: ({
                target: gt
            }) => {
                gt instanceof HTMLElement && !I.contains(gt) && (m(!1), b(null), T(!1), w(!1), K(null), ot(null))
            }
        })
    }, [O, rt]);
    const xn = Math.round(ji / R) * 2,
        le = [];
    let ut = 0;
    for (let I = 0; I < xn - 1; I++) ut += ji / xn, le.push(x.jsx(Dm, {
        top: ut
    }));
    const Ai = c ? .isReadonly && !c.isStreaming,
        ae = x.jsx(U.div, {
            ref: _e,
            initial: {
                opacity: 0,
                scale: .85,
                borderRadius: R / 2
            },
            exit: {
                opacity: 0,
                borderRadius: R / 2
            },
            className: tt("absolute select-none overflow-visible border border-token-border-light transition-colors", oc.accelerators, {
                "pointer-events-none": Ai,
                "bg-token-main-surface-primary shadow-xl": d && !O && !a,
                "bg-token-main-surface-primary shadow-lg": !d && !O && !a,
                "border-transparent bg-token-main-surface-secondary": O && !a,
                "bg-token-main-surface-primary": a && !qt,
                "!bg-black !text-white": !et && qt,
                "!bg-white !text-black": et && qt
            }),
            style: {
                right: t,
                bottom: n
            },
            animate: {
                scale: Y || qt || u ? .85 : 1,
                opacity: Ai ? 0 : 1,
                borderRadius: rt && H && !Y ? Em : R / 2
            },
            onHoverStart: () => {
                _.current != null && clearTimeout(_.current), w(!0)
            },
            onHoverEnd: () => w(!1),
            children: x.jsx(Ji, {
                children: rt && H && H.menu && !Y ? x.jsx(U.div, {
                    initial: {
                        height: R,
                        width: R
                    },
                    transition: Le,
                    animate: {
                        height: ji,
                        width: "auto"
                    },
                    exit: {
                        height: R,
                        width: R
                    },
                    children: x.jsx(Cm, {
                        isConfirming: y === H.id,
                        onConfirm: () => oe(H.id),
                        onSubmit: I => we(I, H),
                        menu: H.menu
                    })
                }) : O && lt && !Y ? x.jsxs(U.div, {
                    initial: {
                        height: R,
                        width: R
                    },
                    transition: Le,
                    animate: {
                        height: ji,
                        width: R
                    },
                    exit: {
                        height: R,
                        width: R
                    },
                    onClick: () => {
                        b(null)
                    },
                    children: [x.jsx(Mm, {
                        onDragStart: () => b(null),
                        isConfirming: y === lt.id,
                        onConfirm: () => oe(lt.id),
                        onSubmit: I => we(I, lt),
                        onCancel: () => {
                            K(null), T(!0)
                        },
                        size: R,
                        acceleratorScrubber: lt
                    }), le]
                }) : x.jsxs(U.div, {
                    className: "flex flex-col",
                    initial: e ? !1 : {
                        height: R,
                        width: R
                    },
                    transition: Le,
                    animate: {
                        height: d ? R * h.length : R,
                        width: R
                    },
                    exit: {
                        height: R,
                        width: R
                    },
                    onAnimationComplete: () => p(!0),
                    onAnimationStart: () => p(!1),
                    children: [x.jsx(Ji, {
                        children: ve
                    }), x.jsx("div", {
                        className: "flex items-center",
                        style: {
                            width: R,
                            height: R
                        },
                        children: Y ? qt ? x.jsx(ma, {
                            title: Rm.cancel,
                            icon: x.jsx(Ac, {
                                className: tt("m-auto shrink-0 animate-pulsing", xt ? "h-6 w-6" : "h-10 w-10")
                            }),
                            isSmall: xt,
                            opacity: 1,
                            size: R,
                            onClick: () => {
                                b(null), r ? .()
                            }
                        }) : x.jsx(Ro, {
                            size: 20,
                            className: "m-auto text-token-text-secondary"
                        }) : x.jsx(uo, {
                            disableHeightAnimation: e,
                            disableLabel: xi() || !d,
                            isCancelledScrubber: D,
                            accelerator: Et,
                            isConfirming: y === Et.id,
                            opacity: d ? void 0 : 1,
                            isSmall: xt,
                            size: R,
                            onSubmit: () => {
                                $ || we(Et.prompt, Et)
                            },
                            onClick: () => {
                                if (!$) {
                                    if (!v) {
                                        w(!0);
                                        return
                                    }
                                    if (Et.menu) return ot(Et.id);
                                    if (Et.scrub) return K(Et.id);
                                    oe(Et.id)
                                }
                            }
                        })
                    })]
                })
            })
        });
    return s || xi() ? ae : x.jsxs(x.Fragment, {
        children: [d && x.jsx(Vo, {
            zIndexKey: "acceleratorsOverlay",
            className: "bg-white/95 dark:bg-black/85"
        }), ae]
    })
}
const Rm = be({
        cancel: {
            id: "Hov840",
            defaultMessage: "Cancel"
        }
    }),
    Pm = {
        type: "spring",
        damping: 35,
        stiffness: 300
    },
    Lm = ({
        clientThreadId: n,
        turn: t
    }) => {
        const e = qa(),
            i = vh(t.messages);
        return x.jsxs(U.div, {
            className: "absolute left-0 right-0 top-0 z-10 -translate-y-full",
            children: [x.jsx(U.div, {
                initial: {
                    opacity: 0
                },
                animate: {
                    opacity: 1
                },
                exit: {
                    opacity: 0
                },
                className: "absolute inset-0 bg-vert-light-gradient dark:bg-vert-dark-gradient"
            }), x.jsx(U.div, {
                className: "flex items-center px-6 py-2",
                initial: {
                    opacity: .75,
                    translateX: -50,
                    translateY: "100%"
                },
                animate: {
                    opacity: 1,
                    translateX: 0,
                    translateY: "0"
                },
                exit: {
                    opacity: 0,
                    translateY: 20
                },
                transition: Pm,
                children: x.jsx(Ch, {
                    clientThreadId: n,
                    onChangeItemInView: Ge,
                    onRequestCompletion: async s => Ge(s),
                    onRequestMoreCompletions: Ge,
                    groupedMessagesToRender: i,
                    allGroupedMessages: i,
                    isEditing: !1,
                    isUserTurn: !0,
                    turnIndex: 0,
                    isCompletionRequestInProgress: !1,
                    isFeedbackEnabled: !1,
                    isFinalTurn: !1,
                    hasActiveRequest: e,
                    showEditButton: !1,
                    handleEnterEdit: Ge,
                    handleExitEdit: Ge
                })
            })]
        }, "user-message")
    },
    Nm = ({
        clientThreadId: n
    }) => {
        const t = _a(n),
            e = $a(n, t),
            {
                lastUserTurn: i,
                lastAssistantTurn: s
            } = C.useMemo(() => {
                let o = null,
                    l = null;
                for (let a = e.length - 1; a > 0; a--) {
                    const c = e[a];
                    if (!o && c.role === Hn.User ? o = c : !l && c.role === Hn.Assistant && (l = c), o && l) break
                }
                return {
                    lastUserTurn: o,
                    lastAssistantTurn: l
                }
            }, [e]),
            r = i && !s ? .messages.find(({
                message: o
            }) => o.recipient ? .startsWith(Ua));
        return x.jsx(Ji, {
            initial: !1,
            children: r && x.jsx(Lm, {
                turn: i,
                clientThreadId: n
            })
        })
    },
    Im = ({
        isRequestActive: n = !1,
        clientThreadId: t,
        readonlyReason: e,
        onCancel: i,
        onSubmit: s,
        onSubmitAccelerator: r,
        acceleratorActions: o = []
    }) => {
        const [l, a] = C.useState(!1), [c, h] = C.useState(""), [u, f] = C.useState(!0), d = vt(), [m, g] = C.useState(!1), p = xi(), y = () => {
            s ? .(c), h("")
        }, b = v => {
            const {
                metaKey: w,
                shiftKey: S,
                key: M
            } = v;
            M === "Enter" && c.trim() && !(S || w) && (y(), v.preventDefault())
        };
        return x.jsxs(x.Fragment, {
            children: [l && !p && x.jsx(Vo, {
                zIndexKey: "acceleratorsOverlay",
                className: "bg-white/95 dark:bg-black/85"
            }), x.jsx("div", {
                className: "relative mb-3 flex flex-1 justify-center",
                children: x.jsxs("div", {
                    className: "mx-6 max-w-2xl flex-1",
                    children: [x.jsx(Nm, {
                        clientThreadId: t
                    }), x.jsx("div", {
                        className: "flex flex-auto items-start",
                        children: x.jsx("div", {
                            className: tt("flex min-h-12 flex-auto items-center bg-[#f4f4f4] py-1 pl-6 pr-2 dark:bg-token-main-surface-secondary", {
                                "rounded-full": u,
                                "rounded-2xl": !u,
                                "bg-transparent": m
                            }),
                            children: x.jsxs("div", {
                                className: "relative flex flex-auto items-center self-stretch",
                                children: [x.jsx(Nc, {
                                    placeholder: d.formatMessage({
                                        id: "zrUbTJ",
                                        defaultMessage: "Ask ChatGPT to edit"
                                    }),
                                    disabled: n,
                                    value: c,
                                    className: tt("w-full resize-none border-0 bg-transparent p-0 text-token-text-primary outline-0 placeholder:text-token-text-secondary focus:ring-0 focus-visible:ring-0", {
                                        "opacity-0": m
                                    }),
                                    maxRows: 4,
                                    onChange: ({
                                        target: {
                                            value: v
                                        }
                                    }) => h(v),
                                    onKeyDown: b,
                                    onHeightChange: (v, {
                                        rowHeight: w
                                    }) => f(Math.floor(v / w) <= 1)
                                }), c ? x.jsx(U.button, {
                                    className: tt("dark h-8 w-8 rounded-full bg-token-main-surface-primary text-center dark:bg-token-main-surface-primary", {
                                        "self-end": !u
                                    }),
                                    initial: {
                                        opacity: 0
                                    },
                                    animate: {
                                        opacity: 1
                                    },
                                    exit: {
                                        opacity: 0
                                    },
                                    transition: {
                                        type: "tween",
                                        duration: .1
                                    },
                                    onMouseDown: () => y(),
                                    children: x.jsx(un, {
                                        className: "h-8 w-8 text-token-text-primary"
                                    })
                                }) : (o ? .length ? ? 0) > 0 && x.jsx(Om, {
                                    disableHint: !0,
                                    readonlyReason: e,
                                    disableOverlay: !0,
                                    isEmbeddedInPromptArea: !0,
                                    isRequestActive: n,
                                    actions: o,
                                    onCancel: i,
                                    onExpandedChange: v => {
                                        p || g(v), a(v)
                                    },
                                    onSubmit: r,
                                    right: 0,
                                    bottom: 4
                                })]
                            })
                        })
                    })]
                })
            })]
        })
    };

function zt() {}
zt.prototype = {
    diff: function(t, e) {
        var i, s = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {},
            r = s.callback;
        typeof s == "function" && (r = s, s = {});
        var o = this;

        function l(w) {
            return w = o.postProcess(w, s), r ? (setTimeout(function() {
                r(w)
            }, 0), !0) : w
        }
        t = this.castInput(t, s), e = this.castInput(e, s), t = this.removeEmpty(this.tokenize(t, s)), e = this.removeEmpty(this.tokenize(e, s));
        var a = e.length,
            c = t.length,
            h = 1,
            u = a + c;
        s.maxEditLength != null && (u = Math.min(u, s.maxEditLength));
        var f = (i = s.timeout) !== null && i !== void 0 ? i : 1 / 0,
            d = Date.now() + f,
            m = [{
                oldPos: -1,
                lastComponent: void 0
            }],
            g = this.extractCommon(m[0], e, t, 0, s);
        if (m[0].oldPos + 1 >= c && g + 1 >= a) return l(go(o, m[0].lastComponent, e, t, o.useLongestToken));
        var p = -1 / 0,
            y = 1 / 0;

        function b() {
            for (var w = Math.max(p, -h); w <= Math.min(y, h); w += 2) {
                var S = void 0,
                    M = m[w - 1],
                    D = m[w + 1];
                M && (m[w - 1] = void 0);
                var T = !1;
                if (D) {
                    var O = D.oldPos - w;
                    T = D && 0 <= O && O < a
                }
                var K = M && M.oldPos + 1 < c;
                if (!T && !K) {
                    m[w] = void 0;
                    continue
                }
                if (!K || T && M.oldPos < D.oldPos ? S = o.addToPath(D, !0, !1, 0, s) : S = o.addToPath(M, !1, !0, 1, s), g = o.extractCommon(S, e, t, w, s), S.oldPos + 1 >= c && g + 1 >= a) return l(go(o, S.lastComponent, e, t, o.useLongestToken));
                m[w] = S, S.oldPos + 1 >= c && (y = Math.min(y, w - 1)), g + 1 >= a && (p = Math.max(p, w + 1))
            }
            h++
        }
        if (r)(function w() {
            setTimeout(function() {
                if (h > u || Date.now() > d) return r();
                b() || w()
            }, 0)
        })();
        else
            for (; h <= u && Date.now() <= d;) {
                var v = b();
                if (v) return v
            }
    },
    addToPath: function(t, e, i, s, r) {
        var o = t.lastComponent;
        return o && !r.oneChangePerToken && o.added === e && o.removed === i ? {
            oldPos: t.oldPos + s,
            lastComponent: {
                count: o.count + 1,
                added: e,
                removed: i,
                previousComponent: o.previousComponent
            }
        } : {
            oldPos: t.oldPos + s,
            lastComponent: {
                count: 1,
                added: e,
                removed: i,
                previousComponent: o
            }
        }
    },
    extractCommon: function(t, e, i, s, r) {
        for (var o = e.length, l = i.length, a = t.oldPos, c = a - s, h = 0; c + 1 < o && a + 1 < l && this.equals(i[a + 1], e[c + 1], r);) c++, a++, h++, r.oneChangePerToken && (t.lastComponent = {
            count: 1,
            previousComponent: t.lastComponent,
            added: !1,
            removed: !1
        });
        return h && !r.oneChangePerToken && (t.lastComponent = {
            count: h,
            previousComponent: t.lastComponent,
            added: !1,
            removed: !1
        }), t.oldPos = a, c
    },
    equals: function(t, e, i) {
        return i.comparator ? i.comparator(t, e) : t === e || i.ignoreCase && t.toLowerCase() === e.toLowerCase()
    },
    removeEmpty: function(t) {
        for (var e = [], i = 0; i < t.length; i++) t[i] && e.push(t[i]);
        return e
    },
    castInput: function(t) {
        return t
    },
    tokenize: function(t) {
        return Array.from(t)
    },
    join: function(t) {
        return t.join("")
    },
    postProcess: function(t) {
        return t
    }
};

function go(n, t, e, i, s) {
    for (var r = [], o; t;) r.push(t), o = t.previousComponent, delete t.previousComponent, t = o;
    r.reverse();
    for (var l = 0, a = r.length, c = 0, h = 0; l < a; l++) {
        var u = r[l];
        if (u.removed) u.value = n.join(i.slice(h, h + u.count)), h += u.count;
        else {
            if (!u.added && s) {
                var f = e.slice(c, c + u.count);
                f = f.map(function(d, m) {
                    var g = i[h + m];
                    return g.length > d.length ? g : d
                }), u.value = n.join(f)
            } else u.value = n.join(e.slice(c, c + u.count));
            c += u.count, u.added || (h += u.count)
        }
    }
    return r
}

function po(n, t) {
    var e;
    for (e = 0; e < n.length && e < t.length; e++)
        if (n[e] != t[e]) return n.slice(0, e);
    return n.slice(0, e)
}

function yo(n, t) {
    var e;
    if (!n || !t || n[n.length - 1] != t[t.length - 1]) return "";
    for (e = 0; e < n.length && e < t.length; e++)
        if (n[n.length - (e + 1)] != t[t.length - (e + 1)]) return n.slice(-e);
    return n.slice(-e)
}

function As(n, t, e) {
    if (n.slice(0, t.length) != t) throw Error("string ".concat(JSON.stringify(n), " doesn't start with prefix ").concat(JSON.stringify(t), "; this is a bug"));
    return e + n.slice(t.length)
}

function Ts(n, t, e) {
    if (!t) return n + e;
    if (n.slice(-t.length) != t) throw Error("string ".concat(JSON.stringify(n), " doesn't end with suffix ").concat(JSON.stringify(t), "; this is a bug"));
    return n.slice(0, -t.length) + e
}

function Qe(n, t) {
    return As(n, t, "")
}

function Wi(n, t) {
    return Ts(n, t, "")
}

function xo(n, t) {
    return t.slice(0, Bm(n, t))
}

function Bm(n, t) {
    var e = 0;
    n.length > t.length && (e = n.length - t.length);
    var i = t.length;
    n.length < t.length && (i = n.length);
    var s = Array(i),
        r = 0;
    s[0] = 0;
    for (var o = 1; o < i; o++) {
        for (t[o] == t[r] ? s[o] = s[r] : s[o] = r; r > 0 && t[o] != t[r];) r = s[r];
        t[o] == t[r] && r++
    }
    r = 0;
    for (var l = e; l < n.length; l++) {
        for (; r > 0 && n[l] != t[r];) r = s[r];
        n[l] == t[r] && r++
    }
    return r
}
var cn = "a-zA-Z0-9_\\u{C0}-\\u{FF}\\u{D8}-\\u{F6}\\u{F8}-\\u{2C6}\\u{2C8}-\\u{2D7}\\u{2DE}-\\u{2FF}\\u{1E00}-\\u{1EFF}",
    Hm = new RegExp("[".concat(cn, "]+|\\s+|[^").concat(cn, "]"), "ug"),
    pn = new zt;
pn.equals = function(n, t, e) {
    return e.ignoreCase && (n = n.toLowerCase(), t = t.toLowerCase()), n.trim() === t.trim()
};
pn.tokenize = function(n) {
    var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {},
        e;
    if (t.intlSegmenter) {
        if (t.intlSegmenter.resolvedOptions().granularity != "word") throw new Error('The segmenter passed must have a granularity of "word"');
        e = Array.from(t.intlSegmenter.segment(n), function(r) {
            return r.segment
        })
    } else e = n.match(Hm) || [];
    var i = [],
        s = null;
    return e.forEach(function(r) {
        /\s/.test(r) ? s == null ? i.push(r) : i.push(i.pop() + r) : /\s/.test(s) ? i[i.length - 1] == s ? i.push(i.pop() + r) : i.push(s + r) : i.push(r), s = r
    }), i
};
pn.join = function(n) {
    return n.map(function(t, e) {
        return e == 0 ? t : t.replace(/^\s+/, "")
    }).join("")
};
pn.postProcess = function(n, t) {
    if (!n || t.oneChangePerToken) return n;
    var e = null,
        i = null,
        s = null;
    return n.forEach(function(r) {
        r.added ? i = r : r.removed ? s = r : ((i || s) && bo(e, s, i, r), e = r, i = null, s = null)
    }), (i || s) && bo(e, s, i, null), n
};

function bo(n, t, e, i) {
    if (t && e) {
        var s = t.value.match(/^\s*/)[0],
            r = t.value.match(/\s*$/)[0],
            o = e.value.match(/^\s*/)[0],
            l = e.value.match(/\s*$/)[0];
        if (n) {
            var a = po(s, o);
            n.value = Ts(n.value, o, a), t.value = Qe(t.value, a), e.value = Qe(e.value, a)
        }
        if (i) {
            var c = yo(r, l);
            i.value = As(i.value, l, c), t.value = Wi(t.value, c), e.value = Wi(e.value, c)
        }
    } else if (e) n && (e.value = e.value.replace(/^\s*/, "")), i && (i.value = i.value.replace(/^\s*/, ""));
    else if (n && i) {
        var h = i.value.match(/^\s*/)[0],
            u = t.value.match(/^\s*/)[0],
            f = t.value.match(/\s*$/)[0],
            d = po(h, u);
        t.value = Qe(t.value, d);
        var m = yo(Qe(h, d), f);
        t.value = Wi(t.value, m), i.value = As(i.value, h, m), n.value = Ts(n.value, h, h.slice(0, h.length - m.length))
    } else if (i) {
        var g = i.value.match(/^\s*/)[0],
            p = t.value.match(/\s*$/)[0],
            y = xo(p, g);
        t.value = Wi(t.value, y)
    } else if (n) {
        var b = n.value.match(/\s*$/)[0],
            v = t.value.match(/^\s*/)[0],
            w = xo(b, v);
        t.value = Qe(t.value, w)
    }
}
var Vm = new zt;
Vm.tokenize = function(n) {
    var t = new RegExp("(\\r?\\n)|[".concat(cn, "]+|[^\\S\\n\\r]+|[^").concat(cn, "]"), "ug");
    return n.match(t) || []
};
var yn = new zt;
yn.tokenize = function(n, t) {
    t.stripTrailingCr && (n = n.replace(/\r\n/g, `
`));
    var e = [],
        i = n.split(/(\n|\r\n)/);
    i[i.length - 1] || i.pop();
    for (var s = 0; s < i.length; s++) {
        var r = i[s];
        s % 2 && !t.newlineIsToken ? e[e.length - 1] += r : e.push(r)
    }
    return e
};
yn.equals = function(n, t, e) {
    return e.ignoreWhitespace ? ((!e.newlineIsToken || !n.includes(`
`)) && (n = n.trim()), (!e.newlineIsToken || !t.includes(`
`)) && (t = t.trim())) : e.ignoreNewlineAtEof && !e.newlineIsToken && (n.endsWith(`
`) && (n = n.slice(0, -1)), t.endsWith(`
`) && (t = t.slice(0, -1))), zt.prototype.equals.call(this, n, t, e)
};

function Fm(n, t, e) {
    return yn.diff(n, t, e)
}
var jm = new zt;
jm.tokenize = function(n) {
    return n.split(/(\S.+?[.!?])(?=\s+|$)/)
};
var Wm = new zt;
Wm.tokenize = function(n) {
    return n.split(/([{}:;,]|\s+)/)
};

function Es(n) {
    "@babel/helpers - typeof";
    return Es = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
        return typeof t
    } : function(t) {
        return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
    }, Es(n)
}
var bi = new zt;
bi.useLongestToken = !0;
bi.tokenize = yn.tokenize;
bi.castInput = function(n, t) {
    var e = t.undefinedReplacement,
        i = t.stringifyReplacer,
        s = i === void 0 ? function(r, o) {
            return typeof o > "u" ? e : o
        } : i;
    return typeof n == "string" ? n : JSON.stringify(Ds(n, null, null, s), s, "  ")
};
bi.equals = function(n, t, e) {
    return zt.prototype.equals.call(bi, n.replace(/,([\r\n])/g, "$1"), t.replace(/,([\r\n])/g, "$1"), e)
};

function Ds(n, t, e, i, s) {
    t = t || [], e = e || [], i && (n = i(s, n));
    var r;
    for (r = 0; r < t.length; r += 1)
        if (t[r] === n) return e[r];
    var o;
    if (Object.prototype.toString.call(n) === "[object Array]") {
        for (t.push(n), o = new Array(n.length), e.push(o), r = 0; r < n.length; r += 1) o[r] = Ds(n[r], t, e, i, s);
        return t.pop(), e.pop(), o
    }
    if (n && n.toJSON && (n = n.toJSON()), Es(n) === "object" && n !== null) {
        t.push(n), o = {}, e.push(o);
        var l = [],
            a;
        for (a in n) Object.prototype.hasOwnProperty.call(n, a) && l.push(a);
        for (l.sort(), r = 0; r < l.length; r += 1) a = l[r], o[a] = Ds(n[a], t, e, i, a);
        t.pop(), e.pop()
    } else o = n;
    return o
}
var Os = new zt;
Os.tokenize = function(n) {
    return n.slice()
};
Os.join = Os.removeEmpty = function(n) {
    return n
};
var Xi = (n => (n.ADDED = "added", n.REMOVED = "removed", n.UNCHANGED = "unchanged", n))(Xi || {});

function _s(n) {
    if (n === "") return 0;
    const t = n.split(`
`).length;
    return n.endsWith(`
`) ? t - 1 : t
}

function zm(n, t) {
    return Fm(n, t, {
        newlineIsToken: !0
    }).map(i => ({
        count: i.count ? ? _s(i.value),
        value: i.value,
        type: i.added ? "added" : i.removed ? "removed" : "unchanged"
    }))
}

function qm(n) {
    let t = "";
    for (const {
            type: e,
            value: i
        } of n)(e === "added" || e === "unchanged") && (t += i);
    return t
}

function _m(n, t) {
    const e = _s(t),
        i = Gm(n, e);
    return {
        changes: zm(i, t),
        numLinesDiffed: e
    }
}

function $m(n) {
    const t = [...n],
        e = [],
        i = [];
    for (; t.length > 0;) {
        const s = t[t.length - 1];
        if (s.type === Xi.REMOVED) t.pop(), s.type === Xi.REMOVED && e.unshift(s);
        else if (s.type === Xi.ADDED) t.pop(), i.unshift(s);
        else break
    }
    return {
        prunedChanges: [...t, ...i],
        prunedRemovedChanges: e
    }
}

function Um(n, t) {
    const {
        changes: e,
        numLinesDiffed: i
    } = _m(n, t), {
        prunedChanges: s,
        prunedRemovedChanges: r
    } = $m(e), o = qm(s), l = r.map(c => c.value).join(`
`), a = ga(n, i, "start");
    return {
        content: o + l + a,
        numLinesDiffed: _s(o)
    }
}

function Gm(n, t) {
    if (t <= 0) return "";
    let e = 0,
        i = n.length;
    for (let s = 0; s < n.length; s++)
        if (n[s] === `
` && (e++, e === t)) {
            i = s + 1;
            break
        }
    return n.substring(0, i)
}

function ga(n, t, e = "start") {
    if (t <= 0) return n;
    if (e === "start") {
        let o = 0;
        for (let l = 0; l < n.length; l++)
            if (n[l] === `
` && (o++, o === t)) return n.substring(l + 1);
        return ""
    }
    let i = 0,
        s = -1;
    const r = n.endsWith(`
`) ? t + 1 : t;
    for (let o = n.length - 1; o >= 0; o--)
        if (n[o] === `
` && (i++, i === r)) {
            s = o;
            break
        }
    return s === -1 ? "" : n.substring(0, s + 1)
}

function Km(n, t) {
    const e = n ? .type ? ? Pt.LOADING,
        i = n ? .content ? ? "",
        s = Po(n);
    if (!Ie(e) || t == null || !s || !Lo(n)) return {
        content: i,
        currentlyStreamingLineIndex: null
    };
    const r = ga(i, 1, "end");
    if (r === "") return {
        content: t.content,
        currentlyStreamingLineIndex: 0
    };
    const o = Um(t.content, r);
    return {
        content: o.content,
        currentlyStreamingLineIndex: o.numLinesDiffed
    }
}

function Ym(n, t) {
    const e = new Set(n.map(l => l.id)),
        i = new Set(t.map(l => l.id)),
        s = n.filter(l => !i.has(l.id)).map(l => ({ ...l,
            diffStatus: Vn.REMOVED
        })),
        r = t.filter(l => !e.has(l.id)).map(l => ({ ...l,
            diffStatus: Vn.ADDED
        })),
        o = n.filter(l => i.has(l.id));
    return s.concat(r, o)
}

function Xm({
    textdocVersion: n
}) {
    const t = vt(),
        e = Ga(),
        [i, s] = C.useState(!1),
        r = Ka(),
        o = C.useRef(n ? .content ? ? "");
    C.useEffect(() => {
        o.current = n ? .content ? ? ""
    }, [n]);
    const l = a => {
        i || (r(() => {
            kt.logButtonClick(Ae.COPY, {
                contentLength: o.current.length,
                textdocType: n ? .type
            }), Sh(o.current, e, a)
        }, 0), s(!0), r(() => s(!1), 2e3))
    };
    return x.jsx(me, {
        label: t.formatMessage(Jm.copy),
        children: x.jsx(Qi, {
            icon: i ? Tc : Ec,
            onClick: l
        })
    })
}
const Jm = be({
    copy: {
        id: "rbIYfo",
        defaultMessage: "Copy"
    }
});

function Qm({
    disabled: n = !1,
    isShowingChanges: t,
    onMouseEnter: e,
    onClick: i,
    onEsc: s
}) {
    const r = vt(),
        o = C.useRef(null);
    return C.useEffect(() => {
        if (t) {
            const l = a => {
                a.key === "Escape" && (s ? .(), o.current && o.current === document.activeElement && o.current.blur())
            };
            return window.document.addEventListener("keydown", l), () => {
                window.document.removeEventListener("keydown", l)
            }
        }
    }, [t, s]), x.jsx(me, {
        label: !n && r.formatMessage(t ? wo.hideChanges : wo.showChanges),
        children: x.jsx(Qi, {
            icon: Dc,
            ref: o,
            disabled: n,
            onClick: i,
            onMouseEnter: e,
            className: tt("transition-colors", t && lc)
        })
    })
}
const wo = be({
    showChanges: {
        id: "3jMGNS",
        defaultMessage: "Show changes"
    },
    hideChanges: {
        id: "HWiQSk",
        defaultMessage: "Hide changes"
    }
});

function Zm({
    disabled: n = !1,
    hasPreviousVersion: t,
    hasNextVersion: e,
    isShowingChanges: i,
    onHoverPrevious: s,
    onHoverShowChanges: r,
    onToggleShowChanges: o,
    onClickPrevious: l,
    onClickNext: a
}) {
    const c = Rs(),
        h = vt();
    return x.jsxs("div", {
        className: tt("flex items-center", c ? "gap-1" : "gap-1.5"),
        children: [x.jsx(Qm, {
            disabled: n || !t,
            isShowingChanges: i,
            onMouseEnter: r,
            onClick: o,
            onEsc: o
        }), x.jsx(me, {
            label: t && h.formatMessage({
                id: "PoD5+8",
                defaultMessage: "Previous version"
            }),
            children: x.jsx(Qi, {
                disabled: n || !t,
                icon: Oc,
                onMouseOver: s,
                onClick: l
            })
        }), x.jsx(me, {
            label: e && h.formatMessage({
                id: "PJ8YVJ",
                defaultMessage: "Next version"
            }),
            children: x.jsx(Qi, {
                disabled: n || !e,
                icon: Rc,
                onClick: a
            })
        })]
    })
}
const tg = ({
        isHistoricalVersion: n,
        textdocVersion: t,
        readonlyReason: e,
        hasDebug: i,
        isEmbedded: s,
        isPersisting: r,
        isShowingChanges: o,
        hideHistoryActions: l = !1,
        onHoverPrevious: a,
        onHoverShowChanges: c,
        onToggleShowChanges: h,
        onClickPrevious: u,
        onClickNext: f,
        setShowDebugView: d,
        onClickCodePreview: m,
        onClose: g,
        isShowingCodePreview: p
    }) => {
        const y = Rs(),
            b = kh(t ? .title ? ? ""),
            v = No(),
            w = Io();
        t == null || Ms(t.type, t.content) && v || qs(t.type);
        const S = tt("transition-opacity duration-500", e.isStreaming && "pointer-events-none opacity-0"),
            M = t ? .versionInt,
            D = M != null && M > 1,
            T = n,
            O = !l && (D || T);
        return x.jsxs(Te.Header, {
            className: "@container",
            children: [x.jsxs("div", {
                className: "flex flex-1 items-center gap-1 truncate leading-[0] @container",
                children: [!y && x.jsx(Te.CloseButton, {
                    onClick: g
                }), x.jsx(Te.Title, {
                    className: "@[0px]:hidden @[150px]:block",
                    children: b || x.jsx("div", {
                        className: "w-52",
                        children: x.jsx(Bc, {
                            lines: 1,
                            size: "base",
                            width: 100,
                            widthVariance: 0
                        })
                    })
                }), r && x.jsx(Ro, {
                    size: 12,
                    className: "pl-2 text-token-text-secondary"
                })]
            }), x.jsxs("div", {
                className: tt("flex select-none items-center leading-[0]", y ? "gap-1" : "gap-2"),
                children: [O && x.jsx("div", {
                    className: S,
                    children: x.jsx(Zm, {
                        disabled: e.isStreaming,
                        hasNextVersion: T,
                        hasPreviousVersion: D,
                        isShowingChanges: o,
                        onHoverPrevious: a,
                        onHoverShowChanges: c,
                        onToggleShowChanges: h,
                        onClickPrevious: u,
                        onClickNext: f
                    })
                }), x.jsx(Xm, {
                    textdocVersion: t
                }), !1, !1, !y && !s && x.jsx(Ic, {}), y && x.jsx(Te.CloseButton, {
                    onClick: g
                })]
            })]
        })
    },
    eg = /\s/,
    ig = 30;

function vo(n, t) {
    const e = n.indexOf(t);
    return e === -1 ? !1 : n.indexOf(t, e + t.length) === -1
}

function ne(n, t) {
    return eg.test(n[t])
}

function Co(n, t, e = !1) {
    if (t === 0 || e && ne(n, t - 1)) return t;
    for (; t > 0 && ne(n, t - 1);) t--;
    for (; t > 0 && !ne(n, t - 1);) t--;
    return ne(n, t) && t++, t
}

function So(n, t, e = !1) {
    if (t === n.length || e && ne(n, t)) return t;
    for (; t < n.length && ne(n, t);) t++;
    for (; t < n.length && !ne(n, t);) t++;
    return ne(n, t - 1) && t--, t
}

function ng(n, t, e = !0, i = ig) {
    if (n.start < 0 || n.end > t.length || n.start > n.end) throw new Error("Invalid commentSourceRange provided.");
    const s = t.substring(n.start, n.end);
    let r = n.start,
        o = n.end;
    e && (r = Co(t, r, !0), o = So(t, o, !0));
    let l = t.substring(r, n.start),
        a = t.substring(n.end, o),
        c = `${l}${s}${a}`;
    if (vo(t, c) && (i == null || c.length >= i)) return {
        before: l,
        after: a,
        allSurrounding: c
    };
    let h = r,
        u = o,
        f = !0;
    for (; f && (i == null || c.length < i);) {
        let d = !1;
        const m = h > 0 ? Co(t, h) : h;
        m < h && (h = m, d = !0);
        const g = u < t.length ? So(t, u) : u;
        if (g > u && (u = g, d = !0), d) {
            const p = t.substring(h, n.start),
                y = t.substring(n.end, u),
                b = `${p}${s}${y}`;
            if (vo(t, b) && (i == null || b.length >= i)) return {
                before: p,
                after: y,
                allSurrounding: b
            };
            l = p, a = y, c = b
        } else f = !1
    }
    return {
        before: l,
        after: a,
        allSurrounding: c
    }
}
const wi = "# Context",
    vi = "# Instructions";

function Ci(n, t, e) {
    if (t == null || e == null) return `The user is referring to the entire text of "${n}".`;
    const i = `
## Selected Text
The user has selected this text in "${n}" in particular:
${t}
`.trim();
    return e.allSurrounding === t ? i : `
${i}

## Surrounding Context
Here is the surrounding context:
${e.allSurrounding}
`.trim()
}

function pa(n, t) {
    return n == null || t == null ? "entire document" : n === t.allSurrounding ? "selected text" : "surrounding context"
}

function ya(n) {
    return `For the update pattern, create a regex which exactly matches the ${n}. Edit just this string in order to fullfill the user's request. NEVER rewrite the entire document. Instead, ALWAYS edit ONLY the ${n}. The only exception to this rule is if the ${n} includes markdown lists or tables. In that case, fully rewrite the document using ".*" as the regex update pattern.`.trim()
}

function sg(n, t, e, i) {
    if (!Ie(t) && e && i) {
        const s = pa(e, i);
        return `
${wi}
The user requests that you directly edit the document.

${Ci(n,e,i)}

${vi}
Use the update_textdoc tool to make this edit. ${ya(s)}`.trim()
    }
    return `
${wi}
The user requests that you directly edit the document.

${Ci(n,e,i)}

${vi}
Use the update_textdoc tool to make this edit. You MUST fully rewrite the entire document by using ".*" as the update regex pattern.`.trim()
}

function rg(n, t, e) {
    return `
${wi}
The user requests that you add comments about some text.

${Ci(n,t,e)}

${vi}
Do not respond to the user's question directly, just leave comments.`.trim()
}

function og(n, t) {
    return Ie(n) ? t === "entire document" ? ` If you choose to update the ${t}, you MUST fully rewrite the ${t} by using ".*" as the update regex pattern.` : ` If you choose to update the ${t}, you MUST fully rewrite the entire document by using ".*" as the update regex pattern. When you do so, ONLY modify the ${t} and rewrite other sections exactly as is, except for parts that must change based on this update` : t === "entire document" ? "" : ` If you choose to update the ${t}, follow these instructions: ${ya(t)}`
}

function lg(n, t, e, i) {
    const s = pa(e, i),
        r = og(t, s);
    return `
${wi}
${Ci(n,e,i)}

${vi}
The user would like you perform one of the following actions:
- Update the ${s} via the \`update_textdoc\` tool.${r}
- Explain the selected text via chat, or answer a general question about the selected text (no tool call required).
- Comment on the ${s} with feedback via the \`comment_textdoc\` tool. This should only be used if the user very explicitly asks for feedback, critique, or comments.

Based on the user's request, choose the appropriate action.
`.trim()
}

function ag(n, t, e) {
    return `
${wi}
${Ci(n,t,e)}

${vi}
The user would like you to create a new textdoc.
`.trim()
}

function hg(n, t, e, i = null, s = null) {
    switch (e) {
        case nt.ASK:
            return lg(n, t, i, s);
        case nt.CREATE_TEXTDOC:
            return ag(n, i, s);
        case nt.EDIT:
            return sg(n, t, i, s);
        case nt.COMMENT:
            return rg(n, i, s)
    }
}

function cg(n) {
    switch (n) {
        case ft.ACCELERATOR:
        case ft.CONSOLE:
        case ft.ACCEPT_COMMENT:
            return !0;
        case ft.ASK_CHATGPT:
        case ft.FULL_SCREEN_SUBMIT:
            return !1
    }
}

function ug(n, t) {
    switch (t) {
        case ft.ASK_CHATGPT:
        case ft.ACCEPT_COMMENT:
        case ft.FULL_SCREEN_SUBMIT:
            return n.formatMessage(dg.askChatGPT);
        case ft.ACCELERATOR:
        case ft.CONSOLE:
            return
    }
}
const fg = (n, t) => {
        const e = vt(),
            {
                tags: i
            } = Mh(n),
            s = Ah(),
            r = Th(n),
            o = Eh(n) ? ? s.id,
            l = Dh({
                clientThreadId: n
            });
        return C.useCallback(async ({
            content: a,
            sourceRange: c,
            action: h,
            userMessageType: u,
            acceleratorMetadata: f,
            selectionMetadata: d
        }) => {
            if (t ? .versionInt == null) return;
            const {
                textdocId: m,
                type: g,
                versionInt: p,
                content: y
            } = t;
            let b, v = null;
            c && c.start !== c.end && (b = y.slice(c.start, c.end), v = ng(c, y));
            const w = hg(m, g, h, b, v),
                M = Ya(w, {
                    exclude_after_next_user_message: !0
                }),
                D = performance.now(),
                T = await Xa(),
                [O, K, rt] = await Promise.all([Ja.getEnforcementToken(T), Oh.getEnforcementToken(T), Qa.getEnforcementToken(T)]),
                ot = new Rh,
                $ = er.getThreadCurrentLeafId(n),
                Z = `${$}-nextPrompt`;
            er.updateTree(n, et => {
                et.addNode(Z, a, $, Hn.User, void 0, {
                    canvas: {
                        textdoc_id: m,
                        textdoc_type: g,
                        version: p,
                        textdoc_content_length: y.length,
                        user_message_type: u,
                        accelerator_metadata: f,
                        selection_metadata: d
                    },
                    is_visually_hidden_from_conversation: cg(u),
                    targeted_reply: b,
                    targeted_reply_label: ug(e, u),
                    open_in_canvas_view: {
                        type: "canvas_textdoc",
                        id: m
                    }
                })
            }), l({
                model: o,
                completionType: Za.Next,
                parentNodeId: Z,
                metadata: {
                    eventSource: "mouse"
                },
                completionMetadata: r ? {
                    conversationMode: r
                } : void 0,
                chatReq: T,
                arkoseToken: O ? ? null,
                turnstileToken: K ? ? null,
                proofToken: rt ? ? null,
                preflightTime: performance.now() - D,
                appendMessages: [M],
                turnTracker: ot
            })
        }, [t, i, n, l, o, r, e])
    },
    dg = be({
        askChatGPT: {
            id: "h5ANdM",
            defaultMessage: "Asked ChatGPT"
        }
    });

function mg(n) {
    const t = /\[([^\]]+)\]\((https?:\/\/[^\s)]+|www\.[^\s)]+)\)/gi,
        e = new Set,
        i = n.matchAll(t);
    for (const s of i) {
        const r = s[2];
        try {
            let o = r;
            o.startsWith("www.") && (o = "http://" + r), new URL(o), e.add(r)
        } catch {}
    }
    return e
}
const gg = async ({
        lastVersion: n,
        textdocId: t,
        content: e,
        comments: i
    }) => {
        const s = Ph(i, e);
        return (await To.safePost("/textdoc/{textdoc_id}", {
            parameters: {
                path: {
                    textdoc_id: t
                }
            },
            requestBody: {
                version: n,
                content: e,
                comments: s
            }
        })).version
    },
    pg = () => {
        const n = C.useRef([]),
            t = C.useRef(null),
            {
                mutateAsync: e,
                isPending: i
            } = th({
                mutationKey: ["canvas", "textdoc", "persist"],
                mutationFn: gg
            });
        return [C.useCallback(async (r, o, l) => {
            const a = new AbortController,
                h = (async () => {
                    const [m] = n.current;
                    try {
                        await m ? .promise
                    } catch (g) {
                        kt.logError("Saving document", g)
                    }
                    if (!a.signal.aborted) try {
                        const g = Math.max(t.current ? ? 0, r.versionInt ? ? Bo);
                        let p = "";
                        try {
                            ir(o) ? p = o() : p = o
                        } catch (w) {
                            kt.logError("Serializing document", w)
                        }
                        let y = [];
                        try {
                            ir(l) ? y = l() : y = l
                        } catch (w) {
                            kt.logError("Adjusting comments", w)
                        }
                        const {
                            textdocId: b
                        } = r;
                        Lh({
                            textdocId: b,
                            basedOnVersionInt: g,
                            content: p,
                            comments: y
                        });
                        const v = await e({
                            textdocId: b,
                            lastVersion: g,
                            content: p,
                            comments: y
                        });
                        Nh({
                            textdocId: b,
                            basedOnVersionInt: g,
                            newVersion: v
                        }), t.current = v
                    } catch (g) {
                        kt.logError("Error saving document", g)
                    } finally {
                        n.current.shift()
                    }
                })(),
                u = {
                    abort: () => a.abort(),
                    promise: h
                },
                [f, d] = n.current;
            return d && (d.abort(), n.current = f ? [f] : []), n.current = f ? [f, u] : [u], h
        }, [e]), n, i]
    },
    yg = 3e3,
    xg = n => {
        const [t, e, i] = pg(), s = vt(), r = C.useRef(null), o = C.useCallback(Ih(t, yg, {
            leading: !1
        }), [t]), l = Bh(n);
        return C.useEffect(() => {
            if (!l) return;
            const c = Bn(window, {
                    pagehide: () => o.flush(),
                    beforeunload: u => {
                        o.flush(), u.returnValue = s.formatMessage({
                            id: "QZrKwi",
                            defaultMessage: "You have a canvas save in progress."
                        })
                    }
                }),
                h = Bn(document, {
                    visibilitychange: () => o.flush(),
                    keydown: () => {
                        r.current = "keyboard"
                    },
                    mousemove: () => {
                        r.current !== "mouse" && o.flush(), r.current = "mouse"
                    }
                });
            return () => {
                r.current = null, h(), c()
            }
        }, [s, l, o]), C.useEffect(() => () => {
            o.flush()
        }, [n, o]), Hh(async () => {
            await o.flush(), await Promise.allSettled(e.current ? .map(({
                promise: c
            }) => c) ? ? [])
        }), [C.useCallback((c, h, u) => {
            const {
                textdocId: f
            } = c;
            return Vh(f), o(c, h, u)
        }, [o]), o.flush, i || l]
    };

function bg(n, t, e) {
    const i = Eo(),
        s = e != null && t != null,
        {
            data: r,
            error: o,
            fetchNextPage: l,
            hasNextPage: a,
            isFetching: c
        } = eh(ko(n, t, s)),
        h = C.useCallback(async () => {
            const g = t != null;
            await i.prefetchInfiniteQuery(ko(n, t, g))
        }, [i, n, t]);
    C.useEffect(() => {
        const g = t;
        return () => {
            i.removeQueries({
                queryKey: xa(n, g),
                exact: !0
            })
        }
    }, [i, n, t]);
    const [u, f, d, m] = C.useMemo(() => {
        if (r && e) {
            const p = r.pages.flatMap(b => b),
                y = p.findIndex(b => "beforeVersion" in e ? (b.versionInt ? ? Bo) < e.beforeVersion : b.versionInt === e.version);
            if (y !== -1) return [y === p.length - 1, p[y], y > 0 ? p[y - 1] : null, y < p.length - 1 ? p[y + 1] : null]
        }
        const g = r ? .pages.flatMap(p => p) ? ? [];
        return [!0, null, null, g.length === 0 ? null : g[0]]
    }, [r, e]);
    return C.useEffect(() => {
        !c && s && a && u && l()
    }, [c, s, a, u, l]), C.useEffect(() => {
        !f && o && Ze(n)
    }, [f, o, n]), {
        historicalTextdocVersion: f,
        nextHistoricalTextdocVersion: d,
        prefetchHistoricalTextdocVersion: h,
        previousHistoricalTextdocVersion: m
    }
}

function xa(n, t = null) {
    return ["textdocHistory", n, t]
}

function ko(n, t, e = !0) {
    return {
        queryKey: xa(n, t),
        queryFn: ({
            pageParam: i
        }) => wg(n, i),
        initialPageParam: t ? ? void 0,
        getNextPageParam: i => {
            const s = ih(i) ? .versionInt;
            if (s && s > 1) return s
        },
        enabled: e,
        staleTime: 1 / 0,
        retry: 2
    }
}
async function wg(n, t) {
    return t === void 0 ? [] : (await To.safeGet("/textdoc/{textdoc_id}/history", {
        parameters: {
            path: {
                textdoc_id: n
            },
            query: {
                before_version: t
            }
        }
    })).previous_doc_states.map(({
        id: i,
        version: s,
        textdoc_type: r,
        title: o,
        content: l,
        updated_at: a,
        comments: c
    }) => ({
        textdocId: i,
        versionInt: s,
        messageId: null,
        title: o,
        type: Fh(r),
        content: l,
        status: jh.COMPLETE,
        createdAt: Wh(a),
        comments: zh(c, l)
    }))
}
const tp = ({
    isFullScreen: n = !1,
    isEmbedded: t = !1,
    hideHeader: e = !1,
    isReadonlyFromQueryParam: i = !1,
    clientThreadId: s,
    focusedTextdoc: r,
    onClose: o,
    isAnimating: l = !1,
    width: a,
    hideBottomComposer: c = !1
}) => {
    const {
        textdocId: h,
        history: u,
        showChangesAtVersion: f = null
    } = r, d = No(), [m, g, p] = xg(h), {
        targetedContent: y
    } = qh(), b = _h(), [v, w] = C.useState(!1), S = $h(h), M = Uh(), D = nh(s), T = sh(D), {
        data: O,
        isLoading: K
    } = Gh(h, f), [rt, ot] = C.useState(!1), $ = S ? .versions ? ? [], Z = $[0] ? .versionInt, {
        historicalTextdocVersion: et,
        nextHistoricalTextdocVersion: xt,
        previousHistoricalTextdocVersion: R,
        prefetchHistoricalTextdocVersion: Bt
    } = bg(h, Z, u), _ = Kh();
    C.useEffect(() => {
        ge.reset()
    }, [h]);
    const Y = $.length > 0 ? $[$.length - 1] : null,
        qt = $.length > 1 ? $[$.length - 2] : null,
        oe = rh(s),
        {
            restoreHistoricalTextdocVersion: we,
            optimisticRestoredTextdocVersion: Et
        } = Yh(oe, Y, et),
        _t = u != null,
        H = _t ? et : Y,
        lt = f != null,
        ve = fg(s, H),
        _e = l ? null : O,
        le = (() => {
            if (l || H == null) return [];
            const W = ho(H.comments);
            return !lt && et != null ? et.comments : !lt || O == null ? W : O.contentBefore !== O.contentAfter ? [] : Ym(O.commentsBefore, O.commentsAfter)
        })(),
        ut = H ? .type ? ? Pt.LOADING,
        Ai = Xh(),
        ae = Po(H),
        I = Lo(H),
        gt = Jh(H),
        Ct = Vc(M);
    C.useEffect(() => {
        $.length === 0 && !M && Ct && o ? .()
    }, [$.length, M]);
    const {
        content: St,
        currentlyStreamingLineIndex: Dt
    } = O ? .contentBefore != null && !Ie(ut) ? {
        content: O.contentBefore,
        currentlyStreamingLineIndex: null
    } : Km(H, qt), he = Hc(oe, Array.from(mg(St))), [Jt, $e] = Ud({
        value: St,
        isRequestActive: T,
        isTextdocStreaming: ae,
        comments: le
    }), $s = Qh(H);
    C.useEffect(() => {
        h && nr().sendMessage({
            type: Fn.Loaded
        })
    }, [h]);
    const Us = Ai === Zh.LAST_TURN || Jt || p;
    C.useEffect(() => {
        nr().sendMessage({
            type: Fn.Streaming,
            streaming: Us
        })
    }, [Us]);
    const ba = ({
            getSerializedDocument: W,
            getAdjustedComments: pt
        }) => {
            H && m(H, W, pt)
        },
        wa = W => {
            if (!H) return;
            const pt = W.doc.toString();
            m(H, pt, W.field(on, !1) ? ? [])
        },
        Gs = (W, pt, Qt, Ce) => {
            $e(!0), ve({
                action: pt,
                content: W,
                userMessageType: ft.ASK_CHATGPT,
                sourceRange: Qt,
                selectionMetadata: {
                    selection_type: Ce,
                    selection_position_range: Qt
                }
            })
        },
        Ks = ({
            id: W
        }) => {
            $s(W, sr.DISMISS), ge.reset()
        },
        Ys = async W => {
            $e(!0);
            const {
                id: pt,
                at: Qt,
                content: Ce
            } = W;
            if (await $s(pt, sr.ACCEPT) === !1) return $e(!1);
            ve({
                content: Ce,
                userMessageType: ft.ACCEPT_COMMENT,
                sourceRange: Qt,
                action: nt.EDIT,
                selectionMetadata: {
                    selection_type: Wn.SELECTION,
                    selection_position_range: Qt
                }
            })
        },
        bn = (W, pt, Qt) => {
            const {
                action: Ce
            } = Qt;
            ve({
                action: Ce,
                content: pt,
                sourceRange: W,
                userMessageType: ft.ACCELERATOR,
                acceleratorMetadata: {
                    action: Ce,
                    id: Qt.id,
                    prompt: pt
                },
                selectionMetadata: W != null ? {
                    selection_type: Wn.SELECTION,
                    selection_position_range: W
                } : void 0
            })
        },
        va = W => {
            ve({
                action: nt.EDIT,
                content: W,
                userMessageType: ft.FULL_SCREEN_SUBMIT
            })
        },
        Ca = oh(),
        Sa = Eo(),
        ka = tc(),
        Xs = W => ka ? .[W] ? ? W,
        wn = () => ic({
            clientThreadId: s,
            currentRequestId: D,
            queryClient: Sa,
            isHistoryAndTrainingDisabled: Ca
        }),
        Ma = () => {
            u ? Ei(h, u) : Ze(h)
        },
        Ot = cc({
            isRestoring: Et != null,
            isStreaming: T || ae,
            isReadonlyFromQueryParam: i,
            isHistoricalVersion: _t,
            isShowingChanges: lt
        });
    let Ue = null;
    const Js = l || Ot.isReadonly || Jt,
        Qs = () => l && le.length > 0 ? Ke.ALL_HIDDEN : Ot.isReadonly ? Ot.isStreaming ? Ke.ENABLED : Ot.isReadonlyFromQueryParam || Ot.isShowingChanges || Ot.isHistoricalVersion ? Ke.COMMENTS_READONLY : Ke.ALL_HIDDEN : Ke.ENABLED,
        Zs = n || l || i;
    let vn = [];
    switch (ut) {
        case Pt.LOADING:
            Ue = x.jsx(uc, {});
            break;
        case Pt.DOCUMENT:
            Ue = x.jsx(hc, {
                value: St,
                comments: le,
                previousValue: qt ? .content,
                previousComments: ho(qt ? .comments),
                isRewriting: I,
                isAnimatingFromPreview: l,
                getStableCommentId: Xs,
                diff: _e,
                isRequestActive: T,
                isDisabled: Ot.isReadonly || M,
                isWaitingForCommentResponse: Jt,
                hideAccelerators: Zs,
                hideToolbar: Js,
                hideEditOverlay: l,
                commentsMode: Qs(),
                readonlyReason: Ot,
                onBlur: g,
                onSave: g,
                onChange: ba,
                onCancelRequest: wn,
                targetedContent: y,
                onAddComment: Gs,
                onAcceptComment: Ys,
                onDismissComment: Ks,
                onSubmitAccelerator: bn,
                onExitShowChanges: Ma,
                safeUrls: he,
                width: a,
                modelCursor: ae && !I ? H ? .modelCursor : void 0,
                shouldResetSelection: H ? .versionInt === 1
            }), vn = lm;
            break;
        default:
            if (Ie(ut)) {
                const W = Ms(ut, St),
                    pt = x.jsx(ac, {
                        id: "codemirror",
                        getStableCommentId: Xs,
                        language: Ho(ut),
                        value: St,
                        comments: le,
                        hideAccelerators: Zs,
                        commentsMode: Qs(),
                        hideToolbar: Js,
                        onSubmitAccelerator: bn,
                        currentlyStreamingLineIndex: Dt ? ? null,
                        readonlyReason: Ot,
                        isRequestActive: T,
                        isWaitingForCommentResponse: Jt,
                        onChange: wa,
                        onCancelRequest: wn,
                        onAddComment: Gs,
                        onDismissComment: Ks,
                        onAcceptComment: Ys,
                        textdocDiff: _e ? ? void 0,
                        modelCursor: ae && Dt == null ? H ? .modelCursor : void 0
                    });
                Ue = !d || !W ? pt : x.jsxs(x.Fragment, {
                    children: [x.jsx("div", {
                        style: {
                            display: rt ? "none" : "block"
                        },
                        children: pt
                    }), !1]
                }), vn = zd
            }
    }
    const Aa = C.useRef(null);
    Io() && !_t && qs(ut);
    const Ta = () => {
            Ms(ut, St) ? ot(W => !W) : Aa.current ? .runCode(ut, St)
        },
        {
            eligible: Ea,
            markAsViewed: Da
        } = ec(),
        tr = Rs(),
        Rt = H ? .versionInt,
        Oa = Rt != null && Rt > 1,
        Ra = _t,
        Ti = R ? .versionInt,
        Cn = xt ? .versionInt,
        Pa = () => {
            lt ? u ? Ei(h, u) : Ze(h) : (kt.logButtonClick(Ae.SHOW_CHANGES, {
                textdocType: ut,
                textdocId: h,
                versionInt: Rt,
                latestVersionInt: Z
            }), Rt && rr(h, Rt, u))
        },
        La = () => {
            kt.logButtonClick(Ae.HISTORY_PREVIOUS, {
                textdocType: ut,
                textdocId: h,
                versionInt: Rt,
                latestVersionInt: Z,
                isShowingChanges: lt
            }), h && Rt && Oa && Ei(h, {
                beforeVersion: Rt
            }, lt && Ti != null ? Ti : void 0)
        },
        Na = () => {
            kt.logButtonClick(Ae.HISTORY_NEXT, {
                textdocType: ut,
                textdocId: h,
                versionInt: Rt,
                latestVersionInt: Z,
                isShowingChanges: lt
            }), Ra && (Cn ? Ei(h, {
                version: Cn
            }, lt ? Cn : void 0) : lt && Z ? rr(h, Z, null) : Ze(h))
        },
        Sn = !e && x.jsx(tg, {
            isHistoricalVersion: _t,
            textdocVersion: H,
            readonlyReason: Ot,
            hasDebug: b,
            isEmbedded: t,
            isPersisting: p,
            isShowingChanges: lt,
            hideHistoryActions: i,
            onHoverPrevious: () => {
                Bt(), Ti && _(h, Ti)
            },
            onHoverShowChanges: () => {
                Bt(), Rt && _(h, Rt)
            },
            onToggleShowChanges: Pa,
            onClickPrevious: La,
            onClickNext: Na,
            setShowDebugView: w,
            onClose: () => {
                kt.logButtonClick(Ae.CLOSE_TEXTDOC, {
                    textdocType: H ? .type
                }), Da(), o ? .()
            },
            onClickCodePreview: Ta,
            isShowingCodePreview: rt
        });
    return x.jsxs(Te, {
        children: [!tr && Sn, x.jsx(Te.Content, {
            scrollToBottomMode: gt ? "bottom" : "top",
            shouldScrollToTop: I,
            isLoading: K,
            children: tr && Sn ? x.jsxs(x.Fragment, {
                children: [Sn, x.jsx("div", {
                    className: "h-[calc(100%-var(--screen-thread-header-min-height,60px))]",
                    children: Ue
                })]
            }) : Ue
        }), !1, x.jsx(Ji, {
            children: _t && !i && x.jsx(Gd, {
                onClickRestore: we,
                onClickResetLatest: () => Ze(h)
            })
        }), n && !_t && !c && x.jsx(Im, {
            isRequestActive: T,
            clientThreadId: s,
            onSubmitAccelerator: bn,
            onSubmit: va,
            onCancel: wn,
            readonlyReason: Ot,
            acceleratorActions: vn
        }), !l && !t && Ea && x.jsx(_c, {
            textdocType: ut
        })]
    })
};
export {
    pm as $, ze as A, _d as B, Fn as C, B as D, P as E, E as F, re as G, qd as H, Wg as I, $g as J, Ug as K, dn as L, wt as M, Ld as N, Ig as O, Ns as P, la as Q, L as R, Tt as S, tp as T, Nd as U, Nt as V, qe as W, Id as X, dm as Y, mm as Z, gm as _, A as a, Xg as a0, Jg as a1, eu as a2, Om as a3, zd as a4, wm as a5, Wn as a6, ge as a7, fm as a8, Yg as a9, Gg as aa, hn as ab, $c as ac, tu as ad, Zc as ae, bm as af, Zg as ag, nt as ah, hm as ai, Vg as aj, cm as ak, am as al, Kg as am, ym as an, xm as ao, Qg as ap, um as aq, lm as ar, Q as b, q as c, G as d, Is as e, bu as f, qg as g, Ve as h, di as i, zn as j, ri as k, Ut as l, $t as m, N as n, ct as o, Xf as p, He as q, Bg as r, zg as s, kd as t, it as u, Gt as v, Wt as w, Fg as x, jg as y, _g as z
};
//# sourceMappingURL=c3g58ox462qsyhe4.js.map