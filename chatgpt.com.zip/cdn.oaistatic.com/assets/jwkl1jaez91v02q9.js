import {
    r as t
} from "./hbhpmx2ipkndwudc.js";
const o = r => {
    const e = t.useRef(void 0);
    return t.useEffect(() => {
        e.current = r
    }, [r]), e.current
};
export {
    o as u
};
//# sourceMappingURL=jwkl1jaez91v02q9.js.map