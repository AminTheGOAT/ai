import {
    r
} from "./hbhpmx2ipkndwudc.js";
var a = r.useLayoutEffect;
export {
    a as i
};
//# sourceMappingURL=ecsmtmpgv59no4oe.js.map