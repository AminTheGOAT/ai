const t = "https://help.openai.com/en/articles/8096356-custom-instructions-for-chatgpt",
    a = "https://help.openai.com/en/articles/7967234-enabling-multi-factor-authentication-mfa-with-openai#h_488a963a1e";
export {
    t as H, a as M
};
//# sourceMappingURL=g4tl5lt9yqf20m4s.js.map