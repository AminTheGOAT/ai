import {
    a$ as a,
    m as e,
    fr as s
} from "./hbhpmx2ipkndwudc.js";
import {
    P as n
} from "./m7u5z7sua6e1c9ci.js";
import {
    j as o
} from "./ab2oz9enzsoo3wow.js";

function m() {
    const {
        isUnauthenticated: r
    } = a(), {
        clientThreadId: t
    } = o();
    return r ? null : e.jsx("div", {
        className: s.profileInContent,
        style: {
            viewTransitionName: "var(--vt-profile-avatar-thread)"
        },
        children: e.jsx(n, {
            clientThreadId: t
        })
    })
}
export {
    m as C
};
//# sourceMappingURL=nqxrsem62j81khrd.js.map